import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';
import { registerSW } from 'virtual:pwa-register';

// Register PWA service worker with auto-update for offline persistence
registerSW({
  immediate: true,
  onNeedRefresh() {
    console.log('New content available, auto-updating service worker...');
  },
  onOfflineReady() {
    console.log('IMRUU Grocery Shop is ready to work offline as a permanent app.');
  },
});

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
