import React from 'react';
import { useStore, TabKey } from '../context/StoreContext';
import { useTranslation } from '../i18n/LanguageContext';
import { TranslationKey } from '../i18n/translations';
import { LanguageToggle } from './LanguageToggle';
import { money, todayLabel } from '../utils/helpers';
import {
  Search,
  Info,
  ShoppingCart,
  TrendingUp,
  Sparkles,
  Building2,
  User,
  UserCheck,
  Settings,
  ShieldCheck,
  LayoutDashboard,
  Receipt,
  Package,
  Truck,
  Wallet,
  BarChart3,
  History,
  Factory,
  Users,
  PanelLeftClose,
  PanelLeftOpen,
  Command,
  Coins,
  DollarSign,
} from 'lucide-react';
import { PWAInstallButton } from './PWAInstallButton';
import { VoiceAssistant } from './VoiceAssistant';

interface HeaderProps {
  isSidebarCollapsed?: boolean;
  onToggleSidebar?: () => void;
}

const TAB_ICONS: Record<TabKey, React.FC<{ className?: string }>> = {
  dashboard: LayoutDashboard,
  pos: Receipt,
  inventory: Package,
  pricing: TrendingUp,
  purchases: Factory,
  customers: Users,
  distribution: Truck,
  finance: Wallet,
  reports: BarChart3,
  activity: History,
  enterprise: Building2,
};

export const Header: React.FC<HeaderProps> = ({
  isSidebarCollapsed = false,
  onToggleSidebar,
}) => {
  const {
    db,
    totals,
    activeTab,
    setActiveTab,
    setIsSearchOpen,
    setIsBusinessInfoOpen,
    setIsCeoProfileModalOpen,
    setIsTaxModalOpen,
    taxSettings,
    businessProfile,
    availableUsers,
    currentUser,
    cart,
  } = useStore();

  const { t } = useTranslation();

  const ceoUser =
    availableUsers.find((u) => u.id === currentUser?.id) ||
    availableUsers.find((u) => u.role.toLowerCase().includes('ceo')) ||
    availableUsers[0];

  const missionTarget = businessProfile.missionTarget || db.target || 1000000;
  const missionPct = Math.min(100, Math.max(0, (totals.value / missionTarget) * 100));

  // Today's total sales
  const todayStr = todayLabel();
  const todaySalesTotal = (db.sales || [])
    .filter((s) => s.date === todayStr)
    .reduce((acc, s) => acc + s.total, 0);

  const currentTabMeta = React.useMemo(() => {
    switch (activeTab) {
      case 'dashboard':
        return { title: t('ceoCommandCenter'), category: t('executiveSuite') };
      case 'pos':
        return { title: t('posTitle'), category: t('retailWholesale') };
      case 'inventory':
        return { title: t('inventoryTitle'), category: t('catalogRestock') };
      case 'pricing':
        return { title: t('navPricing'), category: t('marketIntelligence') };
      case 'purchases':
        return { title: t('navPurchases'), category: t('vendorManagement') };
      case 'customers':
        return { title: t('navCustomers'), category: t('receivablesLedger') };
      case 'distribution':
        return { title: t('navDistribution'), category: t('routeLogistics') };
      case 'finance':
        return { title: t('navFinance'), category: t('treasuryAccounts') };
      case 'reports':
        return { title: t('navReports'), category: t('financialReporting') };
      case 'activity':
        return { title: t('navActivity'), category: t('systemGovernance') };
      case 'enterprise':
        return { title: t('navEnterprise'), category: t('milestonesFacilities') };
      default:
        return { title: t('ceoCommandCenter'), category: t('executiveSuite') };
    }
  }, [activeTab, t]);

  const TabIcon = TAB_ICONS[activeTab] || LayoutDashboard;

  return (
    <header className="sticky top-0 z-30 text-white bg-gradient-to-r from-[#03170f] via-[#064229] to-[#085a37] shadow-xl border-b border-emerald-900/40">
      {/* DESKTOP APP BAR (Visible on lg+) */}
      <div className="hidden lg:flex items-center justify-between px-6 py-2.5 max-w-[1680px] mx-auto w-full gap-4">
        {/* Left: Sidebar Toggle + Module Breadcrumb */}
        <div className="flex items-center gap-3 shrink-0 min-w-0">
          {onToggleSidebar && (
            <button
              onClick={onToggleSidebar}
              className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-emerald-200 hover:text-white transition-colors border border-white/10 shrink-0"
              title={isSidebarCollapsed ? 'Expand Sidebar (Ctrl + B)' : 'Collapse Sidebar (Ctrl + B)'}
            >
              {isSidebarCollapsed ? (
                <PanelLeftOpen className="w-4 h-4" />
              ) : (
                <PanelLeftClose className="w-4 h-4" />
              )}
            </button>
          )}

          <div className="flex items-center gap-2.5">
            <div className="p-1.5 rounded-xl bg-emerald-500/25 text-emerald-300 border border-emerald-400/30 shrink-0">
              <TabIcon className="w-4 h-4" />
            </div>
            <div className="min-w-0">
              <div className="flex items-center gap-1.5 text-[10px] text-emerald-300/80 font-bold uppercase tracking-wider">
                <span>{businessProfile.storeName || 'BARWAAQO'}</span>
                <span>/</span>
                <span>{currentTabMeta.category}</span>
              </div>
              <h1 className="text-sm xl:text-base font-extrabold text-white tracking-tight truncate leading-none">
                {currentTabMeta.title}
              </h1>
            </div>
          </div>
        </div>

        {/* Center: Global Search & Financial Ticker */}
        <div className="flex-1 max-w-xl flex items-center gap-3">
          <button
            onClick={() => setIsSearchOpen(true)}
            className="flex-1 flex items-center justify-between px-3.5 py-1.5 rounded-xl bg-black/30 hover:bg-black/40 text-emerald-100 text-xs border border-white/15 transition-all shadow-inner group"
            title="Global Search (Press / or Ctrl+K)"
          >
            <div className="flex items-center gap-2 text-slate-300 group-hover:text-white transition-colors">
              <Search className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
              <span className="truncate">{t('searchPlaceholder')}</span>
            </div>
            <kbd className="inline-flex items-center gap-0.5 text-[10px] font-mono text-emerald-300 bg-white/10 px-1.5 py-0.5 rounded border border-white/10 shrink-0">
              <Command className="w-2.5 h-2.5" /> K
            </kbd>
          </button>

          {/* Desktop Financial Ticker Pills */}
          <div className="hidden xl:flex items-center gap-2 shrink-0">
            <div
              className="px-2.5 py-1 rounded-xl bg-emerald-950/70 border border-emerald-500/30 text-left"
              title="Today's Recorded Sales"
            >
              <span className="block text-[8.5px] uppercase font-bold text-emerald-300 tracking-wider">
                {t('todaySales')}
              </span>
              <span className="block text-xs font-mono font-black text-white leading-tight">
                {money(todaySalesTotal)}
              </span>
            </div>

            <div
              className="px-2.5 py-1 rounded-xl bg-emerald-950/70 border border-emerald-500/30 text-left"
              title="Total Cash on Hand (Till + Accounts)"
            >
              <span className="block text-[8.5px] uppercase font-bold text-amber-300 tracking-wider">
                {t('cashInTill')}
              </span>
              <span className="block text-xs font-mono font-black text-amber-200 leading-tight">
                {money(totals.cash || db.accounts?.Cash || 0)}
              </span>
            </div>
          </div>
        </div>

        {/* Right: Desktop Actions & User Profile */}
        <div className="flex items-center gap-2 shrink-0">
          <LanguageToggle variant="dropdown" className="bg-white/10 border-white/15" />

          <VoiceAssistant />

          <button
            onClick={() => setIsTaxModalOpen(true)}
            className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-emerald-100 border border-white/15 transition-all shadow-xs"
            title="Configure Multi-Tier Statutory Tax System"
          >
            <ShieldCheck className="w-3.5 h-3.5 text-amber-300" />
            <span className="hidden xl:inline text-[11px]">{taxSettings.taxLabel}</span>
          </button>

          <PWAInstallButton variant="header" />

          {/* CEO User Profile */}
          <button
            id="desktop-header-ceo-btn"
            onClick={() => setIsCeoProfileModalOpen(true)}
            className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-emerald-100 border border-white/15 transition-all shadow-xs group"
            title="CEO Identity, Employee & PIN Settings"
          >
            <div className="w-5 h-5 rounded-lg bg-amber-400 text-amber-950 font-black text-[10px] flex items-center justify-center shadow-xs">
              {ceoUser?.name?.charAt(0) || 'C'}
            </div>
            <span className="text-xs text-white font-bold max-w-[90px] truncate hidden xl:inline">
              {ceoUser?.name || 'Aimraan'}
            </span>
            <Settings className="w-3.5 h-3.5 text-emerald-300 group-hover:text-amber-300 transition-colors" />
          </button>

          {/* POS Cart shortcut */}
          <button
            id="desktop-header-pos-btn"
            onClick={() => setActiveTab('pos')}
            className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-extrabold transition-all shadow-sm ${
              activeTab === 'pos'
                ? 'bg-amber-400 text-amber-950 ring-2 ring-amber-300/60'
                : 'bg-emerald-500 hover:bg-emerald-400 text-emerald-950'
            }`}
          >
            <ShoppingCart className="w-3.5 h-3.5" />
            <span>POS</span>
            {cart.length > 0 && (
              <span className="absolute -top-1.5 -right-1.5 bg-rose-600 text-white font-black text-[10px] px-1.5 py-0.2 rounded-full ring-2 ring-emerald-950 shadow">
                {cart.reduce((a, x) => a + x.qty, 0)}
              </span>
            )}
          </button>
        </div>
      </div>

      {/* MOBILE APP BAR (Visible on screens < lg) */}
      <div className="lg:hidden max-w-6xl mx-auto px-4 py-3 sm:px-6">
        <div className="flex items-center justify-between gap-3">
          {/* Brand & Logo */}
          <div
            id="brand-header"
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="relative">
              <img
                src="/logo.png"
                alt="BARWAAQO"
                className="w-10 h-10 rounded-2xl object-cover shadow-xl ring-2 ring-amber-400/50 group-hover:scale-105 transition-transform"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <span className="absolute -bottom-1 -right-1 flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500 border border-emerald-950"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-black text-base sm:text-lg tracking-wider text-white drop-shadow-sm uppercase">
                  {businessProfile.storeName || 'BARWAAQO'}
                </span>
                <span className="text-[10px] uppercase font-black px-2 py-0.5 rounded-full bg-gradient-to-r from-amber-400 to-amber-500 text-amber-950 shadow-xs border border-amber-300/40">
                  BUSINESS OS
                </span>
              </div>
              <p className="text-[10.5px] text-emerald-200/90 font-medium tracking-tight">
                CEO COMMAND CENTER
              </p>
            </div>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-1.5 sm:gap-2">
            <LanguageToggle variant="dropdown" className="bg-white/10 border-white/15" />
            <VoiceAssistant />
            <PWAInstallButton variant="header" />

            {/* CEO Profile Pill / Quick Edit Button */}
            <button
              id="header-ceo-profile-btn"
              onClick={() => setIsCeoProfileModalOpen(true)}
              className="flex items-center gap-2 px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-xs font-semibold text-emerald-100 border border-white/15 transition-all active:scale-95 group shadow-xs"
              title="CEO Identity & Employee Settings"
            >
              <div className="w-6 h-6 rounded-lg bg-amber-400 text-amber-950 font-black text-xs flex items-center justify-center shadow-xs">
                {ceoUser?.name?.charAt(0) || 'C'}
              </div>
              <div className="text-left hidden sm:block">
                <div className="flex items-center gap-1">
                  <span className="font-extrabold text-xs text-white block leading-tight">
                    {ceoUser?.name || businessProfile.ceoName || 'Aimraan'}
                  </span>
                  <span className="text-[8px] font-black uppercase px-1 py-0.2 rounded bg-amber-400 text-amber-950">
                    CEO
                  </span>
                </div>
              </div>
              <Settings className="w-3.5 h-3.5 text-amber-300 ml-0.5" />
            </button>

            <button
              id="header-search-btn"
              onClick={() => setIsSearchOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-emerald-100 border border-white/15 transition-all active:scale-95"
              title="Global Search"
            >
              <Search className="w-3.5 h-3.5 text-emerald-300" />
            </button>

            {/* Quick POS jump / Cart badge */}
            <button
              id="header-pos-shortcut"
              onClick={() => setActiveTab('pos')}
              className={`relative flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition-all active:scale-95 ${
                activeTab === 'pos'
                  ? 'bg-emerald-400 text-emerald-950 shadow-md'
                  : 'bg-emerald-600/60 hover:bg-emerald-600 text-white border border-emerald-400/30'
              }`}
            >
              <ShoppingCart className="w-3.5 h-3.5" />
              <span>POS</span>
              {cart.length > 0 && (
                <span className="absolute -top-1.5 -right-1.5 bg-amber-400 text-amber-950 font-black text-[10px] px-1.5 py-0.2 rounded-full ring-2 ring-emerald-900 shadow">
                  {cart.reduce((a, x) => a + x.qty, 0)}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Mission Progress Bar: ETB 200K -> 1M */}
        <div className="mt-2.5 pt-2 border-t border-emerald-500/20">
          <div className="flex justify-between items-center text-[10.5px] mb-1">
            <div className="flex items-center gap-1.5 text-emerald-200">
              <TrendingUp className="w-3 h-3 text-emerald-300" />
              <span className="font-bold tracking-wider uppercase text-[9.5px] text-emerald-300">
                {t('missionGoal')}
              </span>
              <span className="text-white/60">·</span>
              <span className="text-white/90 font-medium">ETB 200K → 1M</span>
            </div>
            <div className="flex items-center gap-1.5">
              <span className="font-extrabold text-[11px] text-amber-300 px-1.5 py-0.2 rounded bg-black/30 border border-amber-400/30">
                {missionPct.toFixed(1)}%
              </span>
            </div>
          </div>
          <div className="w-full h-1.5 bg-emerald-950/60 rounded-full overflow-hidden p-0.5 border border-emerald-400/20 shadow-inner">
            <div
              className="h-full rounded-full bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300 transition-all duration-500 shadow-sm"
              style={{ width: `${missionPct}%` }}
            />
          </div>
        </div>
      </div>
    </header>
  );
};

