import React, { useMemo } from 'react';
import { useStore, TabKey } from '../context/StoreContext';
import { useTranslation } from '../i18n/LanguageContext';
import { LanguageToggle } from './LanguageToggle';
import { getDynamicSafetyStockAlerts, money } from '../utils/helpers';
import {
  LayoutDashboard,
  Receipt,
  Package,
  Truck,
  Wallet,
  BarChart3,
  History,
  Factory,
  Users,
  Building2,
  TrendingUp,
  ShieldCheck,
  FileSpreadsheet,
  Search,
  Download,
  ChevronLeft,
  ChevronRight,
  Settings,
  Zap,
  Info,
  Layers,
  Sparkles,
  Command,
} from 'lucide-react';
import { PermanentAppModal } from './PermanentAppModal';

interface DesktopSidebarProps {
  isCollapsed: boolean;
  onToggleCollapse: () => void;
}

interface NavEntry {
  id: TabKey;
  label: string;
  shortLabel: string;
  icon: React.FC<{ className?: string }>;
  badge?: number | string;
  badgeColor?: string;
  badgeTitle?: string;
  hasVelocityRisk?: boolean;
}

export const DesktopSidebar: React.FC<DesktopSidebarProps> = ({
  isCollapsed,
  onToggleCollapse,
}) => {
  const {
    activeTab,
    setActiveTab,
    cart,
    db,
    totals,
    priceSuggestions,
    setIsSearchOpen,
    setIsTaxModalOpen,
    setIsMonthlyTaxReportModalOpen,
    setIsBusinessInfoOpen,
    setIsCeoProfileModalOpen,
    taxSettings,
    businessProfile,
    currentUser,
    availableUsers,
  } = useStore();

  const [isInstallModalOpen, setIsInstallModalOpen] = React.useState(false);

  const { t } = useTranslation();

  // Dynamic alerts
  const safetyAlerts = useMemo(() => {
    return getDynamicSafetyStockAlerts(db);
  }, [db.products, db.sales]);

  const activeOrdersCount = db.orders.filter((o) => o.status !== 'PAID').length;
  const cartItemCount = cart.reduce((a, x) => a + x.qty, 0);

  const actionablePricingCount = useMemo(() => {
    return (priceSuggestions || []).filter((s) => Math.abs(s.priceChangeDelta) >= 1).length;
  }, [priceSuggestions]);

  const ceoUser =
    availableUsers.find((u) => u.id === currentUser?.id) ||
    availableUsers.find((u) => u.role.toLowerCase().includes('ceo')) ||
    availableUsers[0];

  // Core Operations Nav
  const operationsNav: NavEntry[] = useMemo(() => [
    {
      id: 'dashboard',
      label: t('navDashboard'),
      shortLabel: 'CEO',
      icon: LayoutDashboard,
    },
    {
      id: 'pos',
      label: t('navPos'),
      shortLabel: 'POS',
      icon: Receipt,
      badge: cartItemCount > 0 ? cartItemCount : undefined,
      badgeColor: 'bg-amber-400 text-amber-950 font-black',
      badgeTitle: `${cartItemCount} items in cart`,
    },
    {
      id: 'inventory',
      label: t('navInventory'),
      shortLabel: 'Stock',
      icon: Package,
      badge: safetyAlerts.totalBelowSafety > 0 ? safetyAlerts.totalBelowSafety : undefined,
      badgeColor:
        safetyAlerts.velocityTriggeredCount > 0
          ? 'bg-rose-600 text-white font-black animate-pulse ring-1 ring-rose-400'
          : 'bg-rose-500 text-white font-bold',
      badgeTitle: `${safetyAlerts.totalBelowSafety} items below dynamic safety stock`,
      hasVelocityRisk: safetyAlerts.velocityTriggeredCount > 0,
    },
    {
      id: 'distribution',
      label: t('navDistribution'),
      shortLabel: 'Orders',
      icon: Truck,
      badge: activeOrdersCount > 0 ? activeOrdersCount : undefined,
      badgeColor: 'bg-blue-500 text-white font-bold',
      badgeTitle: `${activeOrdersCount} pending orders`,
    },
    {
      id: 'purchases',
      label: t('navPurchases'),
      shortLabel: 'Vendors',
      icon: Factory,
    },
  ], [t, cartItemCount, safetyAlerts, activeOrdersCount]);

  // Financial & Intelligence Nav
  const financeNav: NavEntry[] = useMemo(() => [
    {
      id: 'finance',
      label: t('navFinance'),
      shortLabel: 'Finance',
      icon: Wallet,
    },
    {
      id: 'reports',
      label: t('navReports'),
      shortLabel: 'Reports',
      icon: BarChart3,
    },
    {
      id: 'pricing',
      label: t('navPricing'),
      shortLabel: 'Pricing',
      icon: TrendingUp,
      badge: actionablePricingCount > 0 ? actionablePricingCount : undefined,
      badgeColor: 'bg-emerald-500 text-white font-bold',
      badgeTitle: `${actionablePricingCount} dynamic pricing opportunities`,
    },
  ], [t, actionablePricingCount]);

  // Management & Compliance Nav
  const managementNav: NavEntry[] = useMemo(() => [
    {
      id: 'customers',
      label: t('navCustomers'),
      shortLabel: 'Clients',
      icon: Users,
    },
    {
      id: 'activity',
      label: t('navActivity'),
      shortLabel: 'Audit',
      icon: History,
    },
    {
      id: 'enterprise',
      label: t('navEnterprise'),
      shortLabel: 'Multi-Store',
      icon: Building2,
    },
  ], [t]);

  const missionTarget = businessProfile.missionTarget || db.target || 1000000;
  const missionPct = Math.min(100, Math.max(0, (totals.value / missionTarget) * 100));

  const renderNavGroup = (title: string, items: NavEntry[]) => (
    <div className="space-y-1 mb-4">
      {!isCollapsed && (
        <div className="px-3 pb-1 text-[10px] font-black uppercase tracking-wider text-emerald-400/70 select-none">
          {title}
        </div>
      )}
      {items.map((item) => {
        const Icon = item.icon;
        const isActive = activeTab === item.id;

        return (
          <button
            key={item.id}
            id={`desktop-nav-${item.id}`}
            onClick={() => {
              setActiveTab(item.id);
              window.scrollTo({ top: 0, behavior: 'smooth' });
            }}
            title={isCollapsed ? `${item.label} ${item.badge ? `(${item.badge})` : ''}` : undefined}
            className={`w-full group relative flex items-center gap-3 px-3 py-2 rounded-xl text-left transition-all duration-150 ${
              isActive
                ? 'bg-gradient-to-r from-emerald-600/90 to-emerald-700/80 text-white font-bold shadow-md shadow-emerald-950/40 border border-emerald-400/40'
                : 'text-emerald-100/75 hover:text-white hover:bg-emerald-900/40 font-medium'
            } ${isCollapsed ? 'justify-center px-2' : ''}`}
          >
            <div className="relative shrink-0">
              <Icon
                className={`w-4 h-4 transition-transform group-hover:scale-110 ${
                  isActive ? 'text-white stroke-[2.4]' : 'text-emerald-300/80 stroke-[1.8]'
                }`}
              />
              {item.badge !== undefined && (
                <span
                  title={item.badgeTitle}
                  className={`absolute -top-1.5 -right-2 text-[9px] px-1 py-0.2 rounded-full shadow-xs flex items-center justify-center min-w-[15px] h-[15px] leading-none ${
                    item.badgeColor || 'bg-emerald-500 text-white font-black'
                  }`}
                >
                  {item.hasVelocityRisk && (
                    <Zap className="w-2 h-2 fill-current shrink-0 mr-0.5 text-amber-200" />
                  )}
                  <span>{item.badge}</span>
                </span>
              )}
            </div>

            {!isCollapsed && (
              <div className="flex-1 min-w-0 flex items-center justify-between">
                <span className="text-xs truncate tracking-tight">{item.label}</span>
                {isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-amber-400 shadow-xs shadow-amber-300" />
                )}
              </div>
            )}
          </button>
        );
      })}
    </div>
  );

  return (
    <>
      <aside
        id="desktop-sidebar"
        className={`hidden lg:flex flex-col shrink-0 sticky top-0 h-screen z-40 bg-gradient-to-b from-[#02130c] via-[#042417] to-[#031910] text-white border-r border-emerald-900/50 shadow-2xl transition-all duration-200 select-none ${
          isCollapsed ? 'w-[72px]' : 'w-64 xl:w-72'
        }`}
      >
        {/* Brand & Workspace Header */}
        <div className="p-3.5 border-b border-emerald-800/40 flex items-center justify-between gap-2 shrink-0">
          <div
            onClick={() => setActiveTab('dashboard')}
            className="flex items-center gap-2.5 cursor-pointer group min-w-0"
            title="BARWAAQO Business OS - CEO Command Center"
          >
            <div className="relative shrink-0">
              <img
                src="/logo.png"
                alt="BARWAAQO"
                className="w-9 h-9 rounded-xl object-cover shadow-lg ring-2 ring-amber-400/40 group-hover:scale-105 transition-transform"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <span className="absolute -bottom-0.5 -right-0.5 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500 border border-[#02130c]"></span>
              </span>
            </div>

            {!isCollapsed && (
              <div className="min-w-0">
                <div className="flex items-center gap-1.5">
                  <span className="font-black text-sm tracking-wider text-white truncate uppercase drop-shadow-sm">
                    {businessProfile.storeName || 'BARWAAQO'}
                  </span>
                  <span className="text-[8px] uppercase font-black px-1.5 py-0.2 rounded-full bg-amber-400 text-amber-950 shrink-0">
                    OS
                  </span>
                </div>
                <p className="text-[9.5px] text-emerald-300/80 font-medium tracking-tight truncate">
                  ENTERPRISE DESKTOP
                </p>
              </div>
            )}
          </div>

          <button
            id="sidebar-collapse-btn"
            onClick={onToggleCollapse}
            className="p-1.5 rounded-lg text-emerald-300 hover:text-white hover:bg-emerald-800/40 transition-colors shrink-0"
            title={isCollapsed ? 'Expand sidebar (Ctrl + B)' : 'Collapse sidebar (Ctrl + B)'}
          >
            {isCollapsed ? (
              <ChevronRight className="w-4 h-4" />
            ) : (
              <ChevronLeft className="w-4 h-4" />
            )}
          </button>
        </div>

        {/* Quick Search Shortcut trigger */}
        <div className="p-2.5 shrink-0">
          <button
            id="desktop-search-trigger"
            onClick={() => setIsSearchOpen(true)}
            className={`w-full flex items-center gap-2.5 py-2 px-3 rounded-xl bg-white/5 hover:bg-white/10 text-emerald-200/90 text-xs font-medium border border-emerald-500/20 transition-all ${
              isCollapsed ? 'justify-center px-2' : ''
            }`}
            title="Global Search (Press / or Ctrl+K)"
          >
            <Search className="w-4 h-4 text-emerald-300 shrink-0" />
            {!isCollapsed && (
              <>
                <span className="flex-1 text-left truncate text-slate-300">Quick Search...</span>
                <kbd className="hidden xl:inline-flex items-center gap-0.5 text-[10px] font-mono text-emerald-300/80 bg-black/40 px-1.5 py-0.5 rounded border border-white/10">
                  <Command className="w-2.5 h-2.5" /> K
                </kbd>
              </>
            )}
          </button>
        </div>

        {/* Scrollable Navigation List */}
        <div className="flex-1 overflow-y-auto px-2.5 py-2 space-y-1 custom-scrollbar">
          {renderNavGroup(t('groupOperations'), operationsNav)}
          {renderNavGroup(t('groupFinance'), financeNav)}
          {renderNavGroup(t('groupManagement'), managementNav)}

          {/* Quick Tax & Compliance Actions */}
          <div className="pt-2 border-t border-emerald-900/40 space-y-1 mb-4">
            {!isCollapsed && (
              <div className="px-3 pb-1 text-[10px] font-black uppercase tracking-wider text-emerald-400/70 select-none">
                {t('groupCompliance')}
              </div>
            )}

            <button
              id="desktop-tax-settings-btn"
              onClick={() => setIsTaxModalOpen(true)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-emerald-200/80 hover:text-white hover:bg-emerald-900/40 transition-colors text-left ${
                isCollapsed ? 'justify-center px-2' : ''
              }`}
              title="Multi-Tier Tax Engine Settings"
            >
              <ShieldCheck className="w-4 h-4 text-amber-300 shrink-0 stroke-[2]" />
              {!isCollapsed && (
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-semibold truncate text-white">
                    {taxSettings.taxLabel} Engine
                  </div>
                  <div className="text-[10px] text-emerald-300/70 truncate">
                    {taxSettings.tiers.length} Tiers · {taxSettings.calculationMethod}
                  </div>
                </div>
              )}
            </button>

            <button
              id="desktop-tax-report-btn"
              onClick={() => setIsMonthlyTaxReportModalOpen(true)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl text-emerald-200/80 hover:text-white hover:bg-emerald-900/40 transition-colors text-left ${
                isCollapsed ? 'justify-center px-2' : ''
              }`}
              title="Monthly Tax Return & Statutory Audit Report"
            >
              <FileSpreadsheet className="w-4 h-4 text-teal-300 shrink-0 stroke-[2]" />
              {!isCollapsed && (
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-semibold truncate text-white">Tax Audit Filing</div>
                  <div className="text-[10px] text-teal-300/70 truncate">Reconciliation & Export</div>
                </div>
              )}
            </button>
          </div>

          {/* Permanent Desktop App Install trigger */}
          <div className="pt-2 border-t border-emerald-900/40">
            <button
              id="desktop-pwa-modal-btn"
              onClick={() => setIsInstallModalOpen(true)}
              className={`w-full flex items-center gap-3 px-3 py-2 rounded-xl bg-gradient-to-r from-emerald-950/60 to-teal-950/60 hover:from-emerald-900/70 hover:to-teal-900/70 border border-emerald-500/30 text-emerald-100 transition-all text-left ${
                isCollapsed ? 'justify-center px-2' : ''
              }`}
              title="Install as Permanent Desktop App"
            >
              <Download className="w-4 h-4 text-amber-400 shrink-0" />
              {!isCollapsed && (
                <div className="flex-1 min-w-0">
                  <div className="text-xs font-bold text-white flex items-center gap-1.5">
                    <span>{t('desktopApp')}</span>
                    <span className="text-[8px] bg-amber-400 text-amber-950 font-black px-1 rounded uppercase">
                      PWA
                    </span>
                  </div>
                  <div className="text-[9.5px] text-emerald-300/70 truncate">
                    Offline & Full Screen
                  </div>
                </div>
              )}
            </button>
          </div>
        </div>

        {/* Compact Desktop Mission Indicator (When Expanded) */}
        {!isCollapsed && (
          <div className="p-3 border-t border-emerald-900/40 bg-emerald-950/40 shrink-0">
            <div className="flex justify-between items-center text-[10px] mb-1">
              <span className="text-emerald-300 font-bold uppercase tracking-wider">{t('missionTarget')}</span>
              <span className="font-extrabold text-amber-300">{missionPct.toFixed(0)}%</span>
            </div>
            <div className="w-full h-1.5 bg-black/40 rounded-full overflow-hidden border border-emerald-500/20">
              <div
                className="h-full rounded-full bg-gradient-to-r from-emerald-400 to-amber-400"
                style={{ width: `${missionPct}%` }}
              />
            </div>
            <div className="flex justify-between items-center text-[9px] text-emerald-200/70 mt-1">
              <span>{t('valuation')}</span>
              <span className="font-mono font-bold text-white">{money(totals.value)}</span>
            </div>
          </div>
        )}

        {/* Language Switcher in Sidebar */}
        <div className={`p-2 border-t border-emerald-800/30 bg-[#02130c] shrink-0 ${isCollapsed ? 'flex justify-center' : ''}`}>
          <LanguageToggle variant={isCollapsed ? 'compact' : 'sidebar'} />
        </div>

        {/* Cashier / CEO User Account Footer */}
        <div className="p-2.5 border-t border-emerald-800/40 bg-[#02110a] shrink-0">
          <button
            id="desktop-user-profile-btn"
            onClick={() => setIsCeoProfileModalOpen(true)}
            className={`w-full flex items-center gap-2.5 p-1.5 rounded-xl hover:bg-white/10 transition-colors text-left group ${
              isCollapsed ? 'justify-center p-1' : ''
            }`}
            title="CEO Identity, Employee & PIN Settings"
          >
            <div className="relative shrink-0">
              <div className="w-8 h-8 rounded-xl bg-amber-400 text-amber-950 font-black text-xs flex items-center justify-center shadow-md">
                {ceoUser?.name?.charAt(0) || 'C'}
              </div>
              <span className="absolute -bottom-0.5 -right-0.5 w-2.5 h-2.5 rounded-full bg-emerald-500 ring-2 ring-[#02110a]" />
            </div>

            {!isCollapsed && (
              <>
                <div className="flex-1 min-w-0">
                  <div className="flex items-center gap-1">
                    <span className="font-bold text-xs text-white truncate block">
                      {ceoUser?.name || businessProfile.ceoName || 'Aimraan'}
                    </span>
                    <span className="text-[7.5px] font-black uppercase px-1 py-0.2 rounded bg-amber-400 text-amber-950 shrink-0">
                      {ceoUser?.role?.includes('CEO') ? 'CEO' : 'STAFF'}
                    </span>
                  </div>
                  <span className="text-[9.5px] text-emerald-300/80 font-medium truncate block">
                    {ceoUser?.role || 'CEO & Owner'}
                  </span>
                </div>
                <Settings className="w-3.5 h-3.5 text-emerald-400/80 group-hover:text-amber-300 transition-colors shrink-0" />
              </>
            )}
          </button>
        </div>
      </aside>

      <PermanentAppModal
        isOpen={isInstallModalOpen}
        onClose={() => setIsInstallModalOpen(false)}
      />
    </>
  );
};
