import React, { useState } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, CheckCircle2, ShieldCheck, Monitor, Smartphone, Apple } from 'lucide-react';
import { PermanentAppModal } from './PermanentAppModal';

interface PWAInstallButtonProps {
  variant?: 'compact' | 'full' | 'header';
}

export const PWAInstallButton: React.FC<PWAInstallButtonProps> = ({ variant = 'header' }) => {
  const { isInstallable, isInstalled, isAndroid, isIOS, isDesktop, install } = usePWAInstall();
  const [modalOpen, setModalOpen] = useState(false);

  const handleClick = async () => {
    if (isInstallable) {
      const success = await install();
      if (!success) {
        setModalOpen(true);
      }
    } else {
      setModalOpen(true);
    }
  };

  const DeviceIcon = isIOS ? Apple : isAndroid ? Smartphone : Monitor;

  if (variant === 'compact') {
    return (
      <>
        <button
          onClick={handleClick}
          className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-lg bg-emerald-700/60 hover:bg-emerald-600 text-emerald-100 hover:text-white text-xs font-bold transition border border-emerald-500/30"
          title="Install Permanent App"
        >
          <DeviceIcon className="w-3.5 h-3.5" />
          <span>{isInstalled ? 'Permanent ✓' : 'Install App'}</span>
        </button>
        <PermanentAppModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
      </>
    );
  }

  if (variant === 'header') {
    return (
      <>
        <button
          id="install-permanent-app-button"
          onClick={handleClick}
          className={`flex items-center gap-1.5 px-2.5 sm:px-3 py-1.5 rounded-xl text-xs font-black shadow-md transition active:scale-95 border ${
            isInstalled
              ? 'bg-emerald-900/60 hover:bg-emerald-800/80 text-emerald-200 border-emerald-500/40'
              : 'bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white shadow-emerald-950/40 border-emerald-400/50 animate-pulse-subtle'
          }`}
          title="Install as a permanent standalone app on PC, Mac, iPhone, or Android"
        >
          {isInstalled ? (
            <>
              <CheckCircle2 className="w-3.5 h-3.5 text-emerald-300 shrink-0" />
              <span className="hidden sm:inline">Permanent App Active</span>
              <span className="sm:hidden">App Active</span>
            </>
          ) : (
            <>
              <Download className="w-3.5 h-3.5 text-emerald-100 shrink-0" />
              <span className="font-bold">Download App</span>
              <span className="hidden md:inline-block text-[10px] uppercase font-black px-1 rounded bg-white/20 text-white">
                Direct
              </span>
            </>
          )}
        </button>
        <PermanentAppModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
      </>
    );
  }

  return (
    <>
      <button
        id="install-permanent-app-full"
        onClick={handleClick}
        className="flex items-center gap-2 px-4 py-2 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white text-xs font-extrabold shadow-md shadow-emerald-950/30 transition active:scale-95 border border-emerald-400/40"
      >
        <DeviceIcon className="w-4 h-4 text-emerald-100 shrink-0" />
        <span>{isInstalled ? 'Permanent App Active ✓' : 'Install Standalone App'}</span>
      </button>
      <PermanentAppModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
};
