import React, { useState } from 'react';
import {
  X,
  ShieldCheck,
  Percent,
  Plus,
  Trash2,
  CheckCircle2,
  RotateCcw,
  FileSpreadsheet,
  Calculator,
  Building,
  HelpCircle,
  Sparkles,
  ToggleLeft,
  ToggleRight,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { TaxTier, TaxSettings } from '../../types';
import {
  REGIONAL_TAX_PRESETS,
  calculateLineTax,
  getTaxTier,
} from '../../utils/taxEngine';
import { money } from '../../utils/helpers';

export function TaxSettingsModal() {
  const {
    db,
    isTaxModalOpen,
    setIsTaxModalOpen,
    taxSettings,
    updateTaxSettings,
    addTaxTier,
    updateTaxTier,
    deleteTaxTier,
    setDefaultTaxTier,
    applyTaxPreset,
    setIsMonthlyTaxReportModalOpen,
    showToast,
  } = useStore();

  const [activeTab, setActiveTab] = useState<'tiers' | 'general' | 'presets' | 'simulator'>('tiers');

  // New tier form state
  const [newTierName, setNewTierName] = useState('');
  const [newTierCode, setNewTierCode] = useState('');
  const [newTierRate, setNewTierRate] = useState<number>(15);
  const [newTierDescription, setNewTierDescription] = useState('');
  const [newTierIsExempt, setNewTierIsExempt] = useState(false);
  const [isAddingTier, setIsAddingTier] = useState(false);

  // Edit tier state
  const [editingTierId, setEditingTierId] = useState<string | null>(null);
  const [editTierName, setEditTierName] = useState('');
  const [editTierCode, setEditTierCode] = useState('');
  const [editTierRate, setEditTierRate] = useState<number>(0);
  const [editTierDesc, setEditTierDesc] = useState('');
  const [editTierExempt, setEditTierExempt] = useState(false);

  // Simulator state
  const [simPrice, setSimPrice] = useState<number>(1000);
  const [simQty, setSimQty] = useState<number>(1);
  const [simTierId, setSimTierId] = useState<string>(taxSettings.defaultTierId);

  if (!isTaxModalOpen) return null;

  const handleSaveGeneralSettings = (updates: Partial<TaxSettings>) => {
    updateTaxSettings({
      ...taxSettings,
      ...updates,
    });
  };

  const handleCreateTier = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTierName.trim() || !newTierCode.trim()) {
      showToast('Please provide both tier name and code');
      return;
    }
    addTaxTier({
      name: newTierName.trim(),
      code: newTierCode.trim().toUpperCase(),
      rate: newTierIsExempt ? 0 : Math.max(0, Number(newTierRate) || 0),
      description: newTierDescription.trim(),
      isExempt: newTierIsExempt,
    });
    setNewTierName('');
    setNewTierCode('');
    setNewTierRate(15);
    setNewTierDescription('');
    setNewTierIsExempt(false);
    setIsAddingTier(false);
  };

  const startEditTier = (tier: TaxTier) => {
    setEditingTierId(tier.id);
    setEditTierName(tier.name);
    setEditTierCode(tier.code);
    setEditTierRate(tier.rate);
    setEditTierDesc(tier.description || '');
    setEditTierExempt(!!tier.isExempt);
  };

  const saveEditTier = (id: string) => {
    if (!editTierName.trim() || !editTierCode.trim()) {
      showToast('Tier name and code are required');
      return;
    }
    updateTaxTier(id, {
      name: editTierName.trim(),
      code: editTierCode.trim().toUpperCase(),
      rate: editTierExempt ? 0 : Math.max(0, Number(editTierRate) || 0),
      description: editTierDesc.trim(),
      isExempt: editTierExempt,
    });
    setEditingTierId(null);
  };

  // Simulator calculation
  const simTier = getTaxTier(taxSettings, simTierId);
  const simCalc = calculateLineTax(simPrice, simQty, simTier, taxSettings);

  // Products mapped per tier count
  const tierProductCountMap: Record<string, number> = {};
  db.products.forEach((p) => {
    const tid = p.taxTierId || taxSettings.defaultTierId;
    tierProductCountMap[tid] = (tierProductCountMap[tid] || 0) + 1;
  });

  return (
    <div className="fixed inset-0 z-50 bg-black/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto">
      <div className="bg-slate-900 border border-emerald-700/50 rounded-2xl w-full max-w-4xl shadow-2xl overflow-hidden flex flex-col max-h-[92vh] animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 px-5 py-4 border-b border-slate-800 flex items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <ShieldCheck className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">Tax & Compliance Configuration</h2>
                <span
                  className={`px-2 py-0.5 rounded-full text-xs font-bold ${
                    taxSettings.enabled
                      ? 'bg-emerald-500/20 text-emerald-300 border border-emerald-500/30'
                      : 'bg-rose-500/20 text-rose-300 border border-rose-500/30'
                  }`}
                >
                  {taxSettings.enabled ? 'Tax Engine ACTIVE' : 'Tax Engine OFF'}
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Automated multi-tier POS tax computation, fiscal registration & monthly compliance reporting
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="tax-open-monthly-report-btn"
              onClick={() => {
                setIsTaxModalOpen(false);
                setIsMonthlyTaxReportModalOpen(true);
              }}
              className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
              title="Open Monthly Tax Summary Report"
            >
              <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
              <span>Monthly Report</span>
            </button>
            <button
              id="close-tax-settings-modal"
              onClick={() => setIsTaxModalOpen(false)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Navigation Tabs */}
        <div className="bg-slate-900/80 px-5 pt-2 border-b border-slate-800 flex items-center gap-2 overflow-x-auto">
          <button
            id="tax-tab-tiers"
            onClick={() => setActiveTab('tiers')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'tiers'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Percent className="w-3.5 h-3.5" />
            <span>Multi-Tier Tax Rates ({taxSettings.tiers.length})</span>
          </button>
          <button
            id="tax-tab-general"
            onClick={() => setActiveTab('general')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'general'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Building className="w-3.5 h-3.5" />
            <span>Business TIN & Regimes</span>
          </button>
          <button
            id="tax-tab-presets"
            onClick={() => setActiveTab('presets')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'presets'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5" />
            <span>Regional Presets</span>
          </button>
          <button
            id="tax-tab-simulator"
            onClick={() => setActiveTab('simulator')}
            className={`px-4 py-2.5 text-xs font-bold border-b-2 transition-all flex items-center gap-1.5 whitespace-nowrap ${
              activeTab === 'simulator'
                ? 'border-emerald-500 text-emerald-400'
                : 'border-transparent text-slate-400 hover:text-slate-200'
            }`}
          >
            <Calculator className="w-3.5 h-3.5" />
            <span>Tax Calculator Sandbox</span>
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-sm flex-1">
          
          {/* Quick Engine Master Banner */}
          <div className="bg-slate-800/80 border border-slate-700/60 rounded-xl p-4 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              <button
                id="toggle-tax-master-enabled"
                onClick={() => handleSaveGeneralSettings({ enabled: !taxSettings.enabled })}
                className="text-slate-300 hover:text-white transition-colors"
                title={taxSettings.enabled ? 'Click to disable tax calculation' : 'Click to enable tax calculation'}
              >
                {taxSettings.enabled ? (
                  <ToggleRight className="w-8 h-8 text-emerald-400" />
                ) : (
                  <ToggleLeft className="w-8 h-8 text-slate-500" />
                )}
              </button>
              <div>
                <div className="font-semibold text-white">
                  Automatic Tax Engine is {taxSettings.enabled ? 'Active' : 'Disabled'}
                </div>
                <div className="text-xs text-slate-400">
                  {taxSettings.enabled
                    ? 'POS computes and logs multi-tier tax lines on every sale'
                    : 'Sales transactions are recorded without tax calculation'}
                </div>
              </div>
            </div>

            <div className="flex items-center gap-2 w-full sm:w-auto">
              <span className="text-xs text-slate-400 whitespace-nowrap">Pricing Application:</span>
              <div className="flex bg-slate-900 p-1 rounded-lg border border-slate-700 w-full sm:w-auto">
                <button
                  id="tax-mode-exclusive"
                  onClick={() => handleSaveGeneralSettings({ calculationMethod: 'exclusive' })}
                  className={`px-3 py-1 rounded-md text-xs font-bold transition-all flex-1 sm:flex-initial ${
                    taxSettings.calculationMethod === 'exclusive'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Prices are catalog net; tax is added on top during checkout"
                >
                  Tax-Exclusive (Add-On)
                </button>
                <button
                  id="tax-mode-inclusive"
                  onClick={() => handleSaveGeneralSettings({ calculationMethod: 'inclusive' })}
                  className={`px-3 py-1 rounded-md text-xs font-bold transition-all flex-1 sm:flex-initial ${
                    taxSettings.calculationMethod === 'inclusive'
                      ? 'bg-emerald-600 text-white shadow-xs'
                      : 'text-slate-400 hover:text-slate-200'
                  }`}
                  title="Shelf prices include tax; tax base and tax amount are isolated"
                >
                  Tax-Inclusive (Built-In)
                </button>
              </div>
            </div>
          </div>

          {/* TAB 1: MULTI-TIER TAX RATES */}
          {activeTab === 'tiers' && (
            <div className="space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-2 border-b border-slate-800">
                <div>
                  <h3 className="font-bold text-white text-base">Configured Tax Tiers & Brackets</h3>
                  <p className="text-xs text-slate-400">
                    Assign multi-tier brackets to products. Items default to {getTaxTier(taxSettings).name} ({getTaxTier(taxSettings).rate}%).
                  </p>
                </div>
                {!isAddingTier && (
                  <button
                    id="btn-add-tax-tier"
                    onClick={() => setIsAddingTier(true)}
                    className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-semibold text-xs transition-colors self-start"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Add New Tax Tier</span>
                  </button>
                )}
              </div>

              {/* Add New Tier Inline Form */}
              {isAddingTier && (
                <form
                  onSubmit={handleCreateTier}
                  className="bg-slate-800/90 border border-emerald-600/50 rounded-xl p-4 space-y-3 animate-in fade-in duration-150"
                >
                  <div className="flex items-center justify-between">
                    <span className="font-bold text-sm text-emerald-400 flex items-center gap-2">
                      <Plus className="w-4 h-4" /> New Tax Bracket Specification
                    </span>
                    <button
                      type="button"
                      onClick={() => setIsAddingTier(false)}
                      className="text-slate-400 hover:text-white text-xs"
                    >
                      Cancel
                    </button>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">Tier Name *</label>
                      <input
                        type="text"
                        required
                        value={newTierName}
                        onChange={(e) => setNewTierName(e.target.value)}
                        placeholder="e.g. Agro Reduced Rate"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-hidden focus:border-emerald-500"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">Tax Code *</label>
                      <input
                        type="text"
                        required
                        value={newTierCode}
                        onChange={(e) => setNewTierCode(e.target.value)}
                        placeholder="e.g. RED-5"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-hidden focus:border-emerald-500 uppercase"
                      />
                    </div>
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">Tax Rate (%) *</label>
                      <input
                        type="number"
                        step="0.01"
                        min="0"
                        max="100"
                        disabled={newTierIsExempt}
                        value={newTierIsExempt ? 0 : newTierRate}
                        onChange={(e) => setNewTierRate(Number(e.target.value))}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-hidden focus:border-emerald-500 disabled:opacity-50"
                      />
                    </div>
                  </div>

                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 items-center">
                    <div>
                      <label className="block text-xs text-slate-300 mb-1">Regulatory Description</label>
                      <input
                        type="text"
                        value={newTierDescription}
                        onChange={(e) => setNewTierDescription(e.target.value)}
                        placeholder="e.g. 5% on agricultural produce & cooking oil"
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-hidden focus:border-emerald-500"
                      />
                    </div>
                    <div className="flex items-center gap-2 pt-4 sm:pt-0">
                      <label className="flex items-center gap-2 text-xs text-slate-300 cursor-pointer">
                        <input
                          type="checkbox"
                          checked={newTierIsExempt}
                          onChange={(e) => {
                            setNewTierIsExempt(e.target.checked);
                            if (e.target.checked) setNewTierRate(0);
                          }}
                          className="rounded-sm border-slate-700 bg-slate-900 text-emerald-500 focus:ring-emerald-500"
                        />
                        <span>Zero-Rated / Exempt Category (0% Tax Liability)</span>
                      </label>
                    </div>
                  </div>

                  <div className="flex justify-end gap-2 pt-2 border-t border-slate-700/60">
                    <button
                      type="button"
                      onClick={() => setIsAddingTier(false)}
                      className="px-3 py-1.5 rounded-lg bg-slate-700 hover:bg-slate-600 text-xs text-slate-200"
                    >
                      Cancel
                    </button>
                    <button
                      type="submit"
                      className="px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-xs font-bold text-white"
                    >
                      Save Tax Tier
                    </button>
                  </div>
                </form>
              )}

              {/* Tiers Table */}
              <div className="border border-slate-800 rounded-xl overflow-hidden bg-slate-900/60">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-800/80 border-b border-slate-800 text-xs font-semibold text-slate-400">
                        <th className="py-2.5 px-4">Tax Bracket</th>
                        <th className="py-2.5 px-3">Code</th>
                        <th className="py-2.5 px-3">Rate</th>
                        <th className="py-2.5 px-3">Type</th>
                        <th className="py-2.5 px-3">Catalog Items</th>
                        <th className="py-2.5 px-3 text-right">Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 text-xs">
                      {taxSettings.tiers.map((tier) => {
                        const isDefault = tier.id === taxSettings.defaultTierId || !!tier.isDefault;
                        const isEditing = editingTierId === tier.id;
                        const itemCount = tierProductCountMap[tier.id] || 0;

                        if (isEditing) {
                          return (
                            <tr key={tier.id} className="bg-slate-800/70">
                              <td className="p-3">
                                <input
                                  type="text"
                                  value={editTierName}
                                  onChange={(e) => setEditTierName(e.target.value)}
                                  className="w-full bg-slate-900 border border-slate-700 rounded-md px-2 py-1 text-xs text-white"
                                />
                                <input
                                  type="text"
                                  value={editTierDesc}
                                  onChange={(e) => setEditTierDesc(e.target.value)}
                                  placeholder="Description"
                                  className="w-full mt-1 bg-slate-900 border border-slate-700 rounded-md px-2 py-1 text-[11px] text-slate-400"
                                />
                              </td>
                              <td className="p-3">
                                <input
                                  type="text"
                                  value={editTierCode}
                                  onChange={(e) => setEditTierCode(e.target.value)}
                                  className="w-20 bg-slate-900 border border-slate-700 rounded-md px-2 py-1 text-xs text-white uppercase"
                                />
                              </td>
                              <td className="p-3">
                                <input
                                  type="number"
                                  step="0.1"
                                  min="0"
                                  disabled={editTierExempt}
                                  value={editTierExempt ? 0 : editTierRate}
                                  onChange={(e) => setEditTierRate(Number(e.target.value))}
                                  className="w-16 bg-slate-900 border border-slate-700 rounded-md px-2 py-1 text-xs text-white"
                                />
                              </td>
                              <td className="p-3">
                                <label className="flex items-center gap-1.5 cursor-pointer">
                                  <input
                                    type="checkbox"
                                    checked={editTierExempt}
                                    onChange={(e) => {
                                      setEditTierExempt(e.target.checked);
                                      if (e.target.checked) setEditTierRate(0);
                                    }}
                                  />
                                  <span>Exempt</span>
                                </label>
                              </td>
                              <td className="p-3 text-slate-400">{itemCount} items</td>
                              <td className="p-3 text-right space-x-1">
                                <button
                                  type="button"
                                  onClick={() => saveEditTier(tier.id)}
                                  className="px-2 py-1 bg-emerald-600 hover:bg-emerald-500 rounded text-white font-bold"
                                >
                                  Save
                                </button>
                                <button
                                  type="button"
                                  onClick={() => setEditingTierId(null)}
                                  className="px-2 py-1 bg-slate-700 hover:bg-slate-600 rounded text-slate-300"
                                >
                                  Cancel
                                </button>
                              </td>
                            </tr>
                          );
                        }

                        return (
                          <tr key={tier.id} className="hover:bg-slate-800/40 transition-colors">
                            <td className="py-3 px-4">
                              <div className="font-semibold text-white flex items-center gap-2">
                                <span>{tier.name}</span>
                                {isDefault && (
                                  <span className="px-1.5 py-0.5 rounded-sm bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-[10px] font-bold">
                                    DEFAULT
                                  </span>
                                )}
                              </div>
                              {tier.description && (
                                <div className="text-[11px] text-slate-400 mt-0.5">{tier.description}</div>
                              )}
                            </td>
                            <td className="py-3 px-3">
                              <span className="px-2 py-0.5 rounded-md bg-slate-800 border border-slate-700 text-slate-300 font-mono text-xs">
                                {tier.code}
                              </span>
                            </td>
                            <td className="py-3 px-3">
                              <span
                                className={`font-bold text-sm ${
                                  tier.isExempt ? 'text-amber-400' : 'text-emerald-400'
                                }`}
                              >
                                {tier.rate.toFixed(1)}%
                              </span>
                            </td>
                            <td className="py-3 px-3">
                              {tier.isExempt ? (
                                <span className="px-2 py-0.5 rounded-full bg-amber-500/10 text-amber-300 border border-amber-500/30 text-[11px] font-medium">
                                  Zero-Rated / Exempt
                                </span>
                              ) : (
                                <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 text-[11px]">
                                  Standard Taxable
                                </span>
                              )}
                            </td>
                            <td className="py-3 px-3 text-slate-300">
                              <span className="font-medium text-white">{itemCount}</span> items
                            </td>
                            <td className="py-3 px-3 text-right">
                              <div className="flex items-center justify-end gap-1.5">
                                {!isDefault && (
                                  <button
                                    id={`set-default-tax-tier-${tier.id}`}
                                    onClick={() => setDefaultTaxTier(tier.id)}
                                    className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] transition-colors"
                                    title="Make this the default tier for newly created items"
                                  >
                                    Set Default
                                  </button>
                                )}
                                <button
                                  id={`edit-tax-tier-${tier.id}`}
                                  onClick={() => startEditTier(tier)}
                                  className="px-2 py-1 rounded bg-slate-800 hover:bg-slate-700 text-slate-300 hover:text-white text-[11px] transition-colors"
                                >
                                  Edit
                                </button>
                                {!isDefault && taxSettings.tiers.length > 1 && (
                                  <button
                                    id={`delete-tax-tier-${tier.id}`}
                                    onClick={() => deleteTaxTier(tier.id)}
                                    className="p-1 rounded text-rose-400 hover:text-rose-300 hover:bg-rose-950/30 transition-colors"
                                    title="Delete this tax bracket"
                                  >
                                    <Trash2 className="w-3.5 h-3.5" />
                                  </button>
                                )}
                              </div>
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: BUSINESS TIN & REGIMES */}
          {activeTab === 'general' && (
            <div className="space-y-4 max-w-2xl">
              <div>
                <h3 className="font-bold text-white text-base">Business Tax Identification & Invoicing</h3>
                <p className="text-xs text-slate-400">
                  These details appear on POS tax receipts, official compliance invoices, and monthly summaries.
                </p>
              </div>

              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-4 space-y-4">
                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    Tax Label / Regime Name
                  </label>
                  <input
                    type="text"
                    value={taxSettings.taxLabel}
                    onChange={(e) => handleSaveGeneralSettings({ taxLabel: e.target.value })}
                    placeholder="e.g. VAT, Sales Tax, TOT, GST"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-hidden focus:border-emerald-500"
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Shown on register receipts (e.g. "VAT (15%)" or "Sales Tax (8.25%)").
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    Taxpayer Identification Number (TIN)
                  </label>
                  <input
                    type="text"
                    value={taxSettings.taxIdentificationNumber}
                    onChange={(e) =>
                      handleSaveGeneralSettings({ taxIdentificationNumber: e.target.value })
                    }
                    placeholder="e.g. TIN-00941829-ET"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white font-mono focus:outline-hidden focus:border-emerald-500"
                  />
                  <span className="text-[11px] text-slate-400 mt-1 block">
                    Your official revenue authority TIN required on fiscal audit returns.
                  </span>
                </div>

                <div>
                  <label className="block text-xs font-semibold text-slate-200 mb-1">
                    Registered Taxpayer Legal Business Name
                  </label>
                  <input
                    type="text"
                    value={taxSettings.registeredBusinessName || ''}
                    onChange={(e) =>
                      handleSaveGeneralSettings({ registeredBusinessName: e.target.value })
                    }
                    placeholder="e.g. Aimraan Supreme Wholesale & Retail Grocery Ltd"
                    className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-2 text-sm text-white focus:outline-hidden focus:border-emerald-500"
                  />
                </div>

                <div className="pt-2 border-t border-slate-700/60 flex items-center justify-between">
                  <div className="text-xs text-slate-300">
                    <span className="font-semibold text-white">Default Tier for New Items:</span>{' '}
                    <span className="text-emerald-400 font-bold">{getTaxTier(taxSettings).name}</span> ({getTaxTier(taxSettings).rate}%)
                  </div>
                  <select
                    value={taxSettings.defaultTierId}
                    onChange={(e) => setDefaultTaxTier(e.target.value)}
                    className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1 text-xs text-white focus:outline-hidden focus:border-emerald-500"
                  >
                    {taxSettings.tiers.map((t) => (
                      <option key={t.id} value={t.id}>
                        {t.name} ({t.rate}%)
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: REGIONAL PRESETS */}
          {activeTab === 'presets' && (
            <div className="space-y-4">
              <div>
                <h3 className="font-bold text-white text-base">Instant Regional Tax Presets</h3>
                <p className="text-xs text-slate-400">
                  Quickly initialize multi-tier brackets matching established revenue and customs authority frameworks.
                </p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {REGIONAL_TAX_PRESETS.map((preset) => (
                  <div
                    key={preset.id}
                    className="bg-slate-800/70 border border-slate-700/80 rounded-xl p-4 flex flex-col justify-between hover:border-emerald-500/50 transition-all group"
                  >
                    <div className="space-y-2">
                      <div className="flex items-center justify-between">
                        <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 text-[10px] font-bold">
                          {preset.region}
                        </span>
                        <span className="text-xs font-mono text-slate-400">
                          {preset.calculationMethod === 'exclusive' ? 'Tax-Exclusive' : 'Tax-Inclusive'}
                        </span>
                      </div>
                      <h4 className="font-bold text-white text-sm group-hover:text-emerald-400 transition-colors">
                        {preset.name}
                      </h4>
                      <p className="text-xs text-slate-300 leading-relaxed">{preset.description}</p>
                      
                      {/* Tiers pill preview */}
                      <div className="flex flex-wrap gap-1.5 pt-2">
                        {preset.tiers.map((t) => (
                          <span
                            key={t.id}
                            className="px-2 py-0.5 bg-slate-900 text-slate-300 rounded text-[10px] font-mono border border-slate-700"
                          >
                            {t.code}: {t.rate}%
                          </span>
                        ))}
                      </div>
                    </div>

                    <div className="pt-4 mt-3 border-t border-slate-700/60 flex justify-end">
                      <button
                        id={`load-preset-${preset.id}`}
                        onClick={() => applyTaxPreset(preset.id)}
                        className="px-3 py-1.5 rounded-lg bg-emerald-600/90 hover:bg-emerald-500 text-white font-bold text-xs transition-colors flex items-center gap-1.5"
                      >
                        <RotateCcw className="w-3.5 h-3.5" />
                        <span>Apply Preset</span>
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 4: CALCULATOR SANDBOX */}
          {activeTab === 'simulator' && (
            <div className="space-y-4 max-w-2xl">
              <div>
                <h3 className="font-bold text-white text-base">Real-Time Tax Calculation Simulator</h3>
                <p className="text-xs text-slate-400">
                  Verify how your active multi-tier formulas and pricing modes calculate net taxable base and tax liabilities.
                </p>
              </div>

              <div className="bg-slate-800/60 border border-slate-700/60 rounded-xl p-5 space-y-4">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Unit Price (ETB)</label>
                    <input
                      type="number"
                      step="1"
                      min="1"
                      value={simPrice}
                      onChange={(e) => setSimPrice(Math.max(1, Number(e.target.value) || 0))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Quantity</label>
                    <input
                      type="number"
                      min="1"
                      value={simQty}
                      onChange={(e) => setSimQty(Math.max(1, Number(e.target.value) || 1))}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    />
                  </div>
                  <div>
                    <label className="block text-xs font-semibold text-slate-300 mb-1">Tax Bracket</label>
                    <select
                      value={simTierId}
                      onChange={(e) => setSimTierId(e.target.value)}
                      className="w-full bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs text-white"
                    >
                      {taxSettings.tiers.map((t) => (
                        <option key={t.id} value={t.id}>
                          {t.name} ({t.rate}%)
                        </option>
                      ))}
                    </select>
                  </div>
                </div>

                {/* Calculation Output Box */}
                <div className="bg-slate-900/90 border border-emerald-700/50 rounded-xl p-4 space-y-3">
                  <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                    <span className="text-xs text-slate-400 font-mono">
                      Mode: {taxSettings.calculationMethod.toUpperCase()} · Tier: {simTier.code} ({simTier.rate}%)
                    </span>
                    <span className="text-xs font-bold text-emerald-400">
                      {taxSettings.calculationMethod === 'exclusive' ? 'Net Base + Tax' : 'Extracted from Gross'}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 text-center">
                    <div className="bg-slate-800/60 p-2.5 rounded-lg border border-slate-800">
                      <div className="text-[11px] text-slate-400">Gross Catalog Total</div>
                      <div className="font-bold text-white text-sm mt-0.5">{money(simCalc.grossAmount)}</div>
                    </div>
                    <div className="bg-slate-800/60 p-2.5 rounded-lg border border-slate-800">
                      <div className="text-[11px] text-slate-400">Net Taxable Base</div>
                      <div className="font-bold text-emerald-300 text-sm mt-0.5">{money(simCalc.taxableAmount)}</div>
                    </div>
                    <div className="bg-slate-800/60 p-2.5 rounded-lg border border-slate-800">
                      <div className="text-[11px] text-slate-400">{taxSettings.taxLabel} Liability</div>
                      <div className="font-bold text-amber-300 text-sm mt-0.5">{money(simCalc.taxAmount)}</div>
                    </div>
                    <div className="bg-emerald-950/40 p-2.5 rounded-lg border border-emerald-800/40">
                      <div className="text-[11px] text-emerald-300">Customer Pays</div>
                      <div className="font-black text-white text-sm mt-0.5">{money(simCalc.totalAmount)}</div>
                    </div>
                  </div>

                  <div className="text-xs text-slate-400 pt-2 border-t border-slate-800 flex items-center gap-2">
                    <HelpCircle className="w-3.5 h-3.5 text-emerald-400 shrink-0" />
                    <span>
                      {taxSettings.calculationMethod === 'exclusive'
                        ? `Tax = ${money(simCalc.taxableAmount)} × ${simTier.rate}% = ${money(simCalc.taxAmount)}. Added to gross.`
                        : `Net Base = ${money(simCalc.grossAmount)} ÷ (1 + ${simTier.rate / 100}) = ${money(simCalc.taxableAmount)}. Tax = ${money(simCalc.taxAmount)}.`}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Footer */}
        <div className="bg-slate-900 px-5 py-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>TIN: <strong className="text-white font-mono">{taxSettings.taxIdentificationNumber}</strong></span>
            <span>·</span>
            <span>Regime: <strong className="text-white">{taxSettings.taxLabel} ({taxSettings.calculationMethod})</strong></span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={() => {
                setIsTaxModalOpen(false);
                setIsMonthlyTaxReportModalOpen(true);
              }}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-colors"
            >
              Open Monthly Tax Report
            </button>
            <button
              onClick={() => setIsTaxModalOpen(false)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
            >
              Done
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
