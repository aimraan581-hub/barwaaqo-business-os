import React, { useState, useMemo } from 'react';
import {
  X,
  FileSpreadsheet,
  Printer,
  Calendar,
  Settings,
  ShieldCheck,
  Search,
  ExternalLink,
  ChevronLeft,
  ChevronRight,
  Receipt,
  FileText,
} from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import {
  generateMonthlyTaxReport,
  exportMonthlyTaxReportCSV,
  MonthlyTaxReport,
} from '../../utils/taxEngine';
import { money } from '../../utils/helpers';
import { Sale } from '../../types';

export function MonthlyTaxReportModal() {
  const {
    db,
    isMonthlyTaxReportModalOpen,
    setIsMonthlyTaxReportModalOpen,
    setIsTaxModalOpen,
    taxSettings,
    selectedTaxReportMonth,
    setSelectedTaxReportMonth,
    setLastCompletedSale,
  } = useStore();

  const [activeTab, setActiveTab] = useState<'summary' | 'daily' | 'transactions'>('summary');
  const [searchQuery, setSearchQuery] = useState('');

  // Extract available months from existing sales data
  const availablePeriods = useMemo(() => {
    const periodSet = new Set<string>();
    // Default current month
    const now = new Date();
    const currentPeriod = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}`;
    periodSet.add(currentPeriod);
    periodSet.add('2026-09');
    periodSet.add('2026-08');

    (db.sales || []).forEach((s) => {
      if (s.date && s.date.length >= 7) {
        periodSet.add(s.date.slice(0, 7));
      }
    });

    return Array.from(periodSet)
      .sort((a, b) => b.localeCompare(a))
      .map((p) => {
        const [yearStr, monthStr] = p.split('-');
        return {
          year: parseInt(yearStr, 10),
          month: parseInt(monthStr, 10),
          key: p,
        };
      });
  }, [db.sales]);

  const report: MonthlyTaxReport = useMemo(() => {
    return generateMonthlyTaxReport(
      db.sales || [],
      selectedTaxReportMonth.year,
      selectedTaxReportMonth.month,
      taxSettings,
      db.products || []
    );
  }, [db.sales, selectedTaxReportMonth, taxSettings, db.products]);

  if (!isMonthlyTaxReportModalOpen) return null;

  const handleMonthChange = (year: number, month: number) => {
    setSelectedTaxReportMonth({ year, month });
  };

  const handlePrevMonth = () => {
    let newM = selectedTaxReportMonth.month - 1;
    let newY = selectedTaxReportMonth.year;
    if (newM < 1) {
      newM = 12;
      newY -= 1;
    }
    handleMonthChange(newY, newM);
  };

  const handleNextMonth = () => {
    let newM = selectedTaxReportMonth.month + 1;
    let newY = selectedTaxReportMonth.year;
    if (newM > 12) {
      newM = 1;
      newY += 1;
    }
    handleMonthChange(newY, newM);
  };

  const handlePrintReturn = () => {
    window.print();
  };

  const filteredTransactions = report.transactions.filter((tx) => {
    if (!searchQuery.trim()) return true;
    const q = searchQuery.toLowerCase();
    return (
      tx.invoice.toLowerCase().includes(q) ||
      tx.customer.toLowerCase().includes(q) ||
      tx.payment.toLowerCase().includes(q) ||
      tx.tiersApplied.some((t) => t.toLowerCase().includes(q))
    );
  });

  const handleViewReceipt = (invoiceNum: string) => {
    const sale = db.sales.find((s) => s.invoice === invoiceNum);
    if (sale) {
      setLastCompletedSale(sale);
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4 overflow-y-auto print:p-0 print:bg-white">
      <div className="bg-slate-900 border border-emerald-700/50 rounded-2xl w-full max-w-5xl shadow-2xl overflow-hidden flex flex-col max-h-[94vh] print:max-h-none print:border-none print:bg-white print:text-black">
        
        {/* Header (Screen Only) */}
        <div className="bg-gradient-to-r from-slate-900 via-slate-850 to-slate-900 px-5 py-4 border-b border-slate-800 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 print:hidden">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <FileSpreadsheet className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-lg font-bold text-white tracking-tight">Monthly Tax Summary & Audit Report</h2>
                <span className="px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 text-xs font-bold">
                  {report.taxLabel} Compliance
                </span>
              </div>
              <p className="text-xs text-slate-400">
                Official output tax liability, multi-tier classification breakdown & fiscal reconciliation
              </p>
            </div>
          </div>

          <div className="flex items-center flex-wrap gap-2 w-full sm:w-auto justify-end">
            <button
              id="tax-export-csv-btn"
              onClick={() => exportMonthlyTaxReportCSV(report)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-colors shadow-xs"
              title="Download official CSV export"
            >
              <FileSpreadsheet className="w-4 h-4" />
              <span>Export CSV</span>
            </button>
            <button
              id="tax-print-return-btn"
              onClick={handlePrintReturn}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
              title="Print official filing form"
            >
              <Printer className="w-4 h-4 text-emerald-400" />
              <span>Print Return</span>
            </button>
            <button
              id="tax-open-settings-btn"
              onClick={() => {
                setIsMonthlyTaxReportModalOpen(false);
                setIsTaxModalOpen(true);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold border border-slate-700 transition-colors"
              title="Tax Rates Configuration"
            >
              <Settings className="w-4 h-4 text-slate-400" />
              <span className="hidden sm:inline">Settings</span>
            </button>
            <button
              id="close-monthly-tax-modal"
              onClick={() => setIsMonthlyTaxReportModalOpen(false)}
              className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Official Printable Return Header */}
        <div className="hidden print:block p-6 border-b border-gray-300">
          <div className="flex justify-between items-start">
            <div>
              <h1 className="text-2xl font-black uppercase tracking-tight text-gray-900">
                MONTHLY TAX SUMMARY & STATUTORY RETURN
              </h1>
              <div className="text-sm font-semibold text-gray-700 mt-1">{report.businessName}</div>
              <div className="text-xs text-gray-600 font-mono">Taxpayer Identification Number (TIN): {report.tin}</div>
            </div>
            <div className="text-right">
              <div className="text-base font-bold text-gray-900 uppercase">Filing Period: {report.periodLabel}</div>
              <div className="text-xs text-gray-600">Tax Regime: {report.taxLabel} ({report.calculationMethod.toUpperCase()})</div>
              <div className="text-xs text-gray-500">Date Generated: {new Date().toLocaleDateString()}</div>
            </div>
          </div>
        </div>

        {/* Period Selector Bar (Screen Only) */}
        <div className="bg-slate-800/80 px-5 py-3 border-b border-slate-800 flex flex-col sm:flex-row sm:items-center justify-between gap-3 print:hidden">
          <div className="flex items-center gap-2">
            <button
              onClick={handlePrevMonth}
              className="p-1 rounded-lg bg-slate-900 hover:bg-slate-700 text-slate-300 transition-colors"
              title="Previous Month"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>

            <div className="flex items-center gap-2">
              <Calendar className="w-4 h-4 text-emerald-400" />
              <select
                id="select-tax-report-month"
                value={`${selectedTaxReportMonth.year}-${String(selectedTaxReportMonth.month).padStart(2, '0')}`}
                onChange={(e) => {
                  const [y, m] = e.target.value.split('-');
                  handleMonthChange(parseInt(y, 10), parseInt(m, 10));
                }}
                className="bg-slate-900 border border-slate-700 rounded-lg px-3 py-1.5 text-xs font-bold text-white focus:outline-hidden focus:border-emerald-500"
              >
                {availablePeriods.map((p) => (
                  <option key={p.key} value={p.key}>
                    {new Date(p.year, p.month - 1).toLocaleString('default', { month: 'long', year: 'numeric' })}
                  </option>
                ))}
              </select>
            </div>

            <button
              onClick={handleNextMonth}
              className="p-1 rounded-lg bg-slate-900 hover:bg-slate-700 text-slate-300 transition-colors"
              title="Next Month"
            >
              <ChevronRight className="w-4 h-4" />
            </button>

            <button
              onClick={() => {
                const now = new Date();
                handleMonthChange(now.getFullYear(), now.getMonth() + 1);
              }}
              className="px-2.5 py-1 rounded-md bg-slate-900 hover:bg-slate-700 text-slate-300 text-[11px] font-semibold border border-slate-700 transition-colors"
            >
              Current Month
            </button>
          </div>

          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span>TIN: <strong className="text-white font-mono">{report.tin}</strong></span>
            <span>·</span>
            <span>Business: <strong className="text-white">{report.businessName}</strong></span>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-5 text-sm flex-1 print:p-6 print:text-black">

          {/* KPI Summary Cards */}
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
            <div className="bg-slate-800/80 print:bg-gray-100 border border-slate-700/80 print:border-gray-300 rounded-xl p-3">
              <div className="text-[11px] font-medium text-slate-400 print:text-gray-600">Output Tax Collected</div>
              <div className="text-lg font-black text-emerald-400 print:text-black mt-1">
                {money(report.totalTaxCollected)}
              </div>
              <div className="text-[10px] text-emerald-300/80 mt-0.5">Total {report.taxLabel} Liability</div>
            </div>

            <div className="bg-slate-800/80 print:bg-gray-100 border border-slate-700/80 print:border-gray-300 rounded-xl p-3">
              <div className="text-[11px] font-medium text-slate-400 print:text-gray-600">Net Taxable Base</div>
              <div className="text-lg font-bold text-white print:text-black mt-1">
                {money(report.totalNetTaxableBase)}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">Excludes tax & discounts</div>
            </div>

            <div className="bg-slate-800/80 print:bg-gray-100 border border-slate-700/80 print:border-gray-300 rounded-xl p-3">
              <div className="text-[11px] font-medium text-slate-400 print:text-gray-600">Total Gross Sales</div>
              <div className="text-lg font-bold text-white print:text-black mt-1">
                {money(report.totalGrossSales)}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">All transactions turnover</div>
            </div>

            <div className="bg-slate-800/80 print:bg-gray-100 border border-slate-700/80 print:border-gray-300 rounded-xl p-3">
              <div className="text-[11px] font-medium text-slate-400 print:text-gray-600">Zero-Rated / Exempt</div>
              <div className="text-lg font-bold text-amber-300 print:text-black mt-1">
                {money(report.totalExemptSales)}
              </div>
              <div className="text-[10px] text-amber-400/80 mt-0.5">0% exempt staple turnover</div>
            </div>

            <div className="bg-slate-800/80 print:bg-gray-100 border border-slate-700/80 print:border-gray-300 rounded-xl p-3">
              <div className="text-[11px] font-medium text-slate-400 print:text-gray-600">Effective Tax Rate</div>
              <div className="text-lg font-bold text-teal-400 print:text-black mt-1">
                {report.effectiveTaxRate.toFixed(2)}%
              </div>
              <div className="text-[10px] text-teal-300/80 mt-0.5">Tax ÷ Net Taxable Base</div>
            </div>

            <div className="bg-slate-800/80 print:bg-gray-100 border border-slate-700/80 print:border-gray-300 rounded-xl p-3">
              <div className="text-[11px] font-medium text-slate-400 print:text-gray-600">Audited Invoices</div>
              <div className="text-lg font-bold text-white print:text-black mt-1">
                {report.totalTransactions}
              </div>
              <div className="text-[10px] text-slate-400 mt-0.5">Avg {money(report.averageTaxPerTx)} tax/tx</div>
            </div>
          </div>

          {/* Sub-Navigation Tabs (Screen Only) */}
          <div className="flex items-center gap-2 border-b border-slate-800 print:hidden pt-2">
            <button
              onClick={() => setActiveTab('summary')}
              className={`px-3.5 py-2 text-xs font-bold border-b-2 transition-all ${
                activeTab === 'summary'
                  ? 'border-emerald-500 text-emerald-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Multi-Tier Tax Brackets Breakdown
            </button>
            <button
              onClick={() => setActiveTab('daily')}
              className={`px-3.5 py-2 text-xs font-bold border-b-2 transition-all ${
                activeTab === 'daily'
                  ? 'border-emerald-500 text-emerald-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Daily Tax Collections Ledger
            </button>
            <button
              onClick={() => setActiveTab('transactions')}
              className={`px-3.5 py-2 text-xs font-bold border-b-2 transition-all ${
                activeTab === 'transactions'
                  ? 'border-emerald-500 text-emerald-400'
                  : 'border-transparent text-slate-400 hover:text-slate-200'
              }`}
            >
              Itemized Invoice Tax Audit ({report.transactions.length})
            </button>
          </div>

          {/* SECTION 1: MULTI-TIER TAX BREAKDOWN */}
          {(activeTab === 'summary' || activeTab === 'daily' || activeTab === 'transactions') && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="font-bold text-white print:text-black text-sm">
                    Multi-Tier Tax Liability Schedule ({report.periodLabel})
                  </h3>
                  <p className="text-xs text-slate-400 print:text-gray-600">
                    Detailed classification of taxable sales base and output tax across statutory rate tiers.
                  </p>
                </div>
              </div>

              <div className="border border-slate-800 print:border-gray-300 rounded-xl overflow-hidden bg-slate-900/60 print:bg-white">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-800/80 print:bg-gray-100 border-b border-slate-800 print:border-gray-300 text-xs font-semibold text-slate-400 print:text-gray-700">
                        <th className="py-2.5 px-4">Tax Bracket Name</th>
                        <th className="py-2.5 px-3">Statutory Code</th>
                        <th className="py-2.5 px-3">Rate</th>
                        <th className="py-2.5 px-3 text-right">Net Taxable Base</th>
                        <th className="py-2.5 px-3 text-right">Tax Collected</th>
                        <th className="py-2.5 px-3 text-right">Gross Sales</th>
                        <th className="py-2.5 px-3 text-right">Items Sold</th>
                        <th className="py-2.5 px-4 text-right">Share of Total Tax</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 print:divide-gray-200 text-xs">
                      {report.tierBreakdown.map((tb) => (
                        <tr key={tb.tierId} className="hover:bg-slate-800/40 transition-colors">
                          <td className="py-3 px-4">
                            <div className="font-semibold text-white print:text-black flex items-center gap-2">
                              <span>{tb.name}</span>
                              {tb.isExempt && (
                                <span className="px-1.5 py-0.2 rounded-sm bg-amber-500/20 text-amber-300 border border-amber-500/30 text-[10px] font-bold">
                                  EXEMPT
                                </span>
                              )}
                            </div>
                          </td>
                          <td className="py-3 px-3">
                            <span className="px-2 py-0.5 rounded-md bg-slate-800 print:bg-gray-200 border border-slate-700 print:border-gray-300 font-mono text-[11px] text-slate-300 print:text-black">
                              {tb.code}
                            </span>
                          </td>
                          <td className="py-3 px-3 font-bold text-slate-200 print:text-black">
                            {tb.rate.toFixed(1)}%
                          </td>
                          <td className="py-3 px-3 text-right font-medium text-slate-200 print:text-black">
                            {money(tb.taxableBase)}
                          </td>
                          <td className="py-3 px-3 text-right font-bold text-emerald-400 print:text-black">
                            {money(tb.taxCollected)}
                          </td>
                          <td className="py-3 px-3 text-right text-slate-300 print:text-black">
                            {money(tb.grossSales)}
                          </td>
                          <td className="py-3 px-3 text-right text-slate-400 print:text-black">
                            {tb.itemsCount} pcs
                          </td>
                          <td className="py-3 px-4 text-right">
                            <div className="flex items-center justify-end gap-2">
                              <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden print:hidden">
                                <div
                                  className="h-full bg-emerald-500"
                                  style={{ width: `${Math.min(100, tb.shareOfTotalTax)}%` }}
                                />
                              </div>
                              <span className="font-bold text-slate-200 print:text-black text-[11px]">
                                {tb.shareOfTotalTax.toFixed(1)}%
                              </span>
                            </div>
                          </td>
                        </tr>
                      ))}

                      {/* Totals Row */}
                      <tr className="bg-slate-800/70 print:bg-gray-100 font-bold text-white print:text-black border-t-2 border-slate-700 print:border-gray-400">
                        <td className="py-3 px-4" colSpan={3}>
                          TOTAL STATUTORY LIABILITY ({report.taxLabel})
                        </td>
                        <td className="py-3 px-3 text-right">{money(report.totalNetTaxableBase)}</td>
                        <td className="py-3 px-3 text-right text-emerald-400 print:text-black font-black">
                          {money(report.totalTaxCollected)}
                        </td>
                        <td className="py-3 px-3 text-right">{money(report.totalGrossSales)}</td>
                        <td className="py-3 px-3 text-right">
                          {report.tierBreakdown.reduce((acc, t) => acc + t.itemsCount, 0)} pcs
                        </td>
                        <td className="py-3 px-4 text-right">100.0%</td>
                      </tr>
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Payment Method & Channel Breakdown */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-2">
                <div className="bg-slate-800/60 print:bg-gray-50 border border-slate-700/60 print:border-gray-300 rounded-xl p-4 space-y-3">
                  <h4 className="font-bold text-xs text-white print:text-black uppercase tracking-wider">
                    Tax Collected by Payment Channel
                  </h4>
                  <div className="space-y-2">
                    {report.paymentBreakdown.map((pb) => (
                      <div key={pb.payment} className="flex items-center justify-between text-xs">
                        <span className="text-slate-300 print:text-gray-700 font-medium">
                          {pb.payment} ({pb.count} tx)
                        </span>
                        <div className="flex items-center gap-3">
                          <span className="text-slate-400 print:text-gray-500">Sales: {money(pb.sales)}</span>
                          <span className="font-bold text-emerald-400 print:text-black">
                            Tax: {money(pb.tax)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="bg-slate-800/60 print:bg-gray-50 border border-slate-700/60 print:border-gray-300 rounded-xl p-4 space-y-3">
                  <h4 className="font-bold text-xs text-white print:text-black uppercase tracking-wider">
                    Retail vs Wholesale Tax Distribution
                  </h4>
                  <div className="space-y-2">
                    {report.modeBreakdown.map((mb) => (
                      <div key={mb.mode} className="flex items-center justify-between text-xs">
                        <span className="text-slate-300 print:text-gray-700 font-medium">
                          {mb.mode} Channel ({mb.count} sales)
                        </span>
                        <div className="flex items-center gap-3">
                          <span className="text-slate-400 print:text-gray-500">Sales: {money(mb.sales)}</span>
                          <span className="font-bold text-emerald-400 print:text-black">
                            Tax: {money(mb.tax)}
                          </span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 2: DAILY TAX COLLECTIONS LEDGER */}
          {activeTab === 'daily' && (
            <div className="space-y-4 pt-2">
              <h3 className="font-bold text-white print:text-black text-sm">
                Daily Tax Collections Calendar Log ({report.periodLabel})
              </h3>
              <div className="border border-slate-800 print:border-gray-300 rounded-xl overflow-hidden bg-slate-900/60 print:bg-white">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-800/80 print:bg-gray-100 border-b border-slate-800 print:border-gray-300 text-xs font-semibold text-slate-400 print:text-gray-700">
                        <th className="py-2.5 px-4">Date</th>
                        <th className="py-2.5 px-3">Invoices Issued</th>
                        <th className="py-2.5 px-3 text-right">Gross Sales</th>
                        <th className="py-2.5 px-3 text-right">Net Taxable Base</th>
                        <th className="py-2.5 px-4 text-right">Tax Collected</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 print:divide-gray-200 text-xs">
                      {report.dailyBreakdown.length === 0 ? (
                        <tr>
                          <td colSpan={5} className="py-6 text-center text-slate-400">
                            No sales transactions recorded in {report.periodLabel}
                          </td>
                        </tr>
                      ) : (
                        report.dailyBreakdown.map((db) => (
                          <tr key={db.date} className="hover:bg-slate-800/40">
                            <td className="py-2.5 px-4 font-mono font-medium text-white print:text-black">
                              {db.date} (Day {db.dayNumber})
                            </td>
                            <td className="py-2.5 px-3 text-slate-300 print:text-black">{db.invoiceCount} sales</td>
                            <td className="py-2.5 px-3 text-right text-slate-300 print:text-black">{money(db.grossSales)}</td>
                            <td className="py-2.5 px-3 text-right text-slate-300 print:text-black">{money(db.taxableBase)}</td>
                            <td className="py-2.5 px-4 text-right font-bold text-emerald-400 print:text-black">
                              {money(db.taxCollected)}
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* SECTION 3: TRANSACTION AUDIT LIST */}
          {activeTab === 'transactions' && (
            <div className="space-y-4 pt-2">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                <div>
                  <h3 className="font-bold text-white print:text-black text-sm">
                    Itemized Sales & Tax Invoice Register
                  </h3>
                  <p className="text-xs text-slate-400 print:text-gray-600">
                    Every invoice generated during this tax period with applied rates and tax liabilities.
                  </p>
                </div>

                <div className="relative w-full sm:w-64">
                  <Search className="w-4 h-4 absolute left-3 top-2.5 text-slate-400" />
                  <input
                    type="text"
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    placeholder="Search invoice or customer..."
                    className="w-full bg-slate-800 border border-slate-700 rounded-lg pl-9 pr-3 py-1.5 text-xs text-white focus:outline-hidden focus:border-emerald-500"
                  />
                </div>
              </div>

              <div className="border border-slate-800 print:border-gray-300 rounded-xl overflow-hidden bg-slate-900/60 print:bg-white">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-800/80 print:bg-gray-100 border-b border-slate-800 print:border-gray-300 text-xs font-semibold text-slate-400 print:text-gray-700">
                        <th className="py-2.5 px-4">Invoice #</th>
                        <th className="py-2.5 px-3">Date / Time</th>
                        <th className="py-2.5 px-3">Customer</th>
                        <th className="py-2.5 px-3">Payment</th>
                        <th className="py-2.5 px-3 text-right">Tax Base</th>
                        <th className="py-2.5 px-3 text-right">Tax Collected</th>
                        <th className="py-2.5 px-3 text-right">Invoice Total</th>
                        <th className="py-2.5 px-3">Tax Brackets</th>
                        <th className="py-2.5 px-3 text-right print:hidden">Receipt</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-800/60 print:divide-gray-200 text-xs">
                      {filteredTransactions.length === 0 ? (
                        <tr>
                          <td colSpan={9} className="py-8 text-center text-slate-400">
                            No matching invoices found for the selected month and query
                          </td>
                        </tr>
                      ) : (
                        filteredTransactions.map((tx) => (
                          <tr key={tx.id} className="hover:bg-slate-800/40">
                            <td className="py-2.5 px-4 font-mono font-bold text-white print:text-black">
                              {tx.invoice}
                            </td>
                            <td className="py-2.5 px-3 text-slate-400 print:text-black font-mono text-[11px]">
                              {tx.date} {tx.time}
                            </td>
                            <td className="py-2.5 px-3 font-medium text-slate-200 print:text-black">
                              {tx.customer}
                            </td>
                            <td className="py-2.5 px-3">
                              <span className="px-2 py-0.5 rounded-full bg-slate-800 print:bg-gray-200 text-[10px] text-slate-300 print:text-black border border-slate-700 print:border-gray-300">
                                {tx.payment}
                              </span>
                            </td>
                            <td className="py-2.5 px-3 text-right font-medium text-slate-200 print:text-black">
                              {money(tx.taxableBase)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-bold text-emerald-400 print:text-black">
                              {money(tx.taxCollected)}
                            </td>
                            <td className="py-2.5 px-3 text-right font-black text-white print:text-black">
                              {money(tx.total)}
                            </td>
                            <td className="py-2.5 px-3">
                              <div className="flex flex-wrap gap-1">
                                {tx.tiersApplied.map((t) => (
                                  <span
                                    key={t}
                                    className="px-1.5 py-0.2 rounded-sm bg-slate-800 print:bg-gray-200 text-[9px] font-mono text-slate-300 print:text-black border border-slate-700"
                                  >
                                    {t}
                                  </span>
                                ))}
                              </div>
                            </td>
                            <td className="py-2.5 px-3 text-right print:hidden">
                              <button
                                onClick={() => handleViewReceipt(tx.invoice)}
                                className="p-1 rounded text-slate-400 hover:text-emerald-400 hover:bg-slate-800 transition-colors"
                                title="View fiscal receipt"
                              >
                                <Receipt className="w-4 h-4" />
                              </button>
                            </td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          )}

          {/* Official Printable Sign-Off Section */}
          <div className="hidden print:block pt-8 mt-8 border-t-2 border-gray-400 text-xs">
            <div className="grid grid-cols-2 gap-8">
              <div>
                <div className="font-bold uppercase text-gray-900">Taxpayer Declaration:</div>
                <p className="mt-1 text-gray-600 text-[11px] leading-relaxed">
                  I hereby declare that this monthly return reflects the accurate, true and complete sales revenue,
                  deductions, and output tax collected in conformity with statutory revenue regulations.
                </p>
                <div className="mt-8 border-b border-gray-400 w-64"></div>
                <div className="text-[10px] text-gray-500 mt-1">Authorized Officer Signature & Date</div>
              </div>
              <div className="text-right">
                <div className="font-bold uppercase text-gray-900">Revenue Authority Assessment:</div>
                <p className="mt-1 text-gray-600 text-[11px] leading-relaxed">
                  Filing received and logged under registration TIN: {report.tin}.
                </p>
                <div className="mt-8 border-b border-gray-400 w-64 ml-auto"></div>
                <div className="text-[10px] text-gray-500 mt-1">Official Revenue Officer Verification Stamp</div>
              </div>
            </div>
          </div>

        </div>

        {/* Footer */}
        <div className="bg-slate-900 px-5 py-3 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-slate-400 print:hidden">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Audit Status: <strong className="text-emerald-400">Reconciled</strong></span>
            <span>·</span>
            <span>Net Tax Output: <strong className="text-white">{money(report.totalTaxCollected)}</strong></span>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
            <button
              onClick={() => exportMonthlyTaxReportCSV(report)}
              className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold transition-colors flex items-center gap-1.5"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Download CSV</span>
            </button>
            <button
              onClick={() => setIsMonthlyTaxReportModalOpen(false)}
              className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 transition-colors"
            >
              Close
            </button>
          </div>
        </div>

      </div>
    </div>
  );
}
