import React from 'react';
import { X, Printer, CheckCircle2, ShieldCheck, Download } from 'lucide-react';
import { useStore } from '../../context/StoreContext';
import { money } from '../../utils/helpers';

export function TaxReceiptModal() {
  const { lastCompletedSale, setLastCompletedSale, taxSettings } = useStore();

  if (!lastCompletedSale) return null;

  const handlePrint = () => {
    window.print();
  };

  const sale = lastCompletedSale;
  const isCredit = sale.payment === 'Credit';

  return (
    <div className="fixed inset-0 z-50 bg-black/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto print:p-0 print:bg-white">
      <div className="bg-slate-900 border border-emerald-700/50 rounded-2xl w-full max-w-md shadow-2xl overflow-hidden flex flex-col max-h-[92vh] print:max-h-none print:border-none print:bg-white print:text-black print:w-full print:shadow-none animate-in fade-in zoom-in-95 duration-200">
        
        {/* Header - Screen Only */}
        <div className="bg-gradient-to-r from-slate-900 to-slate-850 px-4 py-3 border-b border-slate-800 flex items-center justify-between print:hidden">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-emerald-400" />
            <span className="font-bold text-sm text-white">Official Fiscal Sales Receipt</span>
          </div>
          <button
            onClick={() => setLastCompletedSale(null)}
            className="p-1 rounded-lg text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
          >
            <X className="w-4 h-4" />
          </button>
        </div>

        {/* Receipt Slip Container */}
        <div className="p-6 overflow-y-auto font-mono text-xs space-y-4 bg-slate-950/80 text-slate-200 print:bg-white print:text-black">
          
          {/* Business Tax Header */}
          <div className="text-center space-y-1 border-b border-dashed border-slate-700 print:border-gray-400 pb-4">
            <h3 className="font-black text-sm uppercase tracking-wide text-white print:text-black">
              {taxSettings.registeredBusinessName || 'AIMRAAN GROCERY & GENERAL TRADE'}
            </h3>
            <div className="text-[11px] text-slate-400 print:text-gray-600">
              Taxpayer Identification No. (TIN):
            </div>
            <div className="font-bold text-emerald-400 print:text-black tracking-wider text-xs">
              {taxSettings.taxIdentificationNumber}
            </div>
            <div className="text-[10px] text-slate-400 print:text-gray-500">
              Official Tax Invoice / Fiscal Cash Sale Receipt
            </div>
          </div>

          {/* Invoice Metadata */}
          <div className="grid grid-cols-2 gap-2 text-[11px] border-b border-dashed border-slate-700 print:border-gray-400 pb-3">
            <div>
              <span className="text-slate-400 print:text-gray-500">Invoice:</span>{' '}
              <strong className="text-white print:text-black font-bold">{sale.invoice}</strong>
            </div>
            <div className="text-right">
              <span className="text-slate-400 print:text-gray-500">Date:</span>{' '}
              <span>{sale.date} {sale.time}</span>
            </div>
            <div>
              <span className="text-slate-400 print:text-gray-500">Customer:</span>{' '}
              <span className="text-white print:text-black">{sale.customer}</span>
            </div>
            <div className="text-right">
              <span className="text-slate-400 print:text-gray-500">Channel:</span>{' '}
              <span className="uppercase font-semibold text-emerald-300 print:text-black">{sale.mode}</span>
            </div>
          </div>

          {/* Items Table */}
          <div className="space-y-2 border-b border-dashed border-slate-700 print:border-gray-400 pb-3">
            <div className="flex justify-between font-bold text-slate-400 print:text-gray-600 text-[10px] uppercase pb-1 border-b border-slate-800 print:border-gray-200">
              <span>Item & Tax Tier</span>
              <span className="text-right">Qty × Price = Amount</span>
            </div>

            {sale.items.map((it, idx) => (
              <div key={idx} className="space-y-0.5">
                <div className="flex justify-between font-semibold text-slate-200 print:text-black">
                  <span className="truncate pr-2">{it.name}</span>
                  <span className="whitespace-nowrap font-bold text-white print:text-black">
                    {money(it.qty * it.price)}
                  </span>
                </div>
                <div className="flex justify-between text-[10px] text-slate-400 print:text-gray-600">
                  <span className="px-1 py-0.2 rounded bg-slate-800 print:bg-gray-200 text-slate-300 print:text-black text-[9px] font-mono">
                    [{it.taxCode || 'TAX'}] {it.taxRate !== undefined ? `${it.taxRate}%` : ''}
                  </span>
                  <span>
                    {it.qty} × {money(it.price)}
                  </span>
                </div>
              </div>
            ))}
          </div>

          {/* Subtotal, Discount, Taxes */}
          <div className="space-y-1.5 text-[11px] border-b border-dashed border-slate-700 print:border-gray-400 pb-3">
            <div className="flex justify-between">
              <span className="text-slate-400 print:text-gray-600">Merchandise Subtotal:</span>
              <span className="text-slate-200 print:text-black">{money(sale.subtotal)}</span>
            </div>

            {sale.discount > 0 && (
              <div className="flex justify-between text-amber-400 print:text-black">
                <span>Discount Allowed:</span>
                <span>-{money(sale.discount)}</span>
              </div>
            )}

            {/* Multi-Tier Tax Breakdown Lines */}
            {sale.taxSummary && sale.taxSummary.length > 0 ? (
              <div className="pt-1 border-t border-slate-800 print:border-gray-200 space-y-1">
                {sale.taxSummary.map((ts) => (
                  <div key={ts.tierId} className="flex justify-between text-emerald-400 print:text-black">
                    <span>
                      {ts.code} ({ts.rate}% on {money(ts.taxableAmount)}):
                    </span>
                    <span className="font-semibold">{money(ts.taxAmount)}</span>
                  </div>
                ))}
              </div>
            ) : (
              sale.taxAmount !== undefined && sale.taxAmount > 0 && (
                <div className="flex justify-between text-emerald-400 print:text-black">
                  <span>{taxSettings.taxLabel} Tax:</span>
                  <span className="font-semibold">{money(sale.taxAmount)}</span>
                </div>
              )
            )}

            {sale.taxCalculationMethod === 'inclusive' && (
              <div className="text-[10px] text-slate-400 print:text-gray-500 italic pt-1">
                * Prices are tax-inclusive ({taxSettings.taxLabel} extracted)
              </div>
            )}
          </div>

          {/* Total Payable */}
          <div className="flex justify-between items-baseline pt-1">
            <span className="font-black text-sm uppercase text-white print:text-black">TOTAL PAYABLE:</span>
            <span className="font-black text-base text-emerald-400 print:text-black">
              {money(sale.total)}
            </span>
          </div>

          {/* Payment Details */}
          <div className="bg-slate-900 print:bg-gray-100 p-2.5 rounded-lg text-[11px] flex justify-between items-center border border-slate-800 print:border-gray-300">
            <div>
              <span className="text-slate-400 print:text-gray-600">Settled via:</span>{' '}
              <strong className="text-white print:text-black uppercase">{sale.payment}</strong>
            </div>
            <div className="text-right">
              <span className="text-xs px-2 py-0.5 rounded-full bg-emerald-500/20 text-emerald-300 print:bg-gray-200 print:text-black font-bold">
                {isCredit ? 'CREDIT BOOKED' : 'PAID IN FULL'}
              </span>
            </div>
          </div>

          {/* Fiscal Barcode & Notice */}
          <div className="text-center pt-2 space-y-2">
            <div className="font-mono text-[9px] tracking-widest text-slate-500 print:text-gray-400">
              * * * FISCAL AUDIT SIGNATURE #{sale.invoice} * * *
            </div>
            <div className="h-7 bg-slate-800 print:bg-gray-200 rounded flex items-center justify-center font-mono text-[9px] text-slate-400 print:text-black tracking-widest uppercase">
              ||| | |||| | ||||| ||| |||| || |||||
            </div>
            <div className="text-[9px] text-slate-500 print:text-gray-500">
              Thank you for your business! Goods sold are verified for tax compliance.
            </div>
          </div>

        </div>

        {/* Actions - Screen Only */}
        <div className="bg-slate-900 px-4 py-3 border-t border-slate-800 flex items-center justify-between print:hidden">
          <button
            onClick={() => setLastCompletedSale(null)}
            className="px-3 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs transition-colors"
          >
            Close
          </button>
          <button
            id="print-tax-receipt-btn"
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-4 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors shadow-xs"
          >
            <Printer className="w-4 h-4" />
            <span>Print Fiscal Receipt</span>
          </button>
        </div>

      </div>
    </div>
  );
}
