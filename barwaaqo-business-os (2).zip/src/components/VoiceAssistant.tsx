import React, { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, AlertCircle } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const VoiceAssistant: React.FC = () => {
  const [isListening, setIsListening] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);
  const recognitionRef = useRef<any>(null);
  const { setActiveTab, setIsSearchOpen, showToast } = useStore();

  useEffect(() => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (SpeechRecognition) {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = false;
      recognition.lang = 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        setError(null);
      };

      recognition.onresult = (event: any) => {
        const text = event.results[0][0].transcript.toLowerCase();
        setTranscript(text);
        processCommand(text);
      };

      recognition.onerror = (event: any) => {
        console.warn('Speech recognition error', event.error);
        if (event.error !== 'no-speech') {
          setError(event.error);
        }
        setIsListening(false);
      };

      recognition.onend = () => {
        setIsListening(false);
      };

      recognitionRef.current = recognition;
    }
  }, []);

  const processCommand = (cmd: string) => {
    // Basic NLP pattern matching for the CEO commands
    if (cmd.includes('stock') || cmd.includes('inventory')) {
      setActiveTab('inventory');
      showToast('Opening Inventory view...');
    } else if (cmd.includes('order') || cmd.includes('sale') || cmd.includes('pos')) {
      setActiveTab('pos');
      showToast('Opening Point of Sale...');
    } else if (cmd.includes('dashboard') || cmd.includes('home')) {
      setActiveTab('dashboard');
      showToast('Opening Dashboard...');
    } else if (cmd.includes('search')) {
      setIsSearchOpen(true);
      showToast('Opening Search...');
    } else if (cmd.includes('finance') || cmd.includes('capital') || cmd.includes('vault') || cmd.includes('cash')) {
      setActiveTab('finance');
      showToast('Opening Vault & Ledger...');
    } else if (cmd.includes('staff') || cmd.includes('team') || cmd.includes('security') || cmd.includes('settings') || cmd.includes('enterprise')) {
      setActiveTab('enterprise');
      showToast('Opening Operations & Security...');
    } else {
      showToast(`Command not recognized: "${cmd}"`);
    }
    
    // Clear transcript after a short delay
    setTimeout(() => {
      setTranscript('');
    }, 3000);
  };

  const toggleListening = () => {
    if (!recognitionRef.current) {
      setError('Speech recognition not supported in this browser.');
      showToast('Speech recognition not supported in this browser.');
      return;
    }

    if (isListening) {
      recognitionRef.current.stop();
    } else {
      try {
        recognitionRef.current.start();
      } catch (e) {
        console.warn(e);
      }
    }
  };

  return (
    <div className="relative">
      <button
        onClick={toggleListening}
        className={`p-2 rounded-full transition-all flex items-center justify-center border ${
          isListening
            ? 'bg-rose-500 hover:bg-rose-600 text-white border-rose-400 shadow-md shadow-rose-500/20 animate-pulse'
            : 'bg-white/10 hover:bg-white/20 text-emerald-100 border-white/20'
        }`}
        title="Voice Assistant"
      >
        {isListening ? <Mic className="w-5 h-5" /> : <MicOff className="w-5 h-5" />}
      </button>

      {/* Popover for feedback */}
      {(isListening || transcript || error) && (
        <div className="absolute top-full right-0 mt-2 w-48 p-3 rounded-xl bg-slate-900 border border-slate-700 shadow-xl z-50">
          {error ? (
            <div className="flex items-center gap-2 text-rose-400 text-xs">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          ) : isListening ? (
            <div className="flex items-center gap-2 text-emerald-400 text-xs">
              <span className="relative flex h-2 w-2 shrink-0">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500"></span>
              </span>
              <span>Listening...</span>
            </div>
          ) : transcript ? (
            <div className="text-xs text-white">
              <span className="text-slate-400">Heard: </span>
              <span className="font-medium italic">"{transcript}"</span>
            </div>
          ) : null}
        </div>
      )}
    </div>
  );
};
