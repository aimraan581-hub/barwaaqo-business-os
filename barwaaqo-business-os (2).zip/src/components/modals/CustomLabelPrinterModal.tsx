import React, { useState, useEffect, useRef } from 'react';
import QRCode from 'qrcode';
import JsBarcode from 'jsbarcode';
import { Product } from '../../types';
import { money } from '../../utils/helpers';
import { useStore } from '../../context/StoreContext';
import {
  X,
  Printer,
  Barcode,
  QrCode,
  Layers,
  Settings2,
  Download,
  Copy,
  Check,
  Tag,
  CheckSquare,
  Square,
  Sparkles,
  Info,
  Sliders,
  ExternalLink,
} from 'lucide-react';

export type LabelPreset = '50x30' | '60x40' | '40x25' | '76x51' | 'a4_sheet';
export type CodeFormat = 'dual' | 'barcode' | 'qr';

interface LabelDimensions {
  widthMm: number;
  heightMm: number;
  name: string;
  desc: string;
  isSheet?: boolean;
}

const PRESET_CONFIGS: Record<LabelPreset, LabelDimensions> = {
  '50x30': {
    widthMm: 50,
    heightMm: 30,
    name: '50 × 30 mm (2" × 1.2")',
    desc: 'Standard thermal retail shelf tag & barcode sticker',
  },
  '60x40': {
    widthMm: 60,
    heightMm: 40,
    name: '60 × 40 mm (2.4" × 1.6")',
    desc: 'Standard shelf edge tag with dual QR & 1D barcode',
  },
  '40x25': {
    widthMm: 40,
    heightMm: 25,
    name: '40 × 25 mm (1.5" × 1")',
    desc: 'Compact price tag for cosmetics, snacks & small items',
  },
  '76x51': {
    widthMm: 76,
    heightMm: 51,
    name: '76 × 51 mm (3" × 2")',
    desc: 'Warehouse carton, pallet & distribution bin label',
  },
  a4_sheet: {
    widthMm: 210,
    heightMm: 297,
    name: 'A4 Sheet (3 × 7 Grid)',
    desc: '21 labels per sheet for standard office laser/inkjet printers',
    isSheet: true,
  },
};

interface CustomLabelPrinterModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  initialProductId?: string | null;
}

export const CustomLabelPrinterModal: React.FC<CustomLabelPrinterModalProps> = ({
  isOpen,
  onClose,
  products,
  initialProductId,
}) => {
  const { businessProfile } = useStore();

  // Mode: 'single' (print 1 or N copies of one product) or 'batch' (select multiple products)
  const [printMode, setPrintMode] = useState<'single' | 'batch'>('single');
  const [selectedProductId, setSelectedProductId] = useState<string>(
    initialProductId || (products[0]?.id ?? '')
  );
  const [copies, setCopies] = useState<number>(1);

  // Batch selection
  const [batchSelection, setBatchSelection] = useState<Record<string, number>>({});
  const [batchFilter, setBatchFilter] = useState<'all' | 'in_stock'>('all');
  const [batchSearch, setBatchSearch] = useState<string>('');

  // Preset & Code format
  const [preset, setPreset] = useState<LabelPreset>('50x30');
  const [codeFormat, setCodeFormat] = useState<CodeFormat>('dual');

  // Customization Toggles
  const [storeHeader, setStoreHeader] = useState<string>(businessProfile.storeName || 'BARWAAQO');
  const [showStoreHeader, setShowStoreHeader] = useState<boolean>(true);
  const [showRetailPrice, setShowRetailPrice] = useState<boolean>(true);
  const [showWholesalePrice, setShowWholesalePrice] = useState<boolean>(false);
  const [showUnit, setShowUnit] = useState<boolean>(true);
  const [showSkuText, setShowSkuText] = useState<boolean>(true);
  const [shelfLocation, setShelfLocation] = useState<string>('');
  const [showLocation, setShowLocation] = useState<boolean>(false);
  const [batchDate, setBatchDate] = useState<string>(new Date().toISOString().slice(0, 10));
  const [showDate, setShowDate] = useState<boolean>(false);

  // Rendered Data URLs for preview
  const [previewQrUrl, setPreviewQrUrl] = useState<string>('');
  const [previewBarcodeUrl, setPreviewBarcodeUrl] = useState<string>('');
  const [isGenerating, setIsGenerating] = useState<boolean>(false);

  // Reference for single product
  const activeProduct = products.find((p) => p.id === selectedProductId) || products[0];

  // Initialize selection when opening
  useEffect(() => {
    if (!isOpen) return;
    if (initialProductId && products.some((p) => p.id === initialProductId)) {
      setSelectedProductId(initialProductId);
      setPrintMode('single');
    } else if (products.length > 0 && !selectedProductId) {
      setSelectedProductId(products[0].id);
    }

    // Default batch selection: 1 copy for each product
    const initialBatch: Record<string, number> = {};
    products.forEach((p) => {
      initialBatch[p.id] = 1;
    });
    setBatchSelection(initialBatch);

    if (businessProfile.storeName) {
      setStoreHeader(businessProfile.storeName);
    }
  }, [isOpen, initialProductId, products, businessProfile.storeName]);

  // Helper to generate barcode canvas DataURL using JsBarcode
  const generateBarcodeDataUrl = (codeText: string): string => {
    try {
      const canvas = document.createElement('canvas');
      const safeCode = codeText.trim() || 'BARWAAQO-001';
      JsBarcode(canvas, safeCode, {
        format: 'CODE128',
        lineColor: '#000000',
        width: 2,
        height: 48,
        displayValue: false, // We render the text with custom typography in the label HTML
        margin: 0,
      });
      return canvas.toDataURL('image/png');
    } catch (err) {
      console.warn('JsBarcode render fallback for code', codeText, err);
      // Fallback with simple CODE128 representation
      try {
        const canvas = document.createElement('canvas');
        JsBarcode(canvas, 'ITEM-12345', {
          format: 'CODE128',
          lineColor: '#000000',
          width: 2,
          height: 48,
          displayValue: false,
          margin: 0,
        });
        return canvas.toDataURL('image/png');
      } catch {
        return '';
      }
    }
  };

  // Helper to generate QR DataURL
  const generateQrDataUrl = async (productId: string, sku: string): Promise<string> => {
    try {
      const baseUrl =
        typeof window !== 'undefined' ? window.location.origin + window.location.pathname : '';
      const deepLink = `${baseUrl}?product=${encodeURIComponent(productId)}&sku=${encodeURIComponent(
        sku
      )}`;
      return await QRCode.toDataURL(deepLink, {
        width: 180,
        margin: 0,
        color: { dark: '#000000', light: '#ffffff' },
        errorCorrectionLevel: 'M',
      });
    } catch (e) {
      console.error('QR code generation failed', e);
      return '';
    }
  };

  // Update live preview when active product or code format changes
  useEffect(() => {
    if (!isOpen || !activeProduct) return;
    let isCancelled = false;

    const updatePreview = async () => {
      setIsGenerating(true);
      const barcodeValue = activeProduct.sku || activeProduct.id.slice(0, 10);
      const bDataUrl = generateBarcodeDataUrl(barcodeValue);
      const qDataUrl = await generateQrDataUrl(activeProduct.id, barcodeValue);

      if (!isCancelled) {
        setPreviewBarcodeUrl(bDataUrl);
        setPreviewQrUrl(qDataUrl);
        setIsGenerating(false);
      }
    };

    updatePreview();

    return () => {
      isCancelled = true;
    };
  }, [isOpen, activeProduct, codeFormat]);

  if (!isOpen) return null;

  // Calculate items to print
  const getItemsToPrint = (): Array<{ product: Product; quantity: number }> => {
    if (printMode === 'single') {
      if (!activeProduct) return [];
      return [{ product: activeProduct, quantity: Math.max(1, copies) }];
    } else {
      return products
        .filter((p) => (batchSelection[p.id] || 0) > 0)
        .map((p) => ({ product: p, quantity: batchSelection[p.id] || 1 }));
    }
  };

  const totalLabelsCount = getItemsToPrint().reduce((sum, item) => sum + item.quantity, 0);

  // Execute Direct Printing
  const handlePrint = async () => {
    const items = getItemsToPrint();
    if (items.length === 0) return;

    setIsGenerating(true);

    // Pre-generate all barcodes and QR codes needed for printing
    const barcodesMap: Record<string, string> = {};
    const qrMap: Record<string, string> = {};

    for (const item of items) {
      const p = item.product;
      const codeVal = p.sku || p.id.slice(0, 10);
      if (!barcodesMap[p.id]) {
        barcodesMap[p.id] = generateBarcodeDataUrl(codeVal);
      }
      if (!qrMap[p.id]) {
        qrMap[p.id] = await generateQrDataUrl(p.id, codeVal);
      }
    }

    setIsGenerating(false);

    const printWindow = window.open('', '_blank');
    if (!printWindow) {
      alert('Pop-up window was blocked. Please allow pop-ups for this site to print labels.');
      return;
    }

    const cfg = PRESET_CONFIGS[preset];
    const isSheet = cfg.isSheet;

    // Build flattened array of labels
    const flattenedLabels: Product[] = [];
    items.forEach(({ product, quantity }) => {
      for (let i = 0; i < quantity; i++) {
        flattenedLabels.push(product);
      }
    });

    const storeTitleHtml = showStoreHeader
      ? `<div class="store-hdr">
          <span>${storeHeader}</span>
          <span class="tag-pill">STOCK VERIFIED</span>
        </div>`
      : '';

    const locationHtml = (loc: string) =>
      showLocation && loc
        ? `<div class="meta-row"><span>LOC:</span> <strong>${loc}</strong></div>`
        : '';

    const dateHtml = showDate
      ? `<div class="meta-row"><span>BATCH / DATE:</span> <strong>${batchDate}</strong></div>`
      : '';

    const renderLabelInner = (p: Product) => {
      const bImg = barcodesMap[p.id] || '';
      const qImg = qrMap[p.id] || '';
      const skuVal = p.sku || 'NONE';

      // Codes layout based on codeFormat
      let codesHtml = '';
      if (codeFormat === 'dual') {
        codesHtml = `
          <div class="codes-dual">
            <div class="qr-wrap">
              <img src="${qImg}" class="qr-img" alt="QR" />
            </div>
            <div class="barcode-wrap">
              <img src="${bImg}" class="barcode-img" alt="Barcode" />
              ${showSkuText ? `<div class="sku-text">${skuVal}</div>` : ''}
            </div>
          </div>
        `;
      } else if (codeFormat === 'barcode') {
        codesHtml = `
          <div class="codes-barcode-only">
            <img src="${bImg}" class="barcode-full" alt="Barcode" />
            ${showSkuText ? `<div class="sku-text-center">${skuVal}</div>` : ''}
          </div>
        `;
      } else {
        codesHtml = `
          <div class="codes-qr-only">
            <img src="${qImg}" class="qr-large" alt="QR" />
            ${showSkuText ? `<div class="sku-text-center">SKU: ${skuVal}</div>` : ''}
          </div>
        `;
      }

      return `
        <div class="label-card ${preset}">
          ${storeTitleHtml}
          <div class="prod-name">${p.name}</div>
          ${codesHtml}
          <div class="price-row">
            ${
              showRetailPrice
                ? `<div class="retail-price">
                    <span class="currency">$</span>${money(p.sell).replace('$', '')}
                    ${showUnit ? `<span class="unit-text">/${p.unit}</span>` : ''}
                  </div>`
                : '<div></div>'
            }
            ${
              showWholesalePrice && p.wholesale
                ? `<div class="ws-badge">WS: ${money(p.wholesale)}</div>`
                : ''
            }
          </div>
          ${
            showLocation || showDate
              ? `<div class="footer-meta">
                  ${locationHtml(shelfLocation || 'SHELF')}
                  ${dateHtml}
                </div>`
              : ''
          }
        </div>
      `;
    };

    const stylesHtml = isSheet
      ? `
        @page {
          size: A4 portrait;
          margin: 8mm;
        }
        * {
          box-sizing: border-box;
        }
        body {
          margin: 0;
          padding: 0;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
          background: #fff;
          color: #000;
        }
        .sheet-grid {
          display: grid;
          grid-template-columns: repeat(3, 1fr);
          gap: 3mm 4mm;
        }
        .label-card {
          border: 1px dashed #999;
          border-radius: 4px;
          padding: 4px 6px;
          height: 38mm;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          break-inside: avoid;
        }
      `
      : `
        @page {
          size: ${cfg.widthMm}mm ${cfg.heightMm}mm;
          margin: 0;
        }
        * {
          box-sizing: border-box;
        }
        body {
          margin: 0;
          padding: 0;
          background: #fff;
          color: #000;
          font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Arial, sans-serif;
        }
        .label-card {
          width: ${cfg.widthMm}mm;
          height: ${cfg.heightMm}mm;
          padding: 2.5mm;
          display: flex;
          flex-direction: column;
          justify-content: space-between;
          page-break-after: always;
          break-after: page;
          overflow: hidden;
        }
      `;

    const commonCardStyles = `
      .store-hdr {
        display: flex;
        justify-content: space-between;
        align-items: center;
        font-size: 7.5px;
        font-weight: 800;
        text-transform: uppercase;
        letter-spacing: 0.5px;
        border-bottom: 1px solid #000;
        padding-bottom: 1.5px;
        margin-bottom: 2px;
      }
      .tag-pill {
        font-size: 6px;
        font-weight: 900;
        border: 0.5px solid #000;
        padding: 0.5px 2px;
        border-radius: 2px;
      }
      .prod-name {
        font-size: 10px;
        font-weight: 900;
        line-height: 1.15;
        max-height: 22px;
        overflow: hidden;
        text-overflow: ellipsis;
        display: -webkit-box;
        -webkit-line-clamp: 2;
        -webkit-box-orient: vertical;
        margin-bottom: 1.5px;
      }
      .codes-dual {
        display: flex;
        align-items: center;
        gap: 3mm;
        margin: 1px 0;
        flex: 1;
      }
      .qr-wrap {
        width: 16mm;
        height: 16mm;
        flex-shrink: 0;
      }
      .qr-img {
        width: 100%;
        height: 100%;
        display: block;
      }
      .barcode-wrap {
        flex: 1;
        min-width: 0;
        display: flex;
        flex-direction: column;
        justify-content: center;
      }
      .barcode-img {
        width: 100%;
        height: 11mm;
        display: block;
        object-fit: fill;
      }
      .barcode-full {
        width: 100%;
        height: 13mm;
        display: block;
        object-fit: fill;
      }
      .qr-large {
        width: 18mm;
        height: 18mm;
        display: block;
        margin: 0 auto;
      }
      .sku-text {
        font-family: monospace;
        font-size: 7.5px;
        font-weight: 700;
        letter-spacing: 0.5px;
        text-align: center;
        margin-top: 1px;
      }
      .sku-text-center {
        font-family: monospace;
        font-size: 8px;
        font-weight: 700;
        text-align: center;
        margin-top: 1.5px;
      }
      .price-row {
        display: flex;
        align-items: baseline;
        justify-content: space-between;
        margin-top: 1px;
      }
      .retail-price {
        font-size: 15px;
        font-weight: 900;
        letter-spacing: -0.5px;
        line-height: 1;
      }
      .currency {
        font-size: 10px;
        font-weight: 800;
        margin-right: 1px;
      }
      .unit-text {
        font-size: 8.5px;
        font-weight: 600;
        color: #333;
        margin-left: 2px;
      }
      .ws-badge {
        font-size: 8px;
        font-weight: 800;
        background: #eee;
        padding: 1px 3px;
        border-radius: 2px;
      }
      .footer-meta {
        border-top: 0.5px dashed #666;
        padding-top: 1px;
        margin-top: 2px;
        display: flex;
        justify-content: space-between;
        font-size: 6px;
        color: #333;
      }
      .meta-row {
        display: flex;
        gap: 2px;
      }
    `;

    const fullHtml = `
      <!DOCTYPE html>
      <html>
        <head>
          <meta charset="utf-8" />
          <title>${storeHeader} - Product Labels (${flattenedLabels.length} pcs)</title>
          <style>
            ${stylesHtml}
            ${commonCardStyles}
          </style>
        </head>
        <body>
          ${
            isSheet
              ? `<div class="sheet-grid">${flattenedLabels.map((p) => renderLabelInner(p)).join('')}</div>`
              : flattenedLabels.map((p) => renderLabelInner(p)).join('')
          }
          <script>
            window.onload = function() {
              setTimeout(function() {
                window.print();
                setTimeout(function() { window.close(); }, 700);
              }, 300);
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.open();
    printWindow.document.write(fullHtml);
    printWindow.document.close();
  };

  // Download Single Label as PNG
  const handleDownloadSinglePng = () => {
    if (!activeProduct) return;
    const canvas = document.createElement('canvas');
    const widthPx = PRESET_CONFIGS[preset].widthMm * 10; // 10px per mm ~ 254 DPI
    const heightPx = PRESET_CONFIGS[preset].heightMm * 10;
    canvas.width = widthPx;
    canvas.height = heightPx;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Draw white background
    ctx.fillStyle = '#ffffff';
    ctx.fillRect(0, 0, widthPx, heightPx);

    // Border
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 3;
    ctx.strokeRect(10, 10, widthPx - 20, heightPx - 20);

    // Header
    if (showStoreHeader) {
      ctx.fillStyle = '#000000';
      ctx.font = 'bold 20px -apple-system, sans-serif';
      ctx.fillText(storeHeader.toUpperCase(), 25, 42);
      ctx.font = 'bold 16px -apple-system, sans-serif';
      ctx.fillText('STOCK LABEL', widthPx - 150, 42);

      ctx.beginPath();
      ctx.moveTo(25, 52);
      ctx.lineTo(widthPx - 25, 52);
      ctx.stroke();
    }

    // Product Title
    ctx.fillStyle = '#000000';
    ctx.font = '900 24px -apple-system, sans-serif';
    ctx.fillText(activeProduct.name.slice(0, 26), 25, 88);

    // Draw Barcode & QR Code
    const bImg = new Image();
    bImg.src = previewBarcodeUrl;
    bImg.onload = () => {
      ctx.drawImage(bImg, 25, 110, widthPx - 180, 80);

      // SKU text below barcode
      if (showSkuText) {
        ctx.font = 'bold 18px monospace';
        ctx.textAlign = 'center';
        ctx.fillText(activeProduct.sku || activeProduct.id, (widthPx - 180) / 2 + 25, 215);
        ctx.textAlign = 'left';
      }

      // Retail Price
      if (showRetailPrice) {
        ctx.font = '900 42px -apple-system, sans-serif';
        ctx.fillText(money(activeProduct.sell), 25, heightPx - 25);
        if (showUnit) {
          ctx.font = 'bold 20px -apple-system, sans-serif';
          ctx.fillText(`/${activeProduct.unit}`, 180, heightPx - 25);
        }
      }

      // Draw QR Code
      const qImg = new Image();
      qImg.src = previewQrUrl;
      qImg.onload = () => {
        ctx.drawImage(qImg, widthPx - 150, 105, 125, 125);

        // Download trigger
        const a = document.createElement('a');
        a.href = canvas.toDataURL('image/png');
        a.download = `Label-${(activeProduct.sku || activeProduct.name).replace(/\s+/g, '_')}.png`;
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
      };
    };
  };

  // Filtered products for batch mode
  const filteredBatchProducts = products.filter((p) => {
    if (batchFilter === 'in_stock' && p.stock <= 0) return false;
    if (
      batchSearch.trim() &&
      !`${p.name} ${p.sku} ${p.unit}`.toLowerCase().includes(batchSearch.toLowerCase().trim())
    ) {
      return false;
    }
    return true;
  });

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-3 sm:p-5 overflow-y-auto">
      <div className="relative w-full max-w-5xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-auto flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="bg-gradient-to-r from-slate-950 via-emerald-950 to-slate-900 text-white p-4 sm:p-5 flex items-center justify-between shrink-0 border-b border-emerald-500/30">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30 shadow-inner">
              <Printer className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-black text-lg tracking-tight text-white">
                  Custom Barcode & QR Label Printer
                </h3>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-800/80 text-emerald-200 border border-emerald-500/40">
                  Standard Label Printers
                </span>
              </div>
              <p className="text-xs text-emerald-100/80 mt-0.5">
                Direct integration for Zebra, Brother, Dymo, Xprinter, MUNBYN & standard A4 sheet label papers
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition cursor-pointer"
            title="Close"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selector: Single Product vs Batch Print */}
        <div className="px-5 pt-3 pb-2 bg-slate-50 border-b border-slate-200 flex items-center justify-between flex-wrap gap-2 shrink-0">
          <div className="flex items-center gap-1.5 p-1 bg-slate-200/80 rounded-xl">
            <button
              onClick={() => setPrintMode('single')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                printMode === 'single'
                  ? 'bg-white text-emerald-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Tag className="w-3.5 h-3.5" />
              <span>Single Product Label</span>
            </button>
            <button
              onClick={() => setPrintMode('batch')}
              className={`px-3 py-1.5 rounded-lg text-xs font-bold transition flex items-center gap-1.5 ${
                printMode === 'batch'
                  ? 'bg-white text-emerald-900 shadow-sm'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              <Layers className="w-3.5 h-3.5" />
              <span>Batch Multi-Product Print</span>
              <span className="text-[10px] px-1.5 py-0.2 rounded-full bg-emerald-100 text-emerald-800 font-extrabold">
                {products.length}
              </span>
            </button>
          </div>

          <div className="flex items-center gap-2 text-xs">
            <span className="text-slate-500">Total Labels:</span>
            <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-950 font-black tabular-nums border border-emerald-300/80">
              {totalLabelsCount} {totalLabelsCount === 1 ? 'sticker' : 'stickers'}
            </span>
          </div>
        </div>

        {/* Modal Main Content (Scrollable Grid) */}
        <div className="p-4 sm:p-6 overflow-y-auto flex-1 grid grid-cols-1 lg:grid-cols-12 gap-5">
          {/* Left / Config Column (7 Cols) */}
          <div className="lg:col-span-7 space-y-4">
            {/* 1. Product Selection */}
            {printMode === 'single' ? (
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between">
                  <label className="text-xs font-extrabold text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                    <Tag className="w-4 h-4 text-emerald-700" />
                    Target Product & Copies
                  </label>
                  {activeProduct && (
                    <span className="text-[11px] font-bold text-slate-500">
                      On-Hand Stock: <strong>{activeProduct.stock} {activeProduct.unit}</strong>
                    </span>
                  )}
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <select
                      value={selectedProductId}
                      onChange={(e) => setSelectedProductId(e.target.value)}
                      className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold text-xs bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                    >
                      {products.map((p) => (
                        <option key={p.id} value={p.id}>
                          {p.name} ({money(p.sell)}) — SKU: {p.sku || 'No SKU'}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <input
                      type="number"
                      min={1}
                      max={500}
                      value={copies}
                      onChange={(e) => setCopies(Math.max(1, parseInt(e.target.value) || 1))}
                      className="w-20 px-2.5 py-2 rounded-xl border border-slate-300 font-extrabold text-xs text-center focus:ring-2 focus:ring-emerald-500"
                      title="Number of stickers to print"
                    />
                    <button
                      type="button"
                      onClick={() => setCopies(Math.max(1, activeProduct?.stock || 1))}
                      className="px-2 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-700 text-[10px] font-bold transition flex-1 text-center"
                      title="Set copies to match current inventory quantity"
                    >
                      Match Stock
                    </button>
                  </div>
                </div>

                {/* Quick Copies Pills */}
                <div className="flex items-center gap-1.5 flex-wrap pt-1">
                  <span className="text-[10px] text-slate-400 font-bold uppercase">Quick Copies:</span>
                  {[1, 5, 10, 25, 50].map((num) => (
                    <button
                      key={num}
                      type="button"
                      onClick={() => setCopies(num)}
                      className={`px-2 py-0.5 rounded-lg text-xs font-bold transition ${
                        copies === num
                          ? 'bg-emerald-700 text-white shadow-xs'
                          : 'bg-white border border-slate-200 text-slate-700 hover:bg-slate-100'
                      }`}
                    >
                      {num}
                    </button>
                  ))}
                </div>
              </div>
            ) : (
              /* Batch Multi-Product Table */
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center justify-between flex-wrap gap-2">
                  <label className="text-xs font-extrabold text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                    <Layers className="w-4 h-4 text-emerald-700" />
                    Select Products & Quantities for Batch
                  </label>
                  <div className="flex items-center gap-1.5">
                    <button
                      type="button"
                      onClick={() => {
                        const next: Record<string, number> = {};
                        products.forEach((p) => {
                          next[p.id] = 1;
                        });
                        setBatchSelection(next);
                      }}
                      className="px-2 py-1 rounded-md bg-white border border-slate-300 text-[10px] font-bold text-slate-700 hover:bg-slate-100"
                    >
                      Select All (1 ea)
                    </button>
                    <button
                      type="button"
                      onClick={() => {
                        const next: Record<string, number> = {};
                        products.forEach((p) => {
                          next[p.id] = Math.max(1, p.stock || 1);
                        });
                        setBatchSelection(next);
                      }}
                      className="px-2 py-1 rounded-md bg-emerald-100 border border-emerald-300 text-[10px] font-bold text-emerald-900 hover:bg-emerald-200"
                    >
                      Match Stock
                    </button>
                    <button
                      type="button"
                      onClick={() => setBatchSelection({})}
                      className="px-2 py-1 rounded-md bg-white border border-slate-300 text-[10px] font-bold text-slate-700 hover:bg-slate-100"
                    >
                      Clear
                    </button>
                  </div>
                </div>

                {/* Batch Filter & Search */}
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    placeholder="Search products by name or SKU..."
                    value={batchSearch}
                    onChange={(e) => setBatchSearch(e.target.value)}
                    className="flex-1 px-3 py-1.5 rounded-xl border border-slate-300 text-xs font-medium bg-white"
                  />
                  <button
                    type="button"
                    onClick={() => setBatchFilter(batchFilter === 'all' ? 'in_stock' : 'all')}
                    className={`px-2.5 py-1.5 rounded-xl text-xs font-bold border transition ${
                      batchFilter === 'in_stock'
                        ? 'bg-emerald-700 text-white border-emerald-700'
                        : 'bg-white border-slate-300 text-slate-700'
                    }`}
                  >
                    In-Stock Only
                  </button>
                </div>

                {/* Batch Product List */}
                <div className="max-h-48 overflow-y-auto space-y-1.5 pr-1 divide-y divide-slate-100">
                  {filteredBatchProducts.map((p) => {
                    const count = batchSelection[p.id] || 0;
                    const isSelected = count > 0;
                    return (
                      <div
                        key={p.id}
                        className={`pt-1.5 flex items-center justify-between gap-2 text-xs ${
                          isSelected ? 'bg-emerald-50/50 p-1.5 rounded-xl' : 'p-1'
                        }`}
                      >
                        <div
                          className="flex items-center gap-2 flex-1 min-w-0 cursor-pointer"
                          onClick={() => {
                            setBatchSelection((prev) => ({
                              ...prev,
                              [p.id]: prev[p.id] ? 0 : 1,
                            }));
                          }}
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                          ) : (
                            <Square className="w-4 h-4 text-slate-300 shrink-0" />
                          )}
                          <div className="min-w-0">
                            <div className="font-bold text-slate-900 truncate">{p.name}</div>
                            <div className="text-[10px] text-slate-500">
                              SKU: {p.sku || 'No SKU'} · Stock: {p.stock} {p.unit} · {money(p.sell)}
                            </div>
                          </div>
                        </div>

                        <div className="flex items-center gap-1 shrink-0">
                          <span className="text-[10px] text-slate-400 font-bold">Qty:</span>
                          <input
                            type="number"
                            min={0}
                            max={500}
                            value={count}
                            onChange={(e) => {
                              const val = Math.max(0, parseInt(e.target.value) || 0);
                              setBatchSelection((prev) => ({
                                ...prev,
                                [p.id]: val,
                              }));
                            }}
                            className="w-14 px-1.5 py-1 rounded-lg border border-slate-300 text-xs font-black text-center bg-white"
                          />
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            )}

            {/* 2. Standard Label Size Presets */}
            <div className="space-y-2">
              <label className="text-xs font-extrabold text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                <Sliders className="w-4 h-4 text-emerald-700" />
                Standard Label Printer Size Presets
              </label>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {(Object.keys(PRESET_CONFIGS) as LabelPreset[]).map((key) => {
                  const cfg = PRESET_CONFIGS[key];
                  const isSelected = preset === key;
                  return (
                    <button
                      key={key}
                      type="button"
                      onClick={() => setPreset(key)}
                      className={`p-3 rounded-2xl border text-left transition-all ${
                        isSelected
                          ? 'bg-emerald-950 text-white border-emerald-600 shadow-md ring-2 ring-emerald-500/40'
                          : 'bg-white hover:bg-slate-50 border-slate-200 text-slate-800'
                      }`}
                    >
                      <div className="font-black text-xs flex items-center justify-between">
                        <span>{cfg.name}</span>
                        {cfg.isSheet && (
                          <span
                            className={`text-[9px] px-1 py-0.2 rounded ${
                              isSelected ? 'bg-emerald-800 text-emerald-100' : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            A4 Sheet
                          </span>
                        )}
                      </div>
                      <p
                        className={`text-[10px] mt-1 leading-tight line-clamp-2 ${
                          isSelected ? 'text-emerald-200/80' : 'text-slate-500'
                        }`}
                      >
                        {cfg.desc}
                      </p>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* 3. Barcode & QR Code Engine Selector */}
            <div className="space-y-2">
              <label className="text-xs font-extrabold text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                <Barcode className="w-4 h-4 text-emerald-700" />
                Scannable Code Format
              </label>

              <div className="grid grid-cols-3 gap-2">
                <button
                  type="button"
                  onClick={() => setCodeFormat('dual')}
                  className={`p-2.5 rounded-xl border text-left transition ${
                    codeFormat === 'dual'
                      ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-1.5 font-black text-xs">
                    <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                    <span>Dual QR + Barcode</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5">Best for retail & camera</p>
                </button>

                <button
                  type="button"
                  onClick={() => setCodeFormat('barcode')}
                  className={`p-2.5 rounded-xl border text-left transition ${
                    codeFormat === 'barcode'
                      ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-1.5 font-black text-xs">
                    <Barcode className="w-3.5 h-3.5 text-emerald-400" />
                    <span>1D Barcode (Code128)</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5">Laser & gun scanners</p>
                </button>

                <button
                  type="button"
                  onClick={() => setCodeFormat('qr')}
                  className={`p-2.5 rounded-xl border text-left transition ${
                    codeFormat === 'qr'
                      ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                      : 'bg-white border-slate-200 text-slate-700 hover:bg-slate-50'
                  }`}
                >
                  <div className="flex items-center gap-1.5 font-black text-xs">
                    <QrCode className="w-3.5 h-3.5 text-teal-400" />
                    <span>2D QR Code Only</span>
                  </div>
                  <p className="text-[10px] text-slate-400 mt-0.5">Direct system link</p>
                </button>
              </div>
            </div>

            {/* 4. Custom Field Toggles & Metadata */}
            <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
              <label className="text-xs font-extrabold text-slate-800 uppercase tracking-wide flex items-center gap-1.5">
                <Settings2 className="w-4 h-4 text-emerald-700" />
                Custom Label Elements
              </label>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 text-xs">
                <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={showStoreHeader}
                    onChange={(e) => setShowStoreHeader(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Store Name Header</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={showRetailPrice}
                    onChange={(e) => setShowRetailPrice(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Retail Price</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={showWholesalePrice}
                    onChange={(e) => setShowWholesalePrice(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Wholesale Price</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={showSkuText}
                    onChange={(e) => setShowSkuText(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Human-Readable SKU</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={showLocation}
                    onChange={(e) => setShowLocation(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Aisle / Shelf Location</span>
                </label>

                <label className="flex items-center gap-2 cursor-pointer font-bold text-slate-700">
                  <input
                    type="checkbox"
                    checked={showDate}
                    onChange={(e) => setShowDate(e.target.checked)}
                    className="rounded text-emerald-600 focus:ring-emerald-500"
                  />
                  <span>Batch Date Stamp</span>
                </label>
              </div>

              {/* Dynamic Inputs when enabled */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 pt-2 border-t border-slate-200/80">
                {showStoreHeader && (
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 block mb-0.5">
                      Header Text
                    </span>
                    <input
                      type="text"
                      value={storeHeader}
                      onChange={(e) => setStoreHeader(e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs font-bold bg-white"
                    />
                  </div>
                )}

                {showLocation && (
                  <div>
                    <span className="text-[10px] font-bold text-slate-500 block mb-0.5">
                      Shelf / Aisle Tag
                    </span>
                    <input
                      type="text"
                      placeholder="e.g. Aisle 3 - Shelf B2"
                      value={shelfLocation}
                      onChange={(e) => setShelfLocation(e.target.value)}
                      className="w-full px-2.5 py-1.5 rounded-lg border border-slate-300 text-xs font-bold bg-white"
                    />
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Right Column: WYSIWYG Live Preview & Printer Output Actions (5 Cols) */}
          <div className="lg:col-span-5 flex flex-col space-y-4">
            <div className="p-4 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-lg flex-1 flex flex-col">
              <div className="flex items-center justify-between pb-3 border-b border-white/10">
                <div className="flex items-center gap-2">
                  <Tag className="w-4 h-4 text-emerald-400" />
                  <span className="text-xs font-black uppercase tracking-wider text-emerald-200">
                    Live Label Preview (WYSIWYG)
                  </span>
                </div>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-white/10 text-slate-300">
                  {PRESET_CONFIGS[preset].widthMm}mm × {PRESET_CONFIGS[preset].heightMm}mm
                </span>
              </div>

              {/* Centered Realistic Sticker Box */}
              <div className="my-auto py-6 flex items-center justify-center">
                <div
                  className="bg-white text-slate-950 rounded-lg p-3 shadow-2xl border border-slate-300 flex flex-col justify-between transition-all"
                  style={{
                    width: preset === '40x25' ? '220px' : preset === '76x51' ? '300px' : '260px',
                    minHeight: preset === '40x25' ? '140px' : preset === '76x51' ? '200px' : '160px',
                  }}
                >
                  {/* Store Header */}
                  {showStoreHeader && (
                    <div className="flex items-center justify-between pb-1 border-b border-black text-[9px] font-black tracking-wider uppercase">
                      <span>{storeHeader || 'BARWAAQO'}</span>
                      <span className="border border-black px-1 py-0.2 rounded text-[7px] font-bold">
                        ORIGINAL
                      </span>
                    </div>
                  )}

                  {/* Product Title */}
                  <div className="mt-1 font-black text-xs leading-snug line-clamp-2">
                    {activeProduct?.name || 'Product Name'}
                  </div>

                  {/* Codes Section */}
                  <div className="my-1.5 flex items-center gap-2.5">
                    {(codeFormat === 'dual' || codeFormat === 'qr') && previewQrUrl && (
                      <img
                        src={previewQrUrl}
                        alt="QR Code"
                        className="w-14 h-14 object-contain shrink-0 bg-white"
                      />
                    )}

                    {(codeFormat === 'dual' || codeFormat === 'barcode') && (
                      <div className="flex-1 min-w-0 flex flex-col items-center justify-center">
                        {previewBarcodeUrl ? (
                          <img
                            src={previewBarcodeUrl}
                            alt="1D Barcode"
                            className="w-full h-8 object-fill block"
                          />
                        ) : (
                          <div className="w-full h-8 bg-slate-200 animate-pulse rounded" />
                        )}
                        {showSkuText && (
                          <span className="font-mono text-[9px] font-bold tracking-widest text-slate-800 mt-0.5">
                            {activeProduct?.sku || activeProduct?.id.slice(0, 8)}
                          </span>
                        )}
                      </div>
                    )}
                  </div>

                  {/* Price & Wholesale */}
                  <div className="flex items-baseline justify-between pt-1 border-t border-slate-100">
                    {showRetailPrice && (
                      <div className="font-black text-lg tracking-tight leading-none text-slate-950">
                        {money(activeProduct?.sell || 0)}
                        {showUnit && (
                          <span className="text-[9px] font-bold text-slate-600 ml-1">
                            /{activeProduct?.unit}
                          </span>
                        )}
                      </div>
                    )}
                    {showWholesalePrice && activeProduct?.wholesale && (
                      <span className="text-[9px] font-extrabold bg-slate-100 px-1.5 py-0.5 rounded text-slate-800">
                        WS: {money(activeProduct.wholesale)}
                      </span>
                    )}
                  </div>

                  {/* Footer metadata */}
                  {(showLocation || showDate) && (
                    <div className="mt-1 pt-1 border-t border-dashed border-slate-300 flex justify-between text-[8px] text-slate-500 font-mono">
                      {showLocation && <span>LOC: {shelfLocation || 'SHELF'}</span>}
                      {showDate && <span>DATE: {batchDate}</span>}
                    </div>
                  )}
                </div>
              </div>

              {/* Thermal Label Printer Setup Note */}
              <div className="p-3 rounded-2xl bg-white/5 border border-white/10 text-slate-300 text-[11px] space-y-1">
                <div className="flex items-center gap-1.5 font-bold text-amber-300">
                  <Info className="w-3.5 h-3.5" />
                  <span>Standard Label Printer Instructions</span>
                </div>
                <p className="text-slate-400 text-[10.5px] leading-relaxed">
                  In your browser print dialog, select your thermal printer (Zebra / Brother / Dymo / Xprinter), set <strong>Margins</strong> to <strong>None</strong>, and set <strong>Scale</strong> to <strong>100%</strong>. The auto-gap sensor will advance 1 sticker per label.
                </p>
              </div>

              {/* Action Buttons */}
              <div className="pt-3 border-t border-white/10 space-y-2">
                <button
                  type="button"
                  onClick={handlePrint}
                  disabled={isGenerating || totalLabelsCount === 0}
                  className="w-full py-3 px-4 rounded-2xl bg-gradient-to-r from-emerald-500 via-teal-500 to-emerald-600 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-sm transition shadow-lg flex items-center justify-center gap-2 cursor-pointer active:scale-98 disabled:opacity-50"
                >
                  <Printer className="w-4 h-4" />
                  <span>
                    Direct Print {totalLabelsCount} {totalLabelsCount === 1 ? 'Label' : 'Labels'}
                  </span>
                </button>

                <button
                  type="button"
                  onClick={handleDownloadSinglePng}
                  disabled={!activeProduct}
                  className="w-full py-2 px-3 rounded-xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs transition flex items-center justify-center gap-1.5 cursor-pointer"
                >
                  <Download className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Download High-Res Label PNG (for Zebra Designer / P-touch)</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
