import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { money } from '../../utils/helpers';
import {
  X,
  Landmark,
  ShieldCheck,
  Lock,
  ArrowUpRight,
  ArrowDownRight,
  UserCheck,
  AlertCircle,
  FileText,
} from 'lucide-react';
import { PinVerificationModal } from './PinVerificationModal';
import { SystemUser } from '../../types';

interface FinancialLedgerModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const FinancialLedgerModal: React.FC<FinancialLedgerModalProps> = ({
  isOpen,
  onClose,
}) => {
  const {
    currentUser,
    availableUsers,
    recordFinancialLedgerAdjustment,
    showToast,
  } = useStore();

  const [adjustmentType, setAdjustmentType] = useState<
    | 'capital_adjustment'
    | 'cash_reconciliation'
    | 'bank_reconciliation'
    | 'expense_correction'
    | 'bad_debt_writeoff'
  >('capital_adjustment');

  const [direction, setDirection] = useState<'credit' | 'debit'>('credit');
  const [amount, setAmount] = useState<number | ''>('');
  const [accountRef, setAccountRef] = useState('CBE-Main-Ledger');
  const [reason, setReason] = useState('');
  const [operatorId, setOperatorId] = useState(currentUser.id);
  const [showPinModal, setShowPinModal] = useState(false);

  if (!isOpen) return null;

  const numAmount = Number(amount) || 0;

  const handleOpenPin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!numAmount || numAmount <= 0) {
      showToast('Please enter a valid adjustment amount.');
      return;
    }
    if (!reason.trim()) {
      showToast('Audit justification reason is required for financial ledger modifications.');
      return;
    }
    setShowPinModal(true);
  };

  const handlePinSuccess = (authorizedUser: SystemUser) => {
    const success = recordFinancialLedgerAdjustment({
      type: adjustmentType,
      amount: numAmount,
      direction,
      account: accountRef,
      reason: reason.trim(),
      operatorId: authorizedUser.id,
      authMeta: {
        verifiedByPin: true,
        authorizedByUserId: authorizedUser.id,
        authorizedByUserName: authorizedUser.name,
        authorizedByUserRole: authorizedUser.role,
      },
    });

    if (success) {
      showToast(`Financial ledger adjustment of ${money(numAmount)} recorded with PIN verification.`);
      setShowPinModal(false);
      onClose();
    }
  };

  const getTypeName = () => {
    switch (adjustmentType) {
      case 'capital_adjustment':
        return 'Founder Capital / Equity Adjustment';
      case 'cash_reconciliation':
        return 'Cash Drawer / Till Reconciliation';
      case 'bank_reconciliation':
        return 'Bank / Digital Account Reconciliation';
      case 'expense_correction':
        return 'Operating Expense Ledger Correction';
      case 'bad_debt_writeoff':
        return 'Audited Bad Debt / Write-off';
      default:
        return 'Financial Ledger Adjustment';
    }
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
        <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
          {/* Header */}
          <div className="p-4 bg-slate-950 text-white flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
                <Landmark className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm tracking-wide">Financial Ledger Audit Adjustment</h3>
                <p className="text-[10px] text-emerald-300">Protected by 4-Digit Security PIN Verification</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleOpenPin} className="p-5 space-y-4">
            {/* Adjustment Category */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Financial Ledger Category
              </label>
              <select
                value={adjustmentType}
                onChange={(e) => setAdjustmentType(e.target.value as any)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                <option value="capital_adjustment">Founder Capital / Equity Adjustment</option>
                <option value="cash_reconciliation">Cash Drawer / Daily Till Reconciliation</option>
                <option value="bank_reconciliation">Bank Account / CBE / Telebirr Adjustment</option>
                <option value="expense_correction">Expense Ledger Correction / Reclassification</option>
                <option value="bad_debt_writeoff">Audited Credit Loss / Bad Debt Write-off</option>
              </select>
            </div>

            {/* Operator Selection */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                Audited Operator (Authorizing Identity)
              </label>
              <select
                value={operatorId}
                onChange={(e) => setOperatorId(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                {availableUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.id} — {u.name} ({u.role})
                  </option>
                ))}
              </select>
            </div>

            {/* Direction & Amount */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Adjustment Flow</label>
                <div className="grid grid-cols-2 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setDirection('credit')}
                    className={`py-2 px-2.5 rounded-xl flex items-center justify-center gap-1 text-xs font-bold border transition-all ${
                      direction === 'credit'
                        ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <ArrowUpRight className="w-3.5 h-3.5 text-emerald-600" />
                    Credit (+)
                  </button>
                  <button
                    type="button"
                    onClick={() => setDirection('debit')}
                    className={`py-2 px-2.5 rounded-xl flex items-center justify-center gap-1 text-xs font-bold border transition-all ${
                      direction === 'debit'
                        ? 'bg-rose-50 border-rose-500 text-rose-700 shadow-xs'
                        : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                    }`}
                  >
                    <ArrowDownRight className="w-3.5 h-3.5 text-rose-600" />
                    Debit (−)
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1.5">Amount (ETB)</label>
                <input
                  type="number"
                  min="1"
                  step="any"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value === '' ? '' : Math.max(0, Number(e.target.value)))}
                  placeholder="e.g. 5000"
                  required
                  className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-bold focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            {/* Account / Reference ID */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Account / Sub-Ledger Reference ID
              </label>
              <input
                type="text"
                value={accountRef}
                onChange={(e) => setAccountRef(e.target.value)}
                placeholder="e.g. CBE-Main-Ledger, Cash-Drawer-01, EXP-2024"
                required
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Reason / Audit Memo */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Audit Justification & Memo <span className="text-rose-500">*</span>
              </label>
              <textarea
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                rows={2}
                placeholder="Detailed reason for financial ledger modification (required for audit compliance)..."
                required
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            {/* Security Notice */}
            <div className="flex items-center gap-2 p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-[11px] text-emerald-900">
              <Lock className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                Action requires <b>4-digit PIN confirmation</b> by <b>{operatorId}</b> to write an immutable audit log entry.
              </span>
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 px-3 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!amount || !reason.trim()}
                className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-xs font-extrabold text-white transition-all shadow-md active:scale-98 flex items-center justify-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Verify PIN & Commit</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* 4-Digit PIN Security Gate Modal */}
      <PinVerificationModal
        isOpen={showPinModal}
        onClose={() => setShowPinModal(false)}
        onSuccess={handlePinSuccess}
        actionTitle="Authorize Financial Ledger Edit"
        actionDescription="This operation adjusts financial balances and commits a permanent entry into the store's audit ledger."
        targetUserId={operatorId}
        actionDetails={[
          { label: 'Category', value: getTypeName() },
          {
            label: 'Adjustment',
            value: `${direction === 'credit' ? '+' : '−'}${money(numAmount)}`,
          },
          { label: 'Account / Ref', value: accountRef },
          { label: 'Justification', value: reason },
        ]}
      />
    </>
  );
};
