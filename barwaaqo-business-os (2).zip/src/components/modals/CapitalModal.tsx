import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { money } from '../../utils/helpers';
import { X, Landmark, Plus, Trash2, ShieldCheck, Lock } from 'lucide-react';
import { PinVerificationModal } from './PinVerificationModal';
import { SystemUser } from '../../types';

export const CapitalModal: React.FC = () => {
  const {
    isCapitalModalOpen,
    setIsCapitalModalOpen,
    db,
    totals,
    saveCapitalEntry,
    deleteCapitalEntry,
    currentUser,
  } = useStore();

  const [category, setCategory] = useState<'Stock' | 'Equipment' | 'Shop setup' | 'Rent' | 'Transport'>('Equipment');
  const [amount, setAmount] = useState<number | ''>('');
  const [note, setNote] = useState('');

  // PIN security states
  const [pendingAction, setPendingAction] = useState<{
    type: 'add' | 'delete';
    category?: string;
    amount?: number;
    note?: string;
    deleteId?: string;
    deleteTitle?: string;
  } | null>(null);

  if (!isCapitalModalOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const val = Number(amount);
    if (!val || val <= 0) return;
    setPendingAction({
      type: 'add',
      category,
      amount: val,
      note,
    });
  };

  const handlePromptDelete = (entry: { id: string; category: string; amount: number }) => {
    setPendingAction({
      type: 'delete',
      deleteId: entry.id,
      deleteTitle: `${entry.category} (${money(entry.amount)})`,
      amount: entry.amount,
    });
  };

  const handlePinSuccess = (authorizedUser: SystemUser) => {
    if (!pendingAction) return;

    if (pendingAction.type === 'add' && pendingAction.category && pendingAction.amount) {
      saveCapitalEntry(pendingAction.category, pendingAction.amount, pendingAction.note || '', {
        verifiedByPin: true,
        authorizedByUserId: authorizedUser.id,
        authorizedByUserName: authorizedUser.name,
      });
      setAmount('');
      setNote('');
    } else if (pendingAction.type === 'delete' && pendingAction.deleteId) {
      deleteCapitalEntry(pendingAction.deleteId, {
        verifiedByPin: true,
        authorizedByUserId: authorizedUser.id,
        authorizedByUserName: authorizedUser.name,
      });
    }

    setPendingAction(null);
  };

  const spent = totals.capitalSpent;
  const remaining = totals.capitalRemaining;
  const isOver = remaining < 0;

  return (
    <>
      <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
        <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
          {/* Header */}
          <div className="p-4 bg-gradient-to-r from-[#031c12] to-[#075936] text-white flex items-center justify-between shrink-0">
            <div className="flex items-center gap-2.5">
              <Landmark className="w-5 h-5 text-emerald-400" />
              <div>
                <h3 className="font-bold text-sm tracking-wide">Initial Capital Spending</h3>
                <p className="text-[11px] text-emerald-200/80">ETB 200,000 Founder Budget Ledger · PIN Protected</p>
              </div>
            </div>
            <button
              onClick={() => setIsCapitalModalOpen(false)}
              className="p-1 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-800/50 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <div className="p-5 overflow-y-auto space-y-5">
            {/* Capital Snapshot Cards */}
            <div className="grid grid-cols-2 gap-3">
              <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200">
                <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 block">
                  Total Capital Spent
                </span>
                <span className="text-lg font-black text-rose-600 tracking-tight block mt-1">
                  −{money(spent)}
                </span>
                <span className="text-[10px] text-slate-400">Recorded deployment</span>
              </div>

              <div
                className={`p-3.5 rounded-2xl border ${
                  isOver
                    ? 'bg-rose-50 border-rose-200 text-rose-800'
                    : 'bg-emerald-50 border-emerald-200 text-emerald-900'
                }`}
              >
                <span className="text-[10px] font-extrabold uppercase tracking-wider block opacity-70">
                  Capital Remaining
                </span>
                <span
                  className={`text-lg font-black tracking-tight block mt-1 ${
                    isOver ? 'text-rose-700' : 'text-emerald-700'
                  }`}
                >
                  {money(remaining)}
                </span>
                <span className="text-[10px] opacity-75 font-semibold">
                  {isOver ? 'Exceeded initial budget' : 'Remaining buffer'}
                </span>
              </div>
            </div>

            {/* Form to Record Capital Spending */}
            <form onSubmit={handleSubmit} className="p-4 rounded-2xl bg-slate-50/80 border border-slate-200 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-1.5 font-bold text-xs text-slate-800">
                  <Plus className="w-4 h-4 text-emerald-600" />
                  <span>Record New Capital Expenditure</span>
                </div>
                <span className="text-[10px] font-bold text-emerald-700 bg-emerald-100/70 px-2 py-0.5 rounded-md flex items-center gap-1">
                  <Lock className="w-3 h-3 text-emerald-700" />
                  4-Digit PIN Gate
                </span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Expenditure Category</label>
                  <select
                    id="capCategory"
                    value={category}
                    onChange={(e) => setCategory(e.target.value as any)}
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  >
                    <option value="Equipment">Equipment (Freezers, Scales, POS)</option>
                    <option value="Shop setup">Shop Setup & Counter Renovation</option>
                    <option value="Stock">Initial Opening Bulk Stock</option>
                    <option value="Rent">Shop Lease & Advance Deposit</option>
                    <option value="Transport">Delivery Vehicle & Logistics</option>
                  </select>
                </div>

                <div>
                  <label className="block text-[11px] font-bold text-slate-600 mb-1">Amount (ETB)</label>
                  <input
                    id="capAmount"
                    type="number"
                    min="1"
                    step="any"
                    value={amount}
                    onChange={(e) => setAmount(e.target.value === '' ? '' : Number(e.target.value))}
                    placeholder="e.g. 15000"
                    required
                    className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Description / Memo (Optional)</label>
                <input
                  id="capNote"
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="e.g. Shelving units & barcode scanner"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <button
                type="submit"
                disabled={!amount || Number(amount) <= 0}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-xs font-extrabold text-white transition-all shadow-sm active:scale-98 flex items-center justify-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Verify PIN & Save Capital Entry</span>
              </button>
            </form>

            {/* Ledger History List */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-bold text-xs text-slate-800 uppercase tracking-wide">
                  Capital Expenditures History ({db.capitalSpending?.length || 0})
                </h4>
              </div>

              <div className="border border-slate-200 rounded-2xl divide-y divide-slate-100 max-h-56 overflow-y-auto bg-white">
                {!db.capitalSpending || db.capitalSpending.length === 0 ? (
                  <div className="p-6 text-center text-xs text-slate-400">
                    No capital expenditures recorded yet.
                  </div>
                ) : (
                  db.capitalSpending.map((entry) => (
                    <div key={entry.id} className="p-3 flex items-center justify-between hover:bg-slate-50 transition-colors">
                      <div>
                        <div className="flex items-center gap-2">
                          <span className="font-bold text-xs text-slate-900">{entry.category}</span>
                          <span className="text-[10px] text-slate-400">{entry.date}</span>
                        </div>
                        {entry.note && (
                          <p className="text-[11px] text-slate-500 mt-0.5">{entry.note}</p>
                        )}
                      </div>
                      <div className="flex items-center gap-3">
                        <span className="font-black text-xs text-rose-600 tracking-tight">
                          −{money(entry.amount)}
                        </span>
                        <button
                          onClick={() => handlePromptDelete(entry)}
                          className="p-1 text-slate-300 hover:text-rose-600 transition-colors"
                          title="Delete entry (PIN protected)"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Security Gate PIN Modal */}
      {pendingAction && (
        <PinVerificationModal
          isOpen={true}
          onClose={() => setPendingAction(null)}
          onSuccess={handlePinSuccess}
          actionTitle={
            pendingAction.type === 'add'
              ? 'Authorize Capital Expenditure'
              : 'Authorize Capital Entry Deletion'
          }
          actionDescription={
            pendingAction.type === 'add'
              ? 'Recording capital expenditures commits financial budget deployment to the founder ledger.'
              : 'Deleting capital expenditure modifies audited financial history and recalculates budget balances.'
          }
          actionDetails={
            pendingAction.type === 'add'
              ? [
                  { label: 'Category', value: pendingAction.category || '' },
                  { label: 'Amount', value: money(pendingAction.amount || 0) },
                  { label: 'Memo', value: pendingAction.note || 'None' },
                ]
              : [
                  { label: 'Entry', value: pendingAction.deleteTitle || '' },
                  { label: 'Amount', value: money(pendingAction.amount || 0) },
                ]
          }
        />
      )}
    </>
  );
};
