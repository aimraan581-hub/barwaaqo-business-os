import React, { useEffect, useState, useRef } from 'react';
import { Html5Qrcode } from 'html5-qrcode';
import { useStore } from '../../context/StoreContext';
import { Product } from '../../types';
import { money } from '../../utils/helpers';
import {
  X,
  Scan,
  CameraOff,
  Camera,
  Flashlight,
  FlashlightOff,
  RefreshCw,
  CheckCircle2,
  AlertCircle,
  Plus,
  Search,
  SlidersHorizontal,
  ArrowRight,
  Copy,
  Sparkles,
  Package,
  Barcode,
  Keyboard,
} from 'lucide-react';

export interface BarcodeScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  // Called when existing product is selected
  onProductFound?: (productId: string, product?: Product) => void;
  // Called to add a new product or fill SKU with this barcode
  onAddNewWithBarcode?: (barcode: string) => void;
  // Called to load an existing product into the Add/Update form
  onLoadProductToForm?: (product: Product) => void;
  // Purpose mode
  mode?: 'find' | 'add' | 'general';
  title?: string;
  subtitle?: string;
}

function playScanSound(type: 'success' | 'new_barcode' = 'success') {
  try {
    const AudioCtx = window.AudioContext || (window as any).webkitAudioContext;
    if (!AudioCtx) return;
    const ctx = new AudioCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();

    if (type === 'success') {
      osc.type = 'sine';
      osc.frequency.setValueAtTime(1200, ctx.currentTime);
      gain.gain.setValueAtTime(0.2, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.12);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.12);
    } else {
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(850, ctx.currentTime);
      osc.frequency.setValueAtTime(1100, ctx.currentTime + 0.08);
      gain.gain.setValueAtTime(0.18, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.18);
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.start();
      osc.stop(ctx.currentTime + 0.18);
    }
  } catch (e) {
    // Ignore audio error
  }
}

function triggerHaptic(duration = 70) {
  try {
    if (typeof navigator !== 'undefined' && navigator.vibrate) {
      navigator.vibrate(duration);
    }
  } catch (e) {
    // Ignore
  }
}

export const BarcodeScannerModal: React.FC<BarcodeScannerModalProps> = ({
  isOpen,
  onClose,
  onProductFound,
  onAddNewWithBarcode,
  onLoadProductToForm,
  mode = 'general',
  title,
  subtitle,
}) => {
  const { db, showToast } = useStore();
  const [hasError, setHasError] = useState(false);
  const [errorMessage, setErrorMessage] = useState('');
  const [isStarting, setIsStarting] = useState(true);
  const [cameras, setCameras] = useState<Array<{ id: string; label: string }>>([]);
  const [selectedCameraId, setSelectedCameraId] = useState<string>('');
  const [torchOn, setTorchOn] = useState(false);
  const [torchSupported, setTorchSupported] = useState(false);
  const [manualInput, setManualInput] = useState('');
  const [showManual, setShowManual] = useState(false);

  // Active scan result card
  const [scannedResult, setScannedResult] = useState<{
    code: string;
    product: Product | null;
  } | null>(null);

  const scannerRef = useRef<Html5Qrcode | null>(null);
  const isStoppingRef = useRef(false);
  const containerId = 'barcode-scanner-video-box';

  // Resolve raw text to database product
  const resolveProduct = (rawText: string): { product: Product | null; barcode: string } => {
    const products = db.products || [];
    const text = rawText.trim();

    // 1. URL parameter ?product=productId
    try {
      const url = new URL(text);
      const paramId = url.searchParams.get('product');
      if (paramId) {
        const byParam = products.find((p) => p.id === paramId);
        if (byParam) return { product: byParam, barcode: byParam.sku || paramId };
      }
    } catch (e) {}

    // 2. Exact match by SKU
    const bySku = products.find(
      (p) => p.sku && p.sku.trim().toLowerCase() === text.toLowerCase()
    );
    if (bySku) return { product: bySku, barcode: bySku.sku };

    // 3. Exact match by ID
    const byId = products.find((p) => p.id === text);
    if (byId) return { product: byId, barcode: byId.sku || byId.id };

    // 4. Match stripped leading zeros
    const cleanCode = text.replace(/^0+/, '');
    if (cleanCode.length >= 4) {
      const byFuzzy = products.find((p) => {
        const cleanP = (p.sku || '').replace(/^0+/, '');
        return cleanP && cleanP.toLowerCase() === cleanCode.toLowerCase();
      });
      if (byFuzzy) return { product: byFuzzy, barcode: byFuzzy.sku };
    }

    return { product: null, barcode: text };
  };

  // Handle scanned decoded text
  const handleDecoded = (decodedText: string) => {
    if (isStoppingRef.current) return;
    const clean = decodedText.trim();
    if (!clean) return;

    // Pause scanner stream to display result
    if (scannerRef.current) {
      try {
        const state = scannerRef.current.getState();
        if (state === 2) {
          scannerRef.current.pause(true);
        }
      } catch (e) {
        console.warn('Could not pause scanner', e);
      }
    }

    const { product, barcode } = resolveProduct(clean);

    if (product) {
      playScanSound('success');
      triggerHaptic(60);
      setScannedResult({ code: barcode, product });

      // In fast add mode, if product already exists, alert user
      if (mode === 'add') {
        showToast(`Existing product: ${product.name} (SKU: ${product.sku})`);
      }
    } else {
      playScanSound('new_barcode');
      triggerHaptic(100);
      setScannedResult({ code: barcode, product: null });
      showToast(`New barcode detected: ${barcode}`);
    }
  };

  // Resume camera scanning
  const resumeScanning = () => {
    setScannedResult(null);
    if (scannerRef.current) {
      try {
        const state = scannerRef.current.getState();
        if (state === 3) {
          scannerRef.current.resume();
        }
      } catch (e) {
        console.warn('Could not resume scanner', e);
      }
    }
  };

  // Switch camera toggle
  const switchCamera = () => {
    if (cameras.length <= 1) return;
    const currentIndex = cameras.findIndex((c) => c.id === selectedCameraId);
    const nextIndex = (currentIndex + 1) % cameras.length;
    const nextCam = cameras[nextIndex];
    setSelectedCameraId(nextCam.id);
  };

  // Torch toggle
  const toggleTorch = async () => {
    if (!scannerRef.current) return;
    try {
      await (scannerRef.current as any).applyVideoConstraints({
        advanced: [{ torch: !torchOn }],
      });
      setTorchOn(!torchOn);
    } catch (e) {
      console.warn('Torch not supported', e);
      setTorchSupported(false);
    }
  };

  // Initialize and start scanner when modal opens
  useEffect(() => {
    if (!isOpen) {
      setScannedResult(null);
      setManualInput('');
      setShowManual(false);
      return;
    }

    setHasError(false);
    setErrorMessage('');
    setIsStarting(true);
    isStoppingRef.current = false;

    let scannerInstance: Html5Qrcode | null = null;

    const startCamera = async () => {
      try {
        // Enumerate video devices
        const devices = await Html5Qrcode.getCameras().catch(() => []);
        if (devices && devices.length > 0) {
          setCameras(devices);
          if (!selectedCameraId) {
            // Prefer back camera if labeled, otherwise first device
            const backCam = devices.find((d) =>
              /back|rear|environment/i.test(d.label || '')
            );
            setSelectedCameraId(backCam ? backCam.id : devices[0].id);
          }
        }

        scannerInstance = new Html5Qrcode(containerId);
        scannerRef.current = scannerInstance;

        const cameraConfig = selectedCameraId
          ? { deviceId: { exact: selectedCameraId } }
          : { facingMode: 'environment' };

        await scannerInstance.start(
          cameraConfig,
          {
            fps: 15,
            qrbox: (viewfinderWidth: number, viewfinderHeight: number) => {
              const minDim = Math.min(viewfinderWidth, viewfinderHeight);
              const w = Math.floor(Math.min(320, minDim * 0.85));
              const h = Math.floor(Math.min(220, w * 0.65));
              return { width: w, height: h };
            },
            aspectRatio: 1.0,
          },
          (decodedText) => {
            handleDecoded(decodedText);
          },
          () => {
            // Transient frame scan error (ignored)
          }
        );

        setIsStarting(false);

        // Check torch capability
        try {
          const track = (scannerInstance as any).getRunningTrackCapabilities?.();
          if (track && 'torch' in track) {
            setTorchSupported(true);
          }
        } catch (e) {}
      } catch (err: any) {
        console.warn('Camera failed to start:', err);
        setHasError(true);
        setErrorMessage(
          err?.message ||
            'Could not access camera. Please verify camera permissions in your browser or enter the barcode manually.'
        );
        setIsStarting(false);
      }
    };

    const timer = setTimeout(startCamera, 150);

    return () => {
      clearTimeout(timer);
      isStoppingRef.current = true;
      if (scannerRef.current) {
        try {
          const state = scannerRef.current.getState();
          if (state === 2 || state === 3) {
            scannerRef.current.stop().catch(console.error);
          } else {
            scannerRef.current.clear();
          }
        } catch (e) {
          console.warn('Scanner cleanup warning:', e);
        }
        scannerRef.current = null;
      }
    };
  }, [isOpen, selectedCameraId]);

  // Submit manual input
  const handleManualSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!manualInput.trim()) return;
    handleDecoded(manualInput.trim());
    setManualInput('');
  };

  if (!isOpen) return null;

  const displayTitle =
    title ||
    (mode === 'add'
      ? 'Scan Barcode to Add Product'
      : mode === 'find'
      ? 'Scan to Find in Inventory'
      : 'Camera Barcode & QR Scanner');

  const displaySubtitle =
    subtitle ||
    (mode === 'add'
      ? 'Align camera to scan grocery barcode for SKU auto-fill'
      : 'Quickly find existing products or catalog new items');

  return (
    <div className="fixed inset-0 z-[70] bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150 flex flex-col max-h-[92vh]">
        {/* Header */}
        <div className="p-4 bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white flex items-center justify-between shrink-0 border-b border-emerald-900/50">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/40 flex items-center justify-center text-emerald-400 shrink-0">
              <Scan className="w-4 h-4" />
            </div>
            <div>
              <h3 className="font-black text-sm tracking-tight flex items-center gap-1.5">
                <span>{displayTitle}</span>
                <span className="text-[9px] font-bold px-1.5 py-0.2 rounded-md bg-emerald-500/20 text-emerald-300 border border-emerald-500/30 uppercase">
                  Live Camera
                </span>
              </h3>
              <p className="text-[10px] text-slate-400 line-clamp-1">{displaySubtitle}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
            title="Close scanner"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Viewfinder / Camera Screen */}
        <div className="p-4 flex-1 flex flex-col bg-slate-950 relative overflow-y-auto space-y-3">
          {hasError ? (
            /* Camera Permission or Hardware Error */
            <div className="w-full aspect-square rounded-2xl flex flex-col items-center justify-center bg-slate-900 text-slate-300 border border-slate-800 p-6 text-center space-y-3">
              <div className="w-12 h-12 rounded-2xl bg-rose-500/10 text-rose-400 border border-rose-500/20 flex items-center justify-center">
                <CameraOff className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h4 className="text-sm font-black text-white">Camera Inactive</h4>
                <p className="text-xs text-slate-400 max-w-xs leading-relaxed">
                  {errorMessage || 'Camera access was blocked or is unavailable on this device.'}
                </p>
              </div>
              <div className="pt-2 w-full max-w-xs">
                <button
                  type="button"
                  onClick={() => setShowManual(true)}
                  className="w-full py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs flex items-center justify-center gap-1.5 transition-colors shadow-sm"
                >
                  <Keyboard className="w-3.5 h-3.5" />
                  <span>Enter Barcode / SKU Manually</span>
                </button>
              </div>
            </div>
          ) : (
            /* Active Live Camera Viewfinder */
            <div className="relative w-full aspect-square max-h-[320px] rounded-2xl overflow-hidden bg-black border-2 border-slate-800 shadow-inner flex items-center justify-center">
              {/* HTML5 QR Container */}
              <div
                id={containerId}
                className="w-full h-full [&_video]:object-cover [&_video]:w-full [&_video]:h-full"
              />

              {/* Scanning Target Overlay */}
              <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center p-6">
                <div className="relative w-4/5 h-3/5 border border-emerald-400/40 rounded-2xl overflow-hidden shadow-2xl flex items-center justify-center">
                  {/* Glowing Corner Brackets */}
                  <div className="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-emerald-400" />
                  <div className="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-emerald-400" />
                  <div className="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-emerald-400" />
                  <div className="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-emerald-400" />

                  {/* Animated Sweeping Laser Line */}
                  <div className="absolute left-0 right-0 h-0.5 bg-gradient-to-r from-transparent via-emerald-400 to-transparent shadow-[0_0_8px_#10b981] animate-pulse" />

                  <span className="text-[10px] font-bold text-emerald-300/80 bg-slate-950/60 px-2 py-0.5 rounded-md backdrop-blur-xs">
                    Align Barcode or QR
                  </span>
                </div>
              </div>

              {/* Floating Camera Controls (Torch, Flip) */}
              <div className="absolute top-3 right-3 flex items-center gap-1.5 z-20">
                {torchSupported && (
                  <button
                    type="button"
                    onClick={toggleTorch}
                    className={`p-2 rounded-xl backdrop-blur-md border transition-all text-xs font-bold ${
                      torchOn
                        ? 'bg-amber-400 text-slate-950 border-amber-300 shadow-lg'
                        : 'bg-slate-900/80 text-white border-slate-700/80 hover:bg-slate-800'
                    }`}
                    title="Toggle Camera Flashlight"
                  >
                    {torchOn ? (
                      <Flashlight className="w-4 h-4 text-amber-900" />
                    ) : (
                      <FlashlightOff className="w-4 h-4" />
                    )}
                  </button>
                )}

                {cameras.length > 1 && (
                  <button
                    type="button"
                    onClick={switchCamera}
                    className="p-2 rounded-xl bg-slate-900/80 hover:bg-slate-800 text-white backdrop-blur-md border border-slate-700/80 transition-all"
                    title="Flip camera"
                  >
                    <RefreshCw className="w-4 h-4" />
                  </button>
                )}
              </div>

              {/* Starting Indicator */}
              {isStarting && (
                <div className="absolute inset-0 bg-slate-950/80 backdrop-blur-xs flex flex-col items-center justify-center text-slate-300 gap-2 z-10">
                  <div className="w-6 h-6 border-2 border-emerald-500 border-t-transparent rounded-full animate-spin" />
                  <span className="text-xs font-bold">Activating Camera...</span>
                </div>
              )}
            </div>
          )}

          {/* Scanned Result Card Overlay */}
          {scannedResult && (
            <div className="rounded-2xl p-3.5 bg-slate-900 border border-slate-800 text-white shadow-xl space-y-3 animate-in fade-in slide-in-from-bottom-2 duration-150">
              {scannedResult.product ? (
                /* MATCHED PRODUCT FOUND */
                <div className="space-y-2.5">
                  <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-2">
                    <div className="flex items-start gap-2">
                      <div className="w-8 h-8 rounded-xl bg-emerald-500/20 border border-emerald-500/30 text-emerald-400 flex items-center justify-center shrink-0 mt-0.5">
                        <CheckCircle2 className="w-4 h-4" />
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="text-[10px] font-black uppercase text-emerald-400 tracking-wider">
                            Product Matched
                          </span>
                          <span className="text-[9px] font-mono px-1.5 py-0.2 bg-slate-800 rounded-md text-slate-300">
                            {scannedResult.code}
                          </span>
                        </div>
                        <h4 className="font-extrabold text-sm text-white mt-0.5">
                          {scannedResult.product.name}
                        </h4>
                      </div>
                    </div>
                    <span className="text-xs font-black text-emerald-300 px-2 py-0.5 rounded-lg bg-emerald-950/80 border border-emerald-800/60 shrink-0">
                      {money(scannedResult.product.sell)}
                    </span>
                  </div>

                  <div className="grid grid-cols-2 gap-2 text-xs">
                    <div className="p-2 rounded-xl bg-slate-800/80 border border-slate-700/60">
                      <span className="text-[9px] font-bold text-slate-400 uppercase block">
                        Current On-Hand
                      </span>
                      <span className="text-xs font-black text-white">
                        {scannedResult.product.stock} {scannedResult.product.unit}
                      </span>
                    </div>
                    <div className="p-2 rounded-xl bg-slate-800/80 border border-slate-700/60">
                      <span className="text-[9px] font-bold text-slate-400 uppercase block">
                        Cost Value
                      </span>
                      <span className="text-xs font-bold text-slate-300">
                        {money(scannedResult.product.buy)}
                      </span>
                    </div>
                  </div>

                  {/* Actions for Matched Product */}
                  <div className="flex flex-col sm:flex-row gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        if (onProductFound) {
                          onProductFound(scannedResult.product!.id, scannedResult.product!);
                        }
                        onClose();
                      }}
                      className="flex-1 py-2 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs transition-colors flex items-center justify-center gap-1.5 shadow-sm"
                    >
                      <Search className="w-3.5 h-3.5" />
                      <span>Find & Highlight in List</span>
                    </button>

                    {onLoadProductToForm && (
                      <button
                        type="button"
                        onClick={() => {
                          onLoadProductToForm(scannedResult.product!);
                          onClose();
                        }}
                        className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 font-bold text-xs transition-colors flex items-center justify-center gap-1.5 border border-slate-700"
                        title="Load into Add/Update form to edit or restock"
                      >
                        <Package className="w-3.5 h-3.5" />
                        <span>Edit / Restock</span>
                      </button>
                    )}

                    <button
                      type="button"
                      onClick={resumeScanning}
                      className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
                      title="Scan another item"
                    >
                      Scan Next
                    </button>
                  </div>
                </div>
              ) : (
                /* UNMATCHED BARCODE (NEW PRODUCT CANDIDATE) */
                <div className="space-y-2.5">
                  <div className="flex items-start justify-between gap-2 border-b border-slate-800 pb-2">
                    <div className="flex items-start gap-2">
                      <div className="w-8 h-8 rounded-xl bg-amber-500/20 border border-amber-500/30 text-amber-400 flex items-center justify-center shrink-0 mt-0.5">
                        <AlertCircle className="w-4 h-4" />
                      </div>
                      <div>
                        <span className="text-[10px] font-black uppercase text-amber-400 tracking-wider block">
                          Unregistered Barcode
                        </span>
                        <span className="text-xs font-mono font-bold text-slate-200 mt-0.5 block">
                          {scannedResult.code}
                        </span>
                      </div>
                    </div>
                  </div>

                  <p className="text-xs text-slate-300">
                    No product exists with this barcode. Would you like to add a new grocery item to
                    the inventory with this SKU?
                  </p>

                  <div className="flex flex-col sm:flex-row gap-2 pt-1">
                    <button
                      type="button"
                      onClick={() => {
                        if (onAddNewWithBarcode) {
                          onAddNewWithBarcode(scannedResult.code);
                        }
                        onClose();
                      }}
                      className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-extrabold text-xs transition-all flex items-center justify-center gap-1.5 shadow-md"
                    >
                      <Plus className="w-4 h-4" />
                      <span>Add as New Product (SKU: {scannedResult.code})</span>
                    </button>

                    <button
                      type="button"
                      onClick={resumeScanning}
                      className="py-2 px-3 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-300 font-bold text-xs transition-colors"
                    >
                      Scan Again
                    </button>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Manual Input Section */}
          <div className="pt-1">
            {!showManual && !scannedResult ? (
              <button
                type="button"
                onClick={() => setShowManual(true)}
                className="w-full py-1.5 text-center text-xs font-semibold text-slate-400 hover:text-emerald-400 transition-colors flex items-center justify-center gap-1.5"
              >
                <Keyboard className="w-3.5 h-3.5" />
                <span>Type Barcode / SKU manually</span>
              </button>
            ) : showManual ? (
              <form onSubmit={handleManualSubmit} className="space-y-2">
                <div className="flex items-center gap-2">
                  <input
                    type="text"
                    value={manualInput}
                    onChange={(e) => setManualInput(e.target.value)}
                    placeholder="Enter SKU or barcode number..."
                    autoFocus
                    className="flex-1 px-3 py-2 rounded-xl bg-slate-900 border border-slate-700 text-white text-xs font-mono placeholder:text-slate-500 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                  <button
                    type="submit"
                    className="px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white font-bold text-xs transition-colors shrink-0"
                  >
                    Check
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowManual(false)}
                    className="p-2 rounded-xl bg-slate-800 text-slate-400 hover:text-white transition-colors"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </form>
            ) : null}
          </div>
        </div>

        {/* Footer info */}
        <div className="p-3 bg-slate-100 text-slate-600 text-[11px] font-medium flex items-center justify-between border-t border-slate-200">
          <span className="flex items-center gap-1 text-slate-500">
            <Barcode className="w-3.5 h-3.5 text-slate-400" />
            Supports standard UPC, EAN-13, Code 128 & QR shelf labels
          </span>
          <button
            type="button"
            onClick={onClose}
            className="font-bold text-slate-700 hover:text-slate-950 px-2 py-0.5 rounded-lg hover:bg-slate-200 transition-colors"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
