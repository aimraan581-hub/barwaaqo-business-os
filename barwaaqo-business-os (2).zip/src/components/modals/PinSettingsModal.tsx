import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { registerBiometrics } from '../../utils/webauthn';
import {
  X,
  KeyRound,
  ShieldCheck,
  CheckCircle2,
  AlertCircle,
  Lock,
  UserCheck,
  RefreshCw,
  Fingerprint,
} from 'lucide-react';

interface PinSettingsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PinSettingsModal: React.FC<PinSettingsModalProps> = ({
  isOpen,
  onClose,
}) => {
  const { availableUsers, updateUserPin, verifyPin, updateUserWebAuthn, showToast } = useStore();

  const [selectedUserId, setSelectedUserId] = useState(availableUsers[0]?.id || 'USR-01');
  const [currentPin, setCurrentPin] = useState('');
  const [newPin, setNewPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [errorMsg, setErrorMsg] = useState('');
  const [successMsg, setSuccessMsg] = useState('');
  
  const [isRegisteringBio, setIsRegisteringBio] = useState(false);

  // Quick PIN Test tool
  const [testUserId, setTestUserId] = useState(availableUsers[0]?.id || 'USR-01');
  const [testPin, setTestPin] = useState('');
  const [testResult, setTestResult] = useState<'idle' | 'success' | 'failed'>('idle');

  if (!isOpen) return null;

  const handleRegisterBiometrics = async () => {
    const user = availableUsers.find(u => u.id === selectedUserId);
    if (!user) return;
    
    setErrorMsg('');
    setSuccessMsg('');
    setIsRegisteringBio(true);
    
    try {
      const credentialId = await registerBiometrics(user.id, user.name);
      if (credentialId) {
        updateUserWebAuthn(user.id, credentialId);
        setSuccessMsg('Biometric authentication enabled successfully.');
      }
    } catch (e: any) {
      setErrorMsg(e.message || 'Failed to setup biometric authentication.');
    } finally {
      setIsRegisteringBio(false);
    }
  };

  const handleUpdatePin = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg('');
    setSuccessMsg('');

    if (currentPin.length !== 4 || !/^\d{4}$/.test(currentPin)) {
      setErrorMsg('Current PIN must be exactly 4 digits.');
      return;
    }

    if (newPin.length !== 4 || !/^\d{4}$/.test(newPin)) {
      setErrorMsg('New PIN must be exactly 4 numeric digits.');
      return;
    }

    if (newPin !== confirmPin) {
      setErrorMsg('New PIN and confirmation PIN do not match.');
      return;
    }

    const verify = verifyPin(selectedUserId, currentPin);
    if (!verify.success) {
      setErrorMsg(verify.message || 'Current PIN verification failed.');
      return;
    }

    const updated = updateUserPin(selectedUserId, newPin);
    if (updated) {
      setSuccessMsg(`PIN successfully updated for ${verify.user?.name || selectedUserId}!`);
      setCurrentPin('');
      setNewPin('');
      setConfirmPin('');
      showToast(`Security PIN updated for ${verify.user?.name}`);
    }
  };

  const handleRunTest = (e: React.FormEvent) => {
    e.preventDefault();
    const res = verifyPin(testUserId, testPin);
    if (res.success) {
      setTestResult('success');
      showToast(`PIN verified! User: ${res.user?.name} (${res.user?.role})`);
    } else {
      setTestResult('failed');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150 max-h-[90vh] flex flex-col">
        {/* Header */}
        <div className="p-4 bg-slate-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
              <KeyRound className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-sm tracking-wide">Operator PIN & Audit Credentials</h3>
              <p className="text-[10px] text-emerald-300">Station Security Layer</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 overflow-y-auto space-y-5">
          {/* Active Operator Directory and Default PINs */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-slate-700 uppercase tracking-wide">
                Authorized Operators
              </label>
              <span className="text-[10px] font-semibold text-emerald-700 bg-emerald-50 border border-emerald-200 px-2 py-0.5 rounded-full">
                Audit Verified
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              {availableUsers.map((u) => (
                <div
                  key={u.id}
                  className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex flex-col justify-between space-y-2"
                >
                  <div>
                    <div className="text-xs font-bold text-slate-900">{u.name}</div>
                    <div className="text-[10px] text-slate-500 font-medium">{u.role}</div>
                    <div className="text-[10px] font-mono text-slate-400 mt-0.5">{u.id}</div>
                  </div>
                  <div className="pt-2 border-t border-slate-200 flex items-center justify-between">
                    <span className="text-[10px] font-semibold text-slate-500">PIN:</span>
                    <span className="text-[11px] font-mono font-black text-emerald-700 bg-white px-2 py-0.5 rounded-md border border-slate-200">
                      {u.pin || '••••'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Change PIN Form */}
          <form onSubmit={handleUpdatePin} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center gap-1.5 font-bold text-xs text-slate-800">
              <Lock className="w-4 h-4 text-emerald-600" />
              <span>Update Operator Security PIN</span>
            </div>

            {errorMsg && (
              <div className="p-2.5 rounded-xl bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
                <AlertCircle className="w-4 h-4 shrink-0" />
                <span>{errorMsg}</span>
              </div>
            )}

            {successMsg && (
              <div className="p-2.5 rounded-xl bg-emerald-50 border border-emerald-200 text-emerald-700 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 shrink-0" />
                <span>{successMsg}</span>
              </div>
            )}

            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                Select Operator
              </label>
              <select
                value={selectedUserId}
                onChange={(e) => {
                  setSelectedUserId(e.target.value);
                  setErrorMsg('');
                  setSuccessMsg('');
                }}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold bg-white focus:ring-2 focus:ring-emerald-500"
              >
                {availableUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.role}) — {u.id}
                  </option>
                ))}
              </select>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">
                  Current 4-Digit PIN
                </label>
                <input
                  type="password"
                  maxLength={4}
                  value={currentPin}
                  onChange={(e) => setCurrentPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  placeholder="••••"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-center font-mono text-sm tracking-widest bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">
                  New 4-Digit PIN
                </label>
                <input
                  type="password"
                  maxLength={4}
                  value={newPin}
                  onChange={(e) => setNewPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  placeholder="••••"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-center font-mono text-sm tracking-widest bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 mb-1">
                  Confirm New PIN
                </label>
                <input
                  type="password"
                  maxLength={4}
                  value={confirmPin}
                  onChange={(e) => setConfirmPin(e.target.value.replace(/\D/g, '').slice(0, 4))}
                  placeholder="••••"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 text-center font-mono text-sm tracking-widest bg-white focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={!currentPin || !newPin || !confirmPin}
              className="w-full py-2.5 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-40 text-white font-extrabold text-xs transition-all shadow-xs flex items-center justify-center gap-1.5"
            >
              <KeyRound className="w-3.5 h-3.5" />
              <span>Save New PIN</span>
            </button>
            <div className="pt-2">
              <button
                type="button"
                onClick={handleRegisterBiometrics}
                disabled={isRegisteringBio}
                className="w-full py-2.5 px-4 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-extrabold text-xs transition-all border border-indigo-200 flex items-center justify-center gap-1.5 disabled:opacity-50"
              >
                <Fingerprint className="w-3.5 h-3.5" />
                <span>{isRegisteringBio ? 'Awaiting Device Prompt...' : 'Enable Device Biometrics (FaceID/TouchID)'}</span>
              </button>
              <p className="text-[10px] text-center text-slate-500 mt-2">
                Adds an alternative high-security authentication method using your device's native biometrics.
              </p>
            </div>
          </form>

          {/* Quick PIN Verification Tester */}
          <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-700" />
                Quick PIN Verification Test
              </span>
              <span className="text-[10px] text-emerald-800 font-medium">Diagnostic Tool</span>
            </div>

            <form onSubmit={handleRunTest} className="flex flex-col sm:flex-row items-center gap-2">
              <select
                value={testUserId}
                onChange={(e) => {
                  setTestUserId(e.target.value);
                  setTestResult('idle');
                }}
                className="w-full sm:w-auto flex-1 px-3 py-2 rounded-xl border border-emerald-300 text-xs font-semibold bg-white"
              >
                {availableUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} ({u.role})
                  </option>
                ))}
              </select>

              <input
                type="password"
                maxLength={4}
                value={testPin}
                onChange={(e) => {
                  setTestPin(e.target.value.replace(/\D/g, '').slice(0, 4));
                  setTestResult('idle');
                }}
                placeholder="4-digit PIN"
                className="w-full sm:w-28 px-3 py-2 rounded-xl border border-emerald-300 text-center font-mono text-xs font-bold bg-white"
              />

              <button
                type="submit"
                className="w-full sm:w-auto px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shrink-0"
              >
                Verify
              </button>
            </form>

            {testResult === 'success' && (
              <div className="p-2 bg-emerald-100/80 rounded-xl text-emerald-900 text-xs font-bold flex items-center gap-1.5">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>PIN Verified Successfully! Access Authorized.</span>
              </div>
            )}

            {testResult === 'failed' && (
              <div className="p-2 bg-rose-100/80 rounded-xl text-rose-900 text-xs font-bold flex items-center gap-1.5">
                <AlertCircle className="w-4 h-4 text-rose-700 shrink-0" />
                <span>Verification Failed: Invalid PIN for selected operator.</span>
              </div>
            )}
          </div>
        </div>

        <div className="p-4 bg-slate-50 border-t border-slate-200 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-200 hover:bg-slate-300 text-slate-800 text-xs font-bold transition-colors"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
