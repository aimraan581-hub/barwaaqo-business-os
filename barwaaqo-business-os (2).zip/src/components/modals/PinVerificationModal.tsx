import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../../context/StoreContext';
import { SystemUser } from '../../types';
import { authenticateBiometrics } from '../../utils/webauthn';
import {
  ShieldAlert,
  ShieldCheck,
  Lock,
  Unlock,
  KeyRound,
  X,
  UserCheck,
  AlertCircle,
  Delete,
  RotateCcw,
  Info,
  Fingerprint,
} from 'lucide-react';

interface PinVerificationModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess: (authorizedUser: SystemUser) => void;
  actionTitle: string;
  actionDescription?: string;
  actionDetails?: { label: string; value: string | React.ReactNode }[];
  requiredRole?: string;
  targetUserId?: string;
}

export const PinVerificationModal: React.FC<PinVerificationModalProps> = ({
  isOpen,
  onClose,
  onSuccess,
  actionTitle,
  actionDescription,
  actionDetails,
  requiredRole,
  targetUserId,
}) => {
  const { availableUsers, currentUser, verifyPin, logSecurityAlert } = useStore();

  const [selectedUser, setSelectedUser] = useState<SystemUser>(() => {
    if (targetUserId) {
      const found = availableUsers.find((u) => u.id === targetUserId);
      if (found) return found;
    }
    return currentUser;
  });

  const [pin, setPin] = useState<string>('');
  const [error, setError] = useState<string | null>(null);
  const [isShaking, setIsShaking] = useState<boolean>(false);
  const [showPin, setShowPin] = useState<boolean>(false);
  const [failedAttempts, setFailedAttempts] = useState<number>(0);

  // Hidden native input ref for mobile software keyboard and physical keyboard
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (isOpen) {
      setPin('');
      setError(null);
      setIsShaking(false);
      const user = targetUserId
        ? availableUsers.find((u) => u.id === targetUserId) || currentUser
        : currentUser;
      setSelectedUser(user);
      setTimeout(() => {
        inputRef.current?.focus();
      }, 100);
    }
  }, [isOpen, targetUserId, currentUser, availableUsers]);

  if (!isOpen) return null;

  const handleDigit = (digit: string) => {
    if (pin.length < 4) {
      const nextPin = pin + digit;
      setPin(nextPin);
      setError(null);
      if (nextPin.length === 4) {
        validatePin(nextPin);
      }
    }
  };

  const handleBackspace = () => {
    setPin((prev) => prev.slice(0, -1));
    setError(null);
  };

  const handleClear = () => {
    setPin('');
    setError(null);
  };

  const validatePin = (inputPin: string) => {
    const res = verifyPin(selectedUser.id, inputPin);
    if (res.success) {
      setError(null);
      onSuccess(res.user || selectedUser);
      onClose();
    } else {
      const nextFailed = failedAttempts + 1;
      setFailedAttempts(nextFailed);
      setError('Incorrect 4-digit security PIN.');
      setIsShaking(true);
      setTimeout(() => setIsShaking(false), 500);
      setPin('');

      // Security audit log for unauthorized attempt
      logSecurityAlert?.(
        'FAILED PIN ATTEMPT',
        `Unauthorized PIN attempt for "${actionTitle}" under User ${selectedUser.name} (${selectedUser.id}). Failed attempts: ${nextFailed}.`,
        {
          userId: selectedUser.id,
          userName: selectedUser.name,
          userRole: selectedUser.role,
        }
      );
    }
  };

  const handleBiometricAuth = async () => {
    if (!selectedUser.webAuthnCredentialId) return;
    try {
      const success = await authenticateBiometrics(selectedUser.webAuthnCredentialId);
      if (success) {
        setError(null);
        onSuccess(selectedUser);
        onClose();
      } else {
        setError('Biometric authentication failed or was cancelled.');
      }
    } catch (e: any) {
      setError(e.message || 'Failed to verify biometrics.');
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key >= '0' && e.key <= '9') {
      handleDigit(e.key);
    } else if (e.key === 'Backspace') {
      handleBackspace();
    } else if (e.key === 'Escape') {
      onClose();
    }
  };

  return (
    <div
      className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150"
      onKeyDown={handleKeyDown}
      tabIndex={0}
    >
      <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden border border-slate-200 flex flex-col max-h-[92vh]">
        {/* Header with Security Styling */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-slate-800 to-emerald-950 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30">
              <Lock className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-1.5">
                <span className="text-[10px] font-black tracking-widest text-emerald-300 uppercase">
                  SECURITY GATE
                </span>
                <span className="px-1.5 py-0.5 rounded text-[9px] font-bold bg-amber-500/30 text-amber-300 border border-amber-500/40">
                  4-DIGIT PIN REQUIRED
                </span>
              </div>
              <h3 className="font-black text-sm sm:text-base text-white tracking-tight">
                {actionTitle}
              </h3>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
            title="Cancel authorization"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-5 overflow-y-auto space-y-4">
          {/* Action description / Context Banner */}
          {actionDescription && (
            <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-xl border border-slate-200/80">
              {actionDescription}
            </p>
          )}

          {/* Action Details Summary (Item name, Qty, Amount, etc.) */}
          {actionDetails && actionDetails.length > 0 && (
            <div className="bg-slate-50 border border-slate-200 rounded-2xl p-3.5 space-y-2 text-xs">
              <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-500 block border-b border-slate-200 pb-1">
                Pending Audited Action Details
              </span>
              <div className="grid grid-cols-2 gap-2 pt-1">
                {actionDetails.map((item, idx) => (
                  <div key={idx} className="space-y-0.5">
                    <span className="text-[11px] text-slate-500 font-medium block">
                      {item.label}
                    </span>
                    <span className="text-xs font-bold text-slate-900 block truncate">
                      {item.value}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Operator Selector */}
          <div className="bg-emerald-50/70 border border-emerald-200/90 rounded-2xl p-3.5 space-y-2">
            <div className="flex items-center justify-between">
              <label className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-emerald-700" />
                <span>Audited Operator (Identity Verification)</span>
              </label>
              <span className="text-[10px] font-mono font-bold text-emerald-800 bg-white px-2 py-0.5 rounded-md border border-emerald-300">
                {selectedUser.id}
              </span>
            </div>

            <select
              aria-label="Authorizing Operator"
              value={selectedUser.id}
              onChange={(e) => {
                const u = availableUsers.find((user) => user.id === e.target.value);
                if (u) {
                  setSelectedUser(u);
                  setPin('');
                  setError(null);
                }
              }}
              className="w-full px-3 py-2 rounded-xl border border-emerald-300 text-xs font-bold bg-white text-slate-900 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            >
              {availableUsers.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.name} · {u.role} ({u.id})
                </option>
              ))}
            </select>
          </div>

          {/* 4-Digit PIN Indicators */}
          <div className="text-center py-2">
            <div className="text-xs font-bold text-slate-700 mb-2.5 flex items-center justify-center gap-1.5">
              <KeyRound className="w-3.5 h-3.5 text-slate-500" />
              <span>Enter 4-Digit Security PIN</span>
              <button
                type="button"
                onClick={() => setShowPin(!showPin)}
                className="ml-2 text-[11px] font-bold text-emerald-700 hover:text-emerald-800 underline"
              >
                {showPin ? 'Mask' : 'Reveal'}
              </button>
            </div>

            {/* Hidden input to catch keyboard / touch input */}
            <input
              ref={inputRef}
              type="password"
              inputMode="numeric"
              maxLength={4}
              value={pin}
              onChange={(e) => {
                const val = e.target.value.replace(/\D/g, '').slice(0, 4);
                setPin(val);
                setError(null);
                if (val.length === 4) {
                  validatePin(val);
                }
              }}
              className="sr-only"
              aria-label="4-Digit Security PIN"
            />

            {/* 4 Visual Digit Slots */}
            <div
              className={`flex items-center justify-center gap-3.5 ${
                isShaking ? 'animate-bounce' : ''
              }`}
            >
              {[0, 1, 2, 3].map((index) => {
                const digit = pin[index];
                const isFilled = digit !== undefined;
                return (
                  <div
                    key={index}
                    onClick={() => inputRef.current?.focus()}
                    className={`w-12 h-13 rounded-2xl border-2 flex items-center justify-center text-lg font-black font-mono transition-all cursor-pointer ${
                      error
                        ? 'border-rose-400 bg-rose-50 text-rose-700'
                        : isFilled
                        ? 'border-emerald-600 bg-emerald-50 text-emerald-950 shadow-sm scale-105'
                        : 'border-slate-300 bg-white text-slate-400 hover:border-slate-400'
                    }`}
                  >
                    {isFilled ? (showPin ? digit : '●') : '—'}
                  </div>
                );
              })}
            </div>

            {/* Error message */}
            {error ? (
              <p className="text-xs font-bold text-rose-600 flex items-center justify-center gap-1.5 mt-2.5 animate-in fade-in">
                <AlertCircle className="w-4 h-4 text-rose-600 shrink-0" />
                <span>{error}</span>
              </p>
            ) : (
              <p className="text-[11px] text-slate-400 mt-2">
                Type 4 digits on keyboard or tap numeric pad below
              </p>
            )}
          </div>

          {/* Numeric Keypad (1-9, Clear, 0, Backspace) */}
          <div className="grid grid-cols-3 gap-2 max-w-[280px] mx-auto pt-1">
            {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((num) => (
              <button
                key={num}
                type="button"
                onClick={() => handleDigit(num)}
                className="h-11 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-emerald-600 active:text-white text-slate-800 font-extrabold text-base transition-colors shadow-xs"
              >
                {num}
              </button>
            ))}

            <button
              type="button"
              onClick={handleClear}
              className="h-11 rounded-xl bg-slate-100 hover:bg-rose-100 text-slate-600 hover:text-rose-700 font-bold text-xs flex items-center justify-center gap-1 transition-colors"
              title="Clear PIN"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              Clear
            </button>

            <button
              type="button"
              onClick={() => handleDigit('0')}
              className="h-11 rounded-xl bg-slate-100 hover:bg-slate-200 active:bg-emerald-600 active:text-white text-slate-800 font-extrabold text-base transition-colors shadow-xs"
            >
              0
            </button>

            <button
              type="button"
              onClick={handleBackspace}
              className="h-11 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center justify-center gap-1 transition-colors"
              title="Backspace"
            >
              <Delete className="w-4 h-4" />
            </button>
          </div>

          {selectedUser.webAuthnCredentialId && (
            <button
              type="button"
              onClick={handleBiometricAuth}
              className="w-full mt-3 py-3 rounded-xl bg-indigo-50 hover:bg-indigo-100 text-indigo-700 font-extrabold text-sm transition-all border border-indigo-200 flex items-center justify-center gap-2 shadow-xs"
            >
              <Fingerprint className="w-5 h-5" />
              <span>Use FaceID / TouchID</span>
            </button>
          )}

          {/* Demo Credentials Helper Pill */}
          <div className="p-2.5 rounded-xl bg-slate-100/90 border border-slate-200 flex items-center justify-between text-[11px] text-slate-600">
            <div className="flex items-center gap-1.5">
              <Info className="w-3.5 h-3.5 text-slate-400 shrink-0" />
              <span>
                Default PIN: <b>1234</b> (Aimraan) · <b>5678</b> (Sara) · <b>4321</b> (Dawit)
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                const pinToUse = selectedUser.pin || '1234';
                setPin(pinToUse);
                validatePin(pinToUse);
              }}
              className="text-[10px] font-extrabold text-emerald-700 hover:text-emerald-900 bg-white px-2 py-0.5 rounded border border-emerald-300 shrink-0 ml-2"
            >
              Auto-Fill
            </button>
          </div>
        </div>

        {/* Footer Actions */}
        <div className="p-3.5 bg-slate-50 border-t border-slate-200 flex items-center justify-between gap-2 shrink-0">
          <button
            type="button"
            onClick={onClose}
            className="py-2 px-4 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-white transition-colors"
          >
            Cancel
          </button>

          <button
            type="button"
            disabled={pin.length !== 4}
            onClick={() => validatePin(pin)}
            className="py-2 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-xs font-extrabold text-white transition-all shadow-sm flex items-center gap-1.5"
          >
            <ShieldCheck className="w-4 h-4" />
            <span>Verify & Authorize</span>
          </button>
        </div>
      </div>
    </div>
  );
};
