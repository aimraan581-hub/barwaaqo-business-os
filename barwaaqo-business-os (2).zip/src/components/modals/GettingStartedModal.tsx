import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { useStore } from '../../context/StoreContext';
import { usePWAInstall } from '../../hooks/usePWAInstall';
import {
  X,
  Smartphone,
  Download,
  CheckCircle2,
  Share2,
  PlusSquare,
  Sparkles,
  WifiOff,
  ScanBarcode,
  HardDrive,
  Copy,
  Check,
  ExternalLink,
  Laptop,
  ArrowRight,
  ShieldCheck,
  HelpCircle,
} from 'lucide-react';

export const GettingStartedModal: React.FC = () => {
  const { isGettingStartedOpen, setIsGettingStartedOpen, showToast } = useStore();
  const { isInstallable, isInstalled, isIOS, isAndroid, install } = usePWAInstall();

  // Determine initial platform tab
  const [platformTab, setPlatformTab] = useState<'android' | 'ios' | 'desktop'>(() => {
    if (isIOS) return 'ios';
    if (isAndroid) return 'android';
    return 'android'; // default friendly mobile tab
  });

  const [dontShowAgain, setDontShowAgain] = useState(false);
  const [copiedLink, setCopiedLink] = useState(false);
  const [qrCodeUrl, setQrCodeUrl] = useState<string>('');

  const productionUrl =
    'https://ais-pre-7zxghfj4nvlqrbhtgd2fzo-336179362284.europe-west2.run.app';

  useEffect(() => {
    if (isIOS) setPlatformTab('ios');
    else if (isAndroid) setPlatformTab('android');
    else setPlatformTab('android');
  }, [isIOS, isAndroid]);

  useEffect(() => {
    if (!isGettingStartedOpen) return;

    let isMounted = true;
    QRCode.toDataURL(productionUrl, {
      width: 200,
      margin: 1,
      color: {
        dark: '#03170f',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    })
      .then((url) => {
        if (isMounted) setQrCodeUrl(url);
      })
      .catch((err) => console.error('Failed to generate QR', err));

    return () => {
      isMounted = false;
    };
  }, [isGettingStartedOpen, productionUrl]);

  if (!isGettingStartedOpen) return null;

  const handleClose = () => {
    if (dontShowAgain) {
      try {
        localStorage.setItem('barwaaqo_getting_started_dismissed', 'true');
      } catch {
        // ignore
      }
    }
    setIsGettingStartedOpen(false);
  };

  const handleDirectInstall = async () => {
    if (isInstallable) {
      const success = await install();
      if (success) {
        showToast('App installation started!');
        handleClose();
      }
    } else {
      showToast('Follow the steps below to Add to Home Screen');
    }
  };

  const handleCopyLink = () => {
    try {
      navigator.clipboard.writeText(productionUrl);
      setCopiedLink(true);
      showToast('Direct app link copied to clipboard!');
      setTimeout(() => setCopiedLink(false), 2500);
    } catch {
      showToast('Could not copy link');
    }
  };

  return (
    <div
      id="getting-started-modal"
      className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
    >
      <div className="bg-white rounded-3xl w-full max-w-2xl shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-200 my-auto flex flex-col max-h-[92vh]">
        {/* Header with Executive Emerald Gradient */}
        <div className="p-4 sm:p-5 bg-gradient-to-br from-[#03170f] via-[#064229] to-[#085a37] text-white shrink-0">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 sm:w-12 sm:h-12 rounded-2xl bg-white/10 p-1 flex items-center justify-center border border-amber-400/30 shadow-md shrink-0">
                <img
                  src="/pwa-192x192.png"
                  alt="BARWAAQO Logo"
                  className="w-full h-full object-cover rounded-xl shadow"
                />
              </div>
              <div>
                <div className="flex items-center gap-2 flex-wrap">
                  <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-400 text-amber-950 flex items-center gap-1 shadow-xs">
                    <Sparkles className="w-3 h-3 text-amber-950 fill-amber-950" />
                    Getting Started Guide
                  </span>
                  <span className="text-[10px] font-bold text-emerald-300">
                    Standalone App
                  </span>
                </div>
                <h3 className="text-base sm:text-lg font-black text-white tracking-tight mt-0.5">
                  How to Install BARWAAQO on Your Phone
                </h3>
              </div>
            </div>
            <button
              onClick={handleClose}
              className="p-1.5 rounded-xl text-emerald-200 hover:text-white hover:bg-white/10 transition-colors"
              aria-label="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <p className="text-xs text-emerald-100/90 mt-2.5 leading-relaxed">
            Install BARWAAQO directly to your home screen. It works like an original app with <strong>zero app stores needed</strong>, runs <strong>100% offline</strong>, and opens in full screen with your phone camera barcode scanner.
          </p>
        </div>

        {/* Benefits Badges */}
        <div className="px-4 sm:px-6 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap gap-2 items-center text-[11px] font-bold text-slate-700 shrink-0">
          <span className="flex items-center gap-1 bg-white px-2.5 py-1 rounded-lg border border-slate-200 text-emerald-800 shadow-xs">
            <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
            No App Store
          </span>
          <span className="flex items-center gap-1 bg-white px-2.5 py-1 rounded-lg border border-slate-200 text-emerald-800 shadow-xs">
            <WifiOff className="w-3.5 h-3.5 text-blue-600" />
            Works 100% Offline
          </span>
          <span className="flex items-center gap-1 bg-white px-2.5 py-1 rounded-lg border border-slate-200 text-emerald-800 shadow-xs">
            <ScanBarcode className="w-3.5 h-3.5 text-purple-600" />
            Camera Barcode Scanner
          </span>
          <span className="flex items-center gap-1 bg-white px-2.5 py-1 rounded-lg border border-slate-200 text-emerald-800 shadow-xs">
            <HardDrive className="w-3.5 h-3.5 text-amber-600" />
            Instant Data Storage
          </span>
        </div>

        {/* Scrollable Body Content */}
        <div className="p-4 sm:p-6 overflow-y-auto space-y-5 flex-1">
          {/* Quick Install Action if browser supports native prompt */}
          {isInstallable && (
            <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-600 to-teal-700 text-white shadow-md flex flex-col sm:flex-row items-center justify-between gap-3">
              <div className="space-y-0.5 text-center sm:text-left">
                <div className="text-xs font-black uppercase text-emerald-200 tracking-wider flex items-center justify-center sm:justify-start gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-300" />
                  Your Browser Supports 1-Click Install
                </div>
                <div className="text-sm font-bold">
                  Tap below to add BARWAAQO to your home screen now
                </div>
              </div>
              <button
                onClick={handleDirectInstall}
                className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-slate-950 text-xs font-black shadow-lg transition active:scale-95 flex items-center justify-center gap-2 shrink-0"
              >
                <Download className="w-4 h-4" />
                <span>1-Click Direct Install</span>
              </button>
            </div>
          )}

          {/* Device Tab Selector */}
          <div>
            <div className="text-xs font-black uppercase tracking-wider text-slate-500 mb-2">
              Select Your Device for Instructions:
            </div>
            <div className="grid grid-cols-3 gap-2 p-1 bg-slate-100 rounded-2xl border border-slate-200">
              <button
                onClick={() => setPlatformTab('android')}
                className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-extrabold transition-all ${
                  platformTab === 'android'
                    ? 'bg-white text-emerald-950 shadow-sm border border-slate-200'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Smartphone className="w-4 h-4 text-emerald-600" />
                <span>Android (Chrome)</span>
              </button>
              <button
                onClick={() => setPlatformTab('ios')}
                className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-extrabold transition-all ${
                  platformTab === 'ios'
                    ? 'bg-white text-emerald-950 shadow-sm border border-slate-200'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Smartphone className="w-4 h-4 text-blue-600" />
                <span>iPhone / iPad</span>
              </button>
              <button
                onClick={() => setPlatformTab('desktop')}
                className={`flex items-center justify-center gap-1.5 py-2 px-3 rounded-xl text-xs font-extrabold transition-all ${
                  platformTab === 'desktop'
                    ? 'bg-white text-emerald-950 shadow-sm border border-slate-200'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                <Laptop className="w-4 h-4 text-slate-700" />
                <span>PC & Mac</span>
              </button>
            </div>
          </div>

          {/* TAB CONTENT 1: ANDROID INSTRUCTIONS */}
          {platformTab === 'android' && (
            <div className="space-y-3 bg-emerald-50/50 p-4 rounded-2xl border border-emerald-200/80">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-emerald-950 uppercase tracking-wide flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-emerald-600" />
                  Step-by-Step for Android (Chrome / Edge / Samsung)
                </span>
                <span className="text-[10px] font-bold bg-emerald-100 text-emerald-800 px-2 py-0.5 rounded-full">
                  Fastest
                </span>
              </div>

              <div className="space-y-3">
                <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-emerald-100 shadow-xs">
                  <div className="w-6 h-6 rounded-full bg-emerald-600 text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </div>
                  <div className="text-xs text-slate-700 leading-relaxed">
                    <strong className="text-slate-900 block font-bold">Open Google Chrome</strong>
                    Open this app link in Google Chrome on your Android phone.
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-emerald-100 shadow-xs">
                  <div className="w-6 h-6 rounded-full bg-emerald-600 text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </div>
                  <div className="text-xs text-slate-700 leading-relaxed">
                    <strong className="text-slate-900 block font-bold">Tap the Chrome Menu (⋮)</strong>
                    Tap the <strong>three vertical dots (⋮)</strong> in the top right corner of the screen.
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-emerald-100 shadow-xs">
                  <div className="w-6 h-6 rounded-full bg-emerald-600 text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                    3
                  </div>
                  <div className="text-xs text-slate-700 leading-relaxed">
                    <strong className="text-slate-900 block font-bold">Tap "Install app" or "Add to Home screen"</strong>
                    Select <strong>"Install app"</strong> (or "Add to Home screen") from the list, then tap <strong>"Install"</strong> to confirm.
                  </div>
                </div>
              </div>

              <div className="p-3 bg-emerald-100/70 rounded-xl text-emerald-900 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-emerald-700 shrink-0" />
                <span>The <strong>BARWAAQO</strong> app icon will appear directly on your home screen and in your phone app list!</span>
              </div>
            </div>
          )}

          {/* TAB CONTENT 2: IPHONE / IPAD INSTRUCTIONS */}
          {platformTab === 'ios' && (
            <div className="space-y-3 bg-blue-50/50 p-4 rounded-2xl border border-blue-200/80">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-blue-950 uppercase tracking-wide flex items-center gap-1.5">
                  <Smartphone className="w-4 h-4 text-blue-600" />
                  Step-by-Step for iPhone & iPad (Safari)
                </span>
                <span className="text-[10px] font-bold bg-blue-100 text-blue-800 px-2 py-0.5 rounded-full">
                  Apple iOS
                </span>
              </div>

              <div className="space-y-3">
                <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-blue-100 shadow-xs">
                  <div className="w-6 h-6 rounded-full bg-blue-600 text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </div>
                  <div className="text-xs text-slate-700 leading-relaxed">
                    <strong className="text-slate-900 block font-bold">Open in Safari</strong>
                    Make sure you are opening the link in Apple's <strong>Safari</strong> browser.
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-blue-100 shadow-xs">
                  <div className="w-6 h-6 rounded-full bg-blue-600 text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </div>
                  <div className="text-xs text-slate-700 leading-relaxed">
                    <strong className="text-slate-900 block font-bold">Tap the Share Button</strong>
                    Tap the <strong>Share icon</strong> at the bottom of the screen (a square with an upward arrow pointing up: <Share2 className="w-3.5 h-3.5 inline text-blue-600" />).
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-blue-100 shadow-xs">
                  <div className="w-6 h-6 rounded-full bg-blue-600 text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                    3
                  </div>
                  <div className="text-xs text-slate-700 leading-relaxed">
                    <strong className="text-slate-900 block font-bold">Tap "Add to Home Screen"</strong>
                    Scroll down in the share sheet and tap <strong>"Add to Home Screen"</strong> (<PlusSquare className="w-3.5 h-3.5 inline text-blue-600" />). Then tap <strong>"Add"</strong> in the top-right corner.
                  </div>
                </div>
              </div>

              <div className="p-3 bg-blue-100/70 rounded-xl text-blue-900 text-xs flex items-center gap-2">
                <CheckCircle2 className="w-4 h-4 text-blue-700 shrink-0" />
                <span>The app will open as a pure standalone iOS app with no Safari browser bars!</span>
              </div>
            </div>
          )}

          {/* TAB CONTENT 3: DESKTOP INSTRUCTIONS */}
          {platformTab === 'desktop' && (
            <div className="space-y-3 bg-slate-50 p-4 rounded-2xl border border-slate-200">
              <div className="flex items-center justify-between">
                <span className="text-xs font-black text-slate-900 uppercase tracking-wide flex items-center gap-1.5">
                  <Laptop className="w-4 h-4 text-slate-700" />
                  Desktop (Windows PC, Mac, Chromebook)
                </span>
                <span className="text-[10px] font-bold bg-slate-200 text-slate-800 px-2 py-0.5 rounded-full">
                  Chrome / Edge
                </span>
              </div>

              <div className="space-y-3">
                <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
                  <div className="w-6 h-6 rounded-full bg-slate-700 text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                    1
                  </div>
                  <div className="text-xs text-slate-700 leading-relaxed">
                    <strong className="text-slate-900 block font-bold">Look at the Address Bar</strong>
                    In Chrome or Edge, look at the right end of the top URL address bar for the small <strong>Install App icon</strong> (computer monitor with a downward arrow).
                  </div>
                </div>

                <div className="flex items-start gap-3 bg-white p-3 rounded-xl border border-slate-200 shadow-xs">
                  <div className="w-6 h-6 rounded-full bg-slate-700 text-white font-black text-xs flex items-center justify-center shrink-0 mt-0.5">
                    2
                  </div>
                  <div className="text-xs text-slate-700 leading-relaxed">
                    <strong className="text-slate-900 block font-bold">Click Install</strong>
                    Click <strong>"Install"</strong>. BARWAAQO will open in its own separate desktop window and place a shortcut on your desktop or dock.
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* QR Code Scan Section (Perfect for PC users who want it on their phone) */}
          <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-slate-950 text-white border border-slate-800 shadow-md">
            <div className="flex flex-col sm:flex-row items-center gap-4">
              {qrCodeUrl ? (
                <div className="bg-white p-1.5 rounded-2xl shadow-lg shrink-0">
                  <img
                    src={qrCodeUrl}
                    alt="Scan to open on phone"
                    className="w-28 h-28 object-contain rounded-xl"
                  />
                </div>
              ) : (
                <div className="w-28 h-28 bg-white/10 rounded-2xl flex items-center justify-center text-xs text-white/50 shrink-0">
                  Generating QR...
                </div>
              )}

              <div className="space-y-2 text-center sm:text-left flex-1">
                <div className="inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md bg-amber-400/20 text-amber-300 text-[10px] font-black uppercase tracking-wide">
                  <Smartphone className="w-3 h-3 text-amber-400" />
                  Scan with Phone Camera
                </div>
                <h4 className="text-sm font-black text-white leading-snug">
                  Want to install on your mobile phone right now?
                </h4>
                <p className="text-xs text-slate-300 leading-relaxed">
                  Open your phone's camera, point it at this QR code, tap the banner, and follow the steps above to Add to Home Screen.
                </p>

                <div className="pt-1 flex flex-wrap items-center justify-center sm:justify-start gap-2">
                  <button
                    onClick={handleCopyLink}
                    className="px-3 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition flex items-center gap-1.5 border border-white/15 active:scale-95"
                  >
                    {copiedLink ? (
                      <Check className="w-3.5 h-3.5 text-emerald-400" />
                    ) : (
                      <Copy className="w-3.5 h-3.5" />
                    )}
                    <span>{copiedLink ? 'Link Copied!' : 'Copy Direct App Link'}</span>
                  </button>

                  <a
                    href={productionUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition flex items-center gap-1.5 shadow-xs active:scale-95"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    <span>Open Direct Link</span>
                  </a>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="p-4 sm:p-5 bg-slate-50 border-t border-slate-200 flex flex-col sm:flex-row items-center justify-between gap-3 shrink-0">
          <label className="flex items-center gap-2 cursor-pointer select-none text-xs text-slate-600">
            <input
              type="checkbox"
              checked={dontShowAgain}
              onChange={(e) => setDontShowAgain(e.target.checked)}
              className="w-4 h-4 text-emerald-600 rounded border-slate-300 focus:ring-emerald-500"
            />
            <span>Don't show this automatically on startup</span>
          </label>

          <button
            onClick={handleClose}
            className="w-full sm:w-auto px-6 py-2.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-extrabold text-xs shadow-md transition active:scale-95 flex items-center justify-center gap-2"
          >
            <span>Start Using BARWAAQO OS</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
