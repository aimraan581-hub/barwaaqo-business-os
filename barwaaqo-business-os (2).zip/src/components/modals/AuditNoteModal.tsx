import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { X, FileEdit, ShieldCheck, Lock } from 'lucide-react';
import { PinVerificationModal } from './PinVerificationModal';
import { ActivityLog, SystemUser } from '../../types';

interface AuditNoteModalProps {
  log: ActivityLog | null;
  isOpen: boolean;
  onClose: () => void;
}

export const AuditNoteModal: React.FC<AuditNoteModalProps> = ({
  log,
  isOpen,
  onClose,
}) => {
  const { currentUser, availableUsers, updateActivityLogNote, showToast } = useStore();
  const [note, setNote] = useState('');
  const [operatorId, setOperatorId] = useState(currentUser.id);
  const [showPinModal, setShowPinModal] = useState(false);

  useEffect(() => {
    if (log) {
      setNote(log.auditNote || '');
      setOperatorId(currentUser.id);
      setShowPinModal(false);
    }
  }, [log, currentUser.id]);

  if (!isOpen || !log) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!note.trim()) {
      showToast('Please enter an audit note.');
      return;
    }
    setShowPinModal(true);
  };

  const handlePinSuccess = (authorizedUser: SystemUser) => {
    updateActivityLogNote(log.id, note.trim(), {
      verifiedByPin: true,
      authorizedByUserId: authorizedUser.id,
      authorizedByUserName: authorizedUser.name,
      authorizedByUserRole: authorizedUser.role,
    });
    showToast('Audit note recorded with PIN verification.');
    setShowPinModal(false);
    onClose();
  };

  return (
    <>
      <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
        <div className="bg-white rounded-3xl w-full max-w-md shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
          <div className="p-4 bg-slate-950 text-white flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              <div className="p-2 rounded-xl bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                <FileEdit className="w-5 h-5" />
              </div>
              <div>
                <h3 className="font-bold text-sm tracking-wide">Audit Note & Annotation</h3>
                <p className="text-[10px] text-slate-300">Protected by 4-Digit Security PIN</p>
              </div>
            </div>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleSubmit} className="p-5 space-y-4">
            <div className="p-3 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="text-[10px] uppercase font-bold text-slate-400">Target Activity Log</div>
              <div className="text-xs font-bold text-slate-900 mt-0.5">{log.action}</div>
              <div className="text-[11px] text-slate-600 mt-1 line-clamp-2">{log.detail}</div>
              <div className="text-[10px] text-slate-400 font-mono mt-1">
                Ref: {log.referenceId || log.id} · {log.date} {log.time}
              </div>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Auditor Identity (Identity to Verify)
              </label>
              <select
                value={operatorId}
                onChange={(e) => setOperatorId(e.target.value)}
                className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                {availableUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.id} — {u.name} ({u.role})
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Audit Findings / Justification Note <span className="text-rose-500">*</span>
              </label>
              <textarea
                value={note}
                onChange={(e) => setNote(e.target.value)}
                rows={3}
                placeholder="Enter auditor explanation, physical count verification details, or regulatory memo..."
                required
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-emerald-500"
              />
            </div>

            <div className="flex items-center gap-2 p-2.5 bg-indigo-50 border border-indigo-200 rounded-xl text-[11px] text-indigo-950">
              <Lock className="w-4 h-4 text-indigo-600 shrink-0" />
              <span>
                Authorizing operator must enter their <b>4-digit PIN</b> to commit this audit note.
              </span>
            </div>

            <div className="flex gap-2 pt-1">
              <button
                type="button"
                onClick={onClose}
                className="flex-1 py-2.5 px-3 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!note.trim()}
                className="flex-1 py-2.5 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-xs font-extrabold text-white transition-all shadow-md active:scale-98 flex items-center justify-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Verify PIN & Save</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      <PinVerificationModal
        isOpen={showPinModal}
        onClose={() => setShowPinModal(false)}
        onSuccess={handlePinSuccess}
        actionTitle="Authorize Audit Note"
        actionDescription="Audit notes provide official regulatory and operational annotations on historical transactions."
        targetUserId={operatorId}
        actionDetails={[
          { label: 'Event', value: log.action },
          { label: 'Date', value: `${log.date} ${log.time}` },
          { label: 'Note', value: note },
        ]}
      />
    </>
  );
};
