import React, { useState, useEffect, useRef } from 'react';
import { useStore } from '../../context/StoreContext';
import { Mic, MicOff, Save, X, Activity, Loader2 } from 'lucide-react';

interface VoiceNoteModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const VoiceNoteModal: React.FC<VoiceNoteModalProps> = ({ isOpen, onClose }) => {
  const { logActivity, showToast, currentUser } = useStore();
  const [isRecording, setIsRecording] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [isSupported, setIsSupported] = useState(true);
  const recognitionRef = useRef<any>(null);

  useEffect(() => {
    // Check for browser support
    const SpeechRecognition =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setIsSupported(false);
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.continuous = true;
    recognition.interimResults = true;
    recognition.lang = 'en-US';

    recognition.onresult = (event: any) => {
      let currentInterim = '';
      let currentFinal = '';

      for (let i = event.resultIndex; i < event.results.length; ++i) {
        if (event.results[i].isFinal) {
          currentFinal += event.results[i][0].transcript + ' ';
        } else {
          currentInterim += event.results[i][0].transcript;
        }
      }

      setTranscript((prev) => prev + currentFinal);
      setInterimTranscript(currentInterim);
    };

    recognition.onerror = (event: any) => {
      console.error('Speech recognition error', event.error);
      setIsRecording(false);
      if (event.error === 'not-allowed') {
        showToast('Microphone access denied. Please check permissions.');
      }
    };

    recognition.onend = () => {
      // Auto-restart if we are supposed to be recording
      if (isRecording) {
        try {
          recognition.start();
        } catch (e) {
          console.error(e);
        }
      }
    };

    recognitionRef.current = recognition;

    return () => {
      if (recognitionRef.current) {
        recognitionRef.current.stop();
      }
    };
  }, []); // Run once on mount

  useEffect(() => {
    // Handle manual stop/start based on state
    if (!recognitionRef.current) return;

    if (isRecording) {
      try {
        recognitionRef.current.start();
      } catch (e) {
        // Already started
      }
    } else {
      recognitionRef.current.stop();
    }
  }, [isRecording]);

  const toggleRecording = () => {
    if (!isSupported) {
      showToast('Voice typing is not supported in this browser.');
      return;
    }
    setIsRecording(!isRecording);
  };

  const handleSave = () => {
    const finalText = (transcript + interimTranscript).trim();
    if (!finalText) {
      showToast('Note is empty.');
      return;
    }

    logActivity(
      'CEO_NOTE_LOGGED',
      `Voice Note: "${finalText}"`,
      {
        category: 'ceo_note',
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        auditNote: finalText,
        isHighValue: false,
      }
    );

    showToast('Voice note saved to audit trail.');
    setTranscript('');
    setInterimTranscript('');
    setIsRecording(false);
    onClose();
  };

  const handleClose = () => {
    setIsRecording(false);
    setTranscript('');
    setInterimTranscript('');
    onClose();
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150 flex flex-col">
        <div className="p-4 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <Mic className="w-5 h-5 text-amber-400" />
            <div>
              <h3 className="font-bold text-sm tracking-wide">Quick Voice Note</h3>
              <p className="text-[10px] text-slate-400">Dictate operational reminders & audit findings</p>
            </div>
          </div>
          <button
            onClick={handleClose}
            className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 flex flex-col gap-4">
          {!isSupported ? (
            <div className="p-4 bg-rose-50 text-rose-700 rounded-2xl text-sm font-medium border border-rose-200 flex items-start gap-2">
              <Activity className="w-5 h-5 shrink-0" />
              Your browser does not support the Web Speech API. Please use Chrome, Edge, or Safari.
            </div>
          ) : (
            <>
              <div
                className={`w-full min-h-[150px] p-4 rounded-2xl border-2 transition-colors duration-300 relative bg-slate-50 ${
                  isRecording ? 'border-amber-400 ring-4 ring-amber-400/20' : 'border-slate-200'
                }`}
              >
                {isRecording && (
                  <div className="absolute top-3 right-3 flex items-center gap-1.5 px-2 py-1 bg-amber-100 text-amber-700 rounded-lg text-[10px] font-bold uppercase tracking-wider animate-pulse">
                    <div className="w-2 h-2 bg-amber-500 rounded-full"></div>
                    Recording...
                  </div>
                )}
                
                <div className="text-sm text-slate-700 font-medium whitespace-pre-wrap mt-1">
                  {transcript}
                  <span className="text-slate-400">{interimTranscript}</span>
                  {!transcript && !interimTranscript && !isRecording && (
                    <span className="text-slate-400 italic">Tap the microphone to start dictating...</span>
                  )}
                  {!transcript && !interimTranscript && isRecording && (
                    <span className="text-slate-400 italic">Listening...</span>
                  )}
                </div>
              </div>

              <div className="flex justify-between items-center mt-2">
                <button
                  onClick={toggleRecording}
                  className={`flex items-center gap-2 px-6 py-3 rounded-2xl font-bold text-sm transition-all shadow-xs ${
                    isRecording
                      ? 'bg-rose-100 text-rose-700 border border-rose-300 hover:bg-rose-200'
                      : 'bg-amber-100 text-amber-700 border border-amber-300 hover:bg-amber-200'
                  }`}
                >
                  {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
                  {isRecording ? 'Stop Recording' : 'Start Dictation'}
                </button>

                <button
                  onClick={handleSave}
                  disabled={!transcript && !interimTranscript}
                  className="flex items-center gap-2 px-6 py-3 rounded-2xl font-bold text-sm bg-slate-900 text-white hover:bg-slate-800 transition-all shadow-xs disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  <Save className="w-4 h-4" />
                  Save Note
                </button>
              </div>
            </>
          )}
        </div>
      </div>
    </div>
  );
};
