import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { money } from '../../utils/helpers';
import {
  X,
  SlidersHorizontal,
  AlertCircle,
  ArrowUpRight,
  ArrowDownRight,
  UserCheck,
  ShieldCheck,
  Lock,
} from 'lucide-react';
import { PinVerificationModal } from './PinVerificationModal';
import { SystemUser } from '../../types';

export const StockAdjustModal: React.FC = () => {
  const {
    stockAdjustProductId,
    setStockAdjustProductId,
    db,
    adjustStock,
    currentUser,
    availableUsers,
  } = useStore();
  const [qty, setQty] = useState<number | ''>('');
  const [type, setType] = useState<'increase' | 'decrease'>('increase');
  const [reason, setReason] = useState('Physical stock count adjustment');
  const [operatorId, setOperatorId] = useState(currentUser.id);
  const [showPinModal, setShowPinModal] = useState(false);

  const product = db.products.find((p) => p.id === stockAdjustProductId);

  useEffect(() => {
    if (stockAdjustProductId) {
      setQty('');
      setType('increase');
      setReason('Physical stock count adjustment');
      setOperatorId(currentUser.id);
      setShowPinModal(false);
    }
  }, [stockAdjustProductId, currentUser.id]);

  if (!stockAdjustProductId || !product) return null;

  const handleOpenPinVerification = (e: React.FormEvent) => {
    e.preventDefault();
    const num = Number(qty);
    if (!num || num <= 0) return;
    if (type === 'decrease' && num > product.stock) return;
    setShowPinModal(true);
  };

  const handlePinSuccess = (authorizedUser: SystemUser) => {
    const num = Number(qty);
    if (!num || num <= 0) return;
    const ok = adjustStock(product.id, num, type, reason, authorizedUser.id, {
      verifiedByPin: true,
      authorizedByUserId: authorizedUser.id,
      authorizedByUserName: authorizedUser.name,
      authorizedByUserRole: authorizedUser.role,
    });
    if (ok) {
      setShowPinModal(false);
      setStockAdjustProductId(null);
    }
  };

  const numQty = Number(qty) || 0;
  const resultingStock =
    type === 'increase'
      ? product.stock + numQty
      : Math.max(0, product.stock - numQty);

  const valueImpact = numQty * (product.buy || 0);

  return (
    <>
      <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl w-full max-w-md shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
          <div className="p-4 bg-emerald-950 text-white flex items-center justify-between">
            <div className="flex items-center gap-2">
              <SlidersHorizontal className="w-5 h-5 text-emerald-400" />
              <div>
                <h3 className="font-bold text-sm tracking-wide">Stock Quantity Adjustment</h3>
                <p className="text-[10px] text-emerald-300">Protected by 4-Digit Security PIN Audit</p>
              </div>
            </div>
            <button
              onClick={() => setStockAdjustProductId(null)}
              className="text-slate-400 hover:text-white transition-colors"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          <form onSubmit={handleOpenPinVerification} className="p-5 space-y-4">
            {/* Product Overview */}
            <div className="p-3.5 bg-slate-50 border border-slate-200 rounded-xl">
              <div className="font-bold text-sm text-slate-900">{product.name}</div>
              <div className="flex justify-between items-center text-xs text-slate-500 mt-1">
                <span>SKU: {product.sku || 'N/A'}</span>
                <span>Unit Cost: {money(product.buy)}</span>
              </div>
              <div className="flex justify-between items-center mt-2 pt-2 border-t border-slate-200 text-xs font-semibold">
                <span className="text-slate-600">Current On Hand:</span>
                <span className="text-emerald-700 font-extrabold text-sm">
                  {product.stock} {product.unit}
                </span>
              </div>
            </div>

            {/* Operator / User ID attribution */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5 flex items-center gap-1.5">
                <UserCheck className="w-3.5 h-3.5 text-emerald-600" />
                Audited Operator (Identity to Verify)
              </label>
              <select
                value={operatorId}
                onChange={(e) => setOperatorId(e.target.value)}
                className="w-full px-3.5 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                {availableUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.id} — {u.name} ({u.role})
                  </option>
                ))}
              </select>
            </div>

            {/* Direction toggle */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Adjustment Mode</label>
              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  onClick={() => setType('increase')}
                  className={`py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 text-xs font-bold border transition-all ${
                    type === 'increase'
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-700 shadow-xs'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <ArrowUpRight className="w-4 h-4 text-emerald-600" />
                  Increase Stock (+)
                </button>
                <button
                  type="button"
                  onClick={() => setType('decrease')}
                  className={`py-2 px-3 rounded-xl flex items-center justify-center gap-1.5 text-xs font-bold border transition-all ${
                    type === 'decrease'
                      ? 'bg-rose-50 border-rose-500 text-rose-700 shadow-xs'
                      : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  <ArrowDownRight className="w-4 h-4 text-rose-600" />
                  Decrease Stock (−)
                </button>
              </div>
            </div>

            {/* Quantity */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Adjustment Quantity ({product.unit})
              </label>
              <input
                id="stockAdjustQty"
                type="number"
                min="1"
                max={type === 'decrease' ? product.stock : 99999}
                value={qty}
                onChange={(e) => setQty(e.target.value === '' ? '' : Math.max(1, Number(e.target.value)))}
                placeholder="e.g. 5"
                required
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-sm font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
              />
              {type === 'decrease' && Number(qty) > product.stock && (
                <p className="text-[11px] text-rose-600 flex items-center gap-1 mt-1">
                  <AlertCircle className="w-3 h-3" /> Cannot decrease more than current stock ({product.stock})
                </p>
              )}
            </div>

            {/* Reason */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">Reason / Audit Category</label>
              <select
                value={reason}
                onChange={(e) => setReason(e.target.value)}
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500 bg-white"
              >
                <option value="Physical stock count adjustment">Physical stock count adjustment</option>
                <option value="Damaged / Expired goods write-off">Damaged / Expired goods write-off</option>
                <option value="Supplier delivery surplus">Supplier delivery surplus</option>
                <option value="Internal store usage / Sample">Internal store usage / Sample</option>
                <option value="Returned undamaged customer item">Returned undamaged customer item</option>
                <option value="Inventory shrinkage / Loss investigation">Inventory shrinkage / Loss investigation</option>
              </select>
            </div>

            {/* Preview & Impact banner */}
            <div className="p-3 rounded-xl bg-slate-100 space-y-1.5 text-xs">
              <div className="flex items-center justify-between">
                <span className="text-slate-600">New Resulting Stock:</span>
                <span className="font-extrabold text-sm text-slate-900">
                  {resultingStock} {product.unit}
                </span>
              </div>
              {numQty > 0 && (
                <div className="flex items-center justify-between pt-1 border-t border-slate-200">
                  <span className="text-slate-500">Valuation Impact:</span>
                  <span className={`font-bold font-mono ${type === 'increase' ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {type === 'increase' ? '+' : '−'}{money(valueImpact)}
                  </span>
                </div>
              )}
            </div>

            <div className="flex items-center gap-2 p-2.5 bg-emerald-50 border border-emerald-200 rounded-xl text-[11px] text-emerald-900">
              <Lock className="w-4 h-4 text-emerald-600 shrink-0" />
              <span>
                A <b>4-digit PIN verification step</b> will be required next to commit this change to the audit ledger.
              </span>
            </div>

            {/* Actions */}
            <div className="flex gap-2 pt-2">
              <button
                type="button"
                onClick={() => setStockAdjustProductId(null)}
                className="flex-1 py-2.5 px-3 rounded-xl border border-slate-300 text-xs font-bold text-slate-700 hover:bg-slate-50 transition-colors"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={!qty || (type === 'decrease' && Number(qty) > product.stock)}
                className="flex-1 py-2.5 px-3 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-xs font-extrabold text-white transition-all shadow-md active:scale-98 flex items-center justify-center gap-1.5"
              >
                <ShieldCheck className="w-4 h-4" />
                <span>Verify PIN & Save</span>
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* 4-Digit PIN Security Gate Modal */}
      <PinVerificationModal
        isOpen={showPinModal}
        onClose={() => setShowPinModal(false)}
        onSuccess={handlePinSuccess}
        actionTitle="Authorize Stock Adjustment"
        actionDescription="Physical stock adjustment commits a permanent change to inventory balances and unit valuation."
        targetUserId={operatorId}
        actionDetails={[
          { label: 'Product', value: product.name },
          {
            label: 'Adjustment',
            value: `${type === 'increase' ? '+' : '−'}${numQty} ${product.unit}`,
          },
          {
            label: 'New Stock',
            value: `${resultingStock} ${product.unit}`,
          },
          {
            label: 'Valuation Impact',
            value: `${type === 'increase' ? '+' : '−'}${money(valueImpact)}`,
          },
          { label: 'Audit Category', value: reason },
        ]}
      />
    </>
  );
};
