import React, { useState, useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { getProductFullLedger, StockHistoryMovement } from '../../utils/productHistory';
import { money } from '../../utils/helpers';
import { ProductQrLabel } from '../ProductQrLabel';
import {
  X,
  QrCode,
  History,
  TrendingUp,
  Package,
  ArrowDownLeft,
  ArrowUpRight,
  SlidersHorizontal,
  Printer,
  Copy,
  Check,
  ExternalLink,
  ShieldCheck,
  AlertTriangle,
  Clock,
  User,
  FileText,
  DollarSign,
  Percent,
  CheckCircle2,
  Calendar,
  Layers,
} from 'lucide-react';

interface ProductQrHistoryModalProps {
  productId: string | null;
  onClose: () => void;
}

export const ProductQrHistoryModal: React.FC<ProductQrHistoryModalProps> = ({ productId, onClose }) => {
  const { db, setStockAdjustProductId, setActiveTab } = useStore();
  const [activeTab, setActiveTabLocal] = useState<'history' | 'profit' | 'qr'>('history');
  const [historyFilter, setHistoryFilter] = useState<'all' | 'in' | 'out' | 'adjust'>('all');
  const [copiedUrl, setCopiedUrl] = useState(false);

  const ledger = useMemo(() => {
    if (!productId) return null;
    return getProductFullLedger(productId, db);
  }, [productId, db]);

  if (!productId || !ledger) return null;

  const { product, metrics, history, profit, qrPayloadUrl } = ledger;

  // Filter movements
  const filteredHistory = history.filter((mov) => {
    if (historyFilter === 'all') return true;
    if (historyFilter === 'in') return mov.direction === 'in';
    if (historyFilter === 'out') return mov.direction === 'out';
    if (historyFilter === 'adjust') return mov.type === 'adjustment';
    return true;
  });

  const totalInflow = history
    .filter((m) => m.direction === 'in')
    .reduce((acc, m) => acc + m.qty, 0);

  const totalOutflow = history
    .filter((m) => m.direction === 'out')
    .reduce((acc, m) => acc + m.qty, 0);

  const handleCopyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(qrPayloadUrl);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-3xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header with Product Identity */}
        <div className="bg-gradient-to-br from-slate-950 via-slate-900 to-emerald-950 text-white p-5 sm:p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 sm:top-5 sm:right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-start sm:items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/10 p-2.5 backdrop-blur-md border border-white/20 shadow-inner flex items-center justify-center shrink-0">
              <QrCode className="w-8 h-8 text-emerald-400" />
            </div>

            <div className="flex-1 pr-6 sm:pr-0">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="px-2 py-0.5 rounded-md bg-emerald-500/25 text-emerald-300 text-[10px] font-black uppercase tracking-wider border border-emerald-400/30">
                  Item Identity & QR Ledger
                </span>
                <span className="text-[10px] font-mono text-slate-300 bg-white/10 px-2 py-0.5 rounded-md">
                  {product.sku ? `SKU: ${product.sku}` : `ID: ${product.id}`}
                </span>
                <span
                  className={`px-2 py-0.5 rounded-md text-[10px] font-bold ${
                    metrics.health === 'out'
                      ? 'bg-rose-500/30 text-rose-200 border border-rose-400/30'
                      : metrics.health === 'low'
                      ? 'bg-amber-500/30 text-amber-200 border border-amber-400/30'
                      : 'bg-emerald-500/30 text-emerald-200 border border-emerald-400/30'
                  }`}
                >
                  {metrics.health === 'out'
                    ? 'Out of Stock'
                    : metrics.health === 'low'
                    ? 'Low Stock Alert'
                    : 'Stock Healthy'}
                </span>
              </div>

              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white mt-1">
                {product.name}
              </h2>
              <p className="text-xs text-emerald-200/80 mt-0.5">
                On Hand: <strong className="text-white">{product.stock} {product.unit}</strong> · Cost:{' '}
                {money(product.buy)} · Retail: <strong className="text-white">{money(product.sell)}</strong> · Unit Margin:{' '}
                <strong className="text-emerald-300">+{money(profit.retailMargin)} ({profit.retailMarginPct.toFixed(1)}%)</strong>
              </p>
            </div>
          </div>

          {/* Navigation Sub-tabs */}
          <div className="flex items-center gap-2 mt-5 pt-3 border-t border-white/10 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setActiveTabLocal('history')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'history'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-white/70 hover:bg-white/10'
              }`}
            >
              <History className="w-3.5 h-3.5" />
              Stock History ({history.length})
            </button>
            <button
              onClick={() => setActiveTabLocal('profit')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'profit'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-white/70 hover:bg-white/10'
              }`}
            >
              <TrendingUp className="w-3.5 h-3.5" />
              Profit Margin Records
            </button>
            <button
              onClick={() => setActiveTabLocal('qr')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap ${
                activeTab === 'qr'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-white/70 hover:bg-white/10'
              }`}
            >
              <QrCode className="w-3.5 h-3.5" />
              QR Code Label & Shelf Tag
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-4 sm:p-6 space-y-4 max-h-[70vh] overflow-y-auto text-slate-700">
          {/* TAB 1: STOCK HISTORY */}
          {activeTab === 'history' && (
            <div className="space-y-4">
              {/* Summary Metrics Row */}
              <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider">
                    Current Stock
                  </span>
                  <div className="text-lg font-black text-slate-900 mt-0.5">
                    {product.stock} <span className="text-xs font-semibold text-slate-500">{product.unit}</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block mt-0.5">
                    Runway: {metrics.daysOfCover >= 999 ? '∞' : `${metrics.daysOfCover}d`}
                  </span>
                </div>

                <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-200">
                  <span className="text-[10px] font-bold text-emerald-700 block uppercase tracking-wider">
                    Total Inflow (+)
                  </span>
                  <div className="text-lg font-black text-emerald-950 mt-0.5">
                    +{totalInflow} <span className="text-xs font-semibold text-emerald-800">{product.unit}</span>
                  </div>
                  <span className="text-[10px] text-emerald-700 block mt-0.5">Purchases & Open Stock</span>
                </div>

                <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200">
                  <span className="text-[10px] font-bold text-amber-700 block uppercase tracking-wider">
                    Total Outflow (−)
                  </span>
                  <div className="text-lg font-black text-amber-950 mt-0.5">
                    −{totalOutflow} <span className="text-xs font-semibold text-amber-800">{product.unit}</span>
                  </div>
                  <span className="text-[10px] text-amber-700 block mt-0.5">Sales & Orders</span>
                </div>

                <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
                  <span className="text-[10px] font-bold text-slate-400 block uppercase tracking-wider">
                    Daily Velocity
                  </span>
                  <div className="text-lg font-black text-slate-900 mt-0.5">
                    {metrics.recentSalesVelocity}{' '}
                    <span className="text-xs font-semibold text-slate-500">{product.unit}/day</span>
                  </div>
                  <span className="text-[10px] text-slate-500 block mt-0.5">
                    Safety Min: {metrics.dynamicSafetyThreshold}
                  </span>
                </div>
              </div>

              {/* Movement Filters & Actions */}
              <div className="flex items-center justify-between gap-2 flex-wrap pt-2">
                <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-bold">
                  <button
                    onClick={() => setHistoryFilter('all')}
                    className={`px-3 py-1 rounded-lg transition ${
                      historyFilter === 'all'
                        ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    All ({history.length})
                  </button>
                  <button
                    onClick={() => setHistoryFilter('in')}
                    className={`px-3 py-1 rounded-lg transition flex items-center gap-1 ${
                      historyFilter === 'in'
                        ? 'bg-white text-emerald-900 shadow-sm border border-slate-200/80'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <ArrowDownLeft className="w-3 h-3 text-emerald-600" />
                    Inflow
                  </button>
                  <button
                    onClick={() => setHistoryFilter('out')}
                    className={`px-3 py-1 rounded-lg transition flex items-center gap-1 ${
                      historyFilter === 'out'
                        ? 'bg-white text-amber-900 shadow-sm border border-slate-200/80'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <ArrowUpRight className="w-3 h-3 text-amber-600" />
                    Outflow
                  </button>
                  <button
                    onClick={() => setHistoryFilter('adjust')}
                    className={`px-3 py-1 rounded-lg transition flex items-center gap-1 ${
                      historyFilter === 'adjust'
                        ? 'bg-white text-purple-900 shadow-sm border border-slate-200/80'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <SlidersHorizontal className="w-3 h-3 text-purple-600" />
                    Adjustments
                  </button>
                </div>

                <button
                  onClick={() => {
                    onClose();
                    setStockAdjustProductId(product.id);
                  }}
                  className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs transition flex items-center gap-1.5 shadow-sm"
                >
                  <SlidersHorizontal className="w-3.5 h-3.5" />
                  <span>Adjust Stock</span>
                </button>
              </div>

              {/* Timeline List */}
              <div className="space-y-2.5">
                {filteredHistory.length === 0 ? (
                  <div className="p-8 text-center bg-slate-50 rounded-2xl border border-slate-200 text-slate-400 text-xs">
                    No movements recorded under this filter.
                  </div>
                ) : (
                  filteredHistory.map((mov) => {
                    const isIn = mov.direction === 'in';
                    const isAdjust = mov.type === 'adjustment';

                    return (
                      <div
                        key={mov.id}
                        className={`p-3.5 rounded-2xl border transition-all ${
                          isIn
                            ? 'bg-emerald-50/40 border-emerald-200/70 hover:border-emerald-300'
                            : isAdjust
                            ? 'bg-purple-50/40 border-purple-200/70 hover:border-purple-300'
                            : 'bg-white border-slate-200 hover:border-slate-300'
                        }`}
                      >
                        <div className="flex items-start justify-between gap-3">
                          <div className="flex items-start gap-3">
                            <div
                              className={`p-2 rounded-xl shrink-0 mt-0.5 ${
                                isIn
                                  ? 'bg-emerald-100 text-emerald-700'
                                  : isAdjust
                                  ? 'bg-purple-100 text-purple-700'
                                  : 'bg-amber-100 text-amber-700'
                              }`}
                            >
                              {isIn ? (
                                <ArrowDownLeft className="w-4 h-4" />
                              ) : isAdjust ? (
                                <SlidersHorizontal className="w-4 h-4" />
                              ) : (
                                <ArrowUpRight className="w-4 h-4" />
                              )}
                            </div>

                            <div>
                              <div className="flex items-center gap-2 flex-wrap">
                                <span className="font-black text-xs text-slate-900">
                                  {mov.typeLabel}
                                </span>
                                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-slate-100 text-slate-700 border border-slate-200">
                                  {mov.reference}
                                </span>
                                {mov.user && (
                                  <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-indigo-50 text-indigo-700 border border-indigo-200 flex items-center gap-1">
                                    <User className="w-2.5 h-2.5" />
                                    {mov.user}
                                  </span>
                                )}
                              </div>

                              <div className="text-xs text-slate-600 mt-1 flex flex-wrap items-center gap-2">
                                {mov.party && (
                                  <span>
                                    Party: <b className="text-slate-800">{mov.party}</b>
                                  </span>
                                )}
                                {mov.unitPrice !== undefined && (
                                  <span>
                                    Rate: <b>{money(mov.unitPrice)}</b>
                                  </span>
                                )}
                                {mov.totalAmount !== undefined && (
                                  <span>
                                    Valuation: <b>{money(mov.totalAmount)}</b>
                                  </span>
                                )}
                              </div>

                              {mov.reason && (
                                <div className="text-[11px] text-slate-500 mt-0.5 italic">
                                  {mov.reason}
                                </div>
                              )}
                            </div>
                          </div>

                          <div className="text-right shrink-0">
                            <div
                              className={`text-sm font-black ${
                                isIn
                                  ? 'text-emerald-700'
                                  : isAdjust
                                  ? mov.signedQty >= 0
                                    ? 'text-purple-700'
                                    : 'text-rose-700'
                                  : 'text-amber-700'
                              }`}
                            >
                              {mov.signedQty > 0 ? `+${mov.qty}` : `−${mov.qty}`} {product.unit}
                            </div>
                            <div className="text-[10px] text-slate-400 mt-0.5 flex items-center justify-end gap-1">
                              <Calendar className="w-2.5 h-2.5" />
                              <span>{mov.date}</span>
                              {mov.time && <span>· {mov.time}</span>}
                            </div>
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>
          )}

          {/* TAB 2: PROFIT MARGIN RECORDS */}
          {activeTab === 'profit' && (
            <div className="space-y-4">
              {/* Unit Economics Highlight Cards */}
              <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                {/* Cost Basis */}
                <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-1">
                  <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400">
                    Purchase Cost Basis
                  </span>
                  <div className="text-xl font-black text-slate-900">{money(profit.buyPrice)}</div>
                  <span className="text-[11px] text-slate-500 block">Unit buy price from vendor</span>
                </div>

                {/* Retail Margin */}
                <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-emerald-700">
                      Retail Gross Margin
                    </span>
                    <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-emerald-200/80 text-emerald-900">
                      {profit.retailMarginPct.toFixed(1)}%
                    </span>
                  </div>
                  <div className="text-xl font-black text-emerald-950">+{money(profit.retailMargin)}</div>
                  <span className="text-[11px] text-emerald-800 block">
                    Retail: {money(profit.sellPrice)} · Markup: {profit.retailMarkupPct.toFixed(1)}%
                  </span>
                </div>

                {/* Wholesale Margin */}
                <div className="p-4 rounded-2xl bg-teal-50/70 border border-teal-200 space-y-1">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] font-extrabold uppercase tracking-wider text-teal-700">
                      Wholesale Gross Margin
                    </span>
                    <span className="text-[10px] font-black px-2 py-0.5 rounded-full bg-teal-200/80 text-teal-900">
                      {profit.wholesaleMarginPct.toFixed(1)}%
                    </span>
                  </div>
                  <div className="text-xl font-black text-teal-950">+{money(profit.wholesaleMargin)}</div>
                  <span className="text-[11px] text-teal-800 block">
                    Wholesale: {money(profit.wholesalePrice)} · Markup: {profit.wholesaleMarkupPct.toFixed(1)}%
                  </span>
                </div>
              </div>

              {/* Cumulative Financial Ledger */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-emerald-950 text-white shadow-lg space-y-3">
                <div className="flex items-center justify-between border-b border-white/10 pb-2">
                  <div className="flex items-center gap-2">
                    <TrendingUp className="w-4 h-4 text-emerald-400" />
                    <span className="font-extrabold text-xs uppercase tracking-wider text-emerald-300">
                      Cumulative Sales & Profit Ledger
                    </span>
                  </div>
                  <span className="text-xs font-bold text-slate-300">
                    {profit.totalUnitsSold} units sold
                  </span>
                </div>

                <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 pt-1">
                  <div>
                    <span className="text-[10px] uppercase text-emerald-200/70 font-semibold block">
                      Lifetime Revenue
                    </span>
                    <span className="text-base font-black text-white">{money(profit.totalSalesRevenue)}</span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase text-emerald-200/70 font-semibold block">
                      Lifetime COGS (Cost)
                    </span>
                    <span className="text-base font-black text-slate-300">{money(profit.totalSalesCost)}</span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase text-emerald-200/70 font-semibold block">
                      Realized Gross Profit
                    </span>
                    <span className="text-base font-black text-emerald-300">
                      +{money(profit.totalRealizedGrossProfit)}
                    </span>
                  </div>
                  <div>
                    <span className="text-[10px] uppercase text-emerald-200/70 font-semibold block">
                      Realized Profit Margin
                    </span>
                    <span className="text-base font-black text-white">
                      {profit.overallGrossMarginPct.toFixed(1)}%
                    </span>
                  </div>
                </div>

                <div className="pt-2 border-t border-white/10 flex flex-wrap items-center justify-between text-xs text-emerald-200/80 gap-2">
                  <span>
                    Unrealized Inventory Profit (in stock):{' '}
                    <strong className="text-white">+{money(profit.unrealizedPotentialProfit)}</strong>
                  </span>
                  <span>
                    Stock Value at Cost:{' '}
                    <strong className="text-white">{money(profit.currentStockCostValue)}</strong> · At Retail:{' '}
                    <strong className="text-white">{money(profit.currentStockRetailValue)}</strong>
                  </span>
                </div>
              </div>

              {/* Itemized Sales Profit Audit Table */}
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <h4 className="font-black text-xs uppercase tracking-wider text-slate-800 flex items-center gap-1.5">
                    <FileText className="w-3.5 h-3.5 text-emerald-600" />
                    Transaction-Level Profit Audit ({profit.salesRecords.length} Sales)
                  </h4>
                  <span className="text-[10px] text-slate-500">Chronological sale receipts</span>
                </div>

                {profit.salesRecords.length === 0 ? (
                  <div className="p-6 text-center bg-slate-50 rounded-2xl border border-slate-200 text-slate-400 text-xs">
                    No sales recorded for this product yet. Margins will automatically compute as sales are made.
                  </div>
                ) : (
                  <div className="border border-slate-200 rounded-2xl overflow-hidden shadow-xs">
                    <div className="overflow-x-auto max-h-60">
                      <table className="w-full text-left text-xs">
                        <thead className="bg-slate-50 border-b border-slate-200 text-[10px] font-extrabold uppercase text-slate-500 sticky top-0 bg-slate-50 z-10">
                          <tr>
                            <th className="py-2.5 px-3">Date / Invoice</th>
                            <th className="py-2.5 px-3">Mode</th>
                            <th className="py-2.5 px-3">Customer</th>
                            <th className="py-2.5 px-3 text-right">Qty</th>
                            <th className="py-2.5 px-3 text-right">Price</th>
                            <th className="py-2.5 px-3 text-right">Cost</th>
                            <th className="py-2.5 px-3 text-right">Gross Profit</th>
                            <th className="py-2.5 px-3 text-right">Margin %</th>
                          </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-100">
                          {profit.salesRecords.map((rec) => (
                            <tr key={rec.id} className="hover:bg-slate-50/80 transition-colors">
                              <td className="py-2.5 px-3 font-mono font-bold text-slate-900">
                                <div>{rec.invoice}</div>
                                <div className="text-[10px] font-normal text-slate-400">{rec.date}</div>
                              </td>
                              <td className="py-2.5 px-3">
                                <span
                                  className={`px-1.5 py-0.5 rounded text-[9px] font-black uppercase ${
                                    rec.mode === 'wholesale'
                                      ? 'bg-blue-100 text-blue-800'
                                      : 'bg-emerald-100 text-emerald-800'
                                  }`}
                                >
                                  {rec.mode}
                                </span>
                              </td>
                              <td className="py-2.5 px-3 text-slate-700 max-w-[120px] truncate">{rec.customer}</td>
                              <td className="py-2.5 px-3 text-right font-black text-slate-900">
                                {rec.qty} {product.unit}
                              </td>
                              <td className="py-2.5 px-3 text-right text-slate-700">{money(rec.unitPrice)}</td>
                              <td className="py-2.5 px-3 text-right text-slate-500">{money(rec.unitCost)}</td>
                              <td className="py-2.5 px-3 text-right font-black text-emerald-700">
                                +{money(rec.totalProfit)}
                              </td>
                              <td className="py-2.5 px-3 text-right font-bold text-slate-800">
                                {rec.marginPct.toFixed(1)}%
                              </td>
                            </tr>
                          ))}
                        </tbody>
                      </table>
                    </div>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 3: QR CODE LABEL & SHELF TAG */}
          {activeTab === 'qr' && (
            <div className="space-y-4">
              <ProductQrLabel product={product} size="shelf" showActions={true} />

              {/* Direct Deep Link Card */}
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2">
                <div className="flex items-center gap-2 font-black text-xs text-slate-900">
                  <ExternalLink className="w-4 h-4 text-emerald-600" />
                  Direct Product Deep Link
                </div>
                <p className="text-xs text-slate-600">
                  Scanning the QR code on a smartphone camera or handheld scanner opens this exact stock and margin ledger directly:
                </p>
                <div className="flex items-center gap-2 p-2 rounded-xl bg-white border border-slate-300">
                  <span className="font-mono text-xs text-slate-800 truncate flex-1 select-all">
                    {qrPayloadUrl}
                  </span>
                  <button
                    onClick={handleCopyLink}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shrink-0 flex items-center gap-1.5"
                  >
                    {copiedUrl ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        Copied
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        Copy Link
                      </>
                    )}
                  </button>
                </div>
              </div>

              {/* Retail Label Specifications */}
              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-2 text-xs text-emerald-900">
                <div className="font-extrabold flex items-center gap-1.5 text-emerald-950">
                  <ShieldCheck className="w-4 h-4 text-emerald-700" />
                  Standard Thermal Shelf Sticker Spec (50mm × 30mm)
                </div>
                <p className="text-[11px] text-emerald-800 leading-relaxed">
                  Our auto-generated QR labels feature high-contrast vector codes formatted for commercial retail thermal barcode printers (Zebra, TSC, Brother, Xprinter). They print crisp on standard shelf adhesive labels with product title, packaging unit, retail selling price, and confidential margin verification.
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="text-xs text-slate-500 font-medium">
            IMRUU Grocery OS · Product Ledger Engine
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition shadow-sm"
          >
            Close
          </button>
        </div>
      </div>
    </div>
  );
};
