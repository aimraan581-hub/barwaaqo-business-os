import React from 'react';
import { useStore } from '../../context/StoreContext';
import { VERSION, money } from '../../utils/helpers';
import { X, Store, CheckCircle2, ShieldAlert, FileText, Sparkles, Edit2, User, Building2, Users } from 'lucide-react';

export const BusinessInfoModal: React.FC = () => {
  const {
    isBusinessInfoOpen,
    setIsBusinessInfoOpen,
    setIsCeoProfileModalOpen,
    openTeamManagement,
    businessProfile,
    availableUsers,
    db,
    totals,
  } = useStore();

  if (!isBusinessInfoOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        <div className="p-5 bg-gradient-to-br from-[#031c12] via-[#064e2f] to-[#0a6b40] text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <img
              src="/logo.png"
              alt="BARWAAQO"
              className="w-11 h-11 rounded-2xl object-cover shadow-md ring-2 ring-amber-400/40 shrink-0"
              onError={(e) => {
                (e.target as HTMLElement).style.display = 'none';
              }}
            />
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base tracking-wide uppercase">
                  {businessProfile.storeName || 'BARWAAQO Business OS'}
                </h3>
                <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-400 text-amber-950">
                  BUSINESS OS
                </span>
              </div>
              <p className="text-[11px] text-emerald-200">
                From Shop to Distribution · CEO: {businessProfile.ceoName}
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsBusinessInfoOpen(false)}
            className="p-1 rounded-lg text-emerald-200 hover:text-white hover:bg-emerald-800/50 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-5 space-y-4 text-xs text-slate-600">
          {/* Executive & Legal Identity Card */}
          <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-2.5">
            <div className="flex items-center justify-between">
              <span className="font-extrabold text-xs uppercase tracking-wider text-slate-500">
                Executive & Corporate Identity
              </span>
              <button
                onClick={() => {
                  setIsBusinessInfoOpen(false);
                  setIsCeoProfileModalOpen(true);
                }}
                className="flex items-center gap-1 text-[11px] font-extrabold text-emerald-700 hover:text-emerald-900 bg-emerald-100/70 hover:bg-emerald-100 px-2.5 py-1 rounded-xl transition"
              >
                <Edit2 className="w-3 h-3" />
                <span>Edit CEO / Store Details</span>
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-[11px]">
              <div>
                <span className="text-slate-400 block font-medium">CEO / Store Owner</span>
                <span className="font-extrabold text-slate-900 text-xs">
                  {businessProfile.ceoName}
                </span>
                <span className="text-[10px] text-slate-500 block">{businessProfile.ceoTitle}</span>
              </div>

              <div>
                <span className="text-slate-400 block font-medium">Tax ID / TIN</span>
                <span className="font-mono font-bold text-slate-800">
                  {businessProfile.tinNumber || 'TIN-00941829-ET'}
                </span>
              </div>

              <div className="sm:col-span-2">
                <span className="text-slate-400 block font-medium">Registered Corporate Entity</span>
                <span className="font-bold text-slate-800">
                  {businessProfile.registeredBusinessName || 'Aimraan Supreme Wholesale & Retail Grocery Ltd'}
                </span>
              </div>

              <div className="sm:col-span-2">
                <span className="text-slate-400 block font-medium">Headquarters Address</span>
                <span className="text-slate-700">
                  {businessProfile.address || 'Bole Medhanealem Commercial District, Addis Ababa, Ethiopia'}
                </span>
              </div>
            </div>
          </div>

          <div className="space-y-2">
            <h4 className="font-bold text-slate-900 text-sm">Enterprise System Specs</h4>
            <div className="grid grid-cols-2 gap-2 text-[11px]">
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 block font-medium">Currency</span>
                <span className="font-bold text-slate-800">Ethiopian Birr (ETB)</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 block font-medium">Active Staff Team</span>
                <span className="font-bold text-purple-800">{availableUsers.length} Authorized Users</span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 block font-medium">Mission Target</span>
                <span className="font-bold text-emerald-700 font-mono">
                  {money(businessProfile.missionTarget || 1000000)}
                </span>
              </div>
              <div className="p-2.5 bg-slate-50 rounded-xl border border-slate-200">
                <span className="text-slate-400 block font-medium">Current Stock Catalog</span>
                <span className="font-bold text-slate-800">{db.products.length} Products</span>
              </div>
            </div>
          </div>

          <div className="p-3.5 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 space-y-1.5">
            <div className="flex items-center gap-1.5 font-bold text-emerald-950">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Mathematical Real-Time Accounting Engine</span>
            </div>
            <p className="text-[11px] leading-relaxed">
              Every single metric across the system — Net Profit, Current Valuation, Working Capital, Accounts Receivable, and Payables — is directly computed from actual sales, purchases, and cash flows.
            </p>
          </div>

          <div className="pt-2 border-t border-slate-200 flex flex-wrap justify-between items-center gap-2 text-[11px]">
            <button
              onClick={() => {
                setIsBusinessInfoOpen(false);
                openTeamManagement();
              }}
              className="font-bold text-purple-700 hover:text-purple-900 flex items-center gap-1"
            >
              <Users className="w-3.5 h-3.5" />
              <span>Manage Team & Staff Permissions</span>
            </button>

            <button
              onClick={() => setIsBusinessInfoOpen(false)}
              className="px-4 py-2 bg-slate-900 hover:bg-slate-800 text-white font-bold rounded-xl transition-all ml-auto"
            >
              Close
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
