import React, { useState, useMemo, useEffect } from 'react';
import { useStore, TabKey } from '../../context/StoreContext';
import { money } from '../../utils/helpers';
import { Search, X, Package, Users, Receipt, Truck, ArrowRight, Command } from 'lucide-react';

export const SearchModal: React.FC = () => {
  const { isSearchOpen, setIsSearchOpen, db, setActiveTab } = useStore();
  const [query, setQuery] = useState('');

  // Desktop global keyboard shortcut (Ctrl+K, Cmd+K, or /)
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      // Ctrl+K or Cmd+K
      if ((e.ctrlKey || e.metaKey) && (e.key === 'k' || e.key === 'K')) {
        e.preventDefault();
        setIsSearchOpen(!isSearchOpen);
        return;
      }

      // Single forward slash '/' when not inside an input/textarea/select
      if (
        e.key === '/' &&
        !isSearchOpen &&
        !(
          document.activeElement instanceof HTMLInputElement ||
          document.activeElement instanceof HTMLTextAreaElement ||
          document.activeElement instanceof HTMLSelectElement
        )
      ) {
        e.preventDefault();
        setIsSearchOpen(true);
        return;
      }

      // Escape to close
      if (e.key === 'Escape' && isSearchOpen) {
        setIsSearchOpen(false);
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isSearchOpen, setIsSearchOpen]);

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return [];

    const list: {
      id: string;
      category: 'product' | 'customer' | 'sale' | 'order';
      title: string;
      subtitle: string;
      badge: string;
      tab: TabKey;
    }[] = [];

    // Products
    db.products.forEach((p) => {
      if (
        p.name.toLowerCase().includes(q) ||
        p.sku.toLowerCase().includes(q) ||
        p.unit.toLowerCase().includes(q)
      ) {
        list.push({
          id: p.id,
          category: 'product',
          title: p.name,
          subtitle: `Stock: ${p.stock} ${p.unit} · Cost: ${money(p.buy)} · Retail: ${money(p.sell)}`,
          badge: p.stock <= 0 ? 'Out of stock' : p.stock <= p.min ? 'Low stock' : 'Stock',
          tab: 'inventory',
        });
      }
    });

    // Customers
    db.customers.forEach((c) => {
      if (
        c.name.toLowerCase().includes(q) ||
        (c.phone && c.phone.toLowerCase().includes(q)) ||
        (c.location && c.location.toLowerCase().includes(q))
      ) {
        list.push({
          id: c.id,
          category: 'customer',
          title: c.name,
          subtitle: `${c.phone || 'No phone'} · ${c.location || 'No location'} · Debt: ${money(c.credit)}`,
          badge: c.credit > 0 ? 'Credit Debt' : 'Customer',
          tab: 'customers',
        });
      }
    });

    // Sales
    db.sales.slice(0, 50).forEach((s) => {
      if (
        s.invoice.toLowerCase().includes(q) ||
        s.customer.toLowerCase().includes(q) ||
        s.payment.toLowerCase().includes(q)
      ) {
        list.push({
          id: s.id,
          category: 'sale',
          title: `${s.invoice} · ${s.customer}`,
          subtitle: `${s.date} ${s.time} · Total: ${money(s.total)} · Paid via ${s.payment}`,
          badge: 'Invoice',
          tab: 'pos',
        });
      }
    });

    // Orders
    db.orders.slice(0, 50).forEach((o) => {
      if (
        o.number.toLowerCase().includes(q) ||
        o.customer.toLowerCase().includes(q) ||
        o.product.toLowerCase().includes(q) ||
        o.status.toLowerCase().includes(q)
      ) {
        list.push({
          id: o.id,
          category: 'order',
          title: `${o.number} · ${o.customer}`,
          subtitle: `${o.product} × ${o.qty} · ${o.status} · Balance: ${money(o.balance)}`,
          badge: o.status,
          tab: 'distribution',
        });
      }
    });

    return list.slice(0, 25);
  }, [query, db]);

  if (!isSearchOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-start justify-center p-3 pt-12 sm:pt-20">
      <div className="bg-white rounded-2xl w-full max-w-xl shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Search header */}
        <div className="p-3.5 border-b border-slate-100 flex items-center gap-2.5 bg-slate-50/70">
          <Search className="w-5 h-5 text-emerald-600 shrink-0" />
          <input
            id="global-search-input"
            autoFocus
            type="text"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search products, customers, invoices, orders..."
            className="w-full bg-transparent border-none text-slate-800 placeholder-slate-400 font-medium text-sm focus:outline-hidden"
          />
          {query && (
            <button
              onClick={() => setQuery('')}
              className="text-xs text-slate-400 hover:text-slate-600 px-1.5 py-0.5 rounded"
            >
              Clear
            </button>
          )}
          <button
            id="search-close-btn"
            onClick={() => setIsSearchOpen(false)}
            className="p-1 rounded-lg text-slate-400 hover:text-slate-700 hover:bg-slate-200/60 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Results List */}
        <div className="max-h-[60vh] overflow-y-auto p-2 divide-y divide-slate-100">
          {!query.trim() ? (
            <div className="p-8 text-center text-slate-400 text-xs">
              <Search className="w-8 h-8 text-slate-300 mx-auto mb-2" />
              Type to search products, customers, sales invoices, and distribution records.
            </div>
          ) : results.length === 0 ? (
            <div className="p-8 text-center text-slate-500 text-xs">
              No matching records found for "{query}".
            </div>
          ) : (
            results.map((item) => {
              const Icon =
                item.category === 'product'
                  ? Package
                  : item.category === 'customer'
                  ? Users
                  : item.category === 'sale'
                  ? Receipt
                  : Truck;

              return (
                <div
                  key={`${item.category}-${item.id}`}
                  onClick={() => {
                    setActiveTab(item.tab);
                    setIsSearchOpen(false);
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="p-3 hover:bg-emerald-50/60 rounded-xl cursor-pointer transition-colors flex items-center justify-between group"
                >
                  <div className="flex items-center gap-3 min-w-0 pr-2">
                    <div className="p-2 rounded-lg bg-slate-100 text-emerald-700 group-hover:bg-emerald-600 group-hover:text-white transition-colors">
                      <Icon className="w-4 h-4" />
                    </div>
                    <div className="min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-xs text-slate-900 truncate">
                          {item.title}
                        </span>
                        <span
                          className={`text-[9px] font-extrabold px-1.5 py-0.2 rounded-full ${
                            item.badge.includes('Out') || item.badge.includes('Debt')
                              ? 'bg-rose-100 text-rose-700'
                              : item.badge.includes('Low')
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-slate-100 text-slate-600'
                          }`}
                        >
                          {item.badge}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 truncate mt-0.5">
                        {item.subtitle}
                      </div>
                    </div>
                  </div>
                  <ArrowRight className="w-4 h-4 text-slate-300 group-hover:text-emerald-600 group-hover:translate-x-0.5 transition-all shrink-0" />
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
