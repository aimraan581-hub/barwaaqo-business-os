import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { Product } from '../../types';
import { money } from '../../utils/helpers';
import { useStore } from '../../context/StoreContext';
import { X, Printer, CheckSquare, Square, QrCode } from 'lucide-react';

interface BatchQrPrintModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
}

export const BatchQrPrintModal: React.FC<BatchQrPrintModalProps> = ({ isOpen, onClose, products }) => {
  const { businessProfile } = useStore();
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set(products.map((p) => p.id)));
  const [qrCodes, setQrCodes] = useState<Record<string, string>>({});
  const [isGenerating, setIsGenerating] = useState(false);

  useEffect(() => {
    if (!isOpen) return;
    setSelectedIds(new Set(products.map((p) => p.id)));
  }, [isOpen, products]);

  useEffect(() => {
    if (!isOpen) return;
    let isCancelled = false;
    setIsGenerating(true);

    const baseUrl = typeof window !== 'undefined' ? window.location.origin + window.location.pathname : '';

    const generateAll = async () => {
      const results: Record<string, string> = {};
      for (const p of products) {
        if (isCancelled) return;
        try {
          const deepLink = `${baseUrl}?product=${encodeURIComponent(p.id)}`;
          const url = await QRCode.toDataURL(deepLink, {
            width: 140,
            margin: 1,
            color: { dark: '#000000', light: '#ffffff' },
            errorCorrectionLevel: 'M',
          });
          results[p.id] = url;
        } catch (e) {
          console.error(e);
        }
      }
      if (!isCancelled) {
        setQrCodes(results);
        setIsGenerating(false);
      }
    };

    generateAll();

    return () => {
      isCancelled = true;
    };
  }, [isOpen, products]);

  if (!isOpen) return null;

  const toggleSelect = (id: string) => {
    const next = new Set(selectedIds);
    if (next.has(id)) {
      next.delete(id);
    } else {
      next.add(id);
    }
    setSelectedIds(next);
  };

  const selectAll = () => {
    setSelectedIds(new Set(products.map((p) => p.id)));
  };

  const selectNone = () => {
    setSelectedIds(new Set());
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const itemsToPrint = products.filter((p) => selectedIds.has(p.id));

    const htmlContent = `
      <!DOCTYPE html>
      <html>
        <head>
          <title>${businessProfile.storeName || 'BARWAAQO'} - Shelf Labels Batch</title>
          <style>
            @page {
              size: A4 portrait;
              margin: 10mm;
            }
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              margin: 0;
              padding: 0;
              background: #fff;
              color: #000;
            }
            .label-grid {
              display: grid;
              grid-template-columns: repeat(3, 1fr);
              gap: 8mm 6mm;
            }
            .label-card {
              border: 1.5px solid #000;
              border-radius: 6px;
              padding: 6px;
              height: 38mm;
              display: flex;
              flex-direction: column;
              justify-content: space-between;
              box-sizing: border-box;
              break-inside: avoid;
            }
            .header {
              font-size: 8px;
              font-weight: 800;
              text-transform: uppercase;
              letter-spacing: 0.5px;
              border-bottom: 1px solid #000;
              padding-bottom: 2px;
              display: flex;
              justify-content: space-between;
            }
            .body {
              display: flex;
              gap: 6px;
              align-items: center;
              margin-top: 3px;
            }
            .qr {
              width: 22mm;
              height: 22mm;
            }
            .info {
              flex: 1;
              min-width: 0;
            }
            .title {
              font-size: 11px;
              font-weight: 900;
              line-height: 1.15;
              max-height: 24px;
              overflow: hidden;
            }
            .sku {
              font-size: 8px;
              color: #444;
              margin-top: 1px;
            }
            .price {
              font-size: 14px;
              font-weight: 900;
              margin-top: 2px;
              letter-spacing: -0.5px;
            }
            .footer {
              border-top: 0.5px dashed #666;
              padding-top: 2px;
              font-size: 7px;
              display: flex;
              justify-content: space-between;
              color: #444;
            }
          </style>
        </head>
        <body>
          <div class="label-grid">
            ${itemsToPrint
              .map((p) => {
                const img = qrCodes[p.id] || '';
                const mrg = p.sell > 0 ? (((p.sell - p.buy) / p.sell) * 100).toFixed(0) : '0';
                return `
                <div class="label-card">
                  <div class="header">
                    <span>${businessProfile.storeName || 'BARWAAQO'}</span>
                    <span>SHELF TAG</span>
                  </div>
                  <div class="body">
                    <img src="${img}" class="qr" />
                    <div class="info">
                      <div class="title">${p.name}</div>
                      <div class="sku">SKU: ${p.sku || 'NONE'} · ${p.unit}</div>
                      <div class="price">${money(p.sell)}</div>
                      <div style="font-size:8px;font-weight:700">WS: ${money(p.wholesale || p.sell)}</div>
                    </div>
                  </div>
                  <div class="footer">
                    <span>Scan QR: Stock & Profit Records</span>
                    <span>MRG: ${mrg}%</span>
                  </div>
                </div>
              `;
              })
              .join('')}
          </div>
          <script>
            window.onload = function() {
              window.print();
              setTimeout(function() { window.close(); }, 500);
            };
          </script>
        </body>
      </html>
    `;

    printWindow.document.write(htmlContent);
    printWindow.document.close();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-4 overflow-y-auto">
      <div className="relative w-full max-w-4xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="bg-gradient-to-r from-slate-900 to-emerald-950 text-white p-5 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30">
              <QrCode className="w-6 h-6" />
            </div>
            <div>
              <h3 className="font-black text-lg">Batch Print Shelf QR Labels</h3>
              <p className="text-xs text-emerald-200/80">
                Print ready-to-stick retail shelf labels with QR codes that link to live stock & profit records
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Action Controls */}
        <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-2">
            <button
              onClick={selectAll}
              className="px-2.5 py-1 rounded-lg bg-white border border-slate-300 font-bold hover:bg-slate-100 text-slate-700"
            >
              Select All ({products.length})
            </button>
            <button
              onClick={selectNone}
              className="px-2.5 py-1 rounded-lg bg-white border border-slate-300 font-bold hover:bg-slate-100 text-slate-700"
            >
              Deselect All
            </button>
            <span className="text-slate-500 font-medium">
              {selectedIds.size} of {products.length} selected
            </span>
          </div>

          <button
            onClick={handlePrint}
            disabled={selectedIds.size === 0 || isGenerating}
            className="px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs transition flex items-center gap-1.5 shadow-sm disabled:opacity-50"
          >
            <Printer className="w-4 h-4" />
            <span>Print {selectedIds.size} Labels</span>
          </button>
        </div>

        {/* Labels Grid Preview */}
        <div className="p-4 sm:p-6 max-h-[60vh] overflow-y-auto">
          {isGenerating ? (
            <div className="p-12 text-center text-slate-500 text-xs font-semibold">
              Generating vector QR codes for all inventory items...
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {products.map((p) => {
                const isChecked = selectedIds.has(p.id);
                const qrUrl = qrCodes[p.id];

                return (
                  <div
                    key={p.id}
                    onClick={() => toggleSelect(p.id)}
                    className={`p-3 rounded-2xl border cursor-pointer transition-all ${
                      isChecked
                        ? 'bg-emerald-50/40 border-emerald-300 ring-1 ring-emerald-300/60'
                        : 'bg-white border-slate-200 opacity-60 hover:opacity-100'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-2 pb-1 border-b border-slate-100">
                      <span className="text-[10px] font-black text-emerald-800 uppercase">Shelf Label</span>
                      <div className="text-slate-400">
                        {isChecked ? (
                          <CheckSquare className="w-4 h-4 text-emerald-600" />
                        ) : (
                          <Square className="w-4 h-4 text-slate-400" />
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-3 mt-2">
                      {qrUrl ? (
                        <img src={qrUrl} alt="" className="w-16 h-16 rounded-md bg-white border border-slate-200 shrink-0" />
                      ) : (
                        <div className="w-16 h-16 rounded-md bg-slate-200 animate-pulse shrink-0" />
                      )}

                      <div className="min-w-0 flex-1">
                        <div className="font-extrabold text-xs text-slate-900 truncate">{p.name}</div>
                        <div className="text-[10px] text-slate-500 truncate">
                          SKU: {p.sku || 'N/A'} · {p.unit}
                        </div>
                        <div className="text-sm font-black text-slate-900 mt-1">{money(p.sell)}</div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-xs text-slate-500">
            Formatted for standard A4 sticker paper (3 columns × 7 rows) or 50×30mm thermal rolls
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
