import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import {
  X,
  Building2,
  ShieldCheck,
  User,
  Phone,
  Mail,
  KeyRound,
  FileText,
  MapPin,
  Target,
  Users,
  Save,
  CheckCircle2,
  Eye,
  EyeOff,
  Briefcase,
  Sparkles,
  ArrowRight,
  PlusCircle,
} from 'lucide-react';
import { SystemUser } from '../../types';

export const CeoProfileModal: React.FC = () => {
  const {
    isCeoProfileModalOpen,
    setIsCeoProfileModalOpen,
    businessProfile,
    updateBusinessProfile,
    availableUsers,
    updateUserPin,
    openTeamManagement,
    showToast,
  } = useStore();

  const ceoUser =
    availableUsers.find(
      (u) => u.id === 'USR-CEO-01' || u.role.toLowerCase().includes('ceo')
    ) || availableUsers[0];

  // Form State
  const [ceoName, setCeoName] = useState(businessProfile.ceoName || ceoUser?.name || 'Aimraan');
  const [ceoTitle, setCeoTitle] = useState(businessProfile.ceoTitle || ceoUser?.role || 'CEO / Founder & Owner');
  const [ceoEmail, setCeoEmail] = useState(businessProfile.ceoEmail || ceoUser?.email || 'ceo@barwaaqo.com');
  const [ceoPhone, setCeoPhone] = useState(businessProfile.ceoPhone || ceoUser?.phone || '+251 911 001 001');
  const [ceoPin, setCeoPin] = useState(ceoUser?.pin || '1234');
  const [showPin, setShowPin] = useState(false);

  // Store Business Profile State
  const [storeName, setStoreName] = useState(businessProfile.storeName || 'BARWAAQO Business OS');
  const [registeredBusinessName, setRegisteredBusinessName] = useState(
    businessProfile.registeredBusinessName || 'Barwaaqo Wholesale & Retail Distribution Ltd'
  );
  const [tinNumber, setTinNumber] = useState(businessProfile.tinNumber || 'TIN-00941829-ET');
  const [address, setAddress] = useState(
    businessProfile.address || 'Bole Medhanealem Commercial District, Addis Ababa, Ethiopia'
  );
  const [missionTarget, setMissionTarget] = useState(businessProfile.missionTarget || 1000000);

  // Active Tab within modal
  const [activeTab, setActiveTab] = useState<'ceo' | 'business' | 'team'>('ceo');

  // Sync state whenever modal opens or businessProfile updates
  useEffect(() => {
    if (isCeoProfileModalOpen) {
      setCeoName(businessProfile.ceoName || ceoUser?.name || 'Aimraan');
      setCeoTitle(businessProfile.ceoTitle || ceoUser?.role || 'CEO / Founder & Owner');
      setCeoEmail(businessProfile.ceoEmail || ceoUser?.email || 'ceo@barwaaqo.com');
      setCeoPhone(businessProfile.ceoPhone || ceoUser?.phone || '+251 911 001 001');
      setCeoPin(ceoUser?.pin || '1234');
      setStoreName(businessProfile.storeName || 'BARWAAQO Business OS');
      setRegisteredBusinessName(
        businessProfile.registeredBusinessName || 'Barwaaqo Wholesale & Retail Distribution Ltd'
      );
      setTinNumber(businessProfile.tinNumber || 'TIN-00941829-ET');
      setAddress(businessProfile.address || 'Bole Medhanealem Commercial District, Addis Ababa, Ethiopia');
      setMissionTarget(businessProfile.missionTarget || 1000000);
    }
  }, [isCeoProfileModalOpen, businessProfile, ceoUser]);

  if (!isCeoProfileModalOpen) return null;

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();

    if (!ceoName.trim()) {
      showToast('Please enter the CEO full name');
      return;
    }

    // Save business and CEO profile updates
    updateBusinessProfile({
      ceoName: ceoName.trim(),
      ceoTitle: ceoTitle.trim() || 'CEO / Founder & Owner',
      ceoEmail: ceoEmail.trim(),
      ceoPhone: ceoPhone.trim(),
      storeName: storeName.trim() || 'BARWAAQO Business OS',
      registeredBusinessName: registeredBusinessName.trim(),
      tinNumber: tinNumber.trim(),
      address: address.trim(),
      missionTarget: Number(missionTarget) || 1000000,
    });

    // Update PIN if changed
    if (ceoUser && ceoPin.trim() && ceoPin !== ceoUser.pin) {
      updateUserPin(ceoUser.id, ceoPin.trim());
    }

    setIsCeoProfileModalOpen(false);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-black/70 backdrop-blur-xs overflow-y-auto">
      <div className="bg-white border border-emerald-950/20 rounded-3xl w-full max-w-2xl overflow-hidden shadow-2xl animate-in zoom-in-95 duration-150 my-8">
        {/* Header with Executive Emerald Gradient */}
        <div className="bg-gradient-to-r from-[#03170f] via-[#064229] to-[#085a37] text-white p-5 sm:p-6 relative">
          <div className="flex items-start justify-between">
            <div className="flex items-center gap-3">
              <img
                src="/logo.png"
                alt="BARWAAQO"
                className="w-12 h-12 rounded-2xl object-cover shadow-lg ring-2 ring-amber-400/50 shrink-0"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
              <div>
                <div className="flex items-center gap-2">
                  <h3 className="font-extrabold text-lg sm:text-xl text-white tracking-wide">
                    Executive Profile & Store Setup
                  </h3>
                  <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-400 text-amber-950 shadow-xs">
                    CEO Control
                  </span>
                </div>
                <p className="text-xs text-emerald-200/90 mt-0.5">
                  Update CEO identity, store credentials, corporate legal profile, and staff access.
                </p>
              </div>
            </div>

            <button
              onClick={() => setIsCeoProfileModalOpen(false)}
              className="p-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-emerald-200 hover:text-white transition-colors"
              title="Close modal"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Quick Tabs */}
          <div className="flex items-center gap-2 mt-5 pt-3 border-t border-emerald-800/60">
            <button
              type="button"
              onClick={() => setActiveTab('ceo')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                activeTab === 'ceo'
                  ? 'bg-amber-400 text-amber-950 shadow-sm'
                  : 'bg-white/10 text-emerald-100 hover:bg-white/20'
              }`}
            >
              <User className="w-3.5 h-3.5" />
              <span>CEO Profile</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('business')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                activeTab === 'business'
                  ? 'bg-amber-400 text-amber-950 shadow-sm'
                  : 'bg-white/10 text-emerald-100 hover:bg-white/20'
              }`}
            >
              <Building2 className="w-3.5 h-3.5" />
              <span>Business & TIN</span>
            </button>

            <button
              type="button"
              onClick={() => setActiveTab('team')}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition ${
                activeTab === 'team'
                  ? 'bg-amber-400 text-amber-950 shadow-sm'
                  : 'bg-white/10 text-emerald-100 hover:bg-white/20'
              }`}
            >
              <Users className="w-3.5 h-3.5" />
              <span>Staff Overview ({availableUsers.length})</span>
            </button>
          </div>
        </div>

        {/* Modal Body */}
        <form onSubmit={handleSave} className="p-5 sm:p-6 space-y-5">
          {/* TAB 1: CEO PROFILE */}
          {activeTab === 'ceo' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="p-3.5 rounded-2xl bg-amber-50/70 border border-amber-200/80 flex items-start gap-3">
                <Sparkles className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" />
                <div className="text-xs text-amber-900 leading-relaxed">
                  Changes to the <b>CEO Name</b> and contact information will immediately update the
                  Command Center, receipt signatures, audit log attribution, and staff permission rosters.
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* CEO Name */}
                <div>
                  <label className="block text-[11px] font-extrabold uppercase text-slate-700 tracking-wider mb-1.5">
                    CEO Full Name <span className="text-rose-500">*</span>
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={ceoName}
                      onChange={(e) => setCeoName(e.target.value)}
                      placeholder="e.g. Aimraan"
                      className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-extrabold text-sm focus:bg-white focus:ring-2 focus:ring-emerald-600 focus:border-transparent transition"
                    />
                    <User className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                {/* CEO Title */}
                <div>
                  <label className="block text-[11px] font-extrabold uppercase text-slate-700 tracking-wider mb-1.5">
                    Executive Title / Role
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={ceoTitle}
                      onChange={(e) => setCeoTitle(e.target.value)}
                      placeholder="e.g. CEO / Founder & Owner"
                      className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-bold text-sm focus:bg-white focus:ring-2 focus:ring-emerald-600 focus:border-transparent transition"
                    />
                    <Briefcase className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                {/* Phone */}
                <div>
                  <label className="block text-[11px] font-extrabold uppercase text-slate-700 tracking-wider mb-1.5">
                    Direct Phone Number
                  </label>
                  <div className="relative">
                    <input
                      type="tel"
                      value={ceoPhone}
                      onChange={(e) => setCeoPhone(e.target.value)}
                      placeholder="e.g. +251 911 001 001"
                      className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-medium text-sm focus:bg-white focus:ring-2 focus:ring-emerald-600 focus:border-transparent transition"
                    />
                    <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                {/* Email */}
                <div>
                  <label className="block text-[11px] font-extrabold uppercase text-slate-700 tracking-wider mb-1.5">
                    Executive Email
                  </label>
                  <div className="relative">
                    <input
                      type="email"
                      value={ceoEmail}
                      onChange={(e) => setCeoEmail(e.target.value)}
                      placeholder="e.g. ceo@barwaaqo.com"
                      className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-medium text-sm focus:bg-white focus:ring-2 focus:ring-emerald-600 focus:border-transparent transition"
                    />
                    <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                {/* Security PIN */}
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-extrabold uppercase text-slate-700 tracking-wider mb-1.5">
                    CEO 4-Digit Security PIN (For High-Value Overrides & Ledger Resets)
                  </label>
                  <div className="relative max-w-xs">
                    <input
                      type={showPin ? 'text' : 'password'}
                      maxLength={6}
                      value={ceoPin}
                      onChange={(e) => setCeoPin(e.target.value)}
                      placeholder="1234"
                      className="w-full pl-9 pr-10 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-mono font-black text-sm tracking-widest focus:bg-white focus:ring-2 focus:ring-emerald-600 focus:border-transparent transition"
                    />
                    <KeyRound className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                    <button
                      type="button"
                      onClick={() => setShowPin(!showPin)}
                      className="absolute right-3 top-2.5 text-slate-400 hover:text-slate-600 p-1"
                      title={showPin ? 'Hide PIN' : 'Reveal PIN'}
                    >
                      {showPin ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                  <p className="text-[11px] text-slate-500 mt-1">
                    Used to authorize high-value cash transactions, delete logs, and edit statutory tax tiers.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: BUSINESS & STORE DETAILS */}
          {activeTab === 'business' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                {/* Store Display Name */}
                <div>
                  <label className="block text-[11px] font-extrabold uppercase text-slate-700 tracking-wider mb-1.5">
                    Store Brand Name (Header & POS Banner)
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      required
                      value={storeName}
                      onChange={(e) => setStoreName(e.target.value)}
                      placeholder="e.g. BARWAAQO Business OS"
                      className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-black text-sm focus:bg-white focus:ring-2 focus:ring-emerald-600 focus:border-transparent transition uppercase"
                    />
                    <Building2 className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                {/* TIN Number */}
                <div>
                  <label className="block text-[11px] font-extrabold uppercase text-slate-700 tracking-wider mb-1.5">
                    Taxpayer Identification Number (TIN)
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={tinNumber}
                      onChange={(e) => setTinNumber(e.target.value)}
                      placeholder="e.g. TIN-00941829-ET"
                      className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-mono font-bold text-sm focus:bg-white focus:ring-2 focus:ring-emerald-600 focus:border-transparent transition uppercase"
                    />
                    <FileText className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                {/* Registered Corporate Legal Name */}
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-extrabold uppercase text-slate-700 tracking-wider mb-1.5">
                    Registered Corporate Entity Name (Appears on Tax Invoices & Reports)
                  </label>
                  <input
                    type="text"
                    value={registeredBusinessName}
                    onChange={(e) => setRegisteredBusinessName(e.target.value)}
                    placeholder="e.g. Aimraan Supreme Wholesale & Retail Grocery Ltd"
                    className="w-full px-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-bold text-sm focus:bg-white focus:ring-2 focus:ring-emerald-600 focus:border-transparent transition"
                  />
                </div>

                {/* Address */}
                <div className="sm:col-span-2">
                  <label className="block text-[11px] font-extrabold uppercase text-slate-700 tracking-wider mb-1.5">
                    Store Physical Address & Headquarters
                  </label>
                  <div className="relative">
                    <input
                      type="text"
                      value={address}
                      onChange={(e) => setAddress(e.target.value)}
                      placeholder="e.g. Bole Medhanealem Commercial District, Addis Ababa, Ethiopia"
                      className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-medium text-sm focus:bg-white focus:ring-2 focus:ring-emerald-600 focus:border-transparent transition"
                    />
                    <MapPin className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                {/* Mission Target */}
                <div>
                  <label className="block text-[11px] font-extrabold uppercase text-slate-700 tracking-wider mb-1.5">
                    Enterprise Goal Target (ETB)
                  </label>
                  <div className="relative">
                    <input
                      type="number"
                      step={10000}
                      value={missionTarget}
                      onChange={(e) => setMissionTarget(Number(e.target.value))}
                      placeholder="1000000"
                      className="w-full pl-9 pr-3.5 py-2.5 bg-slate-50 border border-slate-300 rounded-xl text-slate-900 font-mono font-black text-sm focus:bg-white focus:ring-2 focus:ring-emerald-600 focus:border-transparent transition"
                    />
                    <Target className="w-4 h-4 text-slate-400 absolute left-3 top-3" />
                  </div>
                </div>

                {/* Base Currency */}
                <div>
                  <label className="block text-[11px] font-extrabold uppercase text-slate-700 tracking-wider mb-1.5">
                    Operating Base Currency
                  </label>
                  <input
                    type="text"
                    disabled
                    value="ETB (Ethiopian Birr)"
                    className="w-full px-3.5 py-2.5 bg-slate-100 border border-slate-200 rounded-xl text-slate-600 font-extrabold text-sm cursor-not-allowed"
                  />
                </div>
              </div>
            </div>
          )}

          {/* TAB 3: STAFF & EMPLOYEES ROSTER PREVIEW */}
          {activeTab === 'team' && (
            <div className="space-y-4 animate-in fade-in duration-150">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-extrabold text-sm text-slate-900">Registered Staff & Employees</h4>
                  <p className="text-xs text-slate-500">
                    {availableUsers.length} staff members authorized with POS and terminal privileges.
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => {
                    setIsCeoProfileModalOpen(false);
                    openTeamManagement();
                  }}
                  className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-xs transition"
                >
                  <Users className="w-3.5 h-3.5" />
                  <span>Full Staff Manager</span>
                  <ArrowRight className="w-3.5 h-3.5 ml-0.5" />
                </button>
              </div>

              <div className="divide-y divide-slate-100 border border-slate-200 rounded-2xl overflow-hidden bg-slate-50/50 max-h-64 overflow-y-auto">
                {availableUsers.map((user) => (
                  <div key={user.id} className="p-3 flex items-center justify-between gap-3 hover:bg-white transition">
                    <div className="flex items-center gap-3">
                      <div className="w-9 h-9 rounded-xl bg-purple-100 text-purple-900 font-black text-xs flex items-center justify-center">
                        {user.name.slice(0, 2).toUpperCase()}
                      </div>
                      <div>
                        <div className="flex items-center gap-1.5">
                          <span className="font-extrabold text-xs text-slate-900">{user.name}</span>
                          {user.id === ceoUser?.id && (
                            <span className="text-[9px] font-black uppercase px-1.5 py-0.2 rounded bg-amber-400 text-amber-950">
                              CEO
                            </span>
                          )}
                        </div>
                        <div className="text-[11px] text-slate-500 flex items-center gap-2 mt-0.5">
                          <span>{user.role}</span>
                          <span>•</span>
                          <span className="font-mono">PIN: ****</span>
                          {user.phone && (
                            <>
                              <span>•</span>
                              <span>{user.phone}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <span
                      className={`text-[10px] font-bold px-2 py-0.5 rounded-full ${
                        user.status === 'active' || !user.status
                          ? 'bg-emerald-100 text-emerald-800'
                          : user.status === 'on_leave'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {user.status || 'active'}
                    </span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Footer Controls */}
          <div className="pt-4 border-t border-slate-200 flex flex-col-reverse sm:flex-row items-center justify-between gap-3">
            <button
              type="button"
              onClick={() => {
                setIsCeoProfileModalOpen(false);
                openTeamManagement();
              }}
              className="text-xs font-bold text-purple-700 hover:text-purple-900 flex items-center gap-1"
            >
              <Users className="w-3.5 h-3.5" />
              <span>Go to Advanced Staff Permissions & Roles</span>
            </button>

            <div className="flex items-center gap-2 w-full sm:w-auto justify-end">
              <button
                type="button"
                onClick={() => setIsCeoProfileModalOpen(false)}
                className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition"
              >
                Cancel
              </button>

              <button
                type="submit"
                className="flex items-center justify-center gap-2 px-5 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-extrabold shadow-sm transition active:scale-95"
              >
                <Save className="w-4 h-4" />
                <span>Save All Changes</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
};
