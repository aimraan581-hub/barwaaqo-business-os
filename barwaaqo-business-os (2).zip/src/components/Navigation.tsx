import React, { useState, useMemo } from 'react';
import { useStore, TabKey } from '../context/StoreContext';
import { useTranslation } from '../i18n/LanguageContext';
import { LanguageToggle } from './LanguageToggle';
import { getDynamicSafetyStockAlerts } from '../utils/helpers';
import {
  LayoutDashboard,
  Receipt,
  Package,
  Truck,
  Wallet,
  BarChart3,
  History,
  Factory,
  Users,
  Building2,
  MoreHorizontal,
  X,
  Smartphone,
  Zap,
  Download,
  ShieldCheck,
  TrendingUp,
  FileSpreadsheet,
  Settings,
} from 'lucide-react';
import { PermanentAppModal } from './PermanentAppModal';

export const Navigation: React.FC = () => {
  const {
    activeTab,
    setActiveTab,
    cart,
    db,
    priceSuggestions,
    setIsTaxModalOpen,
    setIsMonthlyTaxReportModalOpen,
    taxSettings,
  } = useStore();
  const [isMoreOpen, setIsMoreOpen] = useState(false);
  const [isInstallOpen, setIsInstallOpen] = useState(false);

  const { t } = useTranslation();

  // Calculate dynamic safety stock alerts based on recent sales velocity (7-day window & replenishment lead buffer)
  const safetyAlerts = useMemo(() => {
    return getDynamicSafetyStockAlerts(db);
  }, [db.products, db.sales]);

  const activeOrdersCount = db.orders.filter((o) => o.status !== 'PAID').length;
  const cartItemCount = cart.reduce((a, x) => a + x.qty, 0);

  // Calculate pending dynamic pricing recommendations
  const actionablePricingCount = useMemo(() => {
    return (priceSuggestions || []).filter((s) => Math.abs(s.priceChangeDelta) >= 1).length;
  }, [priceSuggestions]);

  const navItems: {
    id: TabKey;
    label: string;
    icon: React.FC<{ className?: string }>;
    badge?: number | string;
    badgeColor?: string;
    badgeTitle?: string;
    hasVelocityRisk?: boolean;
  }[] = useMemo(() => [
    { id: 'dashboard', label: t('navDashboard'), icon: LayoutDashboard },
    {
      id: 'pos',
      label: t('navPos'),
      icon: Receipt,
      badge: cartItemCount > 0 ? cartItemCount : undefined,
      badgeColor: 'bg-amber-500 text-white',
      badgeTitle: `${cartItemCount} items in cart`,
    },
    {
      id: 'inventory',
      label: t('navInventory'),
      icon: Package,
      badge: safetyAlerts.totalBelowSafety > 0 ? safetyAlerts.totalBelowSafety : undefined,
      badgeColor:
        safetyAlerts.velocityTriggeredCount > 0
          ? 'bg-gradient-to-r from-amber-500 to-rose-600 text-white ring-rose-300 animate-pulse'
          : 'bg-rose-500 text-white',
      badgeTitle: `${safetyAlerts.totalBelowSafety} items below dynamic safety stock (${safetyAlerts.velocityTriggeredCount} high sales velocity risks, ${safetyAlerts.criticalMinCount} below statutory min)`,
      hasVelocityRisk: safetyAlerts.velocityTriggeredCount > 0,
    },
    {
      id: 'distribution',
      label: t('navDistribution'),
      icon: Truck,
      badge: activeOrdersCount > 0 ? activeOrdersCount : undefined,
      badgeColor: 'bg-blue-600 text-white',
      badgeTitle: `${activeOrdersCount} pending orders`,
    },
    { id: 'finance', label: t('navFinance'), icon: Wallet },
    { id: 'reports', label: t('navReports'), icon: BarChart3 },
    { id: 'activity', label: t('navActivity'), icon: History },
  ], [t, cartItemCount, safetyAlerts, activeOrdersCount]);

  const secondaryItems: {
    id: TabKey;
    label: string;
    desc: string;
    icon: React.FC<{ className?: string }>;
    badge?: number | string;
    badgeColor?: string;
  }[] = useMemo(() => [
    {
      id: 'pricing',
      label: t('navPricing'),
      desc: 'Competitor intel & COGS margin defense',
      icon: TrendingUp,
      badge: actionablePricingCount > 0 ? actionablePricingCount : undefined,
      badgeColor: 'bg-emerald-500 text-slate-950 font-black',
    },
    { id: 'purchases', label: t('navPurchases'), desc: 'Manage vendor procurement & credit', icon: Factory },
    { id: 'customers', label: t('navCustomers'), desc: 'Customer ledgers & payment recovery', icon: Users },
    { id: 'enterprise', label: t('navEnterprise'), desc: 'Strategic milestones & audit integrity', icon: Building2 },
  ], [t, actionablePricingCount]);

  const isSecondaryActive = ['purchases', 'customers', 'enterprise', 'pricing'].includes(activeTab);

  return (
    <>
      {/* Secondary More Menu Drawer (Mobile Only) */}
      {isMoreOpen && (
        <div className="lg:hidden fixed inset-0 z-40 bg-black/60 backdrop-blur-xs flex flex-col justify-end p-4 pb-24 transition-opacity">
          <div className="bg-slate-900 border border-emerald-800/40 rounded-3xl p-5 max-w-lg mx-auto w-full shadow-2xl animate-in slide-in-from-bottom duration-200">
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Building2 className="w-5 h-5 text-emerald-400" />
                <span className="font-bold text-sm text-white">{t('moreModules')}</span>
              </div>
              <button
                onClick={() => setIsMoreOpen(false)}
                className="p-1 rounded-full text-slate-400 hover:text-white hover:bg-slate-800 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-3 space-y-2">
              {secondaryItems.map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    id={`nav-${item.id}`}
                    onClick={() => {
                      setActiveTab(item.id);
                      setIsMoreOpen(false);
                      window.scrollTo({ top: 0, behavior: 'smooth' });
                    }}
                    className={`w-full flex items-center gap-3.5 p-3 rounded-2xl text-left transition-all ${
                      isActive
                        ? 'bg-emerald-900/60 border border-emerald-500/40 text-white'
                        : 'bg-slate-800/60 hover:bg-slate-800 border border-slate-700/40 text-slate-200'
                    }`}
                  >
                    <div className={`p-2.5 rounded-xl ${isActive ? 'bg-emerald-500 text-slate-950' : 'bg-slate-700 text-emerald-300'}`}>
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2">
                        <span className="font-bold text-sm text-white">{item.label}</span>
                        {item.badge !== undefined && (
                          <span
                            className={`px-1.5 py-0.2 rounded-full text-[10px] font-black ${
                              item.badgeColor || 'bg-emerald-500 text-slate-950'
                            }`}
                          >
                            {item.badge}
                          </span>
                        )}
                      </div>
                      <div className="text-xs text-slate-400">{item.desc}</div>
                    </div>
                  </button>
                );
              })}

              {/* Tax & Compliance Statutory Tools */}
              <div className="pt-2 border-t border-slate-800 space-y-2">
                <button
                  id="nav-tax-settings-btn"
                  onClick={() => {
                    setIsMoreOpen(false);
                    setIsTaxModalOpen(true);
                  }}
                  className="w-full flex items-center gap-3.5 p-3 rounded-2xl text-left transition-all bg-slate-800/80 hover:bg-slate-800 border border-emerald-500/30 text-white"
                >
                  <div className="p-2.5 rounded-xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/40">
                    <Settings className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-white">Tax Configuration Settings</span>
                      <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                        {taxSettings?.taxLabel || 'VAT'}
                      </span>
                    </div>
                    <div className="text-xs text-slate-400">
                      Multi-tier tax brackets ({taxSettings?.tiers?.length || 3} tiers), TIN & calculation mode
                    </div>
                  </div>
                </button>

                <button
                  id="nav-tax-report-btn"
                  onClick={() => {
                    setIsMoreOpen(false);
                    setIsMonthlyTaxReportModalOpen(true);
                  }}
                  className="w-full flex items-center gap-3.5 p-3 rounded-2xl text-left transition-all bg-slate-800/80 hover:bg-slate-800 border border-teal-500/30 text-white"
                >
                  <div className="p-2.5 rounded-xl bg-teal-500/20 text-teal-400 border border-teal-500/40">
                    <FileSpreadsheet className="w-5 h-5" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-white">Monthly Tax Summary Report</span>
                      <span className="px-1.5 py-0.2 rounded-full text-[9px] font-bold bg-teal-500/20 text-teal-300 border border-teal-500/30">
                        Audit
                      </span>
                    </div>
                    <div className="text-xs text-slate-400">
                      Output tax reconciliation, statutory returns & CSV export
                    </div>
                  </div>
                </button>
              </div>

              {/* Language Switcher in Drawer */}
              <div className="pt-2 border-t border-slate-800 flex items-center justify-between px-1">
                <span className="text-xs text-slate-300 font-bold uppercase tracking-wider">{t('language')}</span>
                <LanguageToggle variant="pill" />
              </div>

              <div className="pt-2 border-t border-slate-800">
                <button
                  id="nav-install-permanent-app"
                  onClick={() => {
                    setIsMoreOpen(false);
                    setIsInstallOpen(true);
                  }}
                  className="w-full flex items-center gap-3.5 p-3 rounded-2xl text-left transition-all bg-gradient-to-r from-emerald-950/80 to-teal-950/80 hover:from-emerald-900/90 hover:to-teal-900/90 border border-emerald-500/40 text-white"
                >
                  <div className="p-2.5 rounded-xl bg-emerald-500 text-slate-950 shadow-md">
                    <Download className="w-5 h-5" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <span className="font-bold text-sm text-white">{t('desktopApp')}</span>
                      <span className="px-1.5 py-0.2 rounded bg-emerald-400 text-slate-950 text-[9px] font-black uppercase">
                        PC / Mobile
                      </span>
                    </div>
                    <div className="text-xs text-emerald-200/80">Desktop, iPhone, Android install & storage persistence</div>
                  </div>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <PermanentAppModal isOpen={isInstallOpen} onClose={() => setIsInstallOpen(false)} />

      {/* Main Sticky Bottom Nav (Mobile Only) */}
      <nav
        id="main-nav"
        className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-white/98 backdrop-blur-lg border-t border-slate-200/90 shadow-[0_-4px_20px_rgba(15,23,42,0.06)] safe-area-pb"
      >
        <div className="max-w-2xl mx-auto px-2 py-1.5 flex items-center justify-between gap-1">
          {navItems.map((item) => {
            const Icon = item.icon;
            const isActive = activeTab === item.id;
            return (
              <button
                key={item.id}
                id={`n-${item.id}`}
                onClick={() => {
                  setActiveTab(item.id);
                  setIsMoreOpen(false);
                  window.scrollTo({ top: 0, behavior: 'smooth' });
                }}
                className={`relative flex-1 py-1.5 px-1 flex flex-col items-center justify-center rounded-xl transition-all ${
                  isActive
                    ? 'text-emerald-800 font-extrabold bg-emerald-50 border border-emerald-200/70 shadow-2xs'
                    : 'text-slate-600 hover:text-slate-950 hover:bg-slate-100/60 font-semibold'
                }`}
              >
                <div className="relative">
                  <Icon className={`w-5 h-5 ${isActive ? 'text-emerald-800 stroke-[2.5]' : 'text-slate-600 stroke-[1.8]'}`} />
                  {item.badge !== undefined && (
                    <span
                      title={item.badgeTitle}
                      className={`absolute -top-1.5 -right-2.5 text-[9px] font-black px-1.5 py-0.2 rounded-full ring-2 ring-white shadow-xs flex items-center gap-0.5 ${
                        item.badgeColor || 'bg-emerald-600 text-white'
                      }`}
                    >
                      {item.hasVelocityRisk && (
                        <Zap className="w-2.5 h-2.5 fill-current shrink-0 text-amber-200" />
                      )}
                      <span>{item.badge}</span>
                    </span>
                  )}
                </div>
                <span className="text-[10.5px] mt-1 tracking-tight leading-none truncate max-w-[54px]">
                  {item.label}
                </span>
                {isActive && (
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-700 mt-0.5" />
                )}
              </button>
            );
          })}

          {/* More trigger button */}
          <button
            id="n-more"
            onClick={() => setIsMoreOpen((prev) => !prev)}
            className={`flex-1 py-1.5 px-1 flex flex-col items-center justify-center rounded-xl transition-all ${
              isSecondaryActive || isMoreOpen
                ? 'text-emerald-800 font-extrabold bg-emerald-50 border border-emerald-200/70 shadow-2xs'
                : 'text-slate-600 hover:text-slate-950 hover:bg-slate-100/60 font-semibold'
            }`}
          >
            <div className="relative">
              <MoreHorizontal className={`w-5 h-5 ${isSecondaryActive ? 'text-emerald-800 stroke-[2.5]' : 'text-slate-600 stroke-[1.8]'}`} />
              {isSecondaryActive && (
                <span className="absolute -top-1 -right-1 w-2 h-2 rounded-full bg-emerald-700 ring-2 ring-white" />
              )}
              {!isSecondaryActive && actionablePricingCount > 0 && (
                <span className="absolute -top-1.5 -right-2 text-[9px] font-black px-1 py-0.2 rounded-full ring-2 ring-white shadow-xs bg-emerald-600 text-white">
                  {actionablePricingCount}
                </span>
              )}
            </div>
            <span className="text-[10.5px] mt-1 tracking-tight leading-none">
              {t('more')}
            </span>
            {isSecondaryActive && (
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-700 mt-0.5" />
            )}
          </button>
        </div>
      </nav>
    </>
  );
};
