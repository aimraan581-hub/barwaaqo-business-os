import React, { useState, useEffect } from 'react';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { Download, X, Sparkles, QrCode, Smartphone, ExternalLink } from 'lucide-react';
import { PermanentAppModal } from './PermanentAppModal';

export const InstallAppBanner: React.FC = () => {
  const { isInstalled, isInstallable, isIOS, isAndroid, install } = usePWAInstall();
  const [dismissed, setDismissed] = useState(true);
  const [modalOpen, setModalOpen] = useState(false);

  useEffect(() => {
    // Check if dismissed in this session
    try {
      const isSessionDismissed = sessionStorage.getItem('barwaaqo_install_banner_dismissed') === 'true';
      if (!isSessionDismissed) {
        setDismissed(false);
      }
    } catch {
      setDismissed(false);
    }
  }, []);

  if (isInstalled || dismissed) {
    return (
      <>
        <PermanentAppModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
      </>
    );
  }

  const handleDismiss = () => {
    setDismissed(true);
    try {
      sessionStorage.setItem('barwaaqo_install_banner_dismissed', 'true');
    } catch {
      // ignore
    }
  };

  const handleAction = async () => {
    if (isInstallable) {
      const success = await install();
      if (!success) {
        setModalOpen(true);
      }
    } else {
      setModalOpen(true);
    }
  };

  return (
    <>
      <div className="fixed bottom-16 sm:bottom-4 left-3 right-3 sm:left-auto sm:right-4 z-40 max-w-lg bg-gradient-to-r from-slate-950 via-emerald-950 to-slate-900 text-white rounded-2xl p-3 sm:p-4 shadow-2xl border border-emerald-500/40 backdrop-blur-md animate-fade-in">
        <div className="flex items-start gap-3">
          <div className="w-10 h-10 rounded-xl bg-white/10 p-1 flex items-center justify-center border border-white/20 shrink-0 mt-0.5">
            <img src="/pwa-192x192.png" alt="BARWAAQO" className="w-full h-full object-cover rounded-lg shadow-sm" />
          </div>

          <div className="flex-1 min-w-0 pr-6">
            <div className="flex items-center gap-1.5 flex-wrap">
              <span className="text-[10px] font-black uppercase px-1.5 py-0.5 rounded bg-emerald-500/30 text-emerald-300 border border-emerald-400/30 flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                Original App · No App Store
              </span>
            </div>
            <h4 className="text-xs sm:text-sm font-black text-white mt-1 leading-tight">
              Download BARWAAQO App Directly
            </h4>
            <p className="text-[11px] text-emerald-200/90 mt-0.5 leading-snug">
              Install directly on your phone or PC with zero app stores. Works 100% offline with camera barcode scanning.
            </p>

            <div className="flex items-center gap-2 mt-2.5">
              <button
                onClick={handleAction}
                className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 text-xs font-black shadow-md transition active:scale-95 flex items-center gap-1.5"
              >
                <Download className="w-3.5 h-3.5" />
                <span>{isInstallable ? '1-Click Install' : 'Download App'}</span>
              </button>

              <button
                onClick={() => setModalOpen(true)}
                className="px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/20 text-white text-xs font-bold transition flex items-center gap-1 border border-white/15"
                title="View QR Code and Installation Guide"
              >
                <QrCode className="w-3.5 h-3.5 text-amber-400" />
                <span className="hidden xs:inline">QR / Guide</span>
              </button>
            </div>
          </div>

          <button
            onClick={handleDismiss}
            className="absolute top-2.5 right-2.5 p-1 rounded-lg bg-white/10 hover:bg-white/20 text-white/70 hover:text-white transition"
            aria-label="Dismiss banner"
          >
            <X className="w-4 h-4" />
          </button>
        </div>
      </div>

      <PermanentAppModal isOpen={modalOpen} onClose={() => setModalOpen(false)} />
    </>
  );
};
