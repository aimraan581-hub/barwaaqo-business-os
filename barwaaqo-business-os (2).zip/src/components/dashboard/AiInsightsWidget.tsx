import React, { useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { money } from '../../utils/helpers';
import { Sparkles, Award, TrendingUp, AlertCircle, ShoppingBag } from 'lucide-react';

export const AiInsightsWidget: React.FC = () => {
  const { db, totals } = useStore();

  const insights = useMemo(() => {
    const list: { type: 'good' | 'warn' | 'info'; title: string; text: string; metric?: string }[] = [];

    // Top volume product
    const volumeMap: Record<string, number> = {};
    (db.sales || []).forEach((s) =>
      (s.items || []).forEach((item) => {
        volumeMap[item.name] = (volumeMap[item.name] || 0) + (item.qty || 0);
      })
    );
    const topProd = Object.entries(volumeMap).sort((a, b) => b[1] - a[1])[0];
    if (topProd && topProd[1] > 0) {
      list.push({
        type: 'good',
        title: 'Top Sales Velocity Leader',
        text: `${topProd[0]} leads storefront demand. Ensure buffer stock is prioritized.`,
        metric: `${topProd[1]} units sold`,
      });
    }

    // Highest unit margin
    const topMargin = [...db.products]
      .map((p) => ({ name: p.name, margin: p.sell - p.buy, pct: p.sell > 0 ? ((p.sell - p.buy) / p.sell) * 100 : 0 }))
      .sort((a, b) => b.margin - a.margin)[0];
    if (topMargin && topMargin.margin > 0) {
      list.push({
        type: 'info',
        title: 'Highest Margin Generator',
        text: `${topMargin.name} generates the highest profit per transaction.`,
        metric: `${money(topMargin.margin)} (${topMargin.pct.toFixed(0)}%)`,
      });
    }

    // Inventory capital lock check
    if (totals.stock > db.capital * 0.65) {
      list.push({
        type: 'warn',
        title: 'Capital Concentration Risk',
        text: `Over 65% of working capital is tied up in warehouse stock. Run rotation campaigns.`,
        metric: money(totals.stock),
      });
    }

    if (db.sales.length === 0) {
      list.push({
        type: 'info',
        title: 'POS Ready for Transactions',
        text: 'Record transactions through the POS terminal to activate real-time intelligence algorithms.',
        metric: 'Ready',
      });
    }

    return list;
  }, [db.sales, db.products, totals.stock, db.capital]);

  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
      {insights.map((ins, i) => (
        <div
          key={i}
          className={`p-4 rounded-2xl border text-xs space-y-1.5 ${
            ins.type === 'good'
              ? 'bg-emerald-50/70 border-emerald-200 text-emerald-950'
              : ins.type === 'warn'
              ? 'bg-amber-50/70 border-amber-200 text-amber-950'
              : 'bg-slate-50/70 border-slate-200 text-slate-800'
          }`}
        >
          <div className="flex items-center justify-between">
            <div className="font-extrabold flex items-center gap-1.5 text-sm">
              <Award className="w-4 h-4 text-emerald-700 shrink-0" />
              <span>{ins.title}</span>
            </div>
            {ins.metric && (
              <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-md bg-white/90 shadow-2xs border border-slate-200">
                {ins.metric}
              </span>
            )}
          </div>
          <p className="text-xs leading-relaxed opacity-90">{ins.text}</p>
        </div>
      ))}
    </div>
  );
};
