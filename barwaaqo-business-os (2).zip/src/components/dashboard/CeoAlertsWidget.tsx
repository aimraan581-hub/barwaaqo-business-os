import React, { useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { money } from '../../utils/helpers';
import { AlertTriangle, CheckCircle2, Users, Factory, ArrowRight, TrendingUp } from 'lucide-react';

export const CeoAlertsWidget: React.FC = () => {
  const { db, totals, setActiveTab, priceSuggestions } = useStore();

  const lowStockItems = useMemo(() => {
    return (db.products || []).filter((p) => p.stock <= p.min);
  }, [db.products]);

  const debtorCustomers = useMemo(() => {
    return (db.customers || []).filter((c) => (c.credit || 0) > 0);
  }, [db.customers]);

  const criticalPricingCount = useMemo(() => {
    return (priceSuggestions || []).filter((s) => s.urgency === 'critical').length;
  }, [priceSuggestions]);

  const hasAlerts =
    lowStockItems.length > 0 || totals.debt > 0 || totals.supplierDebt > 0 || criticalPricingCount > 0;

  return (
    <div className="space-y-2.5">
      {!hasAlerts ? (
        <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-200 text-emerald-900 text-xs flex items-center gap-3">
          <CheckCircle2 className="w-5 h-5 text-emerald-600 shrink-0" />
          <div>
            <h4 className="font-extrabold text-sm">All Operational Systems Green</h4>
            <p className="text-[11px] text-emerald-800 mt-0.5">
              Stock levels are safe, customer debts are cleared, and vendor balances are in order.
            </p>
          </div>
        </div>
      ) : (
        <>
          {lowStockItems.length > 0 && (
            <div className="p-3.5 rounded-2xl bg-amber-50/90 border border-amber-200 text-amber-950 text-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-500 animate-pulse shrink-0" />
                <div className="min-w-0">
                  <span className="font-bold text-slate-900 block truncate">
                    {lowStockItems.length} Products at Critical Minimum
                  </span>
                  <span className="text-[11px] text-amber-800">
                    Lines like {lowStockItems[0]?.name} need purchase replenishment.
                  </span>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('purchases')}
                className="px-3 py-1.5 bg-white border border-amber-300 text-amber-900 font-extrabold rounded-xl hover:bg-amber-100 transition text-[11px] shrink-0"
              >
                Restock Orders
              </button>
            </div>
          )}

          {totals.debt > 0 && (
            <div className="p-3.5 rounded-2xl bg-rose-50/90 border border-rose-200 text-rose-950 text-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <Users className="w-4 h-4 text-rose-600 shrink-0" />
                <div className="min-w-0">
                  <span className="font-bold text-slate-900 block truncate">
                    {money(totals.debt)} Customer Credit Uncollected
                  </span>
                  <span className="text-[11px] text-rose-800">
                    {debtorCustomers.length} client accounts with active unpaid debt balances.
                  </span>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('customers')}
                className="px-3 py-1.5 bg-white border border-rose-300 text-rose-900 font-extrabold rounded-xl hover:bg-rose-100 transition text-[11px] shrink-0"
              >
                Recover Debt
              </button>
            </div>
          )}

          {totals.supplierDebt > 0 && (
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200 text-slate-800 text-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <Factory className="w-4 h-4 text-slate-600 shrink-0" />
                <div className="min-w-0">
                  <span className="font-bold text-slate-900 block truncate">
                    {money(totals.supplierDebt)} Vendor Credit Payable
                  </span>
                  <span className="text-[11px] text-slate-600">
                    Outstanding supplier invoice obligations.
                  </span>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('purchases')}
                className="px-3 py-1.5 bg-white border border-slate-300 text-slate-900 font-extrabold rounded-xl hover:bg-slate-100 transition text-[11px] shrink-0"
              >
                Pay Invoices
              </button>
            </div>
          )}

          {criticalPricingCount > 0 && (
            <div className="p-3.5 rounded-2xl bg-indigo-50/90 border border-indigo-200 text-indigo-950 text-xs flex items-center justify-between gap-3">
              <div className="flex items-center gap-2.5 min-w-0">
                <TrendingUp className="w-4 h-4 text-indigo-600 shrink-0" />
                <div className="min-w-0">
                  <span className="font-bold text-slate-900 block truncate">
                    {criticalPricingCount} Products With Margin Compression
                  </span>
                  <span className="text-[11px] text-indigo-800">
                    COGS inflation or rival shifts require immediate price adjustments.
                  </span>
                </div>
              </div>
              <button
                onClick={() => setActiveTab('pricing')}
                className="px-3 py-1.5 bg-white border border-indigo-300 text-indigo-900 font-extrabold rounded-xl hover:bg-indigo-100 transition text-[11px] shrink-0"
              >
                Adjust Prices
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
};
