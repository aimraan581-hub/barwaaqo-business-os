import React from 'react';
import { Pin, PinOff, ChevronUp, ChevronDown, RotateCw, LucideIcon } from 'lucide-react';
import { DashboardWidgetId } from '../../types';

interface WidgetCardProps {
  id: DashboardWidgetId;
  title: string;
  subtitle?: string;
  category?: 'financial' | 'inventory' | 'operations' | 'strategy';
  isPinned: boolean;
  onTogglePin: (id: DashboardWidgetId) => void;
  onMoveUp?: (id: DashboardWidgetId) => void;
  onMoveDown?: (id: DashboardWidgetId) => void;
  canMoveUp?: boolean;
  canMoveDown?: boolean;
  badge?: string;
  badgeColor?: string;
  icon?: LucideIcon;
  action?: React.ReactNode;
  children: React.ReactNode;
  className?: string;
  isRefreshing?: boolean;
}

export const WidgetCard: React.FC<WidgetCardProps> = ({
  id,
  title,
  subtitle,
  category = 'financial',
  isPinned,
  onTogglePin,
  onMoveUp,
  onMoveDown,
  canMoveUp = false,
  canMoveDown = false,
  badge,
  badgeColor = 'bg-emerald-100 text-emerald-800',
  icon: Icon,
  action,
  children,
  className = '',
  isRefreshing = false,
}) => {
  const categoryStyles: Record<string, { label: string; color: string }> = {
    financial: { label: 'Financial', color: 'bg-emerald-50 text-emerald-700 border-emerald-200/70' },
    inventory: { label: 'Inventory', color: 'bg-blue-50 text-blue-700 border-blue-200/70' },
    operations: { label: 'Operations', color: 'bg-purple-50 text-purple-700 border-purple-200/70' },
    strategy: { label: 'Strategy', color: 'bg-amber-50 text-amber-700 border-amber-200/70' },
  };

  const cat = categoryStyles[category] || categoryStyles.financial;

  return (
    <div
      id={`widget-${id}`}
      className={`rounded-3xl border transition-all duration-200 shadow-xs bg-white ${
        isPinned
          ? 'border-emerald-400 ring-2 ring-emerald-500/15 shadow-md'
          : 'border-slate-200/90 hover:border-slate-300'
      } ${className}`}
    >
      {/* Widget Header */}
      <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between gap-3">
        <div className="flex items-center gap-2.5 min-w-0">
          {Icon && (
            <div
              className={`p-2 rounded-xl shrink-0 ${
                isPinned ? 'bg-emerald-600 text-white shadow-xs' : 'bg-slate-100 text-slate-700'
              }`}
            >
              <Icon className="w-4 h-4" />
            </div>
          )}
          <div className="min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-extrabold text-sm sm:text-base text-slate-900 tracking-tight truncate">
                {title}
              </h3>
              {badge && (
                <span
                  className={`text-[10px] font-black uppercase tracking-wider px-2 py-0.5 rounded-full shrink-0 ${badgeColor}`}
                >
                  {badge}
                </span>
              )}
              {isRefreshing && (
                <span className="flex items-center gap-1 text-[9px] font-black uppercase tracking-wider px-1.5 py-0.5 rounded-md bg-emerald-100 text-emerald-800 border border-emerald-300 shrink-0 animate-pulse">
                  <RotateCw className="w-2.5 h-2.5 animate-spin text-emerald-700" />
                  Syncing
                </span>
              )}
              <span
                className={`text-[9px] font-bold uppercase tracking-wider px-1.5 py-0.2 rounded-md border shrink-0 hidden sm:inline-block ${cat.color}`}
              >
                {cat.label}
              </span>
            </div>
            {subtitle && (
              <p className="text-xs text-slate-600 mt-0.5 font-medium truncate">{subtitle}</p>
            )}
          </div>
        </div>

        {/* Action Controls: Pin, Move Up, Move Down, Custom Action */}
        <div className="flex items-center gap-1.5 shrink-0">
          {action}

          {/* Reorder Buttons */}
          {(onMoveUp || onMoveDown) && (
            <div className="flex items-center bg-slate-100 rounded-xl p-0.5 border border-slate-200">
              <button
                onClick={() => onMoveUp && onMoveUp(id)}
                disabled={!canMoveUp}
                aria-label="Move Widget Up"
                title="Move Up"
                className={`p-1 rounded-lg transition ${
                  canMoveUp
                    ? 'text-slate-700 hover:text-slate-950 hover:bg-white active:scale-95'
                    : 'text-slate-400 cursor-not-allowed'
                }`}
              >
                <ChevronUp className="w-3.5 h-3.5" />
              </button>
              <button
                onClick={() => onMoveDown && onMoveDown(id)}
                disabled={!canMoveDown}
                aria-label="Move Widget Down"
                title="Move Down"
                className={`p-1 rounded-lg transition ${
                  canMoveDown
                    ? 'text-slate-700 hover:text-slate-950 hover:bg-white active:scale-95'
                    : 'text-slate-400 cursor-not-allowed'
                }`}
              >
                <ChevronDown className="w-3.5 h-3.5" />
              </button>
            </div>
          )}

          {/* Pin / Unpin Button */}
          <button
            onClick={() => onTogglePin(id)}
            aria-label={isPinned ? 'Unpin card' : 'Pin card to top'}
            title={isPinned ? 'Unpin card from top' : 'Pin card to top of CEO dashboard'}
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-bold transition-all active:scale-95 ${
              isPinned
                ? 'bg-emerald-700 text-white shadow-xs hover:bg-emerald-800'
                : 'bg-slate-100 hover:bg-emerald-50 text-slate-700 hover:text-emerald-900 border border-slate-200/90'
            }`}
          >
            {isPinned ? (
              <>
                <PinOff className="w-3.5 h-3.5" />
                <span className="hidden sm:inline text-[11px]">Pinned</span>
              </>
            ) : (
              <>
                <Pin className="w-3.5 h-3.5" />
                <span className="hidden sm:inline text-[11px]">Pin</span>
              </>
            )}
          </button>
        </div>
      </div>

      {/* Widget Body */}
      <div className="p-4 sm:p-5">{children}</div>
    </div>
  );
};
