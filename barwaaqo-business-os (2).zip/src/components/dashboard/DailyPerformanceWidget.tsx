import React, { useState, useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { money, day, todayLabel } from '../../utils/helpers';
import {
  Target,
  TrendingUp,
  Clock,
  Sparkles,
  DollarSign,
  Edit3,
  CheckCircle2,
  AlertCircle,
  ShoppingCart,
  Flame,
  ArrowRight,
  X,
  Sliders,
  Percent,
  Receipt,
  Wallet,
  Calendar,
  AlertTriangle,
  Trophy,
  CheckSquare,
  Square,
  Plus,
  BrainCircuit,
  Activity,
  BarChart3,
  ChevronLeft,
  ChevronRight,
  Zap,
} from 'lucide-react';
import { DailyActionItem } from '../../types';

const PRESET_TARGETS = [15000, 25000, 40000, 60000, 80000, 100000];

export const DailyPerformanceWidget: React.FC = () => {
  const {
    db,
    setDailySalesTarget,
    setDailySalesTargetForDate,
    toggleDailyActionItem,
    addDailyActionItem,
    deleteDailyActionItem,
    setActiveTab,
    showToast,
  } = useStore();

  const todayKey = day();
  const [selectedDate, setSelectedDate] = useState<string>(todayKey);
  const [isEditingTarget, setIsEditingTarget] = useState(false);
  const [isAddingAction, setIsAddingAction] = useState(false);
  const [newActionText, setNewActionText] = useState('');
  const [newActionImpact, setNewActionImpact] = useState<'high' | 'medium' | 'growth'>('high');

  // Target for selected date (defaults to db.dailyTargets[selectedDate], or db.dailySalesTarget, or 25000)
  const targetForSelectedDate = useMemo(() => {
    if (db.dailyTargets && db.dailyTargets[selectedDate] !== undefined) {
      return db.dailyTargets[selectedDate];
    }
    return db.dailySalesTarget || 25000;
  }, [db.dailyTargets, db.dailySalesTarget, selectedDate]);

  const [customTargetInput, setCustomTargetInput] = useState<string>(String(targetForSelectedDate));

  // Sync customTargetInput whenever selected date changes
  React.useEffect(() => {
    setCustomTargetInput(String(targetForSelectedDate));
  }, [selectedDate, targetForSelectedDate]);

  // Sales for selected date
  const selectedDateSales = useMemo(() => {
    return (db.sales || []).filter((s) => s.date === selectedDate);
  }, [db.sales, selectedDate]);

  // Financial calculations for selected date
  const totalSalesSelected = useMemo(() => {
    return selectedDateSales.reduce((acc, s) => acc + (s.total || 0), 0);
  }, [selectedDateSales]);

  const grossProfitSelected = useMemo(() => {
    return selectedDateSales.reduce((acc, s) => acc + (s.profit || 0), 0);
  }, [selectedDateSales]);

  const invoiceCount = selectedDateSales.length;
  const avgBasketSize = invoiceCount > 0 ? totalSalesSelected / invoiceCount : 0;
  const profitMarginPercent = totalSalesSelected > 0 ? (grossProfitSelected / totalSalesSelected) * 100 : 0;

  // Largest single sale
  const maxSingleSale = useMemo(() => {
    if (selectedDateSales.length === 0) return 0;
    return Math.max(...selectedDateSales.map((s) => s.total || 0));
  }, [selectedDateSales]);

  // Payment breakdown
  const paymentBreakdown = useMemo(() => {
    const cash = selectedDateSales.filter((s) => s.payment === 'Cash').reduce((a, s) => a + (s.total || 0), 0);
    const digital = selectedDateSales.filter((s) => s.payment === 'Bank' || s.payment === 'Mobile Money').reduce((a, s) => a + (s.total || 0), 0);
    const credit = selectedDateSales.filter((s) => s.payment === 'Credit').reduce((a, s) => a + (s.total || 0), 0);
    return { cash, digital, credit };
  }, [selectedDateSales]);

  // Progress metrics
  const progressPercent = targetForSelectedDate > 0 ? (totalSalesSelected / targetForSelectedDate) * 100 : 0;
  const cappedProgress = Math.min(100, progressPercent);
  const isTargetAchieved = totalSalesSelected >= targetForSelectedDate && targetForSelectedDate > 0;
  const remainingGap = Math.max(0, targetForSelectedDate - totalSalesSelected);
  const surplusAchieved = Math.max(0, totalSalesSelected - targetForSelectedDate);

  // Hourly Run-Rate Pacing Calculation (Standard 12-hour retail window: 08:00 - 20:00)
  const isToday = selectedDate === todayKey;
  const pacingMetrics = useMemo(() => {
    const now = new Date();
    const currentHour = now.getHours() + now.getMinutes() / 60;
    const storeOpenHour = 8;
    const storeCloseHour = 20;
    const totalOperatingHours = storeCloseHour - storeOpenHour; // 12 hours

    let elapsedHours: number;
    if (!isToday) {
      elapsedHours = totalOperatingHours;
    } else if (currentHour < storeOpenHour) {
      elapsedHours = 0.5; // Early morning baseline
    } else if (currentHour > storeCloseHour) {
      elapsedHours = totalOperatingHours;
    } else {
      elapsedHours = Math.max(0.5, currentHour - storeOpenHour);
    }

    const remainingHours = Math.max(0, totalOperatingHours - elapsedHours);
    const hourlyPace = totalSalesSelected / elapsedHours;
    const projectedEodTotal = hourlyPace * totalOperatingHours;
    const isPacingAhead = projectedEodTotal >= targetForSelectedDate;
    const requiredHourlyToHitTarget = remainingHours > 0 && remainingGap > 0 ? remainingGap / remainingHours : 0;

    return {
      elapsedHours: elapsedHours.toFixed(1),
      remainingHours: remainingHours.toFixed(1),
      hourlyPace,
      projectedEodTotal,
      isPacingAhead,
      requiredHourlyToHitTarget,
    };
  }, [totalSalesSelected, targetForSelectedDate, isToday, remainingGap]);

  // Performance status classification
  const performanceStatus = useMemo(() => {
    if (isTargetAchieved) {
      return {
        label: 'Target Hit',
        color: 'bg-emerald-500 text-white border-emerald-400',
        textColor: 'text-emerald-300',
        indicator: '🟢',
      };
    }
    if (pacingMetrics.isPacingAhead || progressPercent >= 75) {
      return {
        label: 'On Pace',
        color: 'bg-emerald-500/20 text-emerald-300 border-emerald-500/30',
        textColor: 'text-emerald-300',
        indicator: '🟢',
      };
    }
    if (progressPercent >= 45) {
      return {
        label: 'Behind Pace',
        color: 'bg-amber-500/20 text-amber-300 border-amber-500/30',
        textColor: 'text-amber-300',
        indicator: '🟡',
      };
    }
    return {
      label: 'Critical Lag',
      color: 'bg-rose-500/20 text-rose-300 border-rose-500/30',
      textColor: 'text-rose-300',
      indicator: '🔴',
    };
  }, [isTargetAchieved, pacingMetrics.isPacingAhead, progressPercent]);

  // Action focus items for selected date
  const actionItems: DailyActionItem[] = useMemo(() => {
    return db.dailyActionFocus?.[selectedDate] || [
      { id: '1', text: 'Audit high-margin fast-moving grocery inventory', done: false, impact: 'high', assignedTo: 'CEO' },
      { id: '2', text: 'Follow up on pending B2B wholesale client orders', done: false, impact: 'medium', assignedTo: 'Sales' },
      { id: '3', text: 'Verify supplier dispatch lead times for top restocks', done: true, impact: 'growth', assignedTo: 'Operations' },
    ];
  }, [db.dailyActionFocus, selectedDate]);

  // 7-day historical target preview
  const weekHistory = useMemo(() => {
    const list = [];
    for (let i = 6; i >= 0; i--) {
      const d = new Date();
      d.setDate(d.getDate() - i);
      const dStr = d.toISOString().split('T')[0];
      const target = db.dailyTargets?.[dStr] || db.dailySalesTarget || 25000;
      const sales = (db.sales || []).filter((s) => s.date === dStr).reduce((acc, s) => acc + (s.total || 0), 0);
      const hit = sales >= target;
      list.push({
        date: dStr,
        label: d.toLocaleDateString(undefined, { weekday: 'short', month: 'numeric', day: 'numeric' }),
        target,
        sales,
        hit,
        pct: target > 0 ? (sales / target) * 100 : 0,
      });
    }
    return list;
  }, [db.dailyTargets, db.dailySalesTarget, db.sales]);

  // Handle saving target
  const handleSaveTarget = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const num = parseFloat(customTargetInput.replace(/[^0-9.]/g, ''));
    if (isNaN(num) || num <= 0) {
      showToast('Please enter a valid sales target greater than ETB 0');
      return;
    }
    setDailySalesTargetForDate(selectedDate, num);
    setIsEditingTarget(false);
  };

  const handleSelectPreset = (amount: number) => {
    setCustomTargetInput(String(amount));
    setDailySalesTargetForDate(selectedDate, amount);
    setIsEditingTarget(false);
  };

  const handleAddAction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newActionText.trim()) return;
    addDailyActionItem(selectedDate, newActionText, newActionImpact);
    setNewActionText('');
    setIsAddingAction(false);
  };

  return (
    <div className="space-y-4">
      {/* Date Navigation & Selector Bar */}
      <div className="flex flex-wrap items-center justify-between gap-2.5 px-3.5 py-2.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
        <div className="flex items-center gap-2">
          <div className="p-1.5 rounded-xl bg-emerald-100 text-emerald-800">
            <Calendar className="w-4 h-4" />
          </div>
          <div>
            <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
              PERFORMANCE DATE
            </span>
            <div className="flex items-center gap-2">
              <input
                type="date"
                value={selectedDate}
                onChange={(e) => setSelectedDate(e.target.value)}
                className="text-xs font-bold text-slate-800 bg-transparent border-none p-0 focus:ring-0 cursor-pointer"
              />
              {isToday ? (
                <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  Today (Live)
                </span>
              ) : (
                <button
                  onClick={() => setSelectedDate(todayKey)}
                  className="text-[10px] font-bold text-emerald-600 hover:text-emerald-700 underline"
                >
                  Jump to Today
                </button>
              )}
            </div>
          </div>
        </div>

        {/* 7-Day History Mini Strip */}
        <div className="hidden md:flex items-center gap-1.5">
          {weekHistory.map((dayItem) => {
            const isSelected = dayItem.date === selectedDate;
            return (
              <button
                key={dayItem.date}
                onClick={() => setSelectedDate(dayItem.date)}
                title={`${dayItem.date}: ${money(dayItem.sales)} / ${money(dayItem.target)} (${dayItem.pct.toFixed(0)}%)`}
                className={`flex flex-col items-center px-2 py-1 rounded-xl text-[10px] transition-all border ${
                  isSelected
                    ? 'bg-emerald-900 text-white border-emerald-700 shadow-xs'
                    : 'bg-slate-50 hover:bg-slate-100 text-slate-600 border-slate-200'
                }`}
              >
                <span className="font-medium text-[9px] opacity-80">{dayItem.label.split(',')[0]}</span>
                <span className={`font-black ${dayItem.hit ? 'text-emerald-400' : 'text-slate-700'}`}>
                  {dayItem.pct.toFixed(0)}%
                </span>
              </button>
            );
          })}
        </div>
      </div>

      {/* Target Hit Celebratory Banner (12. 🏆 Target-hit indicator) */}
      {isTargetAchieved && (
        <div className="p-4 rounded-2xl bg-gradient-to-r from-amber-500 via-emerald-600 to-teal-700 text-white shadow-md flex items-center justify-between flex-wrap gap-3 animate-in fade-in slide-in-from-top-2 duration-500">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-white/20 backdrop-blur-md text-amber-200 border border-white/30 shadow-inner">
              <Trophy className="w-6 h-6 animate-bounce" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="text-base font-black text-white tracking-tight">
                  Target Hit! Sales Goal Surpassed 🏆
                </h4>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-white/20 text-white border border-white/40">
                  {progressPercent.toFixed(1)}% Achieved
                </span>
              </div>
              <p className="text-xs text-emerald-100 font-medium">
                CEO Target of {money(targetForSelectedDate)} met with{' '}
                <strong className="text-white">+{money(surplusAchieved)} surplus revenue</strong>.
              </p>
            </div>
          </div>
          <button
            onClick={() => setActiveTab('reports')}
            className="px-3.5 py-1.5 rounded-xl bg-white text-emerald-950 font-extrabold text-xs shadow-sm hover:bg-emerald-50 transition active:scale-95"
          >
            Review Profit Ledger
          </button>
        </div>
      )}

      {/* Low-Performance Warning Alert (11. 🚨 Low-performance warning) */}
      {!isTargetAchieved && isToday && progressPercent < 55 && Number(pacingMetrics.elapsedHours) >= 4 && (
        <div className="p-3.5 rounded-2xl bg-rose-50 border border-rose-200 text-rose-900 shadow-2xs flex items-start gap-3">
          <div className="p-2 rounded-xl bg-rose-100 text-rose-700 shrink-0 mt-0.5">
            <AlertTriangle className="w-5 h-5" />
          </div>
          <div className="flex-1">
            <div className="flex items-center justify-between gap-2">
              <h5 className="font-extrabold text-xs text-rose-900 flex items-center gap-1.5">
                <span>🚨 Low-Performance Pacing Warning</span>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-200 text-rose-800">
                  {progressPercent.toFixed(1)}% of Target
                </span>
              </h5>
              <span className="text-[11px] font-black text-rose-700">
                {money(pacingMetrics.requiredHourlyToHitTarget)}/hr Required
              </span>
            </div>
            <p className="text-xs text-rose-800 mt-1">
              Store is currently behind the daily sales curve. To close the{' '}
              <strong>{money(remainingGap)} sales gap</strong> across the remaining{' '}
              {pacingMetrics.remainingHours} trading hours, activate staff promotions, follow up on wholesale deliveries, or run discount alerts.
            </p>
          </div>
        </div>
      )}

      {/* Primary Performance Gauge Card (1, 2, 3, 4, 5, 6) */}
      <div className="relative overflow-hidden rounded-3xl p-5 sm:p-6 bg-gradient-to-br from-slate-900 via-[#031d14] to-[#043321] text-white border border-emerald-800/40 shadow-sm">
        {/* Glow Accent */}
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-44 h-44 rounded-full bg-emerald-500/15 blur-3xl pointer-events-none" />

        {/* Top Header Row */}
        <div className="flex flex-wrap items-center justify-between gap-2.5 pb-4 border-b border-emerald-800/40">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-300 border border-emerald-400/30">
              <Target className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h4 className="font-extrabold text-base text-white tracking-tight">
                  CEO Daily Sales Target (1. 🎯)
                </h4>
                {/* 6. 🚦 Performance status badge */}
                <span className={`inline-flex items-center gap-1 text-[10px] font-black uppercase tracking-wider px-2.5 py-0.5 rounded-full border ${performanceStatus.color}`}>
                  <span>{performanceStatus.indicator}</span>
                  <span>{performanceStatus.label}</span>
                </span>
              </div>
              <p className="text-xs text-emerald-200/80 font-medium mt-0.5">
                Benchmark: <strong className="text-white">{money(targetForSelectedDate)}</strong> · Date: {selectedDate}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                setCustomTargetInput(String(targetForSelectedDate));
                setIsEditingTarget(true);
              }}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-200 border border-emerald-400/30 text-xs font-bold transition active:scale-95"
            >
              <Edit3 className="w-3.5 h-3.5" />
              <span>Adjust Target</span>
            </button>
          </div>
        </div>

        {/* Main Revenue Gauge & Progress (2. 💰, 3. 📊, 4. 📉, 5. 📈) */}
        <div className="mt-5 space-y-4">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <div>
              <span className="text-[10px] font-extrabold text-emerald-300/70 uppercase tracking-wider block">
                2. 💰 TODAY'S ACTUAL SALES
              </span>
              <div className="flex items-baseline gap-2 mt-0.5">
                <span className="text-3xl sm:text-4xl font-black text-white tracking-tight">
                  {money(totalSalesSelected)}
                </span>
                <span className="text-xs sm:text-sm text-emerald-300/80 font-semibold">
                  / {money(targetForSelectedDate)} target
                </span>
              </div>
            </div>

            <div className="text-right">
              <div className="flex items-center justify-end gap-1.5">
                <span className="text-[10px] font-extrabold text-emerald-300/70 uppercase tracking-wider block">
                  3. 📊 ACHIEVEMENT
                </span>
              </div>
              <span
                className={`text-2xl sm:text-3xl font-black tracking-tight block ${
                  isTargetAchieved
                    ? 'text-emerald-300'
                    : progressPercent >= 65
                    ? 'text-teal-300'
                    : 'text-amber-300'
                }`}
              >
                {progressPercent.toFixed(1)}%
              </span>
              {/* 4. 📉 Remaining sales gap */}
              <span className="text-[11px] text-emerald-200/80 font-medium block">
                {isTargetAchieved
                  ? `+${money(surplusAchieved)} surplus over goal`
                  : `${money(remainingGap)} 4. 📉 remaining sales gap`}
              </span>
            </div>
          </div>

          {/* 5. 📈 Live Progress Bar with Milestone Markers */}
          <div className="relative pt-1 pb-2">
            <div className="w-full h-4 bg-emerald-950/90 rounded-full overflow-hidden p-0.5 border border-emerald-700/50 shadow-inner">
              <div
                className={`h-full rounded-full transition-all duration-700 relative ${
                  isTargetAchieved
                    ? 'bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300 shadow-md shadow-emerald-400/30'
                    : progressPercent >= 50
                    ? 'bg-gradient-to-r from-teal-500 via-emerald-400 to-teal-300'
                    : 'bg-gradient-to-r from-amber-500 via-amber-400 to-yellow-300'
                }`}
                style={{ width: `${cappedProgress}%` }}
              >
                <div className="absolute right-0 top-0 bottom-0 w-2 bg-white/70 rounded-full animate-pulse" />
              </div>
            </div>

            {/* Milestones */}
            <div className="flex justify-between text-[10px] text-emerald-400/80 font-bold px-1 mt-1.5">
              <span>0%</span>
              <span className="hidden xs:inline">25% (Morning)</span>
              <span>50% (Mid-Day)</span>
              <span className="hidden xs:inline">75% (Peak Hours)</span>
              <span className="text-emerald-300 font-extrabold flex items-center gap-0.5">
                <Target className="w-3 h-3" /> 100% Target
              </span>
            </div>
          </div>
        </div>

        {/* Pacing Banner */}
        <div className="mt-3 p-3 rounded-2xl bg-white/5 border border-emerald-500/20 flex items-center justify-between flex-wrap gap-2 text-xs">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-emerald-300 shrink-0" />
            <div>
              <span className="font-semibold text-white">Sales Velocity:</span>{' '}
              <span className="text-emerald-200 font-bold">
                {money(pacingMetrics.hourlyPace)}/hr run-rate
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] text-emerald-200/70">Projected EOD:</span>
            <span
              className={`font-black text-xs px-2.5 py-0.5 rounded-lg ${
                pacingMetrics.isPacingAhead
                  ? 'bg-emerald-500/30 text-emerald-200 border border-emerald-400/40'
                  : 'bg-amber-500/20 text-amber-200 border border-amber-400/30'
              }`}
            >
              {money(pacingMetrics.projectedEodTotal)}
            </span>
          </div>
        </div>
      </div>

      {/* 9. 🧠 CEO Performance Insight Card */}
      <div className="p-4 rounded-3xl bg-slate-900 text-white border border-slate-800 shadow-sm relative overflow-hidden">
        <div className="flex items-start justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="p-2 rounded-2xl bg-indigo-500/20 text-indigo-300 border border-indigo-500/30 shrink-0 mt-0.5">
              <BrainCircuit className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h5 className="font-extrabold text-sm text-white">
                  9. 🧠 CEO Performance Insight
                </h5>
                <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-indigo-500/20 text-indigo-300 border border-indigo-400/30">
                  Strategic Recommendation
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 leading-relaxed">
                {isTargetAchieved ? (
                  <>
                    Store is operating at peak efficiency with a healthy{' '}
                    <strong className="text-emerald-400">{profitMarginPercent.toFixed(1)}% profit margin</strong>. Cash receipts make up{' '}
                    {money(paymentBreakdown.cash)} of daily collections. Recommend locking wholesale purchases to reinvest surplus.
                  </>
                ) : pacingMetrics.isPacingAhead ? (
                  <>
                    Strong morning momentum. Realized average basket is{' '}
                    <strong className="text-indigo-300">{money(avgBasketSize)}</strong> across {invoiceCount} orders. Current run-rate projects reaching{' '}
                    <strong className="text-emerald-400">{money(pacingMetrics.projectedEodTotal)}</strong> by closing time.
                  </>
                ) : (
                  <>
                    Revenue pace is currently {progressPercent.toFixed(0)}% of quota with{' '}
                    <strong className="text-amber-400">{money(remainingGap)} remaining</strong>. Recommend promoting high-margin packaged food and dairy items, and checking counter cashier velocity.
                  </>
                )}
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* 10. ⚡ Daily Action Focus Section */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs">
        <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="p-1.5 rounded-xl bg-amber-100 text-amber-800">
              <Zap className="w-4 h-4" />
            </div>
            <div>
              <h5 className="font-extrabold text-sm text-slate-900">
                10. ⚡ Daily Action Focus
              </h5>
              <p className="text-[11px] text-slate-500">
                CEO prioritized tactical steps to achieve today's sales target
              </p>
            </div>
          </div>

          <button
            onClick={() => setIsAddingAction(true)}
            className="flex items-center gap-1 px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Action</span>
          </button>
        </div>

        {/* Action List */}
        <div className="mt-3 space-y-2">
          {actionItems.map((action) => (
            <div
              key={action.id}
              onClick={() => toggleDailyActionItem(selectedDate, action.id)}
              className={`flex items-center justify-between p-3 rounded-2xl border transition cursor-pointer select-none ${
                action.done
                  ? 'bg-slate-50 border-slate-200 text-slate-400'
                  : 'bg-white border-slate-200 hover:border-emerald-300 text-slate-800 shadow-2xs'
              }`}
            >
              <div className="flex items-center gap-3">
                {action.done ? (
                  <CheckSquare className="w-4 h-4 text-emerald-600 shrink-0" />
                ) : (
                  <Square className="w-4 h-4 text-slate-400 shrink-0" />
                )}
                <span className={`text-xs font-bold ${action.done ? 'line-through text-slate-400' : 'text-slate-800'}`}>
                  {action.text}
                </span>
              </div>

              <div className="flex items-center gap-2">
                {action.impact === 'high' && (
                  <span className="text-[9px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full bg-rose-100 text-rose-800">
                    High Impact
                  </span>
                )}
                {action.impact === 'growth' && (
                  <span className="text-[9px] font-extrabold uppercase tracking-wider px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                    Growth
                  </span>
                )}
                {action.assignedTo && (
                  <span className="text-[9px] font-bold px-2 py-0.5 rounded-md bg-slate-100 text-slate-600">
                    {action.assignedTo}
                  </span>
                )}
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteDailyActionItem(selectedDate, action.id);
                  }}
                  className="text-slate-300 hover:text-rose-500 p-1"
                  title="Remove action"
                >
                  <X className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          ))}
        </div>

        {/* Add Action Input Form */}
        {isAddingAction && (
          <form onSubmit={handleAddAction} className="mt-3 p-3 rounded-2xl bg-slate-50 border border-slate-200 flex flex-wrap items-center gap-2">
            <input
              type="text"
              value={newActionText}
              onChange={(e) => setNewActionText(e.target.value)}
              placeholder="e.g. Call supplier for wholesale restocking discount..."
              className="flex-1 min-w-[220px] px-3 py-1.5 text-xs bg-white border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-emerald-500/20 font-medium"
              autoFocus
            />
            <select
              value={newActionImpact}
              onChange={(e) => setNewActionImpact(e.target.value as any)}
              className="px-2.5 py-1.5 text-xs bg-white border border-slate-300 rounded-xl font-bold text-slate-700"
            >
              <option value="high">High Impact</option>
              <option value="medium">Medium</option>
              <option value="growth">Growth</option>
            </select>
            <button
              type="submit"
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs"
            >
              Save Action
            </button>
            <button
              type="button"
              onClick={() => setIsAddingAction(false)}
              className="px-2 py-1.5 text-xs text-slate-500 hover:text-slate-700"
            >
              Cancel
            </button>
          </form>
        )}
      </div>

      {/* 13. 💵 Revenue Tracking Breakdown Metrics Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Total Invoices */}
        <div className="p-3.5 bg-slate-50/90 rounded-2xl border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block">
              TRANSACTIONS
            </span>
            <Receipt className="w-3.5 h-3.5 text-blue-600" />
          </div>
          <span className="text-base sm:text-lg font-black text-slate-900 tracking-tight block mt-1">
            {invoiceCount} Invoices
          </span>
          <span className="text-[10px] text-slate-500 font-medium block mt-0.5">
            Avg Ticket: <strong className="text-blue-700">{money(avgBasketSize)}</strong>
          </span>
        </div>

        {/* Realized Profit Margin */}
        <div className="p-3.5 bg-slate-50/90 rounded-2xl border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block">
              GROSS PROFIT
            </span>
            <Percent className="w-3.5 h-3.5 text-emerald-600" />
          </div>
          <span className="text-base sm:text-lg font-black text-emerald-700 tracking-tight block mt-1">
            {money(grossProfitSelected)}
          </span>
          <span className="text-[10px] text-emerald-800 font-bold block mt-0.5">
            {profitMarginPercent.toFixed(1)}% Realized Margin
          </span>
        </div>

        {/* Largest Ticket Sale */}
        <div className="p-3.5 bg-slate-50/90 rounded-2xl border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block">
              PEAK TICKET
            </span>
            <TrendingUp className="w-3.5 h-3.5 text-amber-600" />
          </div>
          <span className="text-base sm:text-lg font-black text-slate-900 tracking-tight block mt-1">
            {money(maxSingleSale)}
          </span>
          <span className="text-[10px] text-slate-500 font-medium block mt-0.5">
            Highest counter order
          </span>
        </div>

        {/* Cash vs Digital Ratio */}
        <div className="p-3.5 bg-slate-50/90 rounded-2xl border border-slate-200/80 shadow-2xs">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold text-slate-500 uppercase tracking-wider block">
              CASH / DIGITAL
            </span>
            <Wallet className="w-3.5 h-3.5 text-purple-600" />
          </div>
          <span className="text-base sm:text-lg font-black text-slate-900 tracking-tight block mt-1">
            {money(paymentBreakdown.cash)}
          </span>
          <span className="text-[10px] text-purple-700 font-medium block mt-0.5">
            Digital: {money(paymentBreakdown.digital)}
          </span>
        </div>
      </div>

      {/* 8. 🔄 Automatic Sales Progress Update Footer */}
      <div className="flex items-center justify-between pt-1">
        <div className="flex items-center gap-1.5 text-xs text-slate-500 font-medium">
          <CheckCircle2 className="w-4 h-4 text-emerald-600" />
          <span>8. 🔄 Automatic sales progress updates instantly with every POS sale</span>
        </div>

        <button
          onClick={() => setActiveTab('pos')}
          className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition active:scale-95"
        >
          <ShoppingCart className="w-3.5 h-3.5" />
          <span>Open POS Counter</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      {/* Target Setting Modal (7. 📅 Daily target saved by date) */}
      {isEditingTarget && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="relative w-full max-w-md bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden">
            {/* Modal Header */}
            <div className="p-5 bg-gradient-to-r from-emerald-950 via-[#031d14] to-slate-900 text-white flex items-center justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-xl bg-emerald-500 text-slate-950 shadow-xs">
                  <Target className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-base text-white">
                    Set Target for {selectedDate}
                  </h3>
                  <p className="text-xs text-emerald-200/80">
                    7. 📅 Target is automatically saved and persisted by date
                  </p>
                </div>
              </div>
              <button
                onClick={() => setIsEditingTarget(false)}
                className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Modal Body */}
            <form onSubmit={handleSaveTarget} className="p-5 space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                  Target Revenue for {selectedDate} (ETB)
                </label>
                <div className="relative">
                  <span className="absolute left-3.5 top-1/2 -translate-y-1/2 font-bold text-slate-400 text-sm">
                    ETB
                  </span>
                  <input
                    type="number"
                    min="1000"
                    step="500"
                    value={customTargetInput}
                    onChange={(e) => setCustomTargetInput(e.target.value)}
                    placeholder="e.g. 25000"
                    className="w-full pl-14 pr-4 py-2.5 bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 text-base"
                    autoFocus
                  />
                </div>
                <p className="text-[11px] text-slate-500 mt-1">
                  Current actual sales on {selectedDate}: <strong>{money(totalSalesSelected)}</strong>
                </p>
              </div>

              {/* Quick Preset Buttons */}
              <div>
                <label className="block text-xs font-bold text-slate-600 mb-2">
                  Quick Presets
                </label>
                <div className="grid grid-cols-3 gap-2">
                  {PRESET_TARGETS.map((preset) => (
                    <button
                      key={preset}
                      type="button"
                      onClick={() => handleSelectPreset(preset)}
                      className={`px-2.5 py-2 rounded-xl text-xs font-extrabold border transition ${
                        targetForSelectedDate === preset
                          ? 'bg-emerald-600 text-white border-emerald-600 shadow-xs'
                          : 'bg-slate-50 hover:bg-slate-100 text-slate-700 border-slate-200'
                      }`}
                    >
                      {money(preset)}
                    </button>
                  ))}
                </div>
              </div>

              {/* Actions */}
              <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                <button
                  type="button"
                  onClick={() => setIsEditingTarget(false)}
                  className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100 transition"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 rounded-xl text-xs font-extrabold bg-emerald-600 hover:bg-emerald-700 text-white shadow-md transition active:scale-95"
                >
                  Save Date Target
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
