import React, { useMemo, useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { money, day } from '../../utils/helpers';
import {
  ArrowUpRight,
  ArrowDownRight,
  TrendingUp,
  Calendar,
  LineChart as LineChartIcon,
  BarChart2,
  CheckCircle2,
  DollarSign,
  Sparkles,
} from 'lucide-react';
import {
  ResponsiveContainer,
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
} from 'recharts';

interface CustomTooltipProps {
  active?: boolean;
  payload?: Array<{
    value: number;
    name: string;
    color: string;
    payload: {
      dateStr: string;
      dayLabel: string;
      fullDateLabel: string;
      revenue: number;
      profit: number;
      count: number;
      isToday: boolean;
      isFuture: boolean;
    };
  }>;
  label?: string;
}

const CustomRechartsTooltip: React.FC<CustomTooltipProps> = ({ active, payload }) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="bg-slate-900/95 backdrop-blur-md text-white p-3 rounded-2xl shadow-xl border border-slate-700/80 text-xs space-y-2 min-w-[180px]">
        <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
          <span className="font-extrabold text-slate-200">{data.fullDateLabel}</span>
          {data.isToday ? (
            <span className="text-[9px] font-bold px-1.5 py-0.5 bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 rounded-full">
              Today
            </span>
          ) : data.isFuture ? (
            <span className="text-[9px] font-bold px-1.5 py-0.5 bg-slate-800 text-slate-400 border border-slate-700 rounded-full">
              Upcoming
            </span>
          ) : null}
        </div>

        <div className="space-y-1.5">
          <div className="flex items-center justify-between text-emerald-400">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400" />
              <span>Revenue:</span>
            </span>
            <span className="font-black text-white text-xs">{money(data.revenue)}</span>
          </div>

          <div className="flex items-center justify-between text-amber-300">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-amber-400" />
              <span>Gross Profit:</span>
            </span>
            <span className="font-bold text-xs">{money(data.profit)}</span>
          </div>

          <div className="flex items-center justify-between text-slate-400 text-[11px] pt-1.5 border-t border-slate-800/80">
            <span>Sales Orders:</span>
            <span className="font-bold text-slate-200">{data.count} transactions</span>
          </div>
        </div>
      </div>
    );
  }
  return null;
};

export const RevenueVelocityWidget: React.FC = () => {
  const { db } = useStore();
  const [viewRange, setViewRange] = useState<'current_week' | 'rolling_7'>('current_week');
  const [showProfitLine, setShowProfitLine] = useState(true);
  const [chartType, setChartType] = useState<'line' | 'bar'>('line');

  const todayKey = day();

  const metrics = useMemo(() => {
    const now = new Date();
    const daysList: Array<{
      dateStr: string;
      dayLabel: string;
      weekday: string;
      fullDateLabel: string;
      revenue: number;
      profit: number;
      count: number;
      isToday: boolean;
      isFuture: boolean;
    }> = [];

    if (viewRange === 'current_week') {
      // Monday through Sunday of current week
      const dayOfWeek = now.getDay(); // 0 is Sunday, 1 is Monday ... 6 is Saturday
      const diffToMonday = (dayOfWeek + 6) % 7; // days since Monday
      const monday = new Date(now);
      monday.setDate(now.getDate() - diffToMonday);
      monday.setHours(0, 0, 0, 0);

      for (let i = 0; i < 7; i++) {
        const d = new Date(monday);
        d.setDate(monday.getDate() + i);
        const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
          d.getDate()
        ).padStart(2, '0')}`;
        const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
        const monthDay = d.toLocaleDateString('en-US', { month: 'numeric', day: 'numeric' });
        const daySales = (db.sales || []).filter((s) => s.date === k);

        daysList.push({
          dateStr: k,
          dayLabel: `${dayName} ${monthDay}`,
          weekday: dayName,
          fullDateLabel: d.toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
            year: 'numeric',
          }),
          revenue: daySales.reduce((a, x) => a + (x.total || 0), 0),
          profit: daySales.reduce((a, x) => a + (x.profit || 0), 0),
          count: daySales.length,
          isToday: k === todayKey,
          isFuture: k > todayKey,
        });
      }
    } else {
      // Rolling 7 Days (past 6 days + today)
      for (let i = 6; i >= 0; i--) {
        const d = new Date();
        d.setDate(d.getDate() - i);
        const k = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(
          d.getDate()
        ).padStart(2, '0')}`;
        const dayName = d.toLocaleDateString('en-US', { weekday: 'short' });
        const monthDay = d.toLocaleDateString('en-US', { month: 'numeric', day: 'numeric' });
        const daySales = (db.sales || []).filter((s) => s.date === k);

        daysList.push({
          dateStr: k,
          dayLabel: `${dayName} ${monthDay}`,
          weekday: dayName,
          fullDateLabel: d.toLocaleDateString('en-US', {
            weekday: 'short',
            month: 'short',
            day: 'numeric',
            year: 'numeric',
          }),
          revenue: daySales.reduce((a, x) => a + (x.total || 0), 0),
          profit: daySales.reduce((a, x) => a + (x.profit || 0), 0),
          count: daySales.length,
          isToday: k === todayKey,
          isFuture: false,
        });
      }
    }

    // Comparison against previous 7-day window
    const firstDay = new Date(daysList[0].dateStr);
    const prevWindowStart = new Date(firstDay);
    prevWindowStart.setDate(firstDay.getDate() - 7);
    const prevWindowEnd = new Date(firstDay);
    prevWindowEnd.setDate(firstDay.getDate() - 1);

    const prevStartStr = prevWindowStart.toISOString().slice(0, 10);
    const prevEndStr = prevWindowEnd.toISOString().slice(0, 10);

    const prevTotal = (db.sales || [])
      .filter((s) => s.date >= prevStartStr && s.date <= prevEndStr)
      .reduce((a, x) => a + (x.total || 0), 0);

    const totalRevenue = daysList.reduce((a, x) => a + x.revenue, 0);
    const totalProfit = daysList.reduce((a, x) => a + x.profit, 0);
    const trend = prevTotal > 0 ? ((totalRevenue - prevTotal) / prevTotal) * 100 : 0;

    const validDays = daysList.filter((d) => !d.isFuture);
    const bestDay = [...validDays].sort((a, b) => b.revenue - a.revenue)[0];
    const activeDayCount = Math.max(1, validDays.length);

    return {
      chartDays: daysList,
      totalRevenue,
      totalProfit,
      trendPct: trend,
      bestDay,
      dailyAverage: totalRevenue / activeDayCount,
      maxRevenue: Math.max(1, ...daysList.map((d) => d.revenue)),
    };
  }, [db.sales, viewRange, todayKey]);

  return (
    <div className="space-y-4">
      {/* Metrics Header & Controls */}
      <div className="flex flex-wrap items-center justify-between gap-3 text-xs pb-1 border-b border-slate-100">
        <div>
          <div className="flex items-center gap-1.5">
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-wider block">
              {viewRange === 'current_week' ? 'Current Week Revenue' : '7-Day Rolling Revenue'}
            </span>
            <span className="inline-flex items-center gap-1 px-1.5 py-0.2 rounded-md bg-emerald-50 text-emerald-800 text-[10px] font-bold border border-emerald-200">
              <TrendingUp className="w-3 h-3 text-emerald-600" />
              Recharts Line
            </span>
          </div>
          <div className="flex items-baseline gap-2 mt-0.5">
            <span className="text-xl sm:text-2xl font-black text-slate-900 tracking-tight">
              {money(metrics.totalRevenue)}
            </span>
            <span className="text-[11px] text-slate-500 font-medium">
              Gross Profit: <strong className="text-emerald-700 font-bold">{money(metrics.totalProfit)}</strong>
            </span>
          </div>
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          {/* Daily Average */}
          <div className="text-right hidden sm:block px-2.5 py-1 rounded-xl bg-slate-50 border border-slate-200/70">
            <span className="text-[9px] text-slate-400 font-bold uppercase block">Daily Avg</span>
            <span className="text-xs font-black text-slate-800">
              {money(metrics.dailyAverage)}
            </span>
          </div>

          {/* Peak Day */}
          {metrics.bestDay && metrics.bestDay.revenue > 0 && (
            <div className="text-right hidden md:block px-2.5 py-1 rounded-xl bg-slate-50 border border-slate-200/70">
              <span className="text-[9px] text-slate-400 font-bold uppercase block">
                Peak ({metrics.bestDay.weekday})
              </span>
              <span className="text-xs font-black text-emerald-700">
                {money(metrics.bestDay.revenue)}
              </span>
            </div>
          )}

          {/* Trend Badge */}
          <div
            className={`flex items-center gap-1 px-2.5 py-1.5 rounded-xl text-xs font-black border ${
              metrics.trendPct >= 0
                ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                : 'bg-rose-50 text-rose-700 border-rose-200'
            }`}
            title="Revenue trend compared to the previous 7-day period"
          >
            {metrics.trendPct >= 0 ? (
              <ArrowUpRight className="w-3.5 h-3.5 text-emerald-600" />
            ) : (
              <ArrowDownRight className="w-3.5 h-3.5 text-rose-600" />
            )}
            <span>{Math.abs(metrics.trendPct).toFixed(0)}% vs prev week</span>
          </div>
        </div>
      </div>

      {/* Interactive Controls Bar */}
      <div className="flex items-center justify-between gap-2 flex-wrap text-xs">
        {/* View Range Toggle */}
        <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200">
          <button
            type="button"
            onClick={() => setViewRange('current_week')}
            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all ${
              viewRange === 'current_week'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Current Week (Mon–Sun)
          </button>
          <button
            type="button"
            onClick={() => setViewRange('rolling_7')}
            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] transition-all ${
              viewRange === 'rolling_7'
                ? 'bg-white text-emerald-800 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Rolling 7 Days
          </button>
        </div>

        {/* Chart View & Overlays */}
        <div className="flex items-center gap-2">
          <button
            type="button"
            onClick={() => setShowProfitLine((prev) => !prev)}
            className={`px-2.5 py-1 rounded-xl text-[11px] font-bold border transition-all flex items-center gap-1.5 ${
              showProfitLine
                ? 'bg-amber-50 text-amber-900 border-amber-300'
                : 'bg-slate-50 text-slate-500 border-slate-200'
            }`}
            title="Toggle Gross Profit overlay line"
          >
            <span
              className={`w-2 h-2 rounded-full ${
                showProfitLine ? 'bg-amber-500' : 'bg-slate-300'
              }`}
            />
            <span>Profit Line</span>
          </button>

          <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200">
            <button
              type="button"
              onClick={() => setChartType('line')}
              className={`p-1 rounded-lg text-xs font-bold transition-all ${
                chartType === 'line'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Recharts Line Chart View"
            >
              <LineChartIcon className="w-3.5 h-3.5" />
            </button>
            <button
              type="button"
              onClick={() => setChartType('bar')}
              className={`p-1 rounded-lg text-xs font-bold transition-all ${
                chartType === 'bar'
                  ? 'bg-white text-emerald-800 shadow-xs'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
              title="Bar Chart View"
            >
              <BarChart2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      </div>

      {/* Main Recharts Visualization Canvas */}
      {chartType === 'line' ? (
        <div className="w-full h-56 pt-2 select-none">
          <ResponsiveContainer width="100%" height="100%">
            <LineChart
              data={metrics.chartDays}
              margin={{ top: 10, right: 10, left: -10, bottom: 0 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="#f1f5f9" vertical={false} />
              <XAxis
                dataKey="dayLabel"
                tick={{ fontSize: 11, fill: '#64748b', fontWeight: 600 }}
                axisLine={{ stroke: '#e2e8f0' }}
                tickLine={false}
              />
              <YAxis
                tick={{ fontSize: 10, fill: '#64748b', fontWeight: 600 }}
                axisLine={false}
                tickLine={false}
                tickFormatter={(val: number) => {
                  if (val >= 1_000_000) return `${(val / 1_000_000).toFixed(1)}M`;
                  if (val >= 1_000) return `${(val / 1_000).toFixed(0)}k`;
                  return `${val}`;
                }}
              />
              <Tooltip content={<CustomRechartsTooltip />} />
              <Line
                type="monotone"
                dataKey="revenue"
                name="Daily Revenue"
                stroke="#059669"
                strokeWidth={3}
                dot={{
                  r: 4,
                  fill: '#059669',
                  stroke: '#ffffff',
                  strokeWidth: 2,
                }}
                activeDot={{
                  r: 7,
                  fill: '#10b981',
                  stroke: '#064e3b',
                  strokeWidth: 2.5,
                }}
              />
              {showProfitLine && (
                <Line
                  type="monotone"
                  dataKey="profit"
                  name="Gross Profit"
                  stroke="#f59e0b"
                  strokeWidth={2}
                  strokeDasharray="4 4"
                  dot={{
                    r: 3.5,
                    fill: '#f59e0b',
                    stroke: '#ffffff',
                    strokeWidth: 1.5,
                  }}
                  activeDot={{
                    r: 6,
                    fill: '#fbbf24',
                    stroke: '#78350f',
                    strokeWidth: 2,
                  }}
                />
              )}
            </LineChart>
          </ResponsiveContainer>
        </div>
      ) : (
        /* Alternative Bar Visualization */
        <div className="h-52 pt-6 pb-2 flex items-end justify-between gap-2 border-b border-slate-100">
          {metrics.chartDays.map((col) => {
            const heightPx = Math.max(8, (col.revenue / metrics.maxRevenue) * 140);
            return (
              <div key={col.dateStr} className="flex-1 flex flex-col items-center gap-1 group">
                <div className="text-[9px] text-slate-500 font-bold opacity-0 group-hover:opacity-100 transition-opacity whitespace-nowrap">
                  {col.revenue > 0 ? (col.revenue / 1000).toFixed(1) + 'k' : '0'}
                </div>
                <div
                  className={`w-full rounded-t-lg transition-all duration-300 ${
                    col.isToday
                      ? 'bg-gradient-to-t from-emerald-600 to-emerald-400 shadow-sm'
                      : col.isFuture
                      ? 'bg-slate-100 border border-dashed border-slate-300'
                      : 'bg-slate-200 group-hover:bg-emerald-300'
                  }`}
                  style={{ height: `${heightPx}px` }}
                />
                <span
                  className={`text-[10px] font-medium ${
                    col.isToday ? 'text-emerald-700 font-black' : 'text-slate-500'
                  }`}
                >
                  {col.weekday}
                </span>
              </div>
            );
          })}
        </div>
      )}

      {/* Legend & Details Footer */}
      <div className="flex items-center justify-between text-[11px] text-slate-500 pt-1 border-t border-slate-100 flex-wrap gap-2">
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-1.5">
            <span className="w-3 h-1 rounded-full bg-emerald-600" />
            <span className="font-bold text-slate-700">Daily Revenue (ETB)</span>
          </div>
          {showProfitLine && (
            <div className="flex items-center gap-1.5">
              <span className="w-3 h-1 rounded-full bg-amber-500 border-t border-dashed border-amber-600" />
              <span className="font-bold text-amber-700">Gross Profit (ETB)</span>
            </div>
          )}
        </div>
        <span className="text-[10px] text-slate-400">
          Hover data points for exact daily values & transaction count
        </span>
      </div>
    </div>
  );
};
