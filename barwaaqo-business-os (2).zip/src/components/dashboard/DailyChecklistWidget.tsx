import React from 'react';
import { useStore } from '../../context/StoreContext';
import { day } from '../../utils/helpers';
import { CheckCircle2 } from 'lucide-react';

export const DailyChecklistWidget: React.FC = () => {
  const { db, toggleCheck } = useStore();
  const todayKey = day();

  const checkLabels = [
    'Check and reconcile cash balance in drawer & bank accounts',
    'Review out-of-stock and low-stock product inventory',
    'Record all supplier deliveries and purchase invoices',
    'Follow up on outstanding customer credit & overdue debt',
    'Verify today’s gross and net profit margins vs targets',
    'Set restocking and distribution orders priority for tomorrow',
  ];

  const checksToday = db.checks?.[todayKey] || Array(6).fill(false);
  const completedCount = checksToday.filter(Boolean).length;
  const progressPct = Math.round((completedCount / checkLabels.length) * 100);

  return (
    <div className="space-y-3.5">
      {/* Progress Bar */}
      <div className="space-y-1.5">
        <div className="flex justify-between items-center text-xs">
          <span className="text-slate-600 font-bold">
            Completion: {completedCount} of {checkLabels.length} items verified
          </span>
          <span
            className={`font-black text-xs px-2 py-0.5 rounded-full ${
              progressPct === 100
                ? 'bg-emerald-100 text-emerald-800'
                : 'bg-slate-100 text-slate-700'
            }`}
          >
            {progressPct}% Done
          </span>
        </div>
        <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden border border-slate-200">
          <div
            className="h-full bg-emerald-600 rounded-full transition-all duration-300"
            style={{ width: `${progressPct}%` }}
          />
        </div>
      </div>

      {/* Checklist items */}
      <div className="divide-y divide-slate-100 border border-slate-100 rounded-2xl overflow-hidden bg-slate-50/50">
        {checkLabels.map((lbl, idx) => (
          <label
            key={idx}
            className="py-2.5 px-3 flex items-center gap-3 cursor-pointer hover:bg-white transition-colors select-none group"
          >
            <input
              type="checkbox"
              checked={checksToday[idx] || false}
              onChange={() => toggleCheck(idx)}
              className="w-4 h-4 rounded-md text-emerald-600 focus:ring-emerald-500 border-slate-300 transition"
            />
            <span
              className={`text-xs flex-1 transition ${
                checksToday[idx]
                  ? 'line-through text-slate-400 font-medium'
                  : 'text-slate-800 font-semibold group-hover:text-emerald-950'
              }`}
            >
              {lbl}
            </span>
          </label>
        ))}
      </div>
    </div>
  );
};
