import React, { useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { money, capitalData } from '../../utils/helpers';
import { Landmark, Plus } from 'lucide-react';

export const CapitalTrackingWidget: React.FC = () => {
  const { db, setIsCapitalModalOpen } = useStore();

  const cap = useMemo(() => capitalData(db), [db]);
  const capSpent = cap.t.capitalSpent;
  const capRemaining = cap.t.capitalRemaining;
  const capPct = Math.min(100, Math.max(0, (capSpent / db.capital) * 100));

  return (
    <div className="space-y-4">
      <div className="space-y-2">
        <div className="flex justify-between items-center text-xs">
          <span className="text-slate-600 font-medium">
            Founder Budget: <strong>{money(db.capital)}</strong> · Deployed:{' '}
            <b className="text-rose-600">{money(capSpent)}</b>
          </span>
          <span
            className={`font-black text-xs px-2 py-0.5 rounded-full ${
              capRemaining >= 0 ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-700'
            }`}
          >
            {capRemaining >= 0 ? `${money(capRemaining)} Remaining Buffer` : 'Budget Exceeded'}
          </span>
        </div>

        <div className="w-full h-3 bg-slate-100 rounded-full overflow-hidden p-0.5 border border-slate-200">
          <div
            className={`h-full rounded-full transition-all duration-500 ${
              capSpent > db.capital ? 'bg-rose-500' : 'bg-gradient-to-r from-emerald-500 to-teal-500'
            }`}
            style={{ width: `${capPct}%` }}
          />
        </div>
      </div>

      {/* Category breakdown chips */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 pt-1">
        {Object.entries(cap.by).map(([categoryName, catAmt]) => (
          <div
            key={categoryName}
            className="p-2.5 rounded-xl bg-slate-50 border border-slate-200/80 text-xs"
          >
            <span className="text-[10px] text-slate-400 font-semibold block uppercase truncate">
              {categoryName}
            </span>
            <span className="font-extrabold text-slate-800 mt-0.5 block">{money(catAmt as number)}</span>
          </div>
        ))}
        {Object.keys(cap.by).length === 0 && (
          <div className="col-span-2 sm:col-span-4 p-3 text-center text-xs text-slate-400">
            No founder capital expenditures logged. Click "Record Spending" to log store lease, renovation, and shelves.
          </div>
        )}
      </div>

      <div className="pt-2 flex justify-end">
        <button
          onClick={() => setIsCapitalModalOpen(true)}
          className="px-3.5 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-xs border border-emerald-300/60 transition-all flex items-center gap-1.5 active:scale-95 shadow-2xs"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Record Capital Spending</span>
        </button>
      </div>
    </div>
  );
};
