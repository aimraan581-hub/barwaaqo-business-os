import React from 'react';
import { useStore } from '../../context/StoreContext';
import { money } from '../../utils/helpers';
import { Wallet, Landmark, Smartphone, ArrowRight } from 'lucide-react';

export const LiquidityAccountsWidget: React.FC = () => {
  const { db, totals, setActiveTab } = useStore();
  const acc = db.accounts || { Cash: 0, Bank: 0, 'Mobile Money': 0 };

  const accountList = [
    {
      name: 'Cash Register (Till)',
      balance: acc.Cash || 0,
      icon: Wallet,
      color: 'bg-emerald-100 text-emerald-800',
      tag: 'Store Drawer & Petty Cash',
    },
    {
      name: 'Commercial Bank Account',
      balance: acc.Bank || 0,
      icon: Landmark,
      color: 'bg-blue-100 text-blue-800',
      tag: 'CBE / Awash Reserves',
    },
    {
      name: 'Telebirr Mobile Money',
      balance: acc['Mobile Money'] || 0,
      icon: Smartphone,
      color: 'bg-amber-100 text-amber-800',
      tag: 'Digital Mobile Pay',
    },
  ];

  return (
    <div className="space-y-3.5">
      <div className="flex items-center justify-between pb-2 border-b border-slate-100">
        <div>
          <span className="text-[10px] uppercase font-bold text-slate-400 block tracking-wider">
            Total Liquid Available
          </span>
          <span className="text-xl font-black text-emerald-800 tracking-tight">
            {money(totals.cash)}
          </span>
        </div>

        <button
          onClick={() => setActiveTab('finance')}
          className="flex items-center gap-1 text-xs font-bold text-emerald-700 hover:text-emerald-900 bg-emerald-50 hover:bg-emerald-100 px-3 py-1.5 rounded-xl transition active:scale-95"
        >
          <span>Vaults & Transfers</span>
          <ArrowRight className="w-3.5 h-3.5" />
        </button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
        {accountList.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.name}
              className="p-3 rounded-2xl bg-slate-50 border border-slate-200/80 flex items-center justify-between"
            >
              <div className="flex items-center gap-2.5">
                <div className={`p-2 rounded-xl ${item.color} shrink-0`}>
                  <Icon className="w-4 h-4" />
                </div>
                <div>
                  <span className="font-extrabold text-xs text-slate-800 block">
                    {item.name}
                  </span>
                  <span className="text-[10px] text-slate-400">{item.tag}</span>
                </div>
              </div>
              <span className="font-black text-xs sm:text-sm text-slate-900">
                {money(item.balance)}
              </span>
            </div>
          );
        })}
      </div>
    </div>
  );
};
