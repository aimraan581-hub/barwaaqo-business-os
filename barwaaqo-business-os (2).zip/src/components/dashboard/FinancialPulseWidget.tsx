import React, { useState, useEffect } from 'react';
import { useStore } from '../../context/StoreContext';
import { Sparkles, TrendingUp, RefreshCw, Copy, Check, ShieldCheck, AlertCircle, ArrowUpRight, DollarSign } from 'lucide-react';
import { money } from '../../utils/helpers';

interface PulseData {
  analysis: string;
  source: 'gemini' | 'engine';
  model?: string;
  cached?: boolean;
  timestamp: number;
}

const STORAGE_KEY = 'imruu_financial_pulse_cache_v2';

export const FinancialPulseWidget: React.FC = () => {
  const { db, totals } = useStore();
  const [pulseData, setPulseData] = useState<PulseData | null>(null);
  const [loading, setLoading] = useState(false);
  const [copied, setCopied] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as PulseData;
        setPulseData(parsed);
      }
    } catch {
      // ignore
    }
  }, []);

  const generatePulse = async (force = false) => {
    setLoading(true);
    setError(null);

    const summaryData = {
      totalRevenue: totals.rev,
      totalNetProfit: totals.net,
      capital: db.capital,
      inventoryValue: totals.stock,
      salesCount: db.sales.length,
      customerDebt: totals.debt,
      supplierPayables: totals.supplierDebt,
      cashOnHand: db.accounts.Cash || totals.cash,
      bankBalance: db.accounts.Bank || 0,
    };

    try {
      const res = await fetch('/api/financial-pulse', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ summaryData, forceRefresh: force }),
      });

      if (!res.ok) {
        const errorData = await res.json().catch(() => null);
        throw new Error(errorData?.error || 'Failed to synthesize financial pulse.');
      }

      const data = await res.json();
      const updated: PulseData = {
        analysis: data.analysis,
        source: data.source || 'gemini',
        model: data.model,
        cached: data.cached,
        timestamp: Date.now(),
      };

      setPulseData(updated);
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(updated));
      } catch {
        // ignore
      }
    } catch (err: any) {
      // If error occurs and we don't have cached data, synthesize a baseline pulse
      if (!pulseData) {
        const rev = totals.rev;
        const net = totals.net;
        const margin = rev > 0 ? ((net / rev) * 100).toFixed(1) : '0.0';
        const fallback: PulseData = {
          analysis: `Executive Financial Summary: Pacing at ETB ${rev.toLocaleString()} with net margin at ${margin}%. Working capital is actively monitored. Sustain standard operating collection pace to maximize treasury efficiency.`,
          source: 'engine',
          timestamp: Date.now(),
        };
        setPulseData(fallback);
      }
    } finally {
      setLoading(false);
    }
  };

  // Initial fetch on mount only if no cached pulse or if older than 30 minutes
  useEffect(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    if (!saved) {
      generatePulse(false);
    } else {
      try {
        const parsed = JSON.parse(saved) as PulseData;
        if (Date.now() - parsed.timestamp > 30 * 60 * 1000) {
          generatePulse(false);
        }
      } catch {
        generatePulse(false);
      }
    }
  }, []);

  const handleCopy = () => {
    if (!pulseData?.analysis) return;
    navigator.clipboard.writeText(pulseData.analysis);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  // Vitals calculations
  const netMargin = totals.rev > 0 ? ((totals.net / totals.rev) * 100).toFixed(1) : '0.0';
  const invRatio = db.capital > 0 ? Math.round((totals.stock / db.capital) * 100) : 0;
  const receivablesRatio = totals.rev > 0 ? Math.round((totals.debt / totals.rev) * 100) : 0;

  // Relative timestamp formatting
  const timeAgo = pulseData?.timestamp
    ? Math.max(1, Math.round((Date.now() - pulseData.timestamp) / 60000))
    : 0;

  return (
    <div className="p-4 sm:p-5 rounded-3xl bg-[#03170f] border border-emerald-900/60 shadow-lg text-slate-100 relative overflow-hidden">
      {/* Subtle ambient emerald background glow */}
      <div className="absolute top-0 right-0 -mt-8 -mr-8 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex items-center justify-between flex-wrap gap-2 mb-3.5 relative z-10">
        <div className="flex items-center gap-2.5">
          <div className="p-2 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-500/30">
            <Sparkles className="w-4 h-4 animate-pulse" />
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-extrabold text-sm text-white tracking-tight">
                AI Financial Pulse & CFO Briefing
              </h3>
              {pulseData?.source === 'gemini' ? (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black tracking-wider uppercase bg-emerald-500/20 text-emerald-300 border border-emerald-500/40">
                  <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping" />
                  {pulseData.model || 'Gemini 3.8 Flash'}
                </span>
              ) : pulseData?.source === 'engine' ? (
                <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-black tracking-wider uppercase bg-indigo-500/20 text-indigo-300 border border-indigo-500/40">
                  <ShieldCheck className="w-3 h-3 text-indigo-400" />
                  Enterprise Financial Engine
                </span>
              ) : null}

              {pulseData && (
                <span className="text-[11px] text-emerald-300/80 font-medium">
                  • {timeAgo <= 1 ? 'Just updated' : `${timeAgo}m ago`}
                </span>
              )}
            </div>
            <p className="text-xs text-emerald-200/90 font-medium mt-0.5">
              Autonomous ledger analytics, liquidity velocity, and strategic CEO directives
            </p>
          </div>
        </div>

        <div className="flex items-center gap-1.5">
          {pulseData && (
            <button
              onClick={handleCopy}
              className="p-2 rounded-xl bg-slate-800/80 hover:bg-slate-700 text-slate-300 hover:text-white border border-slate-700/60 transition-colors text-xs font-bold"
              title="Copy Briefing"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
            </button>
          )}

          <button
            onClick={() => generatePulse(true)}
            disabled={loading}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white text-xs font-bold transition-all shadow-sm active:scale-98"
          >
            <RefreshCw className={`w-3 h-3 ${loading ? 'animate-spin' : ''}`} />
            <span>{loading ? 'Synthesizing...' : 'Re-Analyze'}</span>
          </button>
        </div>
      </div>

      {/* Main Analysis Card */}
      <div className="relative z-10 bg-slate-900/95 rounded-2xl p-4 border border-emerald-800/40 shadow-inner">
        {loading && !pulseData ? (
          <div className="py-6 flex flex-col items-center justify-center gap-2 text-slate-300 text-xs font-medium">
            <Sparkles className="w-5 h-5 text-emerald-400 animate-spin" />
            <span>Consulting AI Financial Intelligence Engine...</span>
          </div>
        ) : error && !pulseData ? (
          <div className="py-4 flex items-center justify-center gap-2 text-rose-300 text-xs font-semibold">
            <AlertCircle className="w-4 h-4" />
            <span>{error}</span>
          </div>
        ) : pulseData ? (
          <div className="space-y-3">
            <div className="border-l-2 border-emerald-500 pl-3">
              <p className="text-xs sm:text-[13px] text-slate-100 leading-relaxed font-medium">
                {pulseData.analysis}
              </p>
            </div>

            {/* Financial Vital Gauges */}
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5 pt-2.5 border-t border-slate-800/90 text-xs">
              <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/80">
                <span className="text-[10.5px] font-bold text-slate-300 uppercase tracking-wider block">
                  NET PROFIT MARGIN
                </span>
                <div className="flex items-center justify-between mt-1">
                  <span className={`text-base font-black tabular-nums ${Number(netMargin) >= 15 ? 'text-emerald-400' : 'text-amber-400'}`}>
                    {netMargin}%
                  </span>
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-700 text-slate-200">
                    {Number(netMargin) >= 15 ? 'Strong' : 'Moderate'}
                  </span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/80">
                <span className="text-[10.5px] font-bold text-slate-300 uppercase tracking-wider block">
                  INVENTORY ALLOCATION
                </span>
                <div className="flex items-center justify-between mt-1">
                  <span className={`text-base font-black tabular-nums ${invRatio > 60 ? 'text-amber-400' : 'text-emerald-400'}`}>
                    {invRatio}%
                  </span>
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-700 text-slate-200 tabular-nums">
                    {money(totals.stock)}
                  </span>
                </div>
              </div>

              <div className="p-2.5 rounded-xl bg-slate-800/80 border border-slate-700/80">
                <span className="text-[10.5px] font-bold text-slate-300 uppercase tracking-wider block">
                  RECEIVABLES EXPOSURE
                </span>
                <div className="flex items-center justify-between mt-1">
                  <span className={`text-base font-black tabular-nums ${receivablesRatio > 25 ? 'text-rose-400' : 'text-slate-100'}`}>
                    {receivablesRatio}%
                  </span>
                  <span className="text-[10px] font-bold px-1.5 py-0.5 rounded bg-slate-700 text-slate-200 tabular-nums">
                    {money(totals.debt)} due
                  </span>
                </div>
              </div>
            </div>

            {/* Strategic CEO Directives */}
            <div className="pt-2 text-xs text-slate-300 space-y-1">
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-400 block">
                ⚡ Executive Priority Directives:
              </span>
              <ul className="list-disc list-inside space-y-0.5 text-slate-200 font-medium">
                {Number(netMargin) < 15 ? (
                  <li>Audit category discount thresholds to preserve gross margin margins above 15%.</li>
                ) : (
                  <li>Sustain current price elasticity while scaling wholesale B2B distribution volumes.</li>
                )}
                {invRatio > 50 ? (
                  <li>Initiate fast-mover promotions on overstocked units to accelerate cash liquidation.</li>
                ) : (
                  <li>Working capital is balanced; replenish fast-moving staples before lead-time cutoffs.</li>
                )}
                {totals.debt > 5000 && (
                  <li>Follow up with commercial accounts on overdue invoices to maintain liquidity headroom.</li>
                )}
              </ul>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
};
