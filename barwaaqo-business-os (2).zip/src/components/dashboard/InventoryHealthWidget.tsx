import React, { useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { money, getDynamicSafetyStockAlerts } from '../../utils/helpers';
import { Package, AlertCircle, CheckCircle2, ChevronRight, ShoppingCart, Zap } from 'lucide-react';

export const InventoryHealthWidget: React.FC = () => {
  const { db, totals, setActiveTab } = useStore();

  const safetyAlerts = useMemo(() => {
    return getDynamicSafetyStockAlerts(db);
  }, [db.products, db.sales]);

  const { outOfStockItems, retailValuation } = useMemo(() => {
    const out = (db.products || []).filter((p) => p.stock <= 0);
    const retail = (db.products || []).reduce((a, p) => a + (p.stock || 0) * (p.sell || 0), 0);
    return { outOfStockItems: out, retailValuation: retail };
  }, [db.products]);

  const potentialGross = retailValuation - totals.stock;

  return (
    <div className="space-y-4">
      {/* Top Value Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <div className="p-3 bg-slate-50/90 rounded-2xl border border-slate-200/80">
          <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block">
            STOCK VALUE (COST)
          </span>
          <span className="text-base sm:text-lg font-black text-amber-700 tracking-tight block mt-1">
            {money(totals.stock)}
          </span>
          <span className="text-[10px] text-slate-500">{db.products.length} Active SKUs</span>
        </div>

        <div className="p-3 bg-slate-50/90 rounded-2xl border border-slate-200/80">
          <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block">
            RETAIL VALUE (YIELD)
          </span>
          <span className="text-base sm:text-lg font-black text-emerald-700 tracking-tight block mt-1">
            {money(retailValuation)}
          </span>
          <span className="text-[10px] text-emerald-600 font-bold">
            +{money(potentialGross)} Unlocked Profit
          </span>
        </div>

        <div
          onClick={() => setActiveTab('inventory')}
          className="col-span-2 sm:col-span-1 p-3 bg-slate-50/90 hover:bg-slate-100/80 cursor-pointer rounded-2xl border border-slate-200/80 transition"
        >
          <span className="text-[10px] font-extrabold text-slate-400 uppercase tracking-wider block">
            SAFETY STOCK STATUS
          </span>
          <div className="flex items-center gap-2 mt-1">
            {outOfStockItems.length > 0 ? (
              <span className="text-base sm:text-lg font-black text-rose-600">
                {outOfStockItems.length} OUT OF STOCK
              </span>
            ) : safetyAlerts.totalBelowSafety > 0 ? (
              <span className="text-base sm:text-lg font-black text-amber-600 flex items-center gap-1">
                <Zap className="w-4 h-4 fill-current text-amber-500" />
                {safetyAlerts.totalBelowSafety} AT RISK
              </span>
            ) : (
              <span className="text-base sm:text-lg font-black text-emerald-700 flex items-center gap-1">
                <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                OPTIMAL
              </span>
            )}
          </div>
          <span className="text-[10px] text-slate-500">
            {safetyAlerts.velocityTriggeredCount > 0
              ? `${safetyAlerts.velocityTriggeredCount} high sales velocity lines`
              : 'Tap to inspect inventory'}
          </span>
        </div>
      </div>

      {/* Safety stock alert items list preview */}
      {safetyAlerts.alerts.length > 0 ? (
        <div className="space-y-1.5 pt-1">
          <div className="flex items-center justify-between text-xs text-slate-600 font-bold px-1">
            <span className="text-amber-700 flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 fill-current text-amber-500" />
              Dynamic Velocity & Safety Stock Alerts ({safetyAlerts.totalBelowSafety})
            </span>
            <button
              onClick={() => setActiveTab('purchases')}
              className="text-emerald-700 hover:text-emerald-900 text-[11px] font-black"
            >
              Order from Vendors →
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {safetyAlerts.alerts.slice(0, 4).map(({ product: p, metrics: m }) => (
              <div
                key={p.id}
                className={`p-2.5 rounded-xl border flex items-center justify-between text-xs ${
                  p.stock <= 0
                    ? 'bg-rose-50/70 border-rose-200/80'
                    : m.isVelocityTriggered
                    ? 'bg-amber-50/80 border-amber-300/80'
                    : 'bg-amber-50/50 border-amber-200/70'
                }`}
              >
                <div className="min-w-0 pr-2">
                  <div className="font-extrabold text-slate-900 truncate flex items-center gap-1">
                    {p.name}
                    {m.isVelocityTriggered && (
                      <span className="text-[8px] font-black uppercase px-1 py-0.2 rounded bg-amber-400 text-slate-950 shrink-0">
                        VELOCITY
                      </span>
                    )}
                  </div>
                  <div className="text-[10px] text-amber-900">
                    Stock: <strong>{p.stock}</strong> {p.unit} · Safety: <strong>{m.dynamicSafetyThreshold}</strong> (
                    {m.recentSalesVelocity}/day)
                  </div>
                </div>
                <button
                  onClick={() => setActiveTab('purchases')}
                  className="px-2 py-1 rounded-lg bg-white border border-amber-300 text-amber-900 text-[10px] font-extrabold hover:bg-amber-100 transition shrink-0"
                >
                  Restock
                </button>
              </div>
            ))}
          </div>
        </div>
      ) : (
        <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 text-emerald-900 text-xs flex items-center justify-between">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
            <span>Warehouse stock is healthy. All catalog lines are above dynamic safety thresholds.</span>
          </div>
          <button
            onClick={() => setActiveTab('inventory')}
            className="text-emerald-800 font-extrabold hover:underline text-[11px]"
          >
            Audit Catalog
          </button>
        </div>
      )}
    </div>
  );
};
