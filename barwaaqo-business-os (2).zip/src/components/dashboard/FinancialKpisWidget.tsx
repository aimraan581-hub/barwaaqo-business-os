import React, { useMemo } from 'react';
import { useStore } from '../../context/StoreContext';
import { money, day } from '../../utils/helpers';
import { DollarSign, ArrowUpRight, TrendingUp, Users, Factory } from 'lucide-react';

export const FinancialKpisWidget: React.FC = () => {
  const { db, totals, setActiveTab } = useStore();
  const todayKey = day();

  const salesToday = useMemo(() => {
    return (db.sales || []).filter((s) => s.date === todayKey);
  }, [db.sales, todayKey]);

  const salesTodayTotal = salesToday.reduce((a, s) => a + (s.total || 0), 0);
  const grossToday = salesToday.reduce((a, s) => a + (s.profit || 0), 0);
  const expensesToday = (db.expenses || [])
    .filter((e) => e.date === todayKey)
    .reduce((a, e) => a + (e.amount || 0), 0);
  const netProfitToday = grossToday - expensesToday;
  const avgSaleToday = salesToday.length > 0 ? salesTodayTotal / salesToday.length : 0;
  const marginPct = salesTodayTotal > 0 ? (grossToday / salesTodayTotal) * 100 : 0;

  return (
    <div className="space-y-3.5">
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {/* Sales Today */}
        <div className="p-4 bg-slate-50/90 rounded-2xl border border-slate-200/90 hover:border-slate-300 transition-all shadow-2xs">
          <span className="text-[11px] font-black text-slate-600 uppercase tracking-wider block">
            SALES TODAY
          </span>
          <span className="text-lg sm:text-xl font-black text-blue-800 tracking-tight block mt-1.5 tabular-nums">
            {money(salesTodayTotal)}
          </span>
          <div className="flex items-center justify-between text-xs text-slate-600 mt-1.5 font-medium">
            <span>{salesToday.length} invoices</span>
            <span className="font-semibold text-slate-700">Avg {money(avgSaleToday)}</span>
          </div>
        </div>

        {/* Net Profit Today */}
        <div className="p-4 bg-slate-50/90 rounded-2xl border border-slate-200/90 hover:border-slate-300 transition-all shadow-2xs">
          <span className="text-[11px] font-black text-slate-600 uppercase tracking-wider block">
            NET PROFIT TODAY
          </span>
          <span
            className={`text-lg sm:text-xl font-black tracking-tight block mt-1.5 tabular-nums ${
              netProfitToday >= 0 ? 'text-emerald-800' : 'text-rose-700'
            }`}
          >
            {money(netProfitToday)}
          </span>
          <div className="flex items-center justify-between text-xs text-slate-600 mt-1.5 font-medium">
            <span>Gross: {money(grossToday)}</span>
            <span className="font-bold text-emerald-700">{marginPct.toFixed(0)}% margin</span>
          </div>
        </div>

        {/* Customer Receivables */}
        <div
          onClick={() => setActiveTab('customers')}
          className="p-4 bg-slate-50/90 hover:bg-rose-50/60 cursor-pointer rounded-2xl border border-slate-200/90 hover:border-rose-300/80 transition-all shadow-2xs group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black text-slate-600 uppercase tracking-wider block">
              RECEIVABLES (DEBT)
            </span>
            <Users className="w-4 h-4 text-slate-500 group-hover:text-rose-700 transition" />
          </div>
          <span
            className={`text-lg sm:text-xl font-black tracking-tight block mt-1.5 tabular-nums ${
              totals.debt > 0 ? 'text-rose-700' : 'text-slate-900'
            }`}
          >
            {money(totals.debt)}
          </span>
          <span className="text-xs text-slate-600 mt-1.5 font-medium block">
            {db.customers.filter((c) => (c.credit || 0) > 0).length} debtors owe store
          </span>
        </div>

        {/* Supplier Payables */}
        <div
          onClick={() => setActiveTab('purchases')}
          className="p-4 bg-slate-50/90 hover:bg-amber-50/60 cursor-pointer rounded-2xl border border-slate-200/90 hover:border-amber-300/80 transition-all shadow-2xs group"
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black text-slate-600 uppercase tracking-wider block">
              PAYABLES (SUPPLIERS)
            </span>
            <Factory className="w-4 h-4 text-slate-500 group-hover:text-amber-700 transition" />
          </div>
          <span
            className={`text-lg sm:text-xl font-black tracking-tight block mt-1.5 tabular-nums ${
              totals.supplierDebt > 0 ? 'text-amber-800' : 'text-slate-900'
            }`}
          >
            {money(totals.supplierDebt)}
          </span>
          <span className="text-xs text-slate-600 mt-1.5 font-medium block">Vendor credit balances</span>
        </div>
      </div>
    </div>
  );
};
