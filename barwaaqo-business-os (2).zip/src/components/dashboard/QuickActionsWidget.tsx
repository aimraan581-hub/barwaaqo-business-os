import React from 'react';
import { useStore } from '../../context/StoreContext';
import { Receipt, Package, Factory, Users, ChevronRight, Wallet } from 'lucide-react';

export const QuickActionsWidget: React.FC = () => {
  const { setActiveTab, db } = useStore();

  const actions = [
    {
      id: 'pos',
      title: 'New POS Sale',
      desc: 'Cashier checkout terminal',
      icon: Receipt,
      color: 'bg-emerald-100/80 text-emerald-800 group-hover:bg-emerald-600 group-hover:text-white',
      badge: 'Counter',
      tab: 'pos' as const,
    },
    {
      id: 'inventory',
      title: 'Manage Stock',
      desc: `${db.products.length} Products in catalog`,
      icon: Package,
      color: 'bg-blue-100/80 text-blue-800 group-hover:bg-blue-600 group-hover:text-white',
      badge: 'Warehouse',
      tab: 'inventory' as const,
    },
    {
      id: 'purchases',
      title: 'Buy Stock',
      desc: 'Vendor purchase orders',
      icon: Factory,
      color: 'bg-amber-100/80 text-amber-800 group-hover:bg-amber-600 group-hover:text-white',
      badge: 'Supply',
      tab: 'purchases' as const,
    },
    {
      id: 'customers',
      title: 'Customer Accounts',
      desc: `${db.customers.length} Client debt files`,
      icon: Users,
      color: 'bg-purple-100/80 text-purple-800 group-hover:bg-purple-600 group-hover:text-white',
      badge: 'Credit',
      tab: 'customers' as const,
    },
  ];

  return (
    <div className="grid grid-cols-2 sm:grid-cols-4 gap-2.5">
      {actions.map((act) => {
        const Icon = act.icon;
        return (
          <button
            key={act.id}
            id={`btn-quick-${act.id}`}
            onClick={() => setActiveTab(act.tab)}
            className="p-3.5 rounded-2xl bg-white hover:bg-emerald-50/40 border border-slate-200 shadow-2xs hover:border-emerald-400 hover:shadow-xs transition-all text-left group active:scale-98"
          >
            <div className="flex items-center justify-between mb-2">
              <div className={`p-2 rounded-xl transition-colors ${act.color}`}>
                <Icon className="w-4 h-4" />
              </div>
              <ChevronRight className="w-4 h-4 text-slate-400 group-hover:text-emerald-700 group-hover:translate-x-0.5 transition-all" />
            </div>
            <div className="font-extrabold text-sm text-slate-900 tracking-tight">{act.title}</div>
            <div className="text-xs text-slate-600 font-medium mt-0.5">{act.desc}</div>
          </button>
        );
      })}
    </div>
  );
};
