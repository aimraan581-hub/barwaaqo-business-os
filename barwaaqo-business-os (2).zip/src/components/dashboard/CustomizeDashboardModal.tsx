import React, { useState } from 'react';
import {
  X,
  Pin,
  PinOff,
  Eye,
  EyeOff,
  ChevronUp,
  ChevronDown,
  RotateCcw,
  Sliders,
  Sparkles,
  Check,
  Building2,
} from 'lucide-react';
import { DashboardWidgetConfig, DashboardWidgetId } from '../../types';

interface CustomizeDashboardModalProps {
  isOpen: boolean;
  onClose: () => void;
  widgets: DashboardWidgetConfig[];
  onTogglePin: (id: DashboardWidgetId) => void;
  onToggleVisibility: (id: DashboardWidgetId) => void;
  onMoveUp: (id: DashboardWidgetId) => void;
  onMoveDown: (id: DashboardWidgetId) => void;
  onResetLayout: () => void;
}

export const CustomizeDashboardModal: React.FC<CustomizeDashboardModalProps> = ({
  isOpen,
  onClose,
  widgets,
  onTogglePin,
  onToggleVisibility,
  onMoveUp,
  onMoveDown,
  onResetLayout,
}) => {
  const [activeFilter, setActiveFilter] = useState<'all' | 'financial' | 'inventory' | 'operations' | 'strategy'>('all');

  if (!isOpen) return null;

  const filteredWidgets = widgets.filter((w) => {
    if (activeFilter === 'all') return true;
    return w.category === activeFilter;
  });

  const pinnedCount = widgets.filter((w) => w.isPinned).length;
  const visibleCount = widgets.filter((w) => w.isVisible).length;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-slate-950/75 backdrop-blur-sm animate-in fade-in">
      <div className="relative w-full max-w-xl max-h-[90vh] bg-white rounded-3xl shadow-2xl border border-slate-200 overflow-hidden flex flex-col">
        {/* Header */}
        <div className="p-4 sm:p-5 border-b border-slate-100 flex items-center justify-between bg-gradient-to-r from-emerald-950 via-slate-900 to-slate-950 text-white">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-500 text-slate-950 shadow-xs">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <h2 className="font-extrabold text-base sm:text-lg tracking-tight text-white flex items-center gap-2">
                Customize CEO Dashboard
              </h2>
              <p className="text-xs text-emerald-200/80 mt-0.5">
                Pin priority charts to the top, reorder cards, or hide modules.
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Filter bar & Stats */}
        <div className="px-4 py-3 bg-slate-50 border-b border-slate-100 flex items-center justify-between gap-2 flex-wrap text-xs">
          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {(['all', 'financial', 'inventory', 'operations', 'strategy'] as const).map((filter) => (
              <button
                key={filter}
                onClick={() => setActiveFilter(filter)}
                className={`px-2.5 py-1 rounded-lg font-bold capitalize transition ${
                  activeFilter === filter
                    ? 'bg-emerald-700 text-white shadow-2xs'
                    : 'bg-white text-slate-600 hover:bg-slate-200 border border-slate-200'
                }`}
              >
                {filter}
              </button>
            ))}
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-500 font-semibold">
            <span>
              Pinned: <strong className="text-emerald-700">{pinnedCount}</strong>
            </span>
            <span>·</span>
            <span>
              Visible: <strong className="text-slate-800">{visibleCount}/{widgets.length}</strong>
            </span>
          </div>
        </div>

        {/* Widget List */}
        <div className="p-4 sm:p-5 overflow-y-auto flex-1 space-y-2.5 divide-y divide-slate-100">
          {filteredWidgets.map((w, idx) => {
            const isFirst = idx === 0;
            const isLast = idx === filteredWidgets.length - 1;

            return (
              <div
                key={w.id}
                className={`pt-2.5 first:pt-0 flex items-center justify-between gap-2.5 p-3 rounded-2xl transition ${
                  w.isPinned
                    ? 'bg-emerald-50/60 border border-emerald-300/80 shadow-2xs'
                    : !w.isVisible
                    ? 'bg-slate-50 opacity-60'
                    : 'bg-white border border-slate-200/80 hover:border-slate-300'
                }`}
              >
                {/* Info */}
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-sm text-slate-900 truncate">
                      {w.title}
                    </span>
                    {w.isPinned && (
                      <span className="flex items-center gap-0.5 px-2 py-0.5 rounded-full bg-emerald-600 text-white text-[10px] font-black uppercase tracking-wider shrink-0">
                        <Pin className="w-2.5 h-2.5" />
                        Pinned
                      </span>
                    )}
                    <span className="text-[10px] font-bold uppercase text-slate-400 px-1.5 py-0.2 rounded border border-slate-200 shrink-0 hidden sm:inline-block">
                      {w.category}
                    </span>
                  </div>
                  <p className="text-xs text-slate-500 truncate mt-0.5">{w.subtitle}</p>
                </div>

                {/* Controls */}
                <div className="flex items-center gap-1.5 shrink-0">
                  {/* Move buttons */}
                  <div className="flex items-center bg-slate-100 rounded-xl p-0.5 border border-slate-200">
                    <button
                      onClick={() => onMoveUp(w.id)}
                      disabled={isFirst}
                      title="Move Up"
                      className={`p-1.5 rounded-lg transition ${
                        !isFirst
                          ? 'text-slate-700 hover:text-black hover:bg-white active:scale-95'
                          : 'text-slate-300 cursor-not-allowed'
                      }`}
                    >
                      <ChevronUp className="w-4 h-4" />
                    </button>
                    <button
                      onClick={() => onMoveDown(w.id)}
                      disabled={isLast}
                      title="Move Down"
                      className={`p-1.5 rounded-lg transition ${
                        !isLast
                          ? 'text-slate-700 hover:text-black hover:bg-white active:scale-95'
                          : 'text-slate-300 cursor-not-allowed'
                      }`}
                    >
                      <ChevronDown className="w-4 h-4" />
                    </button>
                  </div>

                  {/* Pin Toggle */}
                  <button
                    onClick={() => onTogglePin(w.id)}
                    title={w.isPinned ? 'Unpin card' : 'Pin card to top'}
                    className={`p-2 rounded-xl border transition-all active:scale-95 ${
                      w.isPinned
                        ? 'bg-emerald-600 text-white border-emerald-600 shadow-2xs'
                        : 'bg-slate-100 hover:bg-emerald-50 text-slate-600 hover:text-emerald-800 border-slate-200'
                    }`}
                  >
                    {w.isPinned ? <PinOff className="w-4 h-4" /> : <Pin className="w-4 h-4" />}
                  </button>

                  {/* Visibility Toggle */}
                  <button
                    onClick={() => onToggleVisibility(w.id)}
                    title={w.isVisible ? 'Hide widget' : 'Show widget'}
                    className={`p-2 rounded-xl border transition-all active:scale-95 ${
                      w.isVisible
                        ? 'bg-slate-100 hover:bg-slate-200 text-slate-700 border-slate-200'
                        : 'bg-rose-50 text-rose-700 border-rose-200'
                    }`}
                  >
                    {w.isVisible ? <Eye className="w-4 h-4" /> : <EyeOff className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-slate-100 bg-slate-50 flex items-center justify-between gap-3">
          <button
            onClick={onResetLayout}
            className="flex items-center gap-1.5 px-3 py-2 rounded-xl text-xs font-bold text-slate-600 hover:text-slate-900 hover:bg-slate-200 border border-slate-300/80 transition active:scale-95"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset to Default Layout</span>
          </button>

          <button
            onClick={onClose}
            className="flex items-center gap-1.5 px-5 py-2 rounded-xl text-xs font-black bg-emerald-700 hover:bg-emerald-800 text-white shadow-xs transition active:scale-95"
          >
            <Check className="w-4 h-4" />
            <span>Done Customizing</span>
          </button>
        </div>
      </div>
    </div>
  );
};
