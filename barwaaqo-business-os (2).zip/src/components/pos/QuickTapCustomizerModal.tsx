import React, { useState } from 'react';
import { Product } from '../../types';
import { money } from '../../utils/helpers';
import { X, Search, Check, Plus, Trash2, RotateCcw, Zap, Sparkles, Sliders } from 'lucide-react';

interface QuickTapCustomizerModalProps {
  isOpen: boolean;
  onClose: () => void;
  products: Product[];
  selectedProductIds: string[];
  onSave: (ids: string[], directAdd: boolean) => void;
  directAddToCart: boolean;
}

export const QuickTapCustomizerModal: React.FC<QuickTapCustomizerModalProps> = ({
  isOpen,
  onClose,
  products,
  selectedProductIds,
  onSave,
  directAddToCart,
}) => {
  const [selectedIds, setSelectedIds] = useState<string[]>(selectedProductIds);
  const [directAdd, setDirectAdd] = useState<boolean>(directAddToCart);
  const [searchQuery, setSearchQuery] = useState<string>('');

  if (!isOpen) return null;

  const handleToggleProduct = (pid: string) => {
    if (selectedIds.includes(pid)) {
      setSelectedIds(selectedIds.filter((id) => id !== pid));
    } else {
      if (selectedIds.length >= 12) {
        alert('You can choose up to 12 Quick-Tap products for the cashier bar.');
        return;
      }
      setSelectedIds([...selectedIds, pid]);
    }
  };

  const handleRemove = (pid: string) => {
    setSelectedIds(selectedIds.filter((id) => id !== pid));
  };

  const handleResetDefaults = () => {
    // Pick the top 8 in-stock items
    const defaults = products.slice(0, 8).map((p) => p.id);
    setSelectedIds(defaults);
    setDirectAdd(true);
  };

  const handleSaveAndClose = () => {
    onSave(selectedIds, directAdd);
    onClose();
  };

  const filteredProducts = products.filter(
    (p) =>
      p.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (p.sku && p.sku.toLowerCase().includes(searchQuery.toLowerCase())) ||
      (p.category && p.category.toLowerCase().includes(searchQuery.toLowerCase()))
  );

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl w-full max-w-xl shadow-2xl overflow-hidden border border-slate-200 flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-950 via-slate-900 to-emerald-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30">
              <Sliders className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base tracking-tight text-white">
                  Customize POS Quick-Tap Buttons
                </h3>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-400 text-amber-950">
                  {selectedIds.length} Pinned
                </span>
              </div>
              <p className="text-xs text-emerald-200/80 mt-0.5">
                Pin high-velocity grocery items for 1-tap checkout & keyboard numpad keys (1–9)
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Behavior Setting Bar */}
        <div className="px-5 py-3 bg-slate-50 border-b border-slate-200 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-amber-600" />
            <span className="text-xs font-bold text-slate-800">
              Instant 1-Tap Cart Addition
            </span>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={directAdd}
              onChange={(e) => setDirectAdd(e.target.checked)}
              className="sr-only peer"
            />
            <div className="w-9 h-5 bg-slate-300 peer-focus:outline-hidden rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-slate-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-600"></div>
          </label>
        </div>

        {/* Current Pinned Items Bar */}
        <div className="p-4 sm:p-5 border-b border-slate-200 bg-emerald-50/40 shrink-0">
          <div className="flex items-center justify-between mb-2">
            <span className="text-[11px] font-black uppercase tracking-wider text-emerald-950">
              Active Quick-Tap Shelf (Assigned to Keys 1–{Math.min(9, selectedIds.length)})
            </span>
            <button
              onClick={handleResetDefaults}
              className="text-[10px] text-emerald-800 hover:text-emerald-950 font-bold flex items-center gap-1 underline"
            >
              <RotateCcw className="w-3 h-3" />
              <span>Reset to Top Staples</span>
            </button>
          </div>

          {selectedIds.length === 0 ? (
            <div className="text-center py-3 text-xs text-slate-500 bg-white rounded-xl border border-dashed border-slate-300">
              No items pinned yet. Select items from the list below.
            </div>
          ) : (
            <div className="flex flex-wrap gap-1.5 max-h-24 overflow-y-auto">
              {selectedIds.map((id, index) => {
                const prod = products.find((p) => p.id === id);
                if (!prod) return null;
                return (
                  <div
                    key={id}
                    className="flex items-center gap-1.5 px-2.5 py-1 rounded-xl bg-white border border-emerald-300 text-xs font-bold text-slate-900 shadow-xs"
                  >
                    {index < 9 && (
                      <span className="w-4 h-4 rounded-md bg-slate-900 text-amber-300 font-mono text-[10px] flex items-center justify-center font-black">
                        {index + 1}
                      </span>
                    )}
                    <span className="truncate max-w-[110px]">{prod.name}</span>
                    <button
                      onClick={() => handleRemove(id)}
                      className="text-slate-400 hover:text-rose-600 ml-0.5 p-0.5 rounded"
                      title="Remove from quick tap"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Product Search & Picker */}
        <div className="p-4 sm:p-5 flex-1 overflow-y-auto space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search product by name, category, or SKU..."
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:outline-hidden focus:ring-2 focus:ring-emerald-500"
            />
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
            {filteredProducts.map((p) => {
              const isSelected = selectedIds.includes(p.id);
              return (
                <div
                  key={p.id}
                  onClick={() => handleToggleProduct(p.id)}
                  className={`p-2.5 rounded-xl border text-xs cursor-pointer transition-all flex items-center justify-between gap-2 ${
                    isSelected
                      ? 'bg-emerald-50 border-emerald-500 text-emerald-950 font-bold shadow-xs ring-1 ring-emerald-500/30'
                      : 'bg-white border-slate-200 hover:border-slate-300 text-slate-800'
                  }`}
                >
                  <div className="min-w-0 flex-1">
                    <div className="font-extrabold truncate">{p.name}</div>
                    <div className="text-[10px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                      <span>Retail: {money(p.sell)}</span>
                      <span>·</span>
                      <span className={p.stock <= 0 ? 'text-rose-600 font-bold' : ''}>
                        {p.stock} {p.unit}
                      </span>
                    </div>
                  </div>

                  <div
                    className={`w-6 h-6 rounded-lg flex items-center justify-center shrink-0 text-xs font-black transition-colors ${
                      isSelected
                        ? 'bg-emerald-600 text-white'
                        : 'bg-slate-100 text-slate-400 border border-slate-300'
                    }`}
                  >
                    {isSelected ? <Check className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between shrink-0">
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 transition"
          >
            Cancel
          </button>
          <button
            onClick={handleSaveAndClose}
            className="px-5 py-2.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-black shadow-md transition active:scale-95 flex items-center gap-2"
          >
            <Check className="w-4 h-4" />
            <span>Save Quick Keys ({selectedIds.length})</span>
          </button>
        </div>
      </div>
    </div>
  );
};
