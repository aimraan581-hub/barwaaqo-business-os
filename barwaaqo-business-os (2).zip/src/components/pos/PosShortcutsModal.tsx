import React from 'react';
import { X, Keyboard, Zap, ShoppingCart, CheckCircle, ArrowRight, CornerDownLeft } from 'lucide-react';

interface PosShortcutsModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PosShortcutsModal: React.FC<PosShortcutsModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  const shortcuts = [
    {
      key: '1 – 9',
      altKey: 'Alt + 1–9',
      description: 'Quick-Add common item #1 through #9 directly to the cart',
      category: 'Fast Item Entry',
      icon: Zap,
    },
    {
      key: 'F9 / Ctrl + ↵',
      altKey: 'Ctrl + Enter',
      description: 'Instantly finalize & complete checkout for current cart',
      category: 'Checkout',
      icon: CheckCircle,
    },
    {
      key: 'F8 / Alt + W',
      altKey: 'Alt + W',
      description: 'Toggle between Retail and Wholesale pricing modes',
      category: 'Pricing Mode',
      icon: ShoppingCart,
    },
    {
      key: 'F10 / Alt + P',
      altKey: 'Alt + P',
      description: 'Cycle payment channel (Cash → Bank → Mobile Money → Credit)',
      category: 'Payment',
      icon: CornerDownLeft,
    },
    {
      key: 'F2 / Ctrl + K',
      altKey: 'Ctrl + K',
      description: 'Jump focus to product search & inventory picker',
      category: 'Navigation',
      icon: Keyboard,
    },
    {
      key: 'F4 / Alt + C',
      altKey: 'Alt + C',
      description: 'Clear all items from active cart',
      category: 'Cart Action',
      icon: X,
    },
    {
      key: '?',
      altKey: 'Shift + /',
      description: 'Open this cashier speed shortcuts guide',
      category: 'Help',
      icon: Keyboard,
    },
    {
      key: 'Esc',
      altKey: 'Escape',
      description: 'Close active modals or clear product selection',
      category: 'General',
      icon: X,
    },
  ];

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 animate-in fade-in duration-150">
      <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-200">
        {/* Header */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 text-white flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-400/20 text-amber-400 border border-amber-400/30">
              <Keyboard className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-base tracking-tight text-white">
                  Cashier Keyboard Shortcuts
                </h3>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-500 text-slate-950">
                  SPEED POS
                </span>
              </div>
              <p className="text-xs text-emerald-200/80 mt-0.5">
                Accelerate customer checkout with physical keyboard & numpad keys
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-xl text-slate-400 hover:text-white hover:bg-white/10 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Shortcuts List */}
        <div className="p-4 sm:p-5 max-h-[65vh] overflow-y-auto space-y-2.5">
          <div className="p-3 bg-emerald-50 rounded-2xl border border-emerald-200/60 text-emerald-950 text-xs flex items-start gap-2.5">
            <Zap className="w-4 h-4 text-emerald-700 shrink-0 mt-0.5" />
            <span>
              <strong>Pro Cashier Tip:</strong> When ringing up customers, press numbers{' '}
              <kbd className="px-1.5 py-0.5 rounded bg-white font-mono font-bold text-slate-800 border border-slate-300 shadow-xs">
                1
              </kbd>{' '}
              to{' '}
              <kbd className="px-1.5 py-0.5 rounded bg-white font-mono font-bold text-slate-800 border border-slate-300 shadow-xs">
                9
              </kbd>{' '}
              on your keyboard or numpad to instantly add common goods, then hit{' '}
              <kbd className="px-1.5 py-0.5 rounded bg-white font-mono font-bold text-slate-800 border border-slate-300 shadow-xs">
                F9
              </kbd>{' '}
              to complete the sale!
            </span>
          </div>

          <div className="divide-y divide-slate-100">
            {shortcuts.map((sc, idx) => {
              const Icon = sc.icon;
              return (
                <div
                  key={idx}
                  className="py-2.5 flex items-center justify-between gap-3 text-xs hover:bg-slate-50/80 px-2 rounded-xl transition-colors"
                >
                  <div className="flex items-center gap-2.5 min-w-0 flex-1">
                    <div className="p-1.5 rounded-lg bg-slate-100 text-slate-600 shrink-0">
                      <Icon className="w-3.5 h-3.5" />
                    </div>
                    <div>
                      <div className="font-bold text-slate-900">{sc.description}</div>
                      <div className="text-[10px] text-slate-400">{sc.category}</div>
                    </div>
                  </div>

                  <div className="flex items-center gap-1.5 shrink-0">
                    <kbd className="px-2.5 py-1 rounded-lg bg-slate-900 text-amber-300 font-mono font-black text-xs shadow-xs border border-slate-700">
                      {sc.key}
                    </kbd>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <span className="text-[11px] text-slate-500 font-medium">
            Shortcuts are active when POS view is open
          </span>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs transition active:scale-95"
          >
            Got It (Esc)
          </button>
        </div>
      </div>
    </div>
  );
};
