import React from 'react';
import { PermanentAppModal } from './PermanentAppModal';

export { PermanentAppModal };

interface AndroidInstallModalProps {
  isOpen: boolean;
  onClose: () => void;
}

/**
 * Backward-compatible wrapper around PermanentAppModal
 */
export const AndroidInstallModal: React.FC<AndroidInstallModalProps> = (props) => {
  return <PermanentAppModal {...props} />;
};
