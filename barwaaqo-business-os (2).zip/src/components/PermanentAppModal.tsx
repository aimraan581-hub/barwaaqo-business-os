import React, { useState, useEffect } from 'react';
import QRCode from 'qrcode';
import { usePWAInstall } from '../hooks/usePWAInstall';
import { useStore } from '../context/StoreContext';
import {
  Smartphone,
  Monitor,
  Download,
  CheckCircle2,
  ExternalLink,
  X,
  Share2,
  Sparkles,
  ShieldCheck,
  Cpu,
  Layers,
  HelpCircle,
  HardDrive,
  Cloud,
  FileDown,
  Apple,
  Copy,
  Check,
  AlertCircle,
} from 'lucide-react';

interface PermanentAppModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const PermanentAppModal: React.FC<PermanentAppModalProps> = ({ isOpen, onClose }) => {
  const {
    isInstallable,
    isInstalled,
    isAndroid,
    isIOS,
    isDesktop,
    storageStatus,
    install,
    enablePermanentStorage,
  } = usePWAInstall();

  const { exportBackup } = useStore();
  const [activeTab, setActiveTab] = useState<'install' | 'storage' | 'cloud' | 'apk'>('install');
  const [deviceSubTab, setDeviceSubTab] = useState<'desktop' | 'android' | 'ios'>(
    isIOS ? 'ios' : isAndroid ? 'android' : 'desktop'
  );
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [storageEnabling, setStorageEnabling] = useState(false);
  const [storageMessage, setStorageMessage] = useState<string | null>(null);
  const [qrDataUrl, setQrDataUrl] = useState<string>('');

  const permanentUrl = 'https://ais-pre-7zxghfj4nvlqrbhtgd2fzo-336179362284.europe-west2.run.app';
  const isInIframe = typeof window !== 'undefined' && window.self !== window.top;

  useEffect(() => {
    if (!isOpen) return;
    let isMounted = true;
    QRCode.toDataURL(permanentUrl, {
      width: 180,
      margin: 1,
      color: { dark: '#03170f', light: '#ffffff' },
      errorCorrectionLevel: 'M',
    })
      .then((url) => {
        if (isMounted) setQrDataUrl(url);
      })
      .catch(() => {});
    return () => {
      isMounted = false;
    };
  }, [isOpen, permanentUrl]);

  if (!isOpen) return null;

  const currentUrl = typeof window !== 'undefined' ? window.location.href : '';
  const pwaBuilderUrl = `https://www.pwabuilder.com?url=${encodeURIComponent(permanentUrl)}`;

  const handleCopyLink = (url: string) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(url);
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2500);
    }
  };

  const handleNativeInstall = async () => {
    if (isInstallable) {
      const ok = await install();
      if (ok) {
        onClose();
      }
    }
  };

  const handleEnableStorage = async () => {
    setStorageEnabling(true);
    try {
      const granted = await enablePermanentStorage();
      if (granted) {
        setStorageMessage('Permanent storage granted! Your database is now protected from eviction.');
      } else {
        setStorageMessage('Storage persistence requested. Bookmarking or installing the app guarantees permanent retention.');
      }
    } catch {
      setStorageMessage('Unable to request persistence in current environment.');
    } finally {
      setStorageEnabling(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/75 backdrop-blur-md p-3 sm:p-4 overflow-y-auto">
      <div className="relative w-full max-w-2xl rounded-3xl bg-white shadow-2xl border border-slate-200 overflow-hidden my-6">
        {/* Header */}
        <div className="bg-gradient-to-br from-emerald-950 via-slate-950 to-emerald-900 text-white p-5 sm:p-6 relative">
          <button
            onClick={onClose}
            className="absolute top-4 right-4 sm:top-5 sm:right-5 p-2 rounded-full bg-white/10 hover:bg-white/20 text-white/80 hover:text-white transition"
            aria-label="Close"
          >
            <X className="w-5 h-5" />
          </button>

          <div className="flex items-start sm:items-center gap-4">
            <div className="w-14 h-14 rounded-2xl bg-white/10 p-1.5 backdrop-blur-md border border-white/20 shadow-inner flex items-center justify-center shrink-0">
              <img
                src="/pwa-192x192.png"
                alt="App Icon"
                className="w-full h-full object-cover rounded-xl shadow"
                onError={(e) => {
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />
            </div>
            <div className="flex-1 pr-6 sm:pr-0">
              <div className="flex flex-wrap items-center gap-1.5">
                <span className="px-2 py-0.5 rounded-md bg-emerald-500/25 text-emerald-300 text-[10px] font-black uppercase tracking-wider border border-emerald-400/30">
                  Permanent App & OS Setup
                </span>
                {isInstalled ? (
                  <span className="px-2 py-0.5 rounded-md bg-blue-500/30 text-blue-200 text-[10px] font-bold border border-blue-400/30 flex items-center gap-1">
                    <CheckCircle2 className="w-3 h-3" /> Standalone Installed
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-md bg-emerald-500/20 text-emerald-200 text-[10px] font-bold">
                    Web & Offline Ready
                  </span>
                )}
                {storageStatus.isPersisted && (
                  <span className="px-2 py-0.5 rounded-md bg-amber-500/25 text-amber-200 text-[10px] font-bold border border-amber-400/30 flex items-center gap-1">
                    <ShieldCheck className="w-3 h-3" /> Eviction-Proof
                  </span>
                )}
              </div>
              <h2 className="text-lg sm:text-xl font-black tracking-tight text-white mt-1">
                Make BARWAAQO a Permanent App
              </h2>
              <p className="text-xs text-emerald-200/80 mt-0.5">
                Install as a standalone app on your PC, Mac, iPhone, or Android with guaranteed persistent data.
              </p>
            </div>
          </div>

          {/* Main Navigation Tabs */}
          <div className="flex items-center gap-1.5 sm:gap-2 mt-5 pt-3 border-t border-white/10 overflow-x-auto pb-1 scrollbar-none">
            <button
              onClick={() => setActiveTab('install')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                activeTab === 'install'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-white/70 hover:bg-white/10'
              }`}
            >
              <Download className="w-3.5 h-3.5" />
              Install as App
            </button>
            <button
              onClick={() => setActiveTab('storage')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                activeTab === 'storage'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-white/70 hover:bg-white/10'
              }`}
            >
              <HardDrive className="w-3.5 h-3.5" />
              Permanent Storage
            </button>
            <button
              onClick={() => setActiveTab('cloud')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                activeTab === 'cloud'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-white/70 hover:bg-white/10'
              }`}
            >
              <Cloud className="w-3.5 h-3.5" />
              Cloud & Share Link
            </button>
            <button
              onClick={() => setActiveTab('apk')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition flex items-center gap-1.5 whitespace-nowrap shrink-0 ${
                activeTab === 'apk'
                  ? 'bg-emerald-500 text-slate-950 shadow-md'
                  : 'text-white/70 hover:bg-white/10'
              }`}
            >
              <Smartphone className="w-3.5 h-3.5" />
              Android AAB & Standalone
            </button>
          </div>
        </div>

        {/* Content Body */}
        <div className="p-5 sm:p-6 space-y-5 text-slate-700 max-h-[70vh] overflow-y-auto">
          {/* Iframe Notice for AI Studio Preview */}
          {isInIframe && (
            <div className="p-4 rounded-2xl bg-amber-500/10 border border-amber-500/30 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
              <div className="flex items-start gap-2.5">
                <AlertCircle className="w-5 h-5 text-amber-600 shrink-0 mt-0.5" />
                <div className="text-xs">
                  <span className="font-extrabold text-amber-950 block">Currently Running in AI Studio Preview</span>
                  <span className="text-amber-800 leading-relaxed">
                    Browser security policies disable direct PWA downloads inside preview frames. Open the app in its own browser tab to download and install natively.
                  </span>
                </div>
              </div>
              <a
                href={permanentUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-amber-600 hover:bg-amber-700 text-white font-bold text-xs shadow-sm shrink-0 transition"
              >
                Open in New Tab
                <ExternalLink className="w-3.5 h-3.5" />
              </a>
            </div>
          )}

          {/* TAB 1: INSTALL AS APP */}
          {activeTab === 'install' && (
            <div className="space-y-4">
              {/* Direct Download & Install Highlight Card */}
              <div className="p-4 sm:p-5 rounded-2xl bg-gradient-to-br from-emerald-950 via-slate-900 to-teal-950 text-white border border-emerald-500/40 shadow-lg space-y-4">
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-white font-black text-sm sm:text-base">
                      <Sparkles className="w-4 h-4 text-amber-400 shrink-0" />
                      Download Original App (No App Store Needed)
                    </div>
                    <p className="text-xs text-emerald-200/90 leading-relaxed max-w-lg">
                      BARWAAQO installs directly to your home screen or PC desktop as an independent app. 
                      You do <strong>not</strong> need Google Play, Apple App Store, or any download manager.
                    </p>
                  </div>
                  <a
                    href={permanentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs shadow-md transition flex items-center justify-center gap-2 shrink-0 active:scale-95 text-center"
                  >
                    <ExternalLink className="w-4 h-4" />
                    Open Direct Link to Install
                  </a>
                </div>

                {qrDataUrl && (
                  <div className="pt-3 border-t border-white/15 flex flex-col sm:flex-row items-center gap-4 bg-white/10 p-3.5 rounded-xl backdrop-blur-sm">
                    <img
                      src={qrDataUrl}
                      alt="Scan to download original app"
                      className="w-24 h-24 rounded-xl border border-white/30 shadow-md bg-white p-1 shrink-0"
                    />
                    <div className="text-center sm:text-left space-y-1.5 flex-1">
                      <div className="text-xs font-black text-white flex items-center justify-center sm:justify-start gap-1.5">
                        <Smartphone className="w-3.5 h-3.5 text-amber-400" />
                        Scan with Your Phone Camera to Download
                      </div>
                      <p className="text-[11px] text-emerald-100/90 leading-relaxed">
                        Open your phone camera, scan this QR code, and tap <strong>"Install app"</strong> (on Android) or <strong>"Add to Home Screen"</strong> (on iPhone). The app installs immediately with full offline support.
                      </p>
                      <div className="flex items-center justify-center sm:justify-start gap-2 pt-0.5">
                        <button
                          onClick={() => handleCopyLink(permanentUrl)}
                          className="text-[10px] font-bold text-emerald-300 hover:text-white flex items-center gap-1 bg-white/10 px-2 py-1 rounded-md transition"
                        >
                          {copiedUrl ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                          {copiedUrl ? 'Link Copied!' : 'Copy Direct App Link'}
                        </button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* If browser supports instant native install prompt */}
              {isInstallable && (
                <div className="p-4 rounded-2xl bg-emerald-50 border border-emerald-300 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-sm">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 text-emerald-950 font-extrabold text-sm">
                      <Sparkles className="w-4 h-4 text-emerald-600 shrink-0" />
                      1-Click Native Installation Ready
                    </div>
                    <p className="text-xs text-emerald-800">
                      Your browser has verified this app for instant standalone installation with its own desktop/mobile app window.
                    </p>
                  </div>
                  <button
                    onClick={handleNativeInstall}
                    className="w-full sm:w-auto px-5 py-2.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-black text-xs shadow-lg shadow-emerald-700/25 transition flex items-center justify-center gap-2 shrink-0 active:scale-95"
                  >
                    <Download className="w-4 h-4" />
                    Install Standalone App Now
                  </button>
                </div>
              )}

              {isInstalled && (
                <div className="p-4 rounded-2xl bg-blue-50 border border-blue-200 flex items-center gap-3">
                  <CheckCircle2 className="w-5 h-5 text-blue-600 shrink-0" />
                  <div>
                    <h4 className="text-xs font-black text-blue-950">Standalone App Is Active</h4>
                    <p className="text-xs text-blue-800">
                      You are running the app as a permanent standalone system. All inventory data, sales, and logs persist automatically.
                    </p>
                  </div>
                </div>
              )}

              {/* Sub-tabs for platforms */}
              <div className="space-y-3">
                <div className="flex items-center gap-2 p-1 bg-slate-100 rounded-xl border border-slate-200 text-xs font-bold">
                  <button
                    onClick={() => setDeviceSubTab('desktop')}
                    className={`flex-1 py-1.5 px-3 rounded-lg transition flex items-center justify-center gap-1.5 ${
                      deviceSubTab === 'desktop'
                        ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Monitor className="w-3.5 h-3.5 text-emerald-600" />
                    Desktop (PC / Mac)
                  </button>
                  <button
                    onClick={() => setDeviceSubTab('android')}
                    className={`flex-1 py-1.5 px-3 rounded-lg transition flex items-center justify-center gap-1.5 ${
                      deviceSubTab === 'android'
                        ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Smartphone className="w-3.5 h-3.5 text-emerald-600" />
                    Android & POS
                  </button>
                  <button
                    onClick={() => setDeviceSubTab('ios')}
                    className={`flex-1 py-1.5 px-3 rounded-lg transition flex items-center justify-center gap-1.5 ${
                      deviceSubTab === 'ios'
                        ? 'bg-white text-slate-900 shadow-sm border border-slate-200/80'
                        : 'text-slate-600 hover:text-slate-900'
                    }`}
                  >
                    <Apple className="w-3.5 h-3.5 text-slate-800" />
                    iPhone / iPad (iOS)
                  </button>
                </div>

                {/* DESKTOP GUIDANCE */}
                {deviceSubTab === 'desktop' && (
                  <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-3">
                    <h4 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
                      <Monitor className="w-4 h-4 text-emerald-600" />
                      Install on Windows PC, Mac, or Chromebook (Chrome & Edge)
                    </h4>
                    <p className="text-xs text-slate-600">
                      Installing on desktop gives you a dedicated window (no URL bar or browser tabs), desktop shortcut, taskbar pin, and ultra-fast startup.
                    </p>
                    <ol className="space-y-2.5 text-xs text-slate-600 pl-1">
                      <li className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          1
                        </span>
                        <span>
                          Open the app URL in <strong>Google Chrome</strong>, <strong>Microsoft Edge</strong>, or <strong>Brave</strong>.
                        </span>
                      </li>
                      <li className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          2
                        </span>
                        <span>
                          Look at the right side of the address bar for the <strong>Install icon</strong> (a computer monitor with down arrow or ⊕ symbol).
                        </span>
                      </li>
                      <li className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          3
                        </span>
                        <span>
                          Or click the <strong>3 dots menu (⋮)</strong> &rarr; select <strong>"Install BARWAAQO Business OS"</strong> (or <em>"Save and share" &rarr; "Install page as app"</em>).
                        </span>
                      </li>
                      <li className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          4
                        </span>
                        <span>
                          Click <strong>Install</strong>. The app launches immediately as a permanent desktop application with its own icon in your Start menu, Taskbar, or Mac Dock!
                        </span>
                      </li>
                    </ol>
                  </div>
                )}

                {/* ANDROID GUIDANCE */}
                {deviceSubTab === 'android' && (
                  <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-3">
                    <h4 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
                      <Smartphone className="w-4 h-4 text-emerald-600" />
                      Install on Android Phone, Tablet, or POS Register (Chrome)
                    </h4>
                    <p className="text-xs text-slate-600">
                      Runs as a full-screen WebAPK with hardware barcode scanning, vibration feedback, and thermal receipt support.
                    </p>
                    <ol className="space-y-2.5 text-xs text-slate-600 pl-1">
                      <li className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          1
                        </span>
                        <span>
                          Open this store link on your Android device in <strong>Google Chrome</strong> or <strong>Samsung Internet</strong>.
                        </span>
                      </li>
                      <li className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          2
                        </span>
                        <span>
                          Tap the <strong>three vertical dots (⋮)</strong> menu in the upper-right corner.
                        </span>
                      </li>
                      <li className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          3
                        </span>
                        <span>
                          Select <strong>"Install app"</strong> (or <strong>"Add to Home screen"</strong>).
                        </span>
                      </li>
                      <li className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-emerald-100 text-emerald-800 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          4
                        </span>
                        <span>
                          Confirm install. Android installs a permanent app package directly into your app drawer!
                        </span>
                      </li>
                    </ol>
                  </div>
                )}

                {/* IOS GUIDANCE */}
                {deviceSubTab === 'ios' && (
                  <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-3">
                    <h4 className="text-xs font-black uppercase tracking-wider text-slate-900 flex items-center gap-2">
                      <Apple className="w-4 h-4 text-slate-900" />
                      Install on iPhone & iPad (Safari)
                    </h4>
                    <p className="text-xs text-slate-600">
                      iOS Safari allows any Progressive Web App to be added directly to your home screen as a permanent standalone app.
                    </p>
                    <ol className="space-y-2.5 text-xs text-slate-600 pl-1">
                      <li className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-900 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          1
                        </span>
                        <span>
                          Open the store link in <strong>Safari</strong> on your iPhone or iPad.
                        </span>
                      </li>
                      <li className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-900 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          2
                        </span>
                        <span>
                          Tap the <strong>Share button</strong> (the square with an arrow pointing upward) in the toolbar at the bottom of the screen.
                        </span>
                      </li>
                      <li className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-900 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          3
                        </span>
                        <span>
                          Scroll down the share sheet and tap <strong>"Add to Home Screen"</strong> (with the ⊕ icon).
                        </span>
                      </li>
                      <li className="flex items-start gap-2.5">
                        <span className="w-5 h-5 rounded-full bg-slate-200 text-slate-900 font-bold flex items-center justify-center shrink-0 text-[10px]">
                          4
                        </span>
                        <span>
                          Tap <strong>Add</strong> in the top-right corner. The BARWAAQO icon is now permanently on your iOS home screen!
                        </span>
                      </li>
                    </ol>
                  </div>
                )}
              </div>
            </div>
          )}

          {/* TAB 2: PERMANENT STORAGE */}
          {activeTab === 'storage' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-2">
                <div className="flex items-center gap-2 font-black text-xs text-emerald-950">
                  <ShieldCheck className="w-4 h-4 text-emerald-700 shrink-0" />
                  Anti-Eviction Permanent Storage Guarantee
                </div>
                <p className="text-xs text-emerald-800 leading-relaxed">
                  Web browsers typically treat local storage as "best-effort" (meaning files could theoretically be cleared if hard disk space runs critically low). Enabling <strong>Persistent Storage</strong> tells the browser that this app contains critical business data and must <strong>never be evicted</strong>.
                </p>
              </div>

              {/* Status card */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                    Storage Persistence State
                  </span>
                  <div className="flex items-center gap-2">
                    {storageStatus.isPersisted ? (
                      <span className="px-2.5 py-1 rounded-lg bg-emerald-100 text-emerald-800 text-xs font-black flex items-center gap-1.5 border border-emerald-300">
                        <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                        Guaranteed Permanent (Protected)
                      </span>
                    ) : (
                      <span className="px-2.5 py-1 rounded-lg bg-amber-100 text-amber-800 text-xs font-black flex items-center gap-1.5 border border-amber-300">
                        Standard Local Storage
                      </span>
                    )}
                  </div>
                  <p className="text-[11px] text-slate-500">
                    {storageStatus.isPersisted
                      ? 'Browser has granted permanent status. Data will not be cleared on low disk space.'
                      : 'Requesting permission below instructs your browser to lock your database.'}
                  </p>
                  {!storageStatus.isPersisted && (
                    <button
                      onClick={handleEnableStorage}
                      disabled={storageEnabling}
                      className="mt-2 w-full px-4 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-xs transition shadow-sm flex items-center justify-center gap-2 disabled:opacity-50"
                    >
                      <ShieldCheck className="w-4 h-4" />
                      {storageEnabling ? 'Requesting...' : 'Enable Permanent Storage'}
                    </button>
                  )}
                  {storageMessage && (
                    <p className="text-[11px] font-medium text-emerald-700 bg-emerald-50 p-2 rounded-lg border border-emerald-200">
                      {storageMessage}
                    </p>
                  )}
                </div>

                <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-2">
                  <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
                    Local Database & Cache Quota
                  </span>
                  <div className="text-lg font-black text-slate-900">
                    {storageStatus.usageFormatted || '< 5 MB'}{' '}
                    <span className="text-xs font-normal text-slate-500">
                      used of {storageStatus.quotaFormatted || 'available storage'}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    Includes all products, sales transactions, audit trails, and offline UI assets.
                  </p>
                  <button
                    onClick={exportBackup}
                    className="mt-2 w-full px-4 py-2 rounded-xl bg-white hover:bg-slate-100 border border-slate-300 text-slate-800 font-extrabold text-xs transition shadow-sm flex items-center justify-center gap-2"
                  >
                    <FileDown className="w-4 h-4 text-emerald-600" />
                    Download JSON Backup Copy
                  </button>
                </div>
              </div>

              <div className="p-3.5 rounded-2xl bg-slate-100 text-xs text-slate-600 space-y-1.5 border border-slate-200">
                <div className="font-bold text-slate-800 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-emerald-600" />
                  Triple-Layer Reliability Architecture
                </div>
                <p className="text-[11px] text-slate-600 leading-relaxed">
                  1. <strong>Synchronous State Persistence</strong>: Every transaction is committed immediately to storage.<br />
                  2. <strong>Service Worker Offline Engine</strong>: Precaches all stylesheets, scripts, and fonts for immediate offline launch.<br />
                  3. <strong>Portability</strong>: You can export your full database JSON anytime and restore it on any machine.
                </p>
              </div>
            </div>
          )}

          {/* TAB 3: CLOUD & SHARE LINK */}
          {activeTab === 'cloud' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
                <div className="flex items-center gap-2 font-black text-xs text-slate-900">
                  <Cloud className="w-4 h-4 text-emerald-600 shrink-0" />
                  Permanent Live Web URL
                </div>
                <p className="text-xs text-slate-600">
                  Use this direct URL to access the application outside the AI Studio editor frame, bookmark it in your browser, or send it to your team:
                </p>
                <div className="flex items-center gap-2 p-2.5 rounded-xl bg-white border border-slate-300">
                  <span className="font-mono text-xs text-slate-800 truncate flex-1 select-all">
                    {permanentUrl}
                  </span>
                  <button
                    onClick={() => handleCopyLink(permanentUrl)}
                    className="px-3 py-1.5 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shrink-0 flex items-center gap-1.5"
                  >
                    {copiedUrl ? (
                      <>
                        <Check className="w-3.5 h-3.5" />
                        Copied!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" />
                        Copy Link
                      </>
                    )}
                  </button>
                  <a
                    href={permanentUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="px-3 py-1.5 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold transition shrink-0 flex items-center gap-1.5 border border-slate-300"
                  >
                    <ExternalLink className="w-3.5 h-3.5" />
                    Open Tab
                  </a>
                </div>
              </div>

              {/* Direct Project ZIP Download Card */}
              <div className="p-4 rounded-2xl bg-gradient-to-br from-slate-900 to-emerald-950 text-white border border-emerald-500/30 space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-black text-xs text-white">
                    <FileDown className="w-4 h-4 text-amber-400" />
                    <span>Download Complete Project Source Archive (.zip)</span>
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-800/60 text-emerald-200 border border-emerald-500/30">
                    4.8 MB · Ready to Build
                  </span>
                </div>
                <p className="text-xs text-emerald-100/80 leading-relaxed">
                  Includes the complete React 19 + TypeScript frontend, Express server, and the pre-configured native Android project (<code className="font-mono text-amber-300">/android</code>) ready for Android Studio.
                </p>
                <a
                  href="/api/download-zip"
                  download="barwaaqo-business-os.zip"
                  className="w-full py-2.5 px-4 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 text-slate-950 font-black text-xs transition flex items-center justify-center gap-2 shadow-md cursor-pointer active:scale-98 text-center"
                >
                  <Download className="w-4 h-4" />
                  <span>Download barwaaqo-business-os.zip</span>
                </a>
              </div>

              <div className="p-4 rounded-2xl bg-emerald-50/70 border border-emerald-200 space-y-3">
                <h4 className="font-black text-xs text-emerald-950 flex items-center gap-1.5">
                  <Sparkles className="w-4 h-4 text-emerald-600" />
                  Deploying Permanently in Google AI Studio
                </h4>
                <div className="space-y-2 text-xs text-emerald-900">
                  <p>
                    In <strong>Google AI Studio Build</strong>:
                  </p>
                  <ul className="list-disc pl-5 space-y-1.5 text-[11px] text-emerald-800">
                    <li>
                      <strong>Deploy to Cloud Run</strong>: Click the <strong>Deploy</strong> or <strong>Share</strong> button in the top navigation bar of Google AI Studio. This generates a permanent, autoscaling Cloud Run deployment hosted on Google infrastructure.
                    </li>
                    <li>
                      <strong>Export to GitHub</strong>: In the Settings / Project menu in AI Studio, choose <em>Export to GitHub</em> to synchronize the full codebase with your GitHub account for continuous version control.
                    </li>
                    <li>
                      <strong>Download ZIP</strong>: You can export a standalone ZIP archive of the complete repository to run locally or deploy to any custom domain or VPS.
                    </li>
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: ANDROID STANDALONE & AAB */}
          {activeTab === 'apk' && (
            <div className="space-y-4">
              <div className="p-4 rounded-2xl bg-gradient-to-r from-emerald-950 to-slate-900 text-white border border-emerald-500/40 space-y-2">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2 font-black text-sm text-amber-300">
                    <Smartphone className="w-4 h-4 text-amber-400 shrink-0" />
                    Standalone Android App & Google Play Bundle (.aab)
                  </div>
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-800/80 border border-emerald-500/40 text-emerald-200">
                    com.barwaaqo.businessos
                  </span>
                </div>
                <p className="text-xs text-emerald-100/90 leading-relaxed">
                  The repository now contains a complete <strong>Capacitor Native Android Project</strong> in the <code className="text-amber-200 font-mono">/android</code> directory, fully configured with camera barcode scanner permissions, offline assets, and Gradle build recipes for <strong>.aab</strong> and <strong>.apk</strong> files.
                </p>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {/* Option 1: Native Gradle / Android Studio */}
                <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-2">
                  <h4 className="font-black text-xs text-slate-900 flex items-center gap-1.5">
                    <Cpu className="w-4 h-4 text-emerald-600" />
                    Option 1: Gradle / Android Studio (.aab)
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    Export the project (ZIP or GitHub), open <code className="font-mono text-emerald-800">/android</code> in Android Studio or run Gradle:
                  </p>
                  <code className="block bg-slate-900 text-emerald-300 p-2.5 rounded-xl text-[10px] font-mono select-all leading-relaxed">
                    cd android<br />
                    ./gradlew bundleRelease
                  </code>
                  <div className="text-[10px] text-slate-500">
                    Produces <strong className="text-slate-800 font-mono">app-release.aab</strong> ready to sign and upload to Google Play Console.
                  </div>
                  <a
                    href="/api/download-zip"
                    download="barwaaqo-business-os.zip"
                    className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-emerald-700 hover:bg-emerald-800 text-white text-[11px] font-bold transition shadow-xs mt-1"
                  >
                    <Download className="w-3.5 h-3.5" />
                    Download Project ZIP
                  </a>
                </div>

                {/* Option 2: PWABuilder 1-Click Cloud */}
                <div className="p-4 rounded-2xl border border-slate-200 bg-slate-50 space-y-2">
                  <h4 className="font-black text-xs text-slate-900 flex items-center gap-1.5">
                    <Download className="w-4 h-4 text-blue-600" />
                    Option 2: PWABuilder (1-Click .aab)
                  </h4>
                  <p className="text-[11px] text-slate-600">
                    Generates a verified Google Play Store <strong>.aab</strong> bundle directly in the cloud from your live URL:
                  </p>
                  <a
                    href={pwaBuilderUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold transition shadow-sm"
                  >
                    Build .aab on PWABuilder
                    <ExternalLink className="w-3.5 h-3.5" />
                  </a>
                  <div className="text-[10px] text-slate-500">
                    Automated Google Play signing key and manifest validation included.
                  </div>
                </div>
              </div>

              {/* Bubblewrap CLI & Sync Scripts */}
              <div className="p-4 rounded-2xl border border-slate-200 bg-white space-y-2.5">
                <h4 className="font-black text-xs text-slate-900 flex items-center gap-1.5">
                  <Layers className="w-4 h-4 text-teal-600" />
                  Option 3: Google Bubblewrap TWA CLI
                </h4>
                <p className="text-[11px] text-slate-600">
                  We have included <code className="font-mono text-emerald-800">twa-manifest.json</code> in the project root. You can build with Google's official Bubblewrap tool:
                </p>
                <div className="bg-slate-900 text-emerald-300 p-2.5 rounded-xl text-[10px] font-mono select-all space-y-1">
                  <div>npm install -g @bubblewrap/cli</div>
                  <div>bubblewrap build</div>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-100 text-[11px] text-slate-600 flex items-center gap-2">
                <HelpCircle className="w-4 h-4 text-slate-400 shrink-0" />
                <span>
                  See <code className="font-mono font-bold text-slate-800">ANDROID_BUILD.md</code> in the repository root for detailed build commands, signing keys, and terminal hardware setup.
                </span>
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="p-4 bg-slate-50 border-t border-slate-200 flex items-center justify-between">
          <div className="flex items-center gap-2 text-xs font-medium text-slate-500">
            <span>BARWAAQO Business OS · Permanent Standalone Engine</span>
          </div>
          <button
            onClick={onClose}
            className="px-4 py-2 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition shadow-sm"
          >
            Done
          </button>
        </div>
      </div>
    </div>
  );
};
