import React, { useState, useRef, useEffect } from 'react';
import { useTranslation } from '../i18n/LanguageContext';
import { Language } from '../i18n/types';
import { Globe, Check, ChevronDown } from 'lucide-react';

interface LanguageToggleProps {
  variant?: 'dropdown' | 'pill' | 'compact' | 'sidebar';
  className?: string;
}

export const LanguageToggle: React.FC<LanguageToggleProps> = ({
  variant = 'dropdown',
  className = '',
}) => {
  const { language, setLanguage, languages, t } = useTranslation();
  const [isOpen, setIsOpen] = useState(false);
  const dropdownRef = useRef<HTMLDivElement>(null);

  const currentOption = languages.find((l) => l.code === language) || languages[0];

  useEffect(() => {
    const handleClickOutside = (e: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(e.target as Node)) {
        setIsOpen(false);
      }
    };
    if (isOpen) {
      document.addEventListener('mousedown', handleClickOutside);
    }
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, [isOpen]);

  // Pill variant (direct 3-button switcher)
  if (variant === 'pill') {
    return (
      <div
        className={`inline-flex items-center p-1 rounded-xl bg-black/25 border border-white/15 backdrop-blur-xs ${className}`}
        role="group"
        aria-label={t('selectLanguage')}
      >
        {languages.map((item) => {
          const isActive = item.code === language;
          return (
            <button
              key={item.code}
              type="button"
              onClick={() => setLanguage(item.code)}
              className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                isActive
                  ? 'bg-emerald-500 text-emerald-950 shadow-xs scale-102'
                  : 'text-emerald-100/70 hover:text-white hover:bg-white/10'
              }`}
              title={item.nativeName}
            >
              <span className="text-sm leading-none">{item.flag}</span>
              <span className="uppercase tracking-wider">{item.code}</span>
            </button>
          );
        })}
      </div>
    );
  }

  // Sidebar item variant
  if (variant === 'sidebar') {
    return (
      <div className={`relative ${className}`} ref={dropdownRef}>
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="w-full flex items-center gap-3 px-3 py-2 rounded-xl text-emerald-200/90 hover:text-white hover:bg-emerald-900/40 transition-colors text-left"
          title={`${t('language')}: ${currentOption.nativeName}`}
        >
          <Globe className="w-4 h-4 text-emerald-300 shrink-0" />
          <div className="flex-1 min-w-0 flex items-center justify-between">
            <span className="text-xs font-semibold truncate">{t('language')}</span>
            <div className="flex items-center gap-1 text-[11px] font-bold text-amber-300">
              <span>{currentOption.flag}</span>
              <span>{currentOption.code.toUpperCase()}</span>
            </div>
          </div>
          <ChevronDown
            className={`w-3.5 h-3.5 text-emerald-400 transition-transform ${
              isOpen ? 'rotate-180' : ''
            }`}
          />
        </button>

        {isOpen && (
          <div className="absolute bottom-full left-0 mb-2 w-56 rounded-2xl bg-[#021810] border border-emerald-600/40 shadow-2xl p-1.5 z-50 animate-in fade-in zoom-in-95">
            <div className="px-2.5 py-1.5 text-[10px] font-black uppercase tracking-wider text-emerald-400/80 border-b border-emerald-800/40 mb-1">
              {t('selectLanguage')}
            </div>
            {languages.map((item) => {
              const isActive = item.code === language;
              return (
                <button
                  key={item.code}
                  type="button"
                  onClick={() => {
                    setLanguage(item.code);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-2 rounded-xl text-xs transition-colors ${
                    isActive
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'text-emerald-100 hover:bg-emerald-900/50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">{item.flag}</span>
                    <div className="text-left">
                      <div className="font-semibold">{item.nativeName}</div>
                      <div className="text-[10px] opacity-75">{item.name}</div>
                    </div>
                  </div>
                  {isActive && <Check className="w-4 h-4 text-amber-300" />}
                </button>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  // Compact variant (ideal for collapsed sidebars or tight spaces)
  if (variant === 'compact') {
    return (
      <div className={`relative ${className}`} ref={dropdownRef}>
        <button
          type="button"
          onClick={() => setIsOpen(!isOpen)}
          className="w-10 h-10 rounded-xl bg-white/10 hover:bg-white/20 text-emerald-100 flex items-center justify-center transition-all shadow-xs border border-white/15"
          title={`${t('language')}: ${currentOption.nativeName}`}
        >
          <span className="text-base leading-none">{currentOption.flag}</span>
        </button>

        {isOpen && (
          <div className="absolute bottom-full left-0 mb-2 w-52 rounded-2xl bg-[#021810] border border-emerald-600/40 shadow-2xl p-1.5 z-50 animate-in fade-in zoom-in-95 text-white">
            <div className="px-2.5 py-1 text-[10px] font-black uppercase tracking-wider text-emerald-400/80 border-b border-emerald-800/40 mb-1">
              {t('selectLanguage')}
            </div>
            {languages.map((item) => {
              const isActive = item.code === language;
              return (
                <button
                  key={item.code}
                  type="button"
                  onClick={() => {
                    setLanguage(item.code);
                    setIsOpen(false);
                  }}
                  className={`w-full flex items-center justify-between px-2.5 py-2 rounded-xl text-xs transition-colors ${
                    isActive
                      ? 'bg-emerald-600 text-white font-bold'
                      : 'text-emerald-100 hover:bg-emerald-900/50'
                  }`}
                >
                  <div className="flex items-center gap-2">
                    <span className="text-base">{item.flag}</span>
                    <div className="text-left rtl:text-right">
                      <div className="font-semibold">{item.nativeName}</div>
                      <div className="text-[10px] opacity-75">{item.name}</div>
                    </div>
                  </div>
                  {isActive && <Check className="w-4 h-4 text-amber-300" />}
                </button>
              );
            })}
          </div>
        )}
      </div>
    );
  }

  // Dropdown variant (standard for desktop and mobile header)
  return (
    <div className={`relative ${className}`} ref={dropdownRef}>
      <button
        type="button"
        id="language-toggle-btn"
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-1.5 px-2.5 py-1.5 rounded-xl bg-white/10 hover:bg-white/15 text-xs font-semibold text-emerald-100 border border-white/15 transition-all shadow-xs active:scale-98 group"
        title={`${t('language')}: ${currentOption.nativeName}`}
      >
        <Globe className="w-3.5 h-3.5 text-emerald-300 group-hover:text-white transition-colors" />
        <span className="text-sm leading-none">{currentOption.flag}</span>
        <span className="font-bold text-xs uppercase text-white">{currentOption.code}</span>
        <ChevronDown
          className={`w-3 h-3 text-emerald-300 transition-transform ${
            isOpen ? 'rotate-180' : ''
          }`}
        />
      </button>

      {isOpen && (
        <div className="absolute right-0 rtl:right-auto rtl:left-0 mt-2 w-52 rounded-2xl bg-[#031c12] border border-emerald-500/40 shadow-2xl p-1.5 z-50 animate-in fade-in zoom-in-95 text-white">
          <div className="px-2.5 py-1 text-[10px] font-black uppercase tracking-wider text-emerald-300/80 border-b border-emerald-800/40 mb-1">
            {t('selectLanguage')}
          </div>
          {languages.map((item) => {
            const isActive = item.code === language;
            return (
              <button
                key={item.code}
                type="button"
                onClick={() => {
                  setLanguage(item.code);
                  setIsOpen(false);
                }}
                className={`w-full flex items-center justify-between px-2.5 py-2 rounded-xl text-xs transition-colors ${
                  isActive
                    ? 'bg-emerald-600 text-white font-bold shadow-xs'
                    : 'text-emerald-100 hover:bg-white/10'
                }`}
              >
                <div className="flex items-center gap-2.5">
                  <span className="text-base">{item.flag}</span>
                  <div className="text-left rtl:text-right">
                    <div className="font-bold">{item.nativeName}</div>
                    <div className="text-[10px] opacity-75">{item.name}</div>
                  </div>
                </div>
                {isActive && <Check className="w-4 h-4 text-amber-300 shrink-0" />}
              </button>
            );
          })}
        </div>
      )}
    </div>
  );
};
