import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { WarehouseLocation } from '../../types';
import { money } from '../../utils/helpers';
import {
  Factory,
  Plus,
  ArrowRightLeft,
  MapPin,
  Package,
  Layers,
  CheckCircle2,
  Trash2,
  Edit2,
  X,
  Save,
  Boxes,
  Truck,
  Building2,
  Clock,
} from 'lucide-react';

export const WarehouseManagement: React.FC = () => {
  const {
    db,
    addWarehouse,
    updateWarehouse,
    deleteWarehouse,
    transferStock,
    showToast,
  } = useStore();

  const warehouses = db.warehouses || [];
  const transfers = db.transfers || [];
  const products = db.products || [];

  const [isAddingFacility, setIsAddingFacility] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  // Facility form state
  const [facilityName, setFacilityName] = useState('');
  const [facilityCode, setFacilityCode] = useState('');
  const [facilityType, setFacilityType] = useState<WarehouseLocation['type']>('warehouse');
  const [facilityAddress, setFacilityAddress] = useState('');
  const [facilityCapacity, setFacilityCapacity] = useState<number | ''>(50000);

  // Stock transfer form state
  const [transferFromId, setTransferFromId] = useState(warehouses[0]?.id || '');
  const [transferToId, setTransferToId] = useState(warehouses[1]?.id || warehouses[0]?.id || '');
  const [transferProductId, setTransferProductId] = useState(products[0]?.id || '');
  const [transferQty, setTransferQty] = useState<number | ''>('');
  const [transferNotes, setTransferNotes] = useState('');

  const totalCapacity = warehouses.reduce((acc, w) => acc + (w.capacityUnits || 0), 0);
  const totalStockUnits = products.reduce((acc, p) => acc + (p.stock || 0), 0);
  const overallUtilizationPct = totalCapacity > 0 ? Math.min(100, (totalStockUnits / totalCapacity) * 100) : 0;

  const resetFacilityForm = () => {
    setFacilityName('');
    setFacilityCode('');
    setFacilityType('warehouse');
    setFacilityAddress('');
    setFacilityCapacity(50000);
    setIsAddingFacility(false);
    setEditingId(null);
  };

  const handleEditFacility = (loc: WarehouseLocation) => {
    setFacilityName(loc.name);
    setFacilityCode(loc.code);
    setFacilityType(loc.type);
    setFacilityAddress(loc.address);
    setFacilityCapacity(loc.capacityUnits);
    setEditingId(loc.id);
    setIsAddingFacility(true);
  };

  const handleSaveFacility = (e: React.FormEvent) => {
    e.preventDefault();
    if (!facilityName.trim() || !facilityCode.trim()) {
      showToast('Please provide facility name and code');
      return;
    }

    const payload: Omit<WarehouseLocation, 'id'> = {
      name: facilityName.trim(),
      code: facilityCode.trim().toUpperCase(),
      type: facilityType,
      address: facilityAddress.trim() || 'Central Zone, Addis Ababa',
      manager: 'Facility Operations Lead',
      capacityUnits: Number(facilityCapacity) || 10000,
      phone: '+251 91 100 0000',
      status: 'active',
      currentUtilizationPct: 45, // baseline estimate
      isActive: true,
    };

    if (editingId) {
      updateWarehouse(editingId, payload);
    } else {
      addWarehouse(payload);
    }
    resetFacilityForm();
  };

  const handleExecuteTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transferFromId || !transferToId || !transferProductId || !transferQty) {
      showToast('Please fill all required transfer fields');
      return;
    }

    if (transferFromId === transferToId) {
      showToast('Origin and destination facilities cannot be identical');
      return;
    }

    const ok = transferStock({
      fromLocationId: transferFromId,
      toLocationId: transferToId,
      productId: transferProductId,
      qty: Number(transferQty),
      notes: transferNotes.trim() || undefined,
    });

    if (ok) {
      setTransferQty('');
      setTransferNotes('');
    }
  };

  return (
    <div className="space-y-4">
      {/* KPI Overview */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
            FACILITIES
          </span>
          <span className="text-xl font-black text-slate-900 tracking-tight block mt-0.5">
            {warehouses.length} Locations
          </span>
          <span className="text-[10px] text-slate-500 font-medium block mt-0.5">
            Active hubs & storefronts
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
            STORAGE CAPACITY
          </span>
          <span className="text-xl font-black text-emerald-700 tracking-tight block mt-0.5">
            {totalCapacity.toLocaleString()} Units
          </span>
          <span className="text-[10px] text-emerald-600 font-medium block mt-0.5">
            Combined multi-site volume
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
            CAPACITY UTILIZATION
          </span>
          <span className="text-xl font-black text-indigo-700 tracking-tight block mt-0.5">
            {overallUtilizationPct.toFixed(1)}%
          </span>
          <span className="text-[10px] text-indigo-600 font-medium block mt-0.5">
            {totalStockUnits.toLocaleString()} units stocked
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
            STOCK TRANSFERS
          </span>
          <span className="text-xl font-black text-amber-700 tracking-tight block mt-0.5">
            {transfers.length} Completed
          </span>
          <span className="text-[10px] text-amber-600 font-medium block mt-0.5">
            Inter-facility balance
          </span>
        </div>
      </div>

      {/* Facilities Management Card */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center justify-between gap-2 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <div className="p-2 rounded-xl bg-emerald-100 text-emerald-800">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
                Warehouses & Depots (18. 🏭)
              </h3>
              <p className="text-xs text-slate-500">
                Manage physical depots, retail storefronts, and cold storage facilities
              </p>
            </div>
          </div>

          <button
            onClick={() => {
              resetFacilityForm();
              setIsAddingFacility(true);
            }}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs shadow-xs transition"
          >
            <Plus className="w-4 h-4" />
            <span>Add Facility</span>
          </button>
        </div>

        {/* Add/Edit Facility Form */}
        {isAddingFacility && (
          <form onSubmit={handleSaveFacility} className="p-4 rounded-2xl bg-slate-50 border border-slate-200 space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <h4 className="font-bold text-xs text-slate-800">
                {editingId ? 'Edit Facility' : 'Register New Storage Location'}
              </h4>
              <button
                type="button"
                onClick={resetFacilityForm}
                className="text-slate-400 hover:text-slate-600"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Facility Name *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Kaliti Central Depot"
                  value={facilityName}
                  onChange={(e) => setFacilityName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Location Code *</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. WH-CENTRAL"
                  value={facilityCode}
                  onChange={(e) => setFacilityCode(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold uppercase focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Facility Type</label>
                <select
                  value={facilityType}
                  onChange={(e) => setFacilityType(e.target.value as any)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold"
                >
                  <option value="warehouse">Main Warehouse Depot</option>
                  <option value="storefront">Retail Storefront Shelf</option>
                  <option value="cold_storage">Cold Storage (Perishables)</option>
                  <option value="distribution_hub">Distribution Logistics Hub</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Capacity (Units)</label>
                <input
                  type="number"
                  min="100"
                  step="500"
                  value={facilityCapacity}
                  onChange={(e) => setFacilityCapacity(e.target.value === '' ? '' : Number(e.target.value))}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>

              <div className="sm:col-span-2 md:col-span-4">
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">Physical Address / Zone</label>
                <input
                  type="text"
                  placeholder="e.g. Akaki Kaliti Industrial Zone, Gate 4, Addis Ababa"
                  value={facilityAddress}
                  onChange={(e) => setFacilityAddress(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-emerald-500/20"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={resetFacilityForm}
                className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold shadow-xs"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{editingId ? 'Save Changes' : 'Create Location'}</span>
              </button>
            </div>
          </form>
        )}

        {/* Facilities Grid */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
          {warehouses.map((wh) => {
            return (
              <div
                key={wh.id}
                className="p-4 rounded-2xl bg-white border border-slate-200 hover:border-emerald-300 transition shadow-2xs flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <span className="text-[10px] font-extrabold uppercase px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 font-mono">
                        {wh.code}
                      </span>
                      <h4 className="font-extrabold text-sm text-slate-900 mt-1">
                        {wh.name}
                      </h4>
                    </div>

                    <div className="flex items-center gap-1">
                      <button
                        onClick={() => handleEditFacility(wh)}
                        className="p-1.5 text-slate-400 hover:text-indigo-600 rounded-lg"
                        title="Edit facility"
                      >
                        <Edit2 className="w-3.5 h-3.5" />
                      </button>
                      <button
                        onClick={() => {
                          if (warehouses.length <= 1) {
                            showToast('At least one warehouse location must be retained');
                            return;
                          }
                          if (window.confirm(`Remove facility ${wh.name}?`)) {
                            deleteWarehouse(wh.id);
                          }
                        }}
                        className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg"
                        title="Remove facility"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>

                  <div className="mt-2.5 flex items-center gap-1.5 text-xs text-slate-500">
                    <MapPin className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                    <span className="truncate">{wh.address || 'Central Zone'}</span>
                  </div>

                  {/* Type Badge */}
                  <div className="mt-2">
                    <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-50 text-emerald-800 border border-emerald-200">
                      {wh.type === 'warehouse' && '🏢 Main Warehouse'}
                      {wh.type === 'storefront' && '🛒 Storefront Counter'}
                      {wh.type === 'cold_storage' && '❄️ Cold Storage Unit'}
                      {wh.type === 'distribution_hub' && '🚚 Distribution Hub'}
                    </span>
                  </div>
                </div>

                {/* Capacity Gauge */}
                <div className="mt-4 pt-3 border-t border-slate-100">
                  <div className="flex items-center justify-between text-[11px] font-bold mb-1">
                    <span className="text-slate-500">Capacity Rating</span>
                    <span className="text-slate-900">{wh.capacityUnits.toLocaleString()} units</span>
                  </div>
                  <div className="w-full h-2 bg-slate-100 rounded-full overflow-hidden">
                    <div
                      className="h-full bg-emerald-500 rounded-full"
                      style={{ width: `${Math.min(100, wh.currentUtilizationPct || 40)}%` }}
                    />
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Inter-Location Stock Transfer Engine */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-4">
        <div className="flex items-center gap-2 pb-3 border-b border-slate-100">
          <div className="p-2 rounded-xl bg-indigo-100 text-indigo-800">
            <ArrowRightLeft className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
              Inter-Facility Stock Transfer Engine
            </h3>
            <p className="text-xs text-slate-500">
              Shift pallets and units between central warehouses and storefront shelves
            </p>
          </div>
        </div>

        <form onSubmit={handleExecuteTransfer} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
              From Origin *
            </label>
            <select
              value={transferFromId}
              onChange={(e) => setTransferFromId(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 focus:bg-white"
            >
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name} ({w.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
              To Destination *
            </label>
            <select
              value={transferToId}
              onChange={(e) => setTransferToId(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 focus:bg-white"
            >
              {warehouses.map((w) => (
                <option key={w.id} value={w.id}>
                  {w.name} ({w.code})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
              Product SKU *
            </label>
            <select
              value={transferProductId}
              onChange={(e) => setTransferProductId(e.target.value)}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 focus:bg-white"
            >
              {products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} (Stock: {p.stock} {p.unit})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[10px] font-bold text-slate-500 uppercase mb-1">
              Transfer Qty *
            </label>
            <input
              type="number"
              min="1"
              required
              placeholder="e.g. 50"
              value={transferQty}
              onChange={(e) => setTransferQty(e.target.value === '' ? '' : Number(e.target.value))}
              className="w-full px-3 py-2 text-xs bg-slate-50 border border-slate-300 rounded-xl font-bold text-slate-800 focus:bg-white"
            />
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              className="w-full h-[38px] px-4 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold shadow-xs transition active:scale-95 flex items-center justify-center gap-1.5"
            >
              <ArrowRightLeft className="w-4 h-4" />
              <span>Transfer Stock</span>
            </button>
          </div>
        </form>

        {/* Transfer History Log */}
        {transfers.length > 0 && (
          <div className="mt-4 pt-4 border-t border-slate-100">
            <h4 className="text-xs font-bold text-slate-700 mb-2.5 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-slate-400" />
              <span>Recent Transfer Logs</span>
            </h4>

            <div className="divide-y divide-slate-100 max-h-56 overflow-y-auto">
              {transfers.map((t) => (
                <div key={t.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <div className="flex items-center gap-2">
                      <span className="font-black text-slate-900">{t.qty} units</span>
                      <span className="font-semibold text-slate-700">{t.productName}</span>
                      <span className="text-[10px] font-extrabold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                        {t.status}
                      </span>
                    </div>
                    <div className="text-[11px] text-slate-500 mt-0.5 flex items-center gap-1.5">
                      <span>{t.fromLocationName}</span>
                      <span>→</span>
                      <span className="font-bold text-slate-700">{t.toLocationName}</span>
                      <span>·</span>
                      <span>By {t.transferredBy}</span>
                    </div>
                  </div>

                  <span className="text-[10px] text-slate-400 font-mono">
                    {t.date} {t.time}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
