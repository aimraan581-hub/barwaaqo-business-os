import React, { useState } from 'react';
import { useStore } from '../../context/StoreContext';
import { SystemUser } from '../../types';
import {
  Users,
  Plus,
  Shield,
  KeyRound,
  Mail,
  Phone,
  CheckCircle2,
  Trash2,
  Edit2,
  X,
  Save,
  Lock,
  UserCheck,
  Sparkles,
  AlertCircle,
  Search,
  Building2,
  Crown,
} from 'lucide-react';

const AVAILABLE_PERMISSIONS: { id: string; label: string; desc: string }[] = [
  { id: 'pos', label: 'POS Counter', desc: 'Process sales and cash receipts' },
  { id: 'inventory', label: 'Stock & Catalog', desc: 'Add items and adjust quantities' },
  { id: 'reports', label: 'Finance & P&L', desc: 'Access financial ledgers & tax filings' },
  { id: 'enterprise', label: 'Warehouses & Goals', desc: 'Manage depots and CEO milestones' },
  { id: 'admin', label: 'System Admin', desc: 'Database backups and system preferences' },
];

export const TeamPermissionsManagement: React.FC = () => {
  const {
    availableUsers,
    currentUser,
    setCurrentUser,
    addSystemUser,
    updateSystemUser,
    deleteSystemUser,
    updateUserPin,
    businessProfile,
    setIsCeoProfileModalOpen,
    showToast,
  } = useStore();

  const [isAddingUser, setIsAddingUser] = useState(false);
  const [editingUserId, setEditingUserId] = useState<string | null>(null);

  // Search & Filter
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'active' | 'on_leave' | 'inactive'>('all');

  // Form states
  const [name, setName] = useState('');
  const [role, setRole] = useState<string>('Counter Cashier');
  const [customRole, setCustomRole] = useState('');
  const [email, setEmail] = useState('');
  const [phone, setPhone] = useState('');
  const [pin, setPin] = useState('1234');
  const [status, setStatus] = useState<'active' | 'on_leave' | 'inactive'>('active');
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>(['pos']);

  // Change PIN modal state
  const [pinModalUserId, setPinModalUserId] = useState<string | null>(null);
  const [newPinInput, setNewPinInput] = useState('');

  const STANDARD_ROLES = [
    'CEO / Owner',
    'Store Manager',
    'Head Cashier',
    'Counter Cashier',
    'Inventory / Warehouse Lead',
    'Finance / Accountant',
    'Sales Associate',
    'Compliance Auditor',
    'Custom',
  ];

  const resetForm = () => {
    setName('');
    setRole('Counter Cashier');
    setCustomRole('');
    setEmail('');
    setPhone('');
    setPin('1234');
    setStatus('active');
    setSelectedPermissions(['pos']);
    setIsAddingUser(false);
    setEditingUserId(null);
  };

  const handleEditUser = (user: SystemUser) => {
    setName(user.name);
    if (STANDARD_ROLES.includes(user.role)) {
      setRole(user.role);
      setCustomRole('');
    } else {
      setRole('Custom');
      setCustomRole(user.role);
    }
    setEmail(user.email || '');
    setPhone(user.phone || '');
    setPin(user.pin || '1234');
    setStatus(user.status || 'active');
    setSelectedPermissions(user.permissions || ['pos']);
    setEditingUserId(user.id);
    setIsAddingUser(true);

    // Scroll to the edit form smoothly
    setTimeout(() => {
      const formElement = document.getElementById('team-member-form');
      if (formElement) {
        formElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 50);
  };

  const togglePermission = (permId: string) => {
    setSelectedPermissions((prev) =>
      prev.includes(permId) ? prev.filter((p) => p !== permId) : [...prev, permId]
    );
  };

  const handleSaveUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) {
      showToast('Please provide a staff name');
      return;
    }

    const finalRole = role === 'Custom' ? (customRole.trim() || 'Staff Associate') : role;

    const payload = {
      name: name.trim(),
      role: finalRole,
      email: email.trim() || undefined,
      phone: phone.trim() || undefined,
      pin: pin.trim() || '1234',
      status,
      permissions: selectedPermissions.length > 0 ? selectedPermissions : ['pos'],
    };

    if (editingUserId) {
      updateSystemUser(editingUserId, payload);
    } else {
      addSystemUser(payload);
    }

    resetForm();
  };

  const handleToggleUserPermissionDirect = (user: SystemUser, permId: string) => {
    const currentPerms = user.permissions || ['pos'];
    const updated = currentPerms.includes(permId)
      ? currentPerms.filter((p) => p !== permId)
      : [...currentPerms, permId];

    updateSystemUser(user.id, { permissions: updated });
  };

  const handleChangePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (!pinModalUserId || !newPinInput.trim()) return;
    if (newPinInput.length < 4) {
      showToast('PIN must be at least 4 digits');
      return;
    }

    updateUserPin(pinModalUserId, newPinInput.trim());
    setPinModalUserId(null);
    setNewPinInput('');
  };

  // Filtered Users List
  const filteredUsers = availableUsers.filter((user) => {
    const matchesSearch =
      user.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      user.role.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (user.phone && user.phone.includes(searchTerm)) ||
      (user.email && user.email.toLowerCase().includes(searchTerm.toLowerCase()));

    const matchesStatus =
      statusFilter === 'all' ||
      (statusFilter === 'active' && (user.status === 'active' || !user.status)) ||
      user.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-4">
      {/* Header & Metric summary */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
            TOTAL STAFF
          </span>
          <span className="text-xl font-black text-slate-900 tracking-tight block mt-0.5">
            {availableUsers.length} Operators
          </span>
          <span className="text-[10px] text-slate-500 font-medium block mt-0.5">
            Registered profiles
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
            ACTIVE SESSION
          </span>
          <span className="text-xl font-black text-emerald-700 tracking-tight block mt-0.5 truncate">
            {currentUser.name}
          </span>
          <span className="text-[10px] text-emerald-600 font-bold block mt-0.5">
            Role: {currentUser.role}
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
            ACTIVE STATUS
          </span>
          <span className="text-xl font-black text-indigo-700 tracking-tight block mt-0.5">
            {availableUsers.filter((u) => u.status !== 'inactive').length} Active
          </span>
          <span className="text-[10px] text-indigo-600 font-medium block mt-0.5">
            On store floor
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200 shadow-2xs">
          <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block">
            SECURITY MODEL
          </span>
          <span className="text-xl font-black text-amber-700 tracking-tight block mt-0.5">
            RBAC Enabled
          </span>
          <span className="text-[10px] text-amber-600 font-medium block mt-0.5">
            4-Digit PIN required
          </span>
        </div>
      </div>

      {/* Executive CEO Quick Settings Banner */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-br from-[#03170f] via-[#064229] to-[#085a37] text-white shadow-xl flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 border border-emerald-800/40">
        <div className="flex items-center gap-3.5">
          <div className="w-12 h-12 rounded-2xl bg-amber-400 text-amber-950 font-black text-xl flex items-center justify-center shadow-lg ring-2 ring-amber-300/40 shrink-0">
            {businessProfile.ceoName ? businessProfile.ceoName.charAt(0).toUpperCase() : 'C'}
          </div>
          <div>
            <div className="flex items-center gap-2 flex-wrap">
              <h3 className="font-extrabold text-base tracking-wide text-white">
                {businessProfile.ceoName}
              </h3>
              <span className="text-[9px] uppercase font-black px-2 py-0.5 rounded-full bg-amber-400 text-amber-950 shadow-xs">
                EXECUTIVE CEO
              </span>
            </div>
            <p className="text-xs text-emerald-200 mt-0.5">
              Store: <span className="text-white font-bold">{businessProfile.storeName}</span> · Role: {businessProfile.ceoTitle}
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2 w-full sm:w-auto">
          <button
            onClick={() => setIsCeoProfileModalOpen(true)}
            className="w-full sm:w-auto flex items-center justify-center gap-2 px-4 py-2.5 rounded-2xl bg-amber-400 hover:bg-amber-300 text-amber-950 font-black text-xs shadow-md transition active:scale-95 cursor-pointer"
          >
            <Crown className="w-4 h-4" />
            <span>Edit CEO Profile & Store Identity</span>
          </button>
        </div>
      </div>

      {/* Main Staff Directory Card */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-2xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-purple-100 text-purple-800">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
                Staff & Employee Directory
              </h3>
              <p className="text-xs text-slate-500">
                Manage all employees, CEO identity, assigned permissions, PIN credentials, and operator sessions
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                resetForm();
                setIsAddingUser(true);
                setTimeout(() => {
                  const formElement = document.getElementById('team-member-form');
                  if (formElement) formElement.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }, 50);
              }}
              className="flex items-center gap-1.5 px-3.5 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white font-bold text-xs shadow-xs transition active:scale-95 cursor-pointer"
            >
              <Plus className="w-4 h-4" />
              <span>Add Staff Member</span>
            </button>
          </div>
        </div>

        {/* Search & Filter Bar */}
        <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3">
          <div className="relative flex-1 max-w-md">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search staff by name, role, phone, or email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-8 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-medium focus:ring-2 focus:ring-purple-500/20 focus:bg-white focus:outline-none"
            />
            {searchTerm && (
              <button
                onClick={() => setSearchTerm('')}
                className="absolute right-2.5 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>

          <div className="flex items-center gap-1.5 overflow-x-auto pb-1 sm:pb-0">
            {(['all', 'active', 'on_leave', 'inactive'] as const).map((filter) => {
              const count =
                filter === 'all'
                  ? availableUsers.length
                  : filter === 'active'
                  ? availableUsers.filter((u) => u.status === 'active' || !u.status).length
                  : availableUsers.filter((u) => u.status === filter).length;
              return (
                <button
                  key={filter}
                  onClick={() => setStatusFilter(filter)}
                  className={`px-3 py-1.5 rounded-xl text-xs font-bold capitalize transition whitespace-nowrap cursor-pointer ${
                    statusFilter === filter
                      ? 'bg-purple-600 text-white shadow-xs'
                      : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                  }`}
                >
                  {filter.replace('_', ' ')} ({count})
                </button>
              );
            })}
          </div>
        </div>

        {/* Add/Edit Staff Form */}
        {isAddingUser && (
          <form
            id="team-member-form"
            onSubmit={handleSaveUser}
            className="p-4 sm:p-5 rounded-2xl bg-slate-50 border border-purple-200 shadow-sm space-y-3 animate-in fade-in zoom-in-95 duration-150"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-200">
              <div className="flex items-center gap-2">
                <div className="w-7 h-7 rounded-lg bg-purple-600 text-white flex items-center justify-center font-bold text-xs">
                  {editingUserId ? <Edit2 className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                </div>
                <div>
                  <h4 className="font-extrabold text-xs text-slate-900">
                    {editingUserId ? 'Edit Employee / CEO Profile' : 'Register New Staff Member'}
                  </h4>
                  <p className="text-[11px] text-slate-500">
                    Update personal information, job title, login PIN, and permissions
                  </p>
                </div>
              </div>
              <button
                type="button"
                onClick={resetForm}
                className="p-1 text-slate-400 hover:text-slate-600 rounded-lg hover:bg-slate-200/60"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* CEO Synchronization notice if editing CEO */}
            {(editingUserId === 'USR-CEO-01' || role.toLowerCase().includes('ceo')) && (
              <div className="p-3 rounded-xl bg-amber-50 border border-amber-200 text-amber-900 text-xs flex items-center gap-2.5">
                <Sparkles className="w-4 h-4 text-amber-600 shrink-0" />
                <span>
                  <strong>CEO Synchronization:</strong> Updating the CEO name or title here will automatically synchronize with your corporate identity, POS receipts, tax reports, and command center header.
                </span>
              </div>
            )}

            <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-3 text-xs">
              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Full Name *
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Aimraan or Almaz Tadesse"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-purple-500/20 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Role Title
                </label>
                <select
                  value={role}
                  onChange={(e) => setRole(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-purple-500/20 focus:outline-none"
                >
                  {STANDARD_ROLES.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>

                {role === 'Custom' && (
                  <div className="mt-2">
                    <input
                      type="text"
                      placeholder="Specify custom role title..."
                      value={customRole}
                      onChange={(e) => setCustomRole(e.target.value)}
                      required
                      className="w-full px-3 py-1.5 bg-white border border-purple-300 rounded-xl text-xs font-bold focus:ring-2 focus:ring-purple-500/20 focus:outline-none"
                    />
                  </div>
                )}
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Status
                </label>
                <select
                  value={status}
                  onChange={(e) => setStatus(e.target.value as any)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-bold focus:ring-2 focus:ring-purple-500/20 focus:outline-none"
                >
                  <option value="active">Active (On Duty)</option>
                  <option value="on_leave">On Leave</option>
                  <option value="inactive">Suspended / Inactive</option>
                </select>
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Email Address
                </label>
                <input
                  type="email"
                  placeholder="e.g. employee@barwaaqo.et"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-purple-500/20 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  Phone Number
                </label>
                <input
                  type="tel"
                  placeholder="e.g. +251 911 234 567"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-medium focus:ring-2 focus:ring-purple-500/20 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-[10px] font-bold text-slate-600 uppercase mb-1">
                  4-Digit Security PIN
                </label>
                <input
                  type="password"
                  maxLength={6}
                  placeholder="1234"
                  value={pin}
                  onChange={(e) => setPin(e.target.value)}
                  className="w-full px-3 py-2 bg-white border border-slate-300 rounded-xl font-mono font-bold focus:ring-2 focus:ring-purple-500/20 focus:outline-none"
                />
              </div>
            </div>

            {/* Permission Checkboxes */}
            <div className="pt-2">
              <label className="block text-[10px] font-bold text-slate-600 uppercase mb-2">
                Access Permissions
              </label>
              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-5 gap-2">
                {AVAILABLE_PERMISSIONS.map((perm) => {
                  const isChecked = selectedPermissions.includes(perm.id);
                  return (
                    <button
                      key={perm.id}
                      type="button"
                      onClick={() => togglePermission(perm.id)}
                      className={`p-2.5 rounded-xl border text-left transition cursor-pointer ${
                        isChecked
                          ? 'bg-purple-50 border-purple-300 text-purple-900 shadow-2xs'
                          : 'bg-white border-slate-200 text-slate-600 hover:bg-slate-100'
                      }`}
                    >
                      <div className="flex items-center gap-1.5 font-bold text-xs">
                        <input
                          type="checkbox"
                          checked={isChecked}
                          onChange={() => {}}
                          className="rounded text-purple-600 pointer-events-none"
                        />
                        <span>{perm.label}</span>
                      </div>
                      <span className="text-[10px] text-slate-400 block mt-0.5 leading-tight">
                        {perm.desc}
                      </span>
                    </button>
                  );
                })}
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-200">
              <button
                type="button"
                onClick={resetForm}
                className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-200 transition"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="flex items-center gap-1.5 px-4 py-2 rounded-xl bg-purple-600 hover:bg-purple-700 text-white text-xs font-bold shadow-xs transition active:scale-95 cursor-pointer"
              >
                <Save className="w-3.5 h-3.5" />
                <span>{editingUserId ? 'Save Profile Changes' : 'Register Team Member'}</span>
              </button>
            </div>
          </form>
        )}

        {/* Staff Members List */}
        {filteredUsers.length === 0 ? (
          <div className="p-8 text-center bg-slate-50 rounded-2xl border border-dashed border-slate-200">
            <Users className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <h4 className="font-bold text-sm text-slate-700">No staff members found</h4>
            <p className="text-xs text-slate-500 mt-1">
              Try changing your search term or status filter, or click "Add Staff Member" above.
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {filteredUsers.map((user) => {
              const isSelf = currentUser.id === user.id;
              const isCeo = user.id === 'USR-CEO-01' || user.role.toLowerCase().includes('ceo');
              const perms = user.permissions || ['pos'];

              return (
                <div
                  key={user.id}
                  className={`p-4 rounded-2xl border transition shadow-2xs flex flex-col justify-between ${
                    isSelf
                      ? 'bg-purple-50/40 border-purple-300 ring-1 ring-purple-200'
                      : isCeo
                      ? 'bg-amber-50/20 border-amber-300'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <div className="flex items-center gap-2.5">
                        <div
                          className={`w-10 h-10 rounded-2xl font-black text-sm flex items-center justify-center shadow-xs shrink-0 ${
                            isCeo
                              ? 'bg-amber-400 text-amber-950 ring-2 ring-amber-300/40'
                              : 'bg-purple-100 text-purple-800'
                          }`}
                        >
                          {user.name.split(' ').map((n) => n[0]).join('').slice(0, 2).toUpperCase()}
                        </div>
                        <div>
                          <div className="flex items-center gap-1.5 flex-wrap">
                            <h4 className="font-extrabold text-sm text-slate-900">{user.name}</h4>
                            {isCeo && (
                              <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-amber-400 text-amber-950 flex items-center gap-0.5 shadow-2xs">
                                <Crown className="w-2.5 h-2.5" />
                                <span>CEO</span>
                              </span>
                            )}
                            {isSelf && (
                              <span className="text-[9px] font-black uppercase px-2 py-0.5 rounded-full bg-purple-600 text-white">
                                Active Operator
                              </span>
                            )}
                          </div>
                          <div className="flex items-center gap-1.5 mt-0.5 flex-wrap">
                            <span className="text-[10px] font-extrabold uppercase px-1.5 py-0.2 rounded bg-slate-100 text-slate-700">
                              {user.role}
                            </span>
                            <span
                              className={`text-[10px] font-bold px-2 py-0.2 rounded-full ${
                                user.status === 'active' || !user.status
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : user.status === 'on_leave'
                                  ? 'bg-amber-100 text-amber-800'
                                  : 'bg-rose-100 text-rose-800'
                              }`}
                            >
                              {user.status || 'active'}
                            </span>
                          </div>
                        </div>
                      </div>

                      {/* Action buttons */}
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => {
                            setPinModalUserId(user.id);
                            setNewPinInput('');
                          }}
                          className="p-1.5 text-slate-400 hover:text-amber-600 rounded-lg hover:bg-slate-100 transition"
                          title="Change PIN"
                        >
                          <KeyRound className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => handleEditUser(user)}
                          className="flex items-center gap-1 px-2.5 py-1 text-[11px] font-bold text-indigo-700 hover:text-indigo-900 bg-indigo-50 hover:bg-indigo-100 rounded-lg transition"
                          title="Edit staff details"
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                          <span>Edit</span>
                        </button>
                        {!isSelf && !isCeo && (
                          <button
                            onClick={() => {
                              if (window.confirm(`Remove ${user.name} from system?`)) {
                                deleteSystemUser(user.id);
                              }
                            }}
                            className="p-1.5 text-slate-400 hover:text-rose-600 rounded-lg hover:bg-rose-50 transition"
                            title="Remove user"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                      </div>
                    </div>

                    {/* Contact Info & Switch Session button */}
                    <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-[11px] text-slate-500 pt-2 border-t border-slate-100">
                      <div className="flex flex-wrap items-center gap-3">
                        {user.email && (
                          <div className="flex items-center gap-1">
                            <Mail className="w-3 h-3 text-slate-400" />
                            <span>{user.email}</span>
                          </div>
                        )}
                        {user.phone && (
                          <div className="flex items-center gap-1">
                            <Phone className="w-3 h-3 text-slate-400" />
                            <span>{user.phone}</span>
                          </div>
                        )}
                      </div>

                      {!isSelf && (
                        <button
                          onClick={() => {
                            setCurrentUser(user);
                            showToast(`Active operator switched to ${user.name}`);
                          }}
                          className="flex items-center gap-1 text-[10px] font-bold text-purple-700 hover:text-purple-900 bg-purple-50 hover:bg-purple-100 px-2 py-0.5 rounded-md transition ml-auto"
                        >
                          <UserCheck className="w-3 h-3" />
                          <span>Switch To Operator</span>
                        </button>
                      )}
                    </div>
                  </div>

                  {/* Granular Permission Toggles */}
                  <div className="mt-4 pt-3 border-t border-slate-100">
                    <span className="text-[10px] font-bold text-slate-400 uppercase tracking-wider block mb-1.5">
                      Assigned Permissions
                    </span>
                    <div className="flex flex-wrap gap-1.5">
                      {AVAILABLE_PERMISSIONS.map((perm) => {
                        const hasPerm = perms.includes(perm.id);
                        return (
                          <button
                            key={perm.id}
                            onClick={() => handleToggleUserPermissionDirect(user, perm.id)}
                            className={`px-2 py-0.5 rounded-lg text-[10px] font-bold transition border cursor-pointer ${
                              hasPerm
                                ? 'bg-purple-100 text-purple-900 border-purple-200 hover:bg-purple-200'
                                : 'bg-slate-50 text-slate-400 border-slate-200 hover:bg-slate-100'
                            }`}
                            title={`Click to ${hasPerm ? 'revoke' : 'grant'} ${perm.label}`}
                          >
                            {hasPerm ? '✓ ' : '+ '}
                            {perm.label}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Change PIN Modal */}
      {pinModalUserId && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-sm animate-in fade-in">
          <div className="w-full max-w-sm bg-white rounded-3xl p-5 shadow-2xl border border-slate-200 space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <KeyRound className="w-5 h-5 text-amber-600" />
                <h4 className="font-extrabold text-sm text-slate-900">Change Staff PIN</h4>
              </div>
              <button onClick={() => setPinModalUserId(null)} className="text-slate-400 hover:text-slate-600">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleChangePin} className="space-y-3">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  New 4-6 Digit Security PIN
                </label>
                <input
                  type="password"
                  required
                  maxLength={6}
                  value={newPinInput}
                  onChange={(e) => setNewPinInput(e.target.value)}
                  placeholder="e.g. 5678"
                  className="w-full px-3 py-2 text-center text-lg font-mono font-black tracking-widest bg-slate-50 border border-slate-300 rounded-xl focus:outline-none focus:ring-2 focus:ring-amber-500/20"
                  autoFocus
                />
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setPinModalUserId(null)}
                  className="px-3 py-1.5 rounded-xl text-xs font-bold text-slate-600 hover:bg-slate-100"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-xl text-xs font-bold bg-amber-600 hover:bg-amber-700 text-white shadow-xs"
                >
                  Save PIN
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
