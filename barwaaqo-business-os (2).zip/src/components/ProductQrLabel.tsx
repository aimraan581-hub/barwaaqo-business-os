import React, { useEffect, useState, useRef } from 'react';
import QRCode from 'qrcode';
import { Product } from '../types';
import { money } from '../utils/helpers';
import { useStore } from '../context/StoreContext';
import { Download, Printer, Copy, Check, ExternalLink, QrCode as QrIcon } from 'lucide-react';

interface ProductQrLabelProps {
  product: Product;
  size?: 'compact' | 'shelf' | 'full';
  showActions?: boolean;
  onOpenLedger?: () => void;
}

export const ProductQrLabel: React.FC<ProductQrLabelProps> = ({
  product,
  size = 'shelf',
  showActions = true,
  onOpenLedger,
}) => {
  const { businessProfile } = useStore();
  const [qrDataUrl, setQrDataUrl] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const labelRef = useRef<HTMLDivElement>(null);

  const baseUrl = typeof window !== 'undefined' ? window.location.origin + window.location.pathname : '';
  const deepLinkUrl = `${baseUrl}?product=${encodeURIComponent(product.id)}`;

  useEffect(() => {
    let isMounted = true;
    QRCode.toDataURL(deepLinkUrl, {
      width: size === 'compact' ? 120 : size === 'shelf' ? 180 : 260,
      margin: 1,
      color: {
        dark: '#0f172a',
        light: '#ffffff',
      },
      errorCorrectionLevel: 'M',
    })
      .then((url) => {
        if (isMounted) setQrDataUrl(url);
      })
      .catch((err) => {
        console.error('Failed to generate QR code for product', product.id, err);
      });

    return () => {
      isMounted = false;
    };
  }, [product.id, deepLinkUrl, size]);

  const handleCopyLink = () => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(deepLinkUrl);
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }
  };

  const handleDownloadPng = () => {
    if (!qrDataUrl) return;
    const a = document.createElement('a');
    a.href = qrDataUrl;
    a.download = `QR-Label-${product.sku || product.name.replace(/\s+/g, '_')}.png`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  const handlePrint = () => {
    const printWindow = window.open('', '_blank');
    if (!printWindow) return;

    const retailMargin = Math.max(0, product.sell - product.buy);
    const marginPct = product.sell > 0 ? ((retailMargin / product.sell) * 100).toFixed(1) : '0';

    printWindow.document.write(`
      <!DOCTYPE html>
      <html>
        <head>
          <title>Shelf Label - ${product.name}</title>
          <style>
            @page {
              size: 60mm 40mm;
              margin: 0;
            }
            body {
              font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
              margin: 0;
              padding: 6px;
              background: #fff;
              color: #000;
              width: 58mm;
              box-sizing: border-box;
            }
            .label-box {
              border: 1.5px solid #000;
              border-radius: 4px;
              padding: 5px;
              display: flex;
              flex-direction: column;
              height: 36mm;
              justify-content: space-between;
              box-sizing: border-box;
            }
            .header {
              font-size: 8px;
              font-weight: 800;
              text-transform: uppercase;
              letter-spacing: 0.5px;
              border-bottom: 1px solid #000;
              padding-bottom: 2px;
              display: flex;
              justify-content: space-between;
            }
            .main-content {
              display: flex;
              gap: 6px;
              align-items: center;
              margin-top: 2px;
            }
            .qr-img {
              width: 22mm;
              height: 22mm;
              display: block;
            }
            .info {
              flex: 1;
            }
            .prod-name {
              font-size: 11px;
              font-weight: 900;
              line-height: 1.1;
              max-height: 22px;
              overflow: hidden;
            }
            .sku {
              font-size: 7.5px;
              color: #333;
              margin-top: 1px;
            }
            .price-tag {
              font-size: 14px;
              font-weight: 900;
              margin-top: 2px;
              letter-spacing: -0.5px;
            }
            .unit {
              font-size: 8px;
              font-weight: 600;
              color: #444;
            }
            .footer {
              border-top: 0.5px dashed #666;
              padding-top: 2px;
              font-size: 6.5px;
              display: flex;
              justify-content: space-between;
              color: #333;
            }
          </style>
        </head>
        <body>
          <div class="label-box">
            <div class="header">
              <span>${businessProfile.storeName || 'BARWAAQO'}</span>
              <span>SHELF TAG</span>
            </div>
            <div class="main-content">
              <img src="${qrDataUrl}" class="qr-img" />
              <div class="info">
                <div class="prod-name">${product.name}</div>
                <div class="sku">SKU: ${product.sku || 'NONE'} · ${product.unit}</div>
                <div class="price-tag">${money(product.sell)}</div>
                <div class="unit">WS: ${money(product.wholesale || product.sell)}</div>
              </div>
            </div>
            <div class="footer">
              <span>Scan QR for Stock & Margin</span>
              <span>MRG: ${marginPct}%</span>
            </div>
          </div>
          <script>
            window.onload = function() {
              window.print();
              setTimeout(function() { window.close(); }, 500);
            };
          </script>
        </body>
      </html>
    `);
    printWindow.document.close();
  };

  const retailMargin = Math.max(0, product.sell - product.buy);
  const marginPct = product.sell > 0 ? ((retailMargin / product.sell) * 100).toFixed(1) : '0';

  if (size === 'compact') {
    return (
      <div className="flex items-center gap-2 p-1.5 rounded-xl bg-slate-50 border border-slate-200">
        {qrDataUrl ? (
          <img src={qrDataUrl} alt={`QR Code for ${product.name}`} className="w-10 h-10 rounded-md shrink-0 bg-white" />
        ) : (
          <div className="w-10 h-10 rounded-md bg-slate-200 animate-pulse shrink-0" />
        )}
        <div className="min-w-0 text-left">
          <div className="text-[10px] font-bold text-slate-800 truncate">{product.name}</div>
          <div className="text-[9px] text-slate-500">Scan for history</div>
        </div>
      </div>
    );
  }

  return (
    <div
      ref={labelRef}
      className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md transition text-slate-800"
    >
      {/* Label Badge Top */}
      <div className="flex items-center justify-between pb-2 border-b border-slate-100 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
        <span className="flex items-center gap-1 text-emerald-800 font-extrabold">
          <QrIcon className="w-3.5 h-3.5 text-emerald-600" />
          Auto-Generated QR Label
        </span>
        <span className="text-[9px] px-1.5 py-0.5 rounded bg-slate-100 text-slate-600 font-mono">
          ID: {product.id}
        </span>
      </div>

      {/* Main Body */}
      <div className="mt-3 flex flex-col sm:flex-row items-center gap-4">
        {/* QR Visual */}
        <div className="p-2 rounded-xl bg-slate-50 border border-slate-200 shrink-0 flex flex-col items-center">
          {qrDataUrl ? (
            <img
              src={qrDataUrl}
              alt={`QR Code for ${product.name}`}
              className="w-28 h-28 object-contain rounded-lg bg-white shadow-inner"
            />
          ) : (
            <div className="w-28 h-28 rounded-lg bg-slate-200 animate-pulse" />
          )}
          <span className="text-[9px] text-slate-400 font-mono mt-1 text-center">Scan with Camera</span>
        </div>

        {/* Product Details */}
        <div className="flex-1 min-w-0 text-left space-y-1.5 w-full">
          <div>
            <h4 className="font-black text-sm text-slate-900 leading-snug">{product.name}</h4>
            <div className="text-xs text-slate-500 flex items-center gap-2 mt-0.5">
              <span>
                SKU: <b className="font-mono text-slate-700">{product.sku || 'N/A'}</b>
              </span>
              <span>·</span>
              <span>
                Unit: <b className="text-slate-700">{product.unit}</b>
              </span>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-2 pt-1">
            <div className="p-2 rounded-xl bg-emerald-50/80 border border-emerald-200/80">
              <span className="text-[9px] text-emerald-700 font-bold block uppercase">Retail Selling Price</span>
              <span className="text-sm font-black text-emerald-950">{money(product.sell)}</span>
            </div>
            <div className="p-2 rounded-xl bg-slate-50 border border-slate-200">
              <span className="text-[9px] text-slate-500 font-bold block uppercase">Wholesale Price</span>
              <span className="text-sm font-black text-slate-800">{money(product.wholesale || product.sell)}</span>
            </div>
          </div>

          <div className="flex items-center justify-between text-[10px] text-slate-500 px-1 pt-1">
            <span>
              Buy Cost: <b>{money(product.buy)}</b>
            </span>
            <span className="font-bold text-emerald-700">
              Margin: +{money(retailMargin)} ({marginPct}%)
            </span>
          </div>
        </div>
      </div>

      {/* Action Bar */}
      {showActions && (
        <div className="mt-3 pt-3 border-t border-slate-100 flex flex-wrap items-center justify-between gap-2">
          {onOpenLedger && (
            <button
              onClick={onOpenLedger}
              className="px-3 py-1.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white font-black text-xs transition flex items-center gap-1.5 shadow-sm"
            >
              <span>View Stock History & Margins</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </button>
          )}

          <div className="flex items-center gap-1.5 ml-auto">
            <button
              onClick={handlePrint}
              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition flex items-center gap-1"
              title="Print Shelf Tag"
            >
              <Printer className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Print Tag</span>
            </button>
            <button
              onClick={handleDownloadPng}
              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition flex items-center gap-1"
              title="Download PNG QR Image"
            >
              <Download className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">PNG</span>
            </button>
            <button
              onClick={handleCopyLink}
              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-bold transition flex items-center gap-1"
              title="Copy Direct Link"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-600" /> : <Copy className="w-3.5 h-3.5" />}
              <span className="hidden sm:inline">{copied ? 'Copied' : 'Link'}</span>
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
