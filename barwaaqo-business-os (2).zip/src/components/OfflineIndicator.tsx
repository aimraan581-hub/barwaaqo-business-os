import React, { useEffect, useRef } from 'react';
import { useOnlineStatus } from '../hooks/useOnlineStatus';
import { WifiOff } from 'lucide-react';
import { useStore } from '../context/StoreContext';

export const OfflineIndicator: React.FC = () => {
  const isOnline = useOnlineStatus();
  const { showToast } = useStore();
  const wasOnline = useRef(isOnline);

  useEffect(() => {
    if (wasOnline.current && !isOnline) {
      showToast("Offline: Real-time features like 'Predictive Restock' or 'Financial Pulse' are using cached data.");
    }
    wasOnline.current = isOnline;
  }, [isOnline, showToast]);

  if (isOnline) return null;

  return (
    <div
      id="offline-banner"
      className="fixed bottom-4 left-4 z-50 flex items-center gap-2 rounded-xl bg-amber-600/95 backdrop-blur-md px-3.5 py-2 text-xs font-semibold text-white shadow-xl border border-amber-400/30 animate-pulse"
    >
      <WifiOff className="w-4 h-4 text-amber-100" />
      <span>Offline Mode — All sales & inventory operations run from local storage.</span>
    </div>
  );
};
