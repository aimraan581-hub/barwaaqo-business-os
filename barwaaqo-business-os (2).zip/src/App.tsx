import React, { useState, useEffect } from 'react';
import { LanguageProvider } from './i18n/LanguageContext';
import { StoreProvider, useStore } from './context/StoreContext';
import { Header } from './components/Header';
import { DesktopSidebar } from './components/DesktopSidebar';
import { Navigation } from './components/Navigation';
import { SearchModal } from './components/modals/SearchModal';
import { StockAdjustModal } from './components/modals/StockAdjustModal';
import { CapitalModal } from './components/modals/CapitalModal';
import { BusinessInfoModal } from './components/modals/BusinessInfoModal';
import { CeoProfileModal } from './components/modals/CeoProfileModal';
import { ProductQrHistoryModal } from './components/modals/ProductQrHistoryModal';
import { GettingStartedModal } from './components/modals/GettingStartedModal';
import { OfflineIndicator } from './components/OfflineIndicator';
import { InstallAppBanner } from './components/InstallAppBanner';
import { TaxSettingsModal } from './components/tax/TaxSettingsModal';
import { MonthlyTaxReportModal } from './components/tax/MonthlyTaxReportModal';
import { TaxReceiptModal } from './components/tax/TaxReceiptModal';

import { DashboardView } from './views/DashboardView';
import { PosView } from './views/PosView';
import { InventoryView } from './views/InventoryView';
import { PurchasesView } from './views/PurchasesView';
import { CustomersView } from './views/CustomersView';
import { DistributionView } from './views/DistributionView';
import { FinanceView } from './views/FinanceView';
import { ReportsView } from './views/ReportsView';
import { ActivityView } from './views/ActivityView';
import { EnterpriseView } from './views/EnterpriseView';
import { PricingView } from './views/PricingView';

const MainContent: React.FC = () => {
  const { activeTab } = useStore();

  return (
    <main className="max-w-[1680px] mx-auto w-full px-3.5 py-4 sm:px-6 lg:px-8 pb-28 lg:pb-12 flex-1">
      {activeTab === 'dashboard' && <DashboardView />}
      {activeTab === 'pos' && <PosView />}
      {activeTab === 'inventory' && <InventoryView />}
      {activeTab === 'pricing' && <PricingView />}
      {activeTab === 'purchases' && <PurchasesView />}
      {activeTab === 'customers' && <CustomersView />}
      {activeTab === 'distribution' && <DistributionView />}
      {activeTab === 'finance' && <FinanceView />}
      {activeTab === 'reports' && <ReportsView />}
      {activeTab === 'activity' && <ActivityView />}
      {activeTab === 'enterprise' && <EnterpriseView />}
    </main>
  );
};

const GlobalModals: React.FC = () => {
  const { productQrModalId, setProductQrModalId } = useStore();

  return (
    <>
      <SearchModal />
      <StockAdjustModal />
      <CapitalModal />
      <BusinessInfoModal />
      <CeoProfileModal />
      <GettingStartedModal />
      <OfflineIndicator />
      <InstallAppBanner />
      <TaxSettingsModal />
      <MonthlyTaxReportModal />
      <TaxReceiptModal />
      {productQrModalId && (
        <ProductQrHistoryModal
          productId={productQrModalId}
          onClose={() => setProductQrModalId(null)}
        />
      )}
    </>
  );
};

const AppContent: React.FC = () => {
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState<boolean>(() => {
    try {
      return localStorage.getItem('barwaaqo_desktop_sidebar_collapsed') === 'true';
    } catch {
      return false;
    }
  });

  const toggleSidebar = () => {
    setIsSidebarCollapsed((prev) => {
      const next = !prev;
      try {
        localStorage.setItem('barwaaqo_desktop_sidebar_collapsed', String(next));
      } catch {}
      return next;
    });
  };

  // Keyboard shortcut Ctrl+B or Cmd+B to collapse/expand sidebar
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && (e.key === 'b' || e.key === 'B')) {
        e.preventDefault();
        toggleSidebar();
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  return (
    <div className="min-h-screen bg-slate-100/75 text-slate-900 font-sans antialiased selection:bg-emerald-200 selection:text-emerald-950 flex flex-col lg:flex-row">
      {/* Desktop Persistent Sidebar (lg:flex) */}
      <DesktopSidebar
        isCollapsed={isSidebarCollapsed}
        onToggleCollapse={toggleSidebar}
      />

      {/* Main Desktop Canvas Area */}
      <div className="flex-1 flex flex-col min-w-0 min-h-screen">
        <Header
          isSidebarCollapsed={isSidebarCollapsed}
          onToggleSidebar={toggleSidebar}
        />
        <MainContent />
      </div>

      {/* Mobile Sticky Bottom Nav (lg:hidden) */}
      <Navigation />

      {/* Global Modals */}
      <GlobalModals />
    </div>
  );
};

export default function App() {
  return (
    <LanguageProvider>
      <StoreProvider>
        <AppContent />
      </StoreProvider>
    </LanguageProvider>
  );
}
