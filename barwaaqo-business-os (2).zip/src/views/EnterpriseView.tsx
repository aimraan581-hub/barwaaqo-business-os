import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { money } from '../utils/helpers';
import {
  Building2,
  Target,
  Plus,
  CheckCircle2,
  Trash2,
  Award,
  TrendingUp,
  ShieldCheck,
  Users,
  Clock,
  Calendar,
  BarChart2,
  Factory,
  Layers,
} from 'lucide-react';
import { SuppliersView } from './SuppliersView';
import { WarehouseManagement } from '../components/enterprise/WarehouseManagement';
import { TeamPermissionsManagement } from '../components/enterprise/TeamPermissionsManagement';

type EnterpriseSubTab = 'milestones' | 'warehouses' | 'team' | 'suppliers' | 'shifts';

export const EnterpriseView: React.FC = () => {
  const {
    db,
    totals,
    addGoal,
    toggleGoal,
    deleteGoal,
    availableUsers,
    assignShift,
    deleteShift,
    enterpriseSubTab,
    setEnterpriseSubTab,
  } = useStore();

  const activeSubTab = enterpriseSubTab;
  const setActiveSubTab = setEnterpriseSubTab;
  const [newGoalText, setNewGoalText] = useState('');
  const [newGoalCategory, setNewGoalCategory] = useState<
    'Revenue' | 'Inventory' | 'Operations' | 'Growth'
  >('Revenue');

  const missionTarget = db.target || 1000000;
  const progressPct = Math.min(100, Math.max(0, (totals.value / missionTarget) * 100));

  const handleAddGoal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newGoalText.trim()) return;

    const ok = addGoal(newGoalText.trim(), newGoalCategory);
    if (ok) {
      setNewGoalText('');
    }
  };

  // Shift Scheduler States
  const [shiftDate, setShiftDate] = useState(new Date().toISOString().slice(0, 10));
  const [shiftStart, setShiftStart] = useState('08:00');
  const [shiftEnd, setShiftEnd] = useState('16:00');
  const [shiftUserId, setShiftUserId] = useState(availableUsers[0]?.id || '');
  const [shiftNotes, setShiftNotes] = useState('');

  // Analyze sales volume trends by hour
  const hourlyTrend = useMemo(() => {
    const counts = new Array(24).fill(0);
    (db.sales || []).forEach((sale) => {
      if (sale.time) {
        const hour = parseInt(sale.time.split(':')[0], 10);
        if (!isNaN(hour) && hour >= 0 && hour <= 23) {
          counts[hour] += 1;
        }
      }
    });
    return counts;
  }, [db.sales]);

  const maxHourlyVolume = Math.max(...hourlyTrend, 1);

  const handleAssignShift = (e: React.FormEvent) => {
    e.preventDefault();
    const user = availableUsers.find(u => u.id === shiftUserId);
    if (!user) return;

    assignShift({
      userId: user.id,
      userName: user.name,
      role: user.role,
      date: shiftDate,
      startTime: shiftStart,
      endTime: shiftEnd,
      notes: shiftNotes,
    });

    setShiftNotes('');
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900 text-white shadow-md border border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-400/30">
              <Building2 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white tracking-tight">
                Enterprise Command Center
              </h2>
              <p className="text-[11px] text-slate-300">
                1M Valuation Goals, Multi-Warehouse Facilities, Team Permissions & Vendor Management
              </p>
            </div>
          </div>
        </div>

        {/* Segmented Enterprise Sub-Navigation Tabs */}
        <div className="mt-4 pt-3 border-t border-slate-800 flex items-center gap-1.5 overflow-x-auto pb-1 no-scrollbar">
          <button
            type="button"
            onClick={() => setActiveSubTab('milestones')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 ${
              activeSubTab === 'milestones'
                ? 'bg-amber-400 text-slate-950 shadow-xs'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
            }`}
          >
            <Target className="w-3.5 h-3.5" />
            <span>Milestones & 1M Goal</span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('warehouses')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 ${
              activeSubTab === 'warehouses'
                ? 'bg-emerald-400 text-slate-950 shadow-xs'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
            }`}
          >
            <Factory className="w-3.5 h-3.5" />
            <span>Warehouses & Locations (18)</span>
            <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black bg-slate-900/30">
              {(db.warehouses || []).length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('team')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 ${
              activeSubTab === 'team'
                ? 'bg-purple-400 text-slate-950 shadow-xs'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>Team & Permissions (19)</span>
            <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black bg-slate-900/30">
              {availableUsers.length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('suppliers')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 ${
              activeSubTab === 'suppliers'
                ? 'bg-blue-400 text-slate-950 shadow-xs'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
            }`}
          >
            <Building2 className="w-3.5 h-3.5" />
            <span>Suppliers & Vendors (15)</span>
            <span className="px-1.5 py-0.2 rounded-full text-[9px] font-black bg-slate-900/30">
              {(db.suppliers || []).length}
            </span>
          </button>

          <button
            type="button"
            onClick={() => setActiveSubTab('shifts')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-xl text-xs font-bold transition shrink-0 ${
              activeSubTab === 'shifts'
                ? 'bg-indigo-400 text-slate-950 shadow-xs'
                : 'bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white'
            }`}
          >
            <Calendar className="w-3.5 h-3.5" />
            <span>Shifts & Peak Hours</span>
          </button>
        </div>
      </div>

      {/* Sub-Tab 1: Milestones & Strategic Goals */}
      {activeSubTab === 'milestones' && (
        <div className="space-y-4">
          {/* 1 Million Birr Mission Card */}
          <div className="relative overflow-hidden rounded-3xl p-5 sm:p-6 text-white bg-gradient-to-br from-[#031d13] via-[#064a2c] to-[#0c6b41] shadow-xl border border-emerald-700/50 space-y-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Target className="w-5 h-5 text-emerald-400" />
                <h3 className="font-black text-sm tracking-wide uppercase">
                  Mission · ETB 200,000 → ETB 1,000,000
                </h3>
              </div>
              <span className="font-extrabold text-xs text-amber-300 px-2 py-0.5 rounded-full bg-black/40 border border-amber-400/30">
                {progressPct.toFixed(1)}% Completed
              </span>
            </div>

            <p className="text-xs text-emerald-100/80 leading-relaxed">
              The founder journey from an initial capital deployment of ETB 200,000 to building an asset valuation exceeding 1 Million Ethiopian Birr through operational efficiency, retail turnover, and wholesale distribution.
            </p>

            {/* Progress Bar */}
            <div className="space-y-1.5">
              <div className="w-full h-3 bg-emerald-950/70 rounded-full overflow-hidden p-0.5 border border-emerald-400/30">
                <div
                  className="h-full rounded-full bg-gradient-to-r from-emerald-400 via-teal-300 to-amber-300 transition-all duration-500"
                  style={{ width: `${progressPct}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] text-emerald-200">
                <span>Starting Capital: {money(db.capital)}</span>
                <span>Target: {money(missionTarget)}</span>
              </div>
            </div>

            {/* Valuation Formula Breakdown */}
            <div className="pt-3 border-t border-emerald-600/40 grid grid-cols-2 sm:grid-cols-4 gap-2 text-xs">
              <div className="p-2.5 rounded-xl bg-black/20">
                <span className="text-[10px] text-emerald-300 uppercase block font-semibold">Cash Accounts</span>
                <span className="font-bold text-white block mt-0.5">{money(totals.cash)}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/20">
                <span className="text-[10px] text-emerald-300 uppercase block font-semibold">Warehouse Stock</span>
                <span className="font-bold text-white block mt-0.5">{money(totals.stock)}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/20">
                <span className="text-[10px] text-emerald-300 uppercase block font-semibold">Customer Credit</span>
                <span className="font-bold text-white block mt-0.5">+{money(totals.debt)}</span>
              </div>
              <div className="p-2.5 rounded-xl bg-black/20">
                <span className="text-[10px] text-emerald-300 uppercase block font-semibold">Supplier Debt</span>
                <span className="font-bold text-rose-300 block mt-0.5">−{money(totals.supplierDebt)}</span>
              </div>
            </div>
          </div>

          {/* Strategic Goals & Objectives */}
          <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Award className="w-4 h-4 text-amber-600" />
                <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
                  Corporate Objectives & Milestones
                </h3>
              </div>
              <span className="text-[11px] font-bold text-slate-500">
                {db.goals.filter((g) => g.completed).length} / {db.goals.length} achieved
              </span>
            </div>

            {/* Add goal form */}
            <form onSubmit={handleAddGoal} className="flex gap-2 text-xs">
              <input
                type="text"
                value={newGoalText}
                onChange={(e) => setNewGoalText(e.target.value)}
                placeholder="Add new enterprise objective..."
                className="flex-1 px-3 py-2 rounded-xl border border-slate-300 font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
              />
              <select
                value={newGoalCategory}
                onChange={(e) => setNewGoalCategory(e.target.value as any)}
                className="px-2.5 py-2 rounded-xl border border-slate-300 font-semibold bg-white"
              >
                <option value="Revenue">Revenue</option>
                <option value="Inventory">Inventory</option>
                <option value="Operations">Operations</option>
                <option value="Growth">Growth</option>
              </select>
              <button
                type="submit"
                disabled={!newGoalText.trim()}
                className="px-4 py-2 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-white font-bold transition-all"
              >
                Add
              </button>
            </form>

            {/* Goals List */}
            <div className="divide-y divide-slate-100">
              {db.goals.map((goal) => (
                <div
                  key={goal.id}
                  className="py-3 flex items-center justify-between gap-3 text-xs group"
                >
                  <label className="flex items-center gap-2.5 cursor-pointer select-none flex-1">
                    <input
                      type="checkbox"
                      checked={goal.completed}
                      onChange={() => toggleGoal(goal.id)}
                      className="w-4 h-4 rounded-md text-emerald-600 focus:ring-emerald-500 border-slate-300"
                    />
                    <span
                      className={`${
                        goal.completed
                          ? 'line-through text-slate-400 font-medium'
                          : 'text-slate-800 font-semibold'
                      }`}
                    >
                      {goal.text}
                    </span>
                    <span className="text-[10px] uppercase font-extrabold px-1.5 py-0.2 rounded bg-slate-100 text-slate-600">
                      {goal.category}
                    </span>
                  </label>

                  <button
                    onClick={() => {
                      if (window.confirm('Delete this goal?')) {
                        deleteGoal(goal.id);
                      }
                    }}
                    className="p-1 text-slate-300 hover:text-rose-600 transition-colors opacity-0 group-hover:opacity-100"
                    title="Delete goal"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Sub-Tab 2: Warehouses & Facilities (18. 🏭) */}
      {activeSubTab === 'warehouses' && (
        <WarehouseManagement />
      )}

      {/* Sub-Tab 3: Team & Permissions (19. 👨‍💼) */}
      {activeSubTab === 'team' && (
        <TeamPermissionsManagement />
      )}

      {/* Sub-Tab 4: Suppliers & Vendors (15. 🤝) */}
      {activeSubTab === 'suppliers' && (
        <SuppliersView />
      )}

      {/* Sub-Tab 5: Shifts & Operations */}
      {activeSubTab === 'shifts' && (
        <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-5">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100">
            <div className="flex items-center gap-2">
              <Users className="w-5 h-5 text-indigo-600" />
              <div>
                <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
                  Shift Scheduler & Staffing Optimization
                </h3>
                <p className="text-[11px] text-slate-500 font-medium">
                  Analyze peak hours and assign operator shifts.
                </p>
              </div>
            </div>
            <span className="text-[11px] font-bold text-slate-500 bg-slate-100 px-2 py-1 rounded-lg">
              {(db.shifts || []).length} Active Shifts
            </span>
          </div>

          {/* Hourly Volume Trend (Peak Hours) */}
          <div>
            <h4 className="text-xs font-bold text-slate-700 mb-3 flex items-center gap-1.5">
              <BarChart2 className="w-4 h-4 text-slate-400" />
              Sales Volume Trends by Hour
            </h4>
            <div className="flex items-end h-24 gap-1 sm:gap-1.5 w-full">
              {hourlyTrend.map((count, hour) => {
                const heightPct = count > 0 ? (count / maxHourlyVolume) * 100 : 0;
                const isPeak = heightPct > 70;
                const isBusy = heightPct > 30 && !isPeak;
                return (
                  <div key={hour} className="flex-1 flex flex-col items-center gap-1 group relative">
                    <div
                      className={`w-full rounded-t-sm transition-all duration-300 ${
                        isPeak ? 'bg-rose-500' : isBusy ? 'bg-amber-400' : 'bg-emerald-200'
                      }`}
                      style={{ height: `${Math.max(heightPct, 5)}%` }}
                    />
                    <div className="text-[8px] sm:text-[9px] font-medium text-slate-500">
                      {hour}h
                    </div>
                    
                    {/* Tooltip */}
                    <div className="absolute bottom-full mb-1 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none z-10 bg-slate-900 text-white text-[10px] py-1 px-2 rounded-lg whitespace-nowrap shadow-lg">
                      {hour}:00 - {hour + 1}:00<br/>
                      {count} Sales
                      <div className="font-bold text-emerald-300 mt-0.5">
                        Rec: {isPeak ? '3+ Staff' : isBusy ? '2 Staff' : '1 Staff'}
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Shift Assignment Form */}
          <div className="pt-4 border-t border-slate-100">
            <h4 className="text-xs font-bold text-slate-700 mb-3">Assign Shift</h4>
            <form onSubmit={handleAssignShift} className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-5 gap-3">
              <div className="md:col-span-1">
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Date</label>
                <input
                  type="date"
                  required
                  value={shiftDate}
                  onChange={(e) => setShiftDate(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>
              <div className="md:col-span-1">
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Time</label>
                <div className="flex items-center gap-1">
                  <input
                    type="time"
                    required
                    value={shiftStart}
                    onChange={(e) => setShiftStart(e.target.value)}
                    className="w-full px-2 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white"
                  />
                  <span className="text-slate-400">-</span>
                  <input
                    type="time"
                    required
                    value={shiftEnd}
                    onChange={(e) => setShiftEnd(e.target.value)}
                    className="w-full px-2 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white"
                  />
                </div>
              </div>
              <div className="md:col-span-1">
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Operator</label>
                <select
                  required
                  value={shiftUserId}
                  onChange={(e) => setShiftUserId(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white"
                >
                  {availableUsers.map((u) => (
                    <option key={u.id} value={u.id}>
                      {u.name} ({u.role})
                    </option>
                  ))}
                </select>
              </div>
              <div className="md:col-span-1">
                <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Notes (Opt)</label>
                <input
                  type="text"
                  placeholder="Station 1, restocking..."
                  value={shiftNotes}
                  onChange={(e) => setShiftNotes(e.target.value)}
                  className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white"
                />
              </div>
              <div className="md:col-span-1 flex items-end">
                <button
                  type="submit"
                  className="w-full h-[34px] rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-xs flex items-center justify-center gap-1.5"
                >
                  <Plus className="w-4 h-4" />
                  Assign
                </button>
              </div>
            </form>
          </div>

          {/* Scheduled Shifts List */}
          {(db.shifts || []).length > 0 && (
            <div className="pt-4 border-t border-slate-100">
              <h4 className="text-xs font-bold text-slate-700 mb-3 flex items-center gap-1.5">
                <Calendar className="w-4 h-4 text-slate-400" />
                Scheduled Shifts
              </h4>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                {(db.shifts || []).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()).map((shift) => (
                  <div key={shift.id} className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-start justify-between group">
                    <div>
                      <div className="flex items-center gap-2 mb-1">
                        <span className="text-xs font-bold text-slate-900">{shift.userName}</span>
                        <span className="text-[9px] uppercase font-bold px-1.5 py-0.5 rounded bg-indigo-100 text-indigo-700 border border-indigo-200">
                          {shift.role}
                        </span>
                      </div>
                      <div className="flex items-center gap-3 text-[11px] text-slate-500 font-medium">
                        <span className="flex items-center gap-1">
                          <Calendar className="w-3 h-3 text-slate-400" />
                          {shift.date}
                        </span>
                        <span className="flex items-center gap-1">
                          <Clock className="w-3 h-3 text-slate-400" />
                          {shift.startTime} - {shift.endTime}
                        </span>
                      </div>
                      {shift.notes && (
                        <div className="mt-1.5 text-[10px] text-slate-600 bg-white px-2 py-1 rounded-lg border border-slate-200 inline-block">
                          {shift.notes}
                        </div>
                      )}
                    </div>
                    <button
                      onClick={() => {
                        if (window.confirm(`Remove shift for ${shift.userName}?`)) {
                          deleteShift(shift.id);
                        }
                      }}
                      className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors opacity-0 group-hover:opacity-100"
                      title="Remove shift"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
};
