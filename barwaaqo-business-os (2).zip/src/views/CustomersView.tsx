import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { CustomerType } from '../types';
import { money } from '../utils/helpers';
import {
  Users,
  Plus,
  Phone,
  MapPin,
  Search,
  Trash2,
  ArrowUpRight,
  FileText,
  Clock,
  UserCheck,
} from 'lucide-react';

export const CustomersView: React.FC = () => {
  const { db, totals, addCustomer, payCustomerCredit, deleteCustomer } = useStore();

  const [search, setSearch] = useState('');
  const [filterType, setFilterType] = useState<'ALL' | 'B2B' | 'DEBT'>('ALL');

  // New customer form
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [location, setLocation] = useState('');
  const [limit, setLimit] = useState<number | ''>(15000);
  const [customerType, setCustomerType] = useState<CustomerType>('b2b_supermarket');
  const [tinNumber, setTinNumber] = useState('');
  const [paymentTerms, setPaymentTerms] = useState('Net 15 Days');
  const [contactPerson, setContactPerson] = useState('');

  // Repayment form
  const [repayCustomerId, setRepayCustomerId] = useState('');
  const [repayAmount, setRepayAmount] = useState<number | ''>('');

  const selectedRepayCustomer = db.customers.find((c) => c.id === repayCustomerId);

  const handleAddCustomer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const ok = addCustomer({
      name: name.trim(),
      phone: phone.trim(),
      location: location.trim(),
      limit: Number(limit) || 10000,
      customerType,
      tinNumber: tinNumber.trim(),
      paymentTerms: paymentTerms.trim(),
      contactPerson: contactPerson.trim(),
    });

    if (ok) {
      setName('');
      setPhone('');
      setLocation('');
      setLimit(15000);
      setTinNumber('');
      setContactPerson('');
    }
  };

  const handleRepay = (e: React.FormEvent) => {
    e.preventDefault();
    if (!repayCustomerId || !repayAmount || Number(repayAmount) <= 0) return;
    const ok = payCustomerCredit(repayCustomerId, Number(repayAmount));
    if (ok) {
      setRepayAmount('');
    }
  };

  const filteredCustomers = useMemo(() => {
    const q = search.trim().toLowerCase();
    return db.customers.filter((c) => {
      const match =
        !q ||
        c.name.toLowerCase().includes(q) ||
        (c.phone && c.phone.toLowerCase().includes(q)) ||
        (c.location && c.location.toLowerCase().includes(q)) ||
        (c.tinNumber && c.tinNumber.toLowerCase().includes(q)) ||
        (c.contactPerson && c.contactPerson.toLowerCase().includes(q));
      if (!match) return false;
      if (filterType === 'DEBT' && c.credit <= 0) return false;
      if (filterType === 'B2B' && (!c.customerType || c.customerType === 'individual')) return false;
      return true;
    });
  }, [db.customers, search, filterType]);

  const b2bCount = db.customers.filter((c) => c.customerType && c.customerType !== 'individual').length;

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900 text-white shadow-md border border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-purple-500/20 text-purple-400 border border-purple-400/30">
              <Users className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white tracking-tight">
                B2B Client Portfolios & Credit Ledgers
              </h2>
              <p className="text-[11px] text-slate-300">
                Wholesale contracts, commercial accounts, credit limits, and statutory TIN invoicing
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 block">
            REGISTERED CLIENTS
          </span>
          <span className="text-lg font-black text-slate-900 mt-0.5 block">
            {db.customers.length} accounts
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 block">
            B2B COMMERCIAL
          </span>
          <span className="text-lg font-black text-indigo-600 mt-0.5 block">
            {b2bCount} wholesale
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 block">
            TOTAL OUTSTANDING
          </span>
          <span className="text-lg font-black text-rose-600 mt-0.5 block">
            {money(totals.debt)}
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 block">
            CLIENTS IN DEBT
          </span>
          <span className="text-lg font-black text-amber-600 mt-0.5 block">
            {db.customers.filter((c) => c.credit > 0).length} accounts
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Add Customer Form (7 cols) */}
        <div className="lg:col-span-7">
          <form
            onSubmit={handleAddCustomer}
            className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-700" />
                <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
                  Register Client / B2B Commercial Account
                </h3>
              </div>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Business / Client Name *
                </label>
                <input
                  id="custName"
                  type="text"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  placeholder="e.g. Bethel Hypermarket PLC"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Account Classification
                </label>
                <select
                  value={customerType}
                  onChange={(e) => setCustomerType(e.target.value as CustomerType)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                >
                  <option value="b2b_supermarket">🏢 B2B Supermarket / Grocer</option>
                  <option value="b2b_wholesaler">📦 B2B Wholesale Distributor</option>
                  <option value="b2b_hotel_restaurant">🏨 B2B Hotel / Restaurant / Cafe</option>
                  <option value="b2b_kiosk">🏪 B2B Retail Kiosk / Mini-Shop</option>
                  <option value="individual">👤 Retail Individual Shopper</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Key Contact Person
                </label>
                <input
                  type="text"
                  value={contactPerson}
                  onChange={(e) => setContactPerson(e.target.value)}
                  placeholder="e.g. Ato Yohannes (Purchasing Mgr)"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Phone Number</label>
                <input
                  id="custPhone"
                  type="text"
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. +251 911 234 567"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">Location / Zone</label>
                <input
                  id="custLoc"
                  type="text"
                  value={location}
                  onChange={(e) => setLocation(e.target.value)}
                  placeholder="e.g. Bole Medhanialem, Addis Ababa"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Credit Limit (ETB)
                </label>
                <input
                  id="custLimit"
                  type="number"
                  min="0"
                  value={limit}
                  onChange={(e) => setLimit(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="e.g. 50000"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Statutory TIN Number
                </label>
                <input
                  type="text"
                  value={tinNumber}
                  onChange={(e) => setTinNumber(e.target.value)}
                  placeholder="e.g. 0048192837"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Payment Terms
                </label>
                <select
                  value={paymentTerms}
                  onChange={(e) => setPaymentTerms(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
                >
                  <option value="Cash on Delivery">Cash on Delivery (COD)</option>
                  <option value="Net 7 Days">Net 7 Days</option>
                  <option value="Net 15 Days">Net 15 Days</option>
                  <option value="Net 30 Days">Net 30 Days</option>
                  <option value="Advance Payment">100% Advance Payment</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={!name.trim()}
              className="w-full py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-xs font-bold text-white transition-all shadow-sm active:scale-98"
            >
              Add Client Portfolio
            </button>
          </form>
        </div>

        {/* Collect Customer Debt Payment (5 cols) */}
        <div className="lg:col-span-5">
          <form
            onSubmit={handleRepay}
            className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <ArrowUpRight className="w-4 h-4 text-emerald-700" />
                <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
                  Settle Credit Ledger
                </h3>
              </div>
            </div>

            <p className="text-[11px] text-slate-500">
              Record payments received from B2B accounts. Automatically credits treasury cash balance.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Select Customer
                </label>
                <select
                  id="repayCust"
                  value={repayCustomerId}
                  onChange={(e) => setRepayCustomerId(e.target.value)}
                  required
                  className="w-full px-3 py-2.5 rounded-xl border border-slate-300 font-semibold bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                >
                  <option value="">-- Choose Customer --</option>
                  {db.customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} · Debt: {money(c.credit)}
                    </option>
                  ))}
                </select>
              </div>

              {selectedRepayCustomer && (
                <div className="p-2.5 rounded-xl bg-slate-50 border border-slate-200 text-xs flex justify-between items-center">
                  <span className="text-slate-500">Current Outstanding:</span>
                  <span className="font-extrabold text-rose-600">
                    {money(selectedRepayCustomer.credit)}
                  </span>
                </div>
              )}

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Amount Received (ETB)
                </label>
                <input
                  id="repayAmt"
                  type="number"
                  min="1"
                  step="any"
                  value={repayAmount}
                  onChange={(e) => setRepayAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="e.g. 2500"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <button
                type="submit"
                disabled={!repayCustomerId || !repayAmount || Number(repayAmount) <= 0}
                className="w-full py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-xs font-black uppercase tracking-wider text-white transition-all shadow-xs active:scale-98"
              >
                Record Payment & Clear Debt
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Customer Directory List */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
            Client Directory & Commercial Accounts ({filteredCustomers.length})
          </h3>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setFilterType('ALL')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all border ${
                filterType === 'ALL'
                  ? 'bg-slate-900 text-white border-slate-900'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              All Clients
            </button>
            <button
              onClick={() => setFilterType('B2B')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all border ${
                filterType === 'B2B'
                  ? 'bg-indigo-600 text-white border-indigo-600'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              🏢 B2B Commercial Only
            </button>
            <button
              onClick={() => setFilterType('DEBT')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all border ${
                filterType === 'DEBT'
                  ? 'bg-rose-50 border-rose-300 text-rose-800'
                  : 'bg-slate-50 border-slate-200 text-slate-600 hover:bg-slate-100'
              }`}
            >
              Outstanding Debt Only
            </button>
          </div>
        </div>

        {/* Search */}
        <div className="relative">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
          <input
            id="custSearch"
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search clients by name, contact person, TIN, phone, or location..."
            className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
          />
        </div>

        {/* Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
          {filteredCustomers.length === 0 ? (
            <div className="col-span-2 py-8 text-center text-xs text-slate-400">
              No customer records found matching current criteria.
            </div>
          ) : (
            filteredCustomers.map((cust) => {
              const custLimit = cust.limit || 15000;
              const creditPct = custLimit > 0 ? Math.min(100, Math.round((cust.credit / custLimit) * 100)) : 0;
              const isOverLimit = cust.credit > custLimit;

              return (
                <div
                  key={cust.id}
                  className={`p-4 rounded-2xl border transition-all ${
                    isOverLimit
                      ? 'bg-rose-50/40 border-rose-300'
                      : cust.credit > 0
                      ? 'bg-amber-50/20 border-amber-200'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-1.5 flex-wrap">
                        <h4 className="font-extrabold text-sm text-slate-900">{cust.name}</h4>
                        {cust.customerType && cust.customerType !== 'individual' && (
                          <span className="px-2 py-0.5 rounded-full text-[9px] font-black uppercase tracking-wider bg-indigo-50 text-indigo-700 border border-indigo-200">
                            {cust.customerType.replace('b2b_', 'B2B ')}
                          </span>
                        )}
                      </div>

                      <div className="space-y-1 mt-2 text-xs text-slate-500">
                        {cust.contactPerson && (
                          <div className="flex items-center gap-1 text-slate-700 font-medium">
                            <UserCheck className="w-3 h-3 text-slate-400" />
                            <span>Contact: {cust.contactPerson}</span>
                          </div>
                        )}
                        {cust.phone && (
                          <div className="flex items-center gap-1">
                            <Phone className="w-3 h-3 text-slate-400" />
                            <span>{cust.phone}</span>
                          </div>
                        )}
                        {cust.location && (
                          <div className="flex items-center gap-1">
                            <MapPin className="w-3 h-3 text-slate-400" />
                            <span>{cust.location}</span>
                          </div>
                        )}
                        {cust.tinNumber && (
                          <div className="flex items-center gap-1 text-[11px] text-slate-600">
                            <FileText className="w-3 h-3 text-slate-400" />
                            <span>TIN: <b className="font-mono">{cust.tinNumber}</b></span>
                          </div>
                        )}
                        {cust.paymentTerms && (
                          <div className="flex items-center gap-1 text-[11px] text-slate-600">
                            <Clock className="w-3 h-3 text-slate-400" />
                            <span>Terms: <b>{cust.paymentTerms}</b></span>
                          </div>
                        )}
                      </div>
                    </div>

                    <div className="text-right">
                      <span className="text-[10px] uppercase font-bold text-slate-400 block">
                        OUTSTANDING DEBT
                      </span>
                      <span
                        className={`text-base font-black tracking-tight ${
                          cust.credit > 0 ? 'text-rose-600' : 'text-emerald-700'
                        }`}
                      >
                        {money(cust.credit)}
                      </span>
                      <span className="text-[10px] text-slate-400 block mt-0.5">
                        Limit: {money(custLimit)}
                      </span>
                    </div>
                  </div>

                  {/* Credit Utilization Bar */}
                  <div className="mt-3 pt-2.5 border-t border-slate-100">
                    <div className="flex items-center justify-between text-[10px] text-slate-500 font-bold mb-1">
                      <span>Credit Line Utilization</span>
                      <span className={creditPct > 80 ? 'text-rose-600' : 'text-slate-600'}>
                        {creditPct}% ({money(cust.credit)} / {money(custLimit)})
                      </span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          creditPct > 90
                            ? 'bg-rose-500'
                            : creditPct > 70
                            ? 'bg-amber-500'
                            : 'bg-emerald-500'
                        }`}
                        style={{ width: `${Math.min(100, creditPct)}%` }}
                      />
                    </div>
                  </div>

                  <div className="mt-3 pt-2 border-t border-slate-100 flex items-center justify-between text-xs">
                    {cust.credit > 0 ? (
                      <button
                        onClick={() => {
                          setRepayCustomerId(cust.id);
                          setRepayAmount(cust.credit);
                          window.scrollTo({ top: 300, behavior: 'smooth' });
                        }}
                        className="text-emerald-700 hover:text-emerald-900 font-extrabold text-[11px] flex items-center gap-1"
                      >
                        <ArrowUpRight className="w-3.5 h-3.5" />
                        Collect Debt
                      </button>
                    ) : (
                      <span className="text-[11px] text-emerald-700 font-bold flex items-center gap-1">
                        ✓ Clear & Good Standing
                      </span>
                    )}

                    <button
                      onClick={() => {
                        if (window.confirm(`Delete customer ${cust.name}?`)) {
                          deleteCustomer(cust.id);
                        }
                      }}
                      className="p-1 text-slate-300 hover:text-rose-600 transition-colors"
                      title="Delete customer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>
    </div>
  );
};
