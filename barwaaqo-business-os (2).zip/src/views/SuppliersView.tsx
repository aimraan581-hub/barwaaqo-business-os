import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { Truck, Plus, Star, Phone, User, Clock, Trash2, Edit2, CheckCircle2, ShieldCheck, Mail, Save, X, Upload, Download } from 'lucide-react';
import { Supplier, SupplierStatus } from '../types';

export const SuppliersView: React.FC = () => {
  const { db, addSupplier, updateSupplier, deleteSupplier } = useStore();
  const suppliers = db.suppliers || [];

  const [isAdding, setIsAdding] = useState(false);
  const [isImportOpen, setIsImportOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [formData, setFormData] = useState<Omit<Supplier, 'id'>>({
    name: '',
    contactPerson: '',
    phone: '',
    category: '',
    leadTimeDays: 0,
    reliabilityScore: 100,
    notes: '',
    status: 'Active',
  });

  const resetForm = () => {
    setFormData({
      name: '',
      contactPerson: '',
      phone: '',
      category: '',
      leadTimeDays: 0,
      reliabilityScore: 100,
      notes: '',
      status: 'Active',
    });
    setIsAdding(false);
    setEditingId(null);
  };

  const handleEdit = (supplier: Supplier) => {
    setFormData({ ...supplier });
    setEditingId(supplier.id);
    setIsAdding(false);
  };

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    if (editingId) {
      updateSupplier(editingId, formData);
    } else {
      addSupplier(formData);
    }
    resetForm();
  };

  const getReliabilityColor = (score: number) => {
    if (score >= 90) return 'text-emerald-500 bg-emerald-50 border-emerald-200';
    if (score >= 70) return 'text-amber-500 bg-amber-50 border-amber-200';
    return 'text-rose-500 bg-rose-50 border-rose-200';
  };

  const handleExport = () => {
    const headers = ['Name', 'Phone', 'Contact Person', 'Lead Time Days', 'Category', 'Reliability Score', 'Notes'];
    const csvContent = [
      headers.join(','),
      ...suppliers.map(s => [
        `"${s.name || ''}"`,
        `"${s.phone || ''}"`,
        `"${s.contactPerson || ''}"`,
        s.leadTimeDays || 0,
        `"${s.category || ''}"`,
        s.reliabilityScore || 0,
        `"${s.notes?.replace(/"/g, '""') || ''}"`
      ].join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'suppliers_export.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-5">
      <div className="flex items-center justify-between pb-3 border-b border-slate-100">
        <div className="flex items-center gap-2">
          <div className="p-2 rounded-xl bg-indigo-50 text-indigo-600 border border-indigo-100">
            <Truck className="w-5 h-5" />
          </div>
          <div>
            <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
              Vendor & Supplier Reliability
            </h3>
            <p className="text-[11px] text-slate-500 font-medium">
              Track vendor performance, lead times, and contact information
            </p>
          </div>
        </div>
        {!isAdding && !editingId && (
          <div className="flex items-center gap-2">
            <button
              onClick={handleExport}
              className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
              title="Download CSV"
            >
              <Download className="w-4 h-4" />
              <span className="hidden sm:inline">Export</span>
            </button>
            <button
              onClick={() => setIsImportOpen(true)}
              className="p-2 sm:px-3 sm:py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
            >
              <Upload className="w-4 h-4" />
              <span className="hidden sm:inline">Bulk Import</span>
            </button>
            <button
              onClick={() => setIsAdding(true)}
              className="p-2 sm:px-3 sm:py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs flex items-center gap-1.5 transition-all shadow-xs"
            >
              <Plus className="w-4 h-4" />
              <span className="hidden sm:inline">Add Supplier</span>
            </button>
          </div>
        )}
      </div>

      {(isAdding || editingId) && (
        <form onSubmit={handleSave} className="bg-slate-50 p-4 rounded-2xl border border-slate-200 mb-6 space-y-4">
          <div className="flex items-center justify-between mb-2">
            <h4 className="font-extrabold text-slate-800 text-sm">
              {editingId ? 'Edit Supplier' : 'New Supplier Profile'}
            </h4>
            <button
              type="button"
              onClick={resetForm}
              className="text-slate-400 hover:text-slate-600 p-1"
            >
              <X className="w-4 h-4" />
            </button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Company / Vendor Name *</label>
              <input
                type="text"
                required
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white"
                placeholder="e.g. Habesha Breweries"
              />
            </div>
            
            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Category / Goods Provided</label>
              <input
                type="text"
                value={formData.category || ''}
                onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white"
                placeholder="e.g. Beverages"
              />
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Contact Person</label>
              <div className="relative">
                <User className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={formData.contactPerson || ''}
                  onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white"
                  placeholder="e.g. Ato Dawit"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Phone Number</label>
              <div className="relative">
                <Phone className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="tel"
                  value={formData.phone || ''}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white"
                  placeholder="09..."
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Avg Lead Time (Days)</label>
              <div className="relative">
                <Clock className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="number"
                  min="0"
                  value={formData.leadTimeDays || ''}
                  onChange={(e) => setFormData({ ...formData, leadTimeDays: Number(e.target.value) })}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white"
                  placeholder="Days to deliver"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Reliability Score (0-100)</label>
              <div className="relative">
                <Star className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="number"
                  min="0"
                  max="100"
                  value={formData.reliabilityScore || ''}
                  onChange={(e) => setFormData({ ...formData, reliabilityScore: Number(e.target.value) })}
                  className="w-full pl-9 pr-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white"
                  placeholder="Score out of 100"
                />
              </div>
            </div>

            <div>
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Vendor Status</label>
              <select
                value={formData.status || 'Active'}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as SupplierStatus })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white font-bold text-slate-700"
              >
                <option value="Active">🟢 Active (Prioritized / Trusted)</option>
                <option value="Under Review">🟡 Under Review (Auditing Lead Times)</option>
                <option value="At Risk">🔴 At Risk (Delayed / Quality Issue)</option>
              </select>
            </div>
            
            <div className="md:col-span-2">
              <label className="block text-[10px] font-bold text-slate-500 uppercase tracking-wider mb-1">Notes & Performance Metrics</label>
              <textarea
                value={formData.notes || ''}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="w-full px-3 py-2 text-xs rounded-xl border border-slate-300 focus:ring-2 focus:ring-indigo-500 bg-white min-h-[60px]"
                placeholder="Track fulfillment rates, defect rates, or negotiation notes here..."
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-200">
            <button
              type="button"
              onClick={resetForm}
              className="px-4 py-2 rounded-xl text-slate-600 hover:bg-slate-200 text-xs font-bold transition-colors"
            >
              Cancel
            </button>
            <button
              type="submit"
              className="px-5 py-2 rounded-xl bg-indigo-600 hover:bg-indigo-700 text-white text-xs font-bold transition-all shadow-xs flex items-center gap-1.5"
            >
              <Save className="w-4 h-4" />
              {editingId ? 'Save Changes' : 'Create Supplier'}
            </button>
          </div>
        </form>
      )}

      {suppliers.length === 0 && !isAdding ? (
        <div className="py-8 text-center bg-slate-50 rounded-2xl border border-slate-100">
          <Truck className="w-8 h-8 text-slate-300 mx-auto mb-2" />
          <h4 className="text-sm font-bold text-slate-600 mb-1">No Suppliers Tracked</h4>
          <p className="text-xs text-slate-500">Monitor vendor lead times and reliability directly from the Enterprise tab.</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {suppliers.map((supplier) => {
            const scoreColor = getReliabilityColor(supplier.reliabilityScore || 0);
            const status: SupplierStatus = supplier.status || (
              (supplier.reliabilityScore || 0) >= 85 ? 'Active' :
              (supplier.reliabilityScore || 0) >= 65 ? 'Under Review' : 'At Risk'
            );
            
            return (
              <div key={supplier.id} className="p-4 rounded-2xl bg-white border border-slate-200 shadow-sm hover:shadow-md transition-shadow group relative flex flex-col justify-between min-h-[160px]">
                <div className="absolute top-3 right-3 flex items-center gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button
                    onClick={() => handleEdit(supplier)}
                    className="p-1.5 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-lg transition-colors"
                    title="Edit supplier"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      if (window.confirm(`Remove ${supplier.name}?`)) {
                        deleteSupplier(supplier.id);
                      }
                    }}
                    className="p-1.5 text-slate-400 hover:text-rose-600 hover:bg-rose-50 rounded-lg transition-colors"
                    title="Remove supplier"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                <div>
                  <div className="flex items-start justify-between mb-3 pr-16">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-extrabold text-slate-900 text-sm tracking-tight">{supplier.name}</h4>
                        {status === 'Active' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-50 text-emerald-700 border border-emerald-300">
                            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse" />
                            Active
                          </span>
                        )}
                        {status === 'Under Review' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-amber-50 text-amber-700 border border-amber-300">
                            <span className="w-1.5 h-1.5 rounded-full bg-amber-500" />
                            Under Review
                          </span>
                        )}
                        {status === 'At Risk' && (
                          <span className="inline-flex items-center gap-1 px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-rose-50 text-rose-700 border border-rose-300">
                            <span className="w-1.5 h-1.5 rounded-full bg-rose-500" />
                            At Risk
                          </span>
                        )}
                      </div>
                      {supplier.category && (
                        <span className="inline-block mt-1 text-[9px] font-bold uppercase tracking-wider px-2 py-0.5 rounded bg-slate-100 text-slate-600 border border-slate-200">
                          {supplier.category}
                        </span>
                      )}
                    </div>
                  </div>

                  <div className="space-y-1.5">
                    {supplier.contactPerson && (
                      <div className="flex items-center gap-2 text-[11px] text-slate-600 font-medium">
                        <User className="w-3.5 h-3.5 text-slate-400" />
                        <span>{supplier.contactPerson}</span>
                      </div>
                    )}
                    {supplier.phone && (
                      <div className="flex items-center gap-2 text-[11px] text-slate-600 font-medium">
                        <Phone className="w-3.5 h-3.5 text-slate-400" />
                        <span>{supplier.phone}</span>
                      </div>
                    )}
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between">
                  <div className="flex items-center gap-1.5" title="Average Lead Time">
                    <Clock className="w-4 h-4 text-slate-400" />
                    <span className="text-[11px] font-bold text-slate-700">
                      {supplier.leadTimeDays || 0} days
                    </span>
                  </div>
                  
                  <div className={`flex items-center gap-1 px-2 py-1 rounded-lg border text-[11px] font-extrabold ${scoreColor}`} title="Reliability Score">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    {supplier.reliabilityScore || 0}/100
                  </div>
                </div>
                
                {supplier.notes && (
                   <div className="mt-3 text-[10px] text-slate-500 line-clamp-2 italic">
                     "{supplier.notes}"
                   </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {isImportOpen && (
        <BulkImportModal
          onClose={() => setIsImportOpen(false)}
        />
      )}
    </div>
  );
};

const BulkImportModal: React.FC<{ onClose: () => void }> = ({ onClose }) => {
  const { updateSuppliers, db, showToast } = useStore();
  const [rawText, setRawText] = useState('');

  const handleImport = () => {
    if (!rawText.trim()) return;

    const lines = rawText.trim().split('\n');
    const newSuppliers: Supplier[] = [];

    lines.forEach((line) => {
      // Very basic parsing: Name, Phone, Contact Person, Lead Time
      const parts = line.split(',').map((p) => p.trim());
      if (parts.length > 0 && parts[0]) {
        newSuppliers.push({
          id: `SUP-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
          name: parts[0],
          phone: parts[1] || '',
          contactPerson: parts[2] || '',
          leadTimeDays: parseInt(parts[3]) || 0,
          reliabilityScore: 100,
          category: parts[4] || '',
        });
      }
    });

    if (newSuppliers.length > 0) {
      updateSuppliers([...(db.suppliers || []), ...newSuppliers]);
      showToast(`Imported ${newSuppliers.length} suppliers`);
      onClose();
    } else {
      showToast('No valid suppliers found');
    }
  };

  const handleDownloadTemplate = () => {
    const headers = ['Name', 'Phone', 'Contact Person', 'Lead Time Days', 'Category'];
    const sampleData = ['Acme Corp', '+123456789', 'John Doe', '5', 'Electronics'];
    const csvContent = headers.join(',') + '\n' + sampleData.join(',');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'supplier_import_template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="fixed inset-0 bg-slate-900/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl p-6 w-full max-w-lg shadow-xl">
        <div className="flex items-center justify-between mb-4">
          <h3 className="font-extrabold text-slate-900">Bulk Import Suppliers</h3>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-slate-600 hover:bg-slate-100 rounded-xl">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <div className="flex items-center justify-between mb-4">
          <p className="text-xs text-slate-500">
            Paste supplier data as comma-separated values (CSV).<br/>
            Format: <strong>Name, Phone, Contact Person, Lead Time Days, Category</strong>
          </p>
          <button 
            onClick={handleDownloadTemplate}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded-lg text-xs font-bold transition-colors"
          >
            <Download className="w-3.5 h-3.5" />
            Template
          </button>
        </div>

        <textarea
          value={rawText}
          onChange={(e) => setRawText(e.target.value)}
          className="w-full h-48 p-3 text-sm font-mono border border-slate-200 rounded-xl focus:border-indigo-500 focus:ring-4 focus:ring-indigo-500/10 transition-all resize-none"
          placeholder="Acme Corp, +123456789, John Doe, 5, Electronics&#10;Global Supply, +987654321, Jane Smith, 2, Packaging"
        />

        <div className="flex justify-end gap-2 mt-6">
          <button
            onClick={onClose}
            className="px-4 py-2 text-slate-600 font-bold text-sm hover:bg-slate-100 rounded-xl transition-colors"
          >
            Cancel
          </button>
          <button
            onClick={handleImport}
            className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-sm rounded-xl shadow-xs transition-colors"
          >
            Import Data
          </button>
        </div>
      </div>
    </div>
  );
};
