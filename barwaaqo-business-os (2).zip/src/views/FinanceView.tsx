import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { money } from '../utils/helpers';
import { FinancialPulseWidget } from '../components/dashboard/FinancialPulseWidget';
import {
  Wallet,
  Landmark,
  Smartphone,
  Plus,
  ArrowRightLeft,
  Trash2,
  TrendingDown,
  Building,
  PieChart,
} from 'lucide-react';

export const FinanceView: React.FC = () => {
  const {
    db,
    totals,
    updateAccountBalance,
    transferBetweenAccounts,
    addExpense,
    deleteExpense,
    setIsCapitalModalOpen,
  } = useStore();

  // Expense form
  const [expenseTitle, setExpenseTitle] = useState('');
  const [expenseCategory, setExpenseCategory] = useState<
    'Rent' | 'Electricity' | 'Water' | 'Packaging' | 'Transport' | 'Salaries' | 'Cleaning' | 'Other'
  >('Packaging');
  const [expenseAmount, setExpenseAmount] = useState<number | ''>('');
  const [expenseAccount, setExpenseAccount] = useState<'cash' | 'bank' | 'telebirr'>('cash');

  // Transfer form
  const [fromAccount, setFromAccount] = useState<'cash' | 'bank' | 'telebirr'>('cash');
  const [toAccount, setToAccount] = useState<'cash' | 'bank' | 'telebirr'>('bank');
  const [transferAmount, setTransferAmount] = useState<number | ''>('');

  const handleAddExpense = (e: React.FormEvent) => {
    e.preventDefault();
    if (!expenseTitle.trim() || !expenseAmount || Number(expenseAmount) <= 0) return;

    const ok = addExpense(
      expenseTitle.trim(),
      expenseCategory,
      Number(expenseAmount),
      expenseAccount
    );

    if (ok) {
      setExpenseTitle('');
      setExpenseAmount('');
    }
  };

  const handleTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (!transferAmount || Number(transferAmount) <= 0) return;
    const ok = transferBetweenAccounts(fromAccount, toAccount, Number(transferAmount));
    if (ok) {
      setTransferAmount('');
    }
  };

  const cashBalance = db.accounts.Cash || 0;
  const bankBalance = db.accounts.Bank || 0;
  const telebirrBalance = db.accounts['Mobile Money'] || 0;

  const totalExpenses = db.expenses.reduce((a, e) => a + (e.amount || 0), 0);

  // Breakdown of expenses by category
  const expenseByCategory = db.expenses.reduce((acc, e) => {
    const cat = e.category || 'Other';
    acc[cat] = (acc[cat] || 0) + e.amount;
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900 text-white shadow-md border border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30">
              <Wallet className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white tracking-tight">
                Finance & Cash Flow Command
              </h2>
              <p className="text-[11px] text-slate-300">
                Multi-Account Liquidity, Operational Expenses & Founder Capital
              </p>
            </div>
          </div>
          <button
            onClick={() => setIsCapitalModalOpen(true)}
            className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white font-bold text-xs shadow-xs transition-all active:scale-95"
          >
            Capital Budget
          </button>
        </div>
      </div>

      {/* AI Financial Pulse Widget */}
      <FinancialPulseWidget />

      {/* Account Balances Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
        <div className="p-4 rounded-3xl bg-white border border-slate-200/90 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold uppercase text-slate-400">
              CASH DRAWER / REGISTER
            </span>
            <div className="p-1.5 rounded-lg bg-emerald-100 text-emerald-800">
              <Wallet className="w-4 h-4" />
            </div>
          </div>
          <span className="text-xl font-black text-slate-900 block">
            {money(cashBalance)}
          </span>
          <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-[11px]">
            <span className="text-slate-500">Physical shop cash</span>
            <button
              onClick={() => {
                const val = prompt('Set cash balance (ETB):', cashBalance.toString());
                if (val !== null && !isNaN(Number(val))) {
                  updateAccountBalance('cash', Number(val));
                }
              }}
              className="text-emerald-700 font-bold hover:underline"
            >
              Reconcile
            </button>
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-white border border-slate-200/90 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold uppercase text-slate-400">
              BANK ACCOUNT (CBE / AWASH)
            </span>
            <div className="p-1.5 rounded-lg bg-blue-100 text-blue-800">
              <Landmark className="w-4 h-4" />
            </div>
          </div>
          <span className="text-xl font-black text-slate-900 block">
            {money(bankBalance)}
          </span>
          <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-[11px]">
            <span className="text-slate-500">Commercial deposit</span>
            <button
              onClick={() => {
                const val = prompt('Set bank balance (ETB):', bankBalance.toString());
                if (val !== null && !isNaN(Number(val))) {
                  updateAccountBalance('bank', Number(val));
                }
              }}
              className="text-blue-700 font-bold hover:underline"
            >
              Reconcile
            </button>
          </div>
        </div>

        <div className="p-4 rounded-3xl bg-white border border-slate-200/90 shadow-xs space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-extrabold uppercase text-slate-400">
              TELEBIRR / MOBILE MONEY
            </span>
            <div className="p-1.5 rounded-lg bg-purple-100 text-purple-800">
              <Smartphone className="w-4 h-4" />
            </div>
          </div>
          <span className="text-xl font-black text-slate-900 block">
            {money(telebirrBalance)}
          </span>
          <div className="pt-2 border-t border-slate-100 flex justify-between items-center text-[11px]">
            <span className="text-slate-500">Merchant wallet</span>
            <button
              onClick={() => {
                const val = prompt('Set telebirr balance (ETB):', telebirrBalance.toString());
                if (val !== null && !isNaN(Number(val))) {
                  updateAccountBalance('telebirr', Number(val));
                }
              }}
              className="text-purple-700 font-bold hover:underline"
            >
              Reconcile
            </button>
          </div>
        </div>
      </div>

      {/* Transfer Funds Between Accounts */}
      <form
        onSubmit={handleTransfer}
        className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3"
      >
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <ArrowRightLeft className="w-4 h-4 text-slate-700" />
          <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
            Inter-Account Liquidity Transfer
          </h3>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 text-xs">
          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">From Account</label>
            <select
              value={fromAccount}
              onChange={(e) => setFromAccount(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            >
              <option value="cash">Cash Register ({money(cashBalance)})</option>
              <option value="bank">Bank Account ({money(bankBalance)})</option>
              <option value="telebirr">Telebirr ({money(telebirrBalance)})</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">To Account</label>
            <select
              value={toAccount}
              onChange={(e) => setToAccount(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            >
              <option value="bank">Bank Account ({money(bankBalance)})</option>
              <option value="cash">Cash Register ({money(cashBalance)})</option>
              <option value="telebirr">Telebirr ({money(telebirrBalance)})</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Transfer Amount (ETB)
            </label>
            <input
              type="number"
              min="1"
              step="any"
              value={transferAmount}
              onChange={(e) => setTransferAmount(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="e.g. 5000"
              required
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
          </div>

          <div className="flex items-end">
            <button
              type="submit"
              disabled={!transferAmount || Number(transferAmount) <= 0}
              className="w-full py-2 px-4 rounded-xl bg-slate-900 hover:bg-slate-800 disabled:opacity-50 text-xs font-black uppercase tracking-wider text-white transition-all shadow-xs"
            >
              Execute Transfer
            </button>
          </div>
        </div>
      </form>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Record Expense Form (7 cols) */}
        <div className="lg:col-span-7">
          <form
            onSubmit={handleAddExpense}
            className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Plus className="w-4 h-4 text-rose-600" />
                <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
                  Record Operating Expense
                </h3>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-rose-100 text-rose-800">
                DEDUCTS CASH & NET PROFIT
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Expense Description *
                </label>
                <input
                  id="expDesc"
                  type="text"
                  value={expenseTitle}
                  onChange={(e) => setExpenseTitle(e.target.value)}
                  placeholder="e.g. Shopping plastic bags 2 bundles"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-rose-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Category
                </label>
                <select
                  id="expCategory"
                  value={expenseCategory}
                  onChange={(e) => setExpenseCategory(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white focus:ring-2 focus:ring-rose-500 focus:outline-hidden"
                >
                  <option value="Packaging">Packaging (Bags, boxes)</option>
                  <option value="Electricity">Electricity & Utilities</option>
                  <option value="Water">Water Bill</option>
                  <option value="Transport">Transport & Fuel</option>
                  <option value="Rent">Shop Rent Payment</option>
                  <option value="Salaries">Staff / Helper Salaries</option>
                  <option value="Cleaning">Cleaning & Hygiene</option>
                  <option value="Other">Other Expenses</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Amount (ETB) *
                </label>
                <input
                  id="expAmount"
                  type="number"
                  min="1"
                  step="any"
                  value={expenseAmount}
                  onChange={(e) => setExpenseAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="e.g. 450"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold focus:ring-2 focus:ring-rose-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Paid From Account
                </label>
                <select
                  id="expAccount"
                  value={expenseAccount}
                  onChange={(e) => setExpenseAccount(e.target.value as any)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white focus:ring-2 focus:ring-rose-500 focus:outline-hidden"
                >
                  <option value="cash">Cash Drawer</option>
                  <option value="bank">Bank Account</option>
                  <option value="telebirr">Telebirr</option>
                </select>
              </div>
            </div>

            <button
              type="submit"
              disabled={!expenseTitle.trim() || !expenseAmount || Number(expenseAmount) <= 0}
              className="w-full py-2.5 px-4 rounded-xl bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-xs font-black uppercase tracking-wider text-white transition-all shadow-sm active:scale-98"
            >
              Post Expense
            </button>
          </form>
        </div>

        {/* Expenses by Category Breakdown (5 cols) */}
        <div className="lg:col-span-5">
          <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
                Expense Categorization
              </h3>
              <span className="font-black text-xs text-rose-600">
                Total: −{money(totalExpenses)}
              </span>
            </div>

            <div className="space-y-2">
              {Object.keys(expenseByCategory).length === 0 ? (
                <div className="py-6 text-center text-xs text-slate-400">
                  No operational expenses logged yet.
                </div>
              ) : (
                Object.entries(expenseByCategory).map(([cat, amt]) => {
                  const pct = totalExpenses > 0 ? (amt / totalExpenses) * 100 : 0;
                  return (
                    <div key={cat} className="space-y-1 text-xs">
                      <div className="flex justify-between items-center text-slate-700">
                        <span className="font-bold">{cat}</span>
                        <span>
                          {money(amt)}{' '}
                          <span className="text-[10px] text-slate-400">({pct.toFixed(0)}%)</span>
                        </span>
                      </div>
                      <div className="w-full h-1.5 bg-slate-100 rounded-full overflow-hidden">
                        <div
                          className="h-full bg-rose-500 rounded-full"
                          style={{ width: `${pct}%` }}
                        />
                      </div>
                    </div>
                  );
                })
              )}
            </div>
          </div>
        </div>
      </div>

      {/* Expenses History List */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
            Operating Expenses Ledger ({db.expenses.length})
          </h3>
        </div>

        <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
          {db.expenses.length === 0 ? (
            <div className="py-6 text-center text-xs text-slate-400">
              No operating expenses recorded yet.
            </div>
          ) : (
            db.expenses.map((exp) => (
              <div key={exp.id} className="py-2.5 flex items-center justify-between gap-2 text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-bold text-slate-900">{exp.title || exp.name}</span>
                    <span className="text-[10px] font-semibold px-1.5 py-0.2 rounded bg-slate-100 text-slate-600">
                      {exp.category || 'Expense'}
                    </span>
                    <span className="text-[10px] text-slate-400">{exp.date}</span>
                  </div>
                  <span className="text-[10px] text-slate-400">
                    Paid via {exp.account} account
                  </span>
                </div>

                <div className="flex items-center gap-3">
                  <span className="font-black text-xs text-rose-600">
                    −{money(exp.amount)}
                  </span>
                  <button
                    onClick={() => {
                      if (window.confirm(`Delete expense "${exp.title || exp.name}"?`)) {
                        deleteExpense(exp.id);
                      }
                    }}
                    className="p-1 text-slate-300 hover:text-rose-600 transition-colors"
                    title="Delete expense"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
