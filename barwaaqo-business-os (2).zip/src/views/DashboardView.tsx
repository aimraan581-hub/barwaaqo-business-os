import React, { useState, useEffect, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { money, todayLabel, day } from '../utils/helpers';
import { DashboardWidgetConfig, DashboardWidgetId } from '../types';
import {
  Calendar,
  Sliders,
  Pin,
  RotateCcw,
  RotateCw,
  BarChart2,
  TrendingUp,
  Package,
  Wallet,
  Landmark,
  AlertTriangle,
  Sparkles,
  CheckCircle2,
  Zap,
  Truck,
  ArrowRight,
  DollarSign,
  Boxes,
  Target,
} from 'lucide-react';

import { WidgetCard } from '../components/dashboard/WidgetCard';
import { RevenueVelocityWidget } from '../components/dashboard/RevenueVelocityWidget';
import { FinancialKpisWidget } from '../components/dashboard/FinancialKpisWidget';
import { DailyPerformanceWidget } from '../components/dashboard/DailyPerformanceWidget';
import { LiquidityAccountsWidget } from '../components/dashboard/LiquidityAccountsWidget';
import { InventoryHealthWidget } from '../components/dashboard/InventoryHealthWidget';
import { CapitalTrackingWidget } from '../components/dashboard/CapitalTrackingWidget';
import { CeoAlertsWidget } from '../components/dashboard/CeoAlertsWidget';
import { AiInsightsWidget } from '../components/dashboard/AiInsightsWidget';
import { DailyChecklistWidget } from '../components/dashboard/DailyChecklistWidget';
import { QuickActionsWidget } from '../components/dashboard/QuickActionsWidget';
import { CustomizeDashboardModal } from '../components/dashboard/CustomizeDashboardModal';
import { FinancialPulseWidget } from '../components/dashboard/FinancialPulseWidget';

const STORAGE_KEY = 'imruu_ceo_widget_layout_v18';

const DEFAULT_WIDGETS: DashboardWidgetConfig[] = [
  {
    id: 'financial_pulse',
    title: 'AI Financial Pulse',
    subtitle: 'AI-driven natural language summary of business performance',
    category: 'financial',
    isPinned: true,
    isVisible: true,
    order: -1, // Keep it at the top
  },
  {
    id: 'daily_performance',
    title: 'Daily Performance & Target',
    subtitle: 'Track live sales progress versus CEO daily target with run-rate pacing',
    category: 'financial',
    isPinned: true,
    isVisible: true,
    order: 0,
  },
  {
    id: 'financial_kpis',
    title: "Today's Live Performance",
    subtitle: 'Real-time sales, net profit, customer receivables, and supplier payables',
    category: 'financial',
    isPinned: true,
    isVisible: true,
    order: 1,
  },
  {
    id: 'revenue_velocity',
    title: 'Daily Revenue Trends (Current Week)',
    subtitle: 'Recharts interactive daily revenue line chart, profit trajectory, and week-over-week growth',
    category: 'financial',
    isPinned: true,
    isVisible: true,
    order: 1,
  },
  {
    id: 'inventory_health',
    title: 'Stock Valuation & Restock',
    subtitle: 'Warehouse valuation at purchase cost, retail yield potential, and critical thresholds',
    category: 'inventory',
    isPinned: false,
    isVisible: true,
    order: 2,
  },
  {
    id: 'liquidity_accounts',
    title: 'Multi-Vault Liquidity & Accounts',
    subtitle: 'Cash in drawer, Commercial Bank of Ethiopia (CBE), Awash Bank, and Telebirr',
    category: 'financial',
    isPinned: false,
    isVisible: true,
    order: 3,
  },
  {
    id: 'capital_tracking',
    title: 'Founder Capital Deployment (ETB 200,000)',
    subtitle: 'Founding capital deployment across equipment, renovations, stock, and lease',
    category: 'strategy',
    isPinned: false,
    isVisible: true,
    order: 4,
  },
  {
    id: 'ceo_alerts',
    title: 'Priority Action Alerts',
    subtitle: 'Urgent stock alerts, uncollected client debts, and supplier balances',
    category: 'operations',
    isPinned: false,
    isVisible: true,
    order: 5,
  },
  {
    id: 'ai_insights',
    title: 'Executive Intelligence & Recommendations',
    subtitle: 'Top sales volume drivers, highest gross margin products, and capital concentration',
    category: 'strategy',
    isPinned: false,
    isVisible: true,
    order: 6,
  },
  {
    id: 'daily_checklist',
    title: 'Daily Executive Verification',
    subtitle: 'End-of-day cash reconciliation, inventory audit, and restocking priorities',
    category: 'operations',
    isPinned: false,
    isVisible: true,
    order: 7,
  },
  {
    id: 'quick_actions',
    title: 'Executive Quick Launch',
    subtitle: 'Instant shortcuts to counter POS, stock inventory, vendor purchasing, and customer debt',
    category: 'operations',
    isPinned: false,
    isVisible: true,
    order: 8,
  },
];

export const DashboardView: React.FC = () => {
  const { db, totals, refreshData, showToast, setActiveTab, businessProfile } = useStore();
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastRefreshed, setLastRefreshed] = useState<Date>(new Date());
  const [refreshKey, setRefreshKey] = useState(0);

  // Real-time Quick Snapshot Metrics
  const todayKey = day();
  const todaySales = useMemo(() => {
    return (db.sales || []).filter((s) => s.date === todayKey);
  }, [db.sales, todayKey]);

  const todayRevenue = useMemo(() => {
    return todaySales.reduce((acc, s) => acc + (s.total || 0), 0);
  }, [todaySales]);

  const todayGrossProfit = useMemo(() => {
    return todaySales.reduce((acc, s) => acc + (s.profit || 0), 0);
  }, [todaySales]);

  const pendingOrders = useMemo(() => {
    return (db.orders || []).filter(
      (o) => o.status !== 'PAID' && o.status !== 'DELIVERED'
    );
  }, [db.orders]);

  const pendingOrdersBalance = useMemo(() => {
    return pendingOrders.reduce(
      (acc, o) => acc + (o.balance ?? (o.total - (o.paid || 0))),
      0
    );
  }, [pendingOrders]);

  const totalActiveSkus = db.products?.length || 0;
  const inStockSkus = useMemo(() => {
    return (db.products || []).filter((p) => (p.stock || 0) > 0).length;
  }, [db.products]);
  const lowStockSkus = useMemo(() => {
    return (db.products || []).filter(
      (p) => (p.stock || 0) > 0 && (p.stock || 0) <= (p.min || 0)
    ).length;
  }, [db.products]);

  const [widgets, setWidgets] = useState<DashboardWidgetConfig[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved) as DashboardWidgetConfig[];
        // Merge with DEFAULT_WIDGETS in case new widgets were added
        const validIds = new Set(DEFAULT_WIDGETS.map((w) => w.id));
        const merged = parsed.filter((w) => validIds.has(w.id));
        DEFAULT_WIDGETS.forEach((def) => {
          if (!merged.some((m) => m.id === def.id)) {
            merged.push(def);
          }
        });
        return merged.sort((a, b) => a.order - b.order);
      }
    } catch {
      // ignore
    }
    return DEFAULT_WIDGETS;
  });

  const [isCustomizeOpen, setIsCustomizeOpen] = useState(false);

  // Save to localStorage whenever widgets change
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(widgets));
    } catch {
      // ignore
    }
  }, [widgets]);

  // Handler to toggle pin
  const handleTogglePin = (id: DashboardWidgetId) => {
    setWidgets((prev) =>
      prev.map((w) => (w.id === id ? { ...w, isPinned: !w.isPinned } : w))
    );
  };

  // Handler to toggle visibility
  const handleToggleVisibility = (id: DashboardWidgetId) => {
    setWidgets((prev) =>
      prev.map((w) => (w.id === id ? { ...w, isVisible: !w.isVisible } : w))
    );
  };

  // Handler to move widget up in order
  const handleMoveUp = (id: DashboardWidgetId) => {
    setWidgets((prev) => {
      const sorted = [...prev].sort((a, b) => a.order - b.order);
      const index = sorted.findIndex((w) => w.id === id);
      if (index <= 0) return prev;

      // Swap orders
      const temp = sorted[index].order;
      sorted[index].order = sorted[index - 1].order;
      sorted[index - 1].order = temp;

      return [...sorted].sort((a, b) => a.order - b.order);
    });
  };

  // Handler to move widget down in order
  const handleMoveDown = (id: DashboardWidgetId) => {
    setWidgets((prev) => {
      const sorted = [...prev].sort((a, b) => a.order - b.order);
      const index = sorted.findIndex((w) => w.id === id);
      if (index === -1 || index >= sorted.length - 1) return prev;

      // Swap orders
      const temp = sorted[index].order;
      sorted[index].order = sorted[index + 1].order;
      sorted[index + 1].order = temp;

      return [...sorted].sort((a, b) => a.order - b.order);
    });
  };

  // Reset to default
  const handleResetLayout = () => {
    setWidgets(DEFAULT_WIDGETS);
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  };

  // Manual Refresh All Widgets
  const handleRefreshAll = async () => {
    if (isRefreshing) return;
    setIsRefreshing(true);
    try {
      await refreshData();
      setRefreshKey((prev) => prev + 1);
      setLastRefreshed(new Date());
      showToast('All active widgets and financial metrics refreshed');
    } catch (e) {
      console.error('Error refreshing widgets', e);
      showToast('Error refreshing widgets');
    } finally {
      setTimeout(() => {
        setIsRefreshing(false);
      }, 600);
    }
  };

  // Icon mapping for widgets
  const widgetIcons: Record<DashboardWidgetId, any> = {
    daily_performance: Target,
    financial_kpis: TrendingUp,
    revenue_velocity: BarChart2,
    inventory_health: Package,
    liquidity_accounts: Wallet,
    capital_tracking: Landmark,
    ceo_alerts: AlertTriangle,
    ai_insights: Sparkles,
    daily_checklist: CheckCircle2,
    quick_actions: Zap,
    financial_pulse: Sparkles,
  };

  // Render individual widget component based on ID
  const renderWidgetContent = (id: DashboardWidgetId) => {
    switch (id) {
      case 'daily_performance':
        return <DailyPerformanceWidget />;
      case 'financial_pulse':
        return <FinancialPulseWidget />;
      case 'financial_kpis':
        return <FinancialKpisWidget />;
      case 'revenue_velocity':
        return <RevenueVelocityWidget />;
      case 'inventory_health':
        return <InventoryHealthWidget />;
      case 'liquidity_accounts':
        return <LiquidityAccountsWidget />;
      case 'capital_tracking':
        return <CapitalTrackingWidget />;
      case 'ceo_alerts':
        return <CeoAlertsWidget />;
      case 'ai_insights':
        return <AiInsightsWidget />;
      case 'daily_checklist':
        return <DailyChecklistWidget />;
      case 'quick_actions':
        return <QuickActionsWidget />;
      default:
        return null;
    }
  };

  // Sorted and filtered widget lists
  const sortedWidgets = useMemo(() => {
    return [...widgets].sort((a, b) => a.order - b.order);
  }, [widgets]);

  const pinnedWidgets = useMemo(() => {
    return sortedWidgets.filter((w) => w.isPinned && w.isVisible);
  }, [sortedWidgets]);

  const visibleWidgets = useMemo(() => {
    return sortedWidgets.filter((w) => w.isVisible);
  }, [sortedWidgets]);

  return (
    <div className="space-y-5 pb-16">
      {/* Hero Banner */}
      <div className="relative overflow-hidden rounded-3xl p-5 sm:p-6 text-white bg-gradient-to-br from-[#021810] via-[#054329] to-[#0a663d] shadow-xl border border-emerald-800/40">
        <div className="absolute top-0 right-0 -mt-10 -mr-10 w-44 h-44 rounded-full bg-emerald-400/10 blur-2xl pointer-events-none" />
        <div className="relative z-10 flex flex-col justify-between">
          <div className="flex items-center justify-between">
            <span className="text-[10px] uppercase tracking-widest font-black text-emerald-300 px-2.5 py-0.5 rounded-full bg-emerald-950/60 border border-emerald-400/20">
              V18 · CEO Command Center
            </span>
            <span className="text-xs text-emerald-200/90 font-semibold flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-emerald-400" />
              {todayLabel()}
            </span>
          </div>

          <div className="mt-3 flex flex-col sm:flex-row sm:items-end justify-between gap-4">
            <div>
              <h2 className="text-xl sm:text-2xl font-black tracking-tight text-white drop-shadow-xs uppercase">
                {businessProfile.storeName ? `${businessProfile.storeName} COMMAND CENTER` : 'BARWAAQO CEO COMMAND CENTER'}
              </h2>
              <p className="text-xs text-emerald-100/80 mt-1 max-w-lg leading-relaxed">
                Executive oversight for enterprise commerce, distribution, multi-tier tax compliance, and stock intelligence.
              </p>
              <div className="mt-2 flex items-center gap-2 text-[11px] text-emerald-300/80">
                <span className="inline-block w-2 h-2 rounded-full bg-emerald-400 animate-pulse" />
                <span>
                  Synchronized: {lastRefreshed.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
                </span>
              </div>
            </div>

            {/* Action Buttons: Refresh All Widgets + Customize Dashboard */}
            <div className="flex items-center gap-2 self-start sm:self-auto flex-wrap">
              <button
                id="btn-refresh-widgets"
                onClick={handleRefreshAll}
                disabled={isRefreshing}
                title="Fetch fresh data & recalculate all active widgets"
                className={`px-3.5 py-2 rounded-2xl font-bold text-xs border transition-all flex items-center gap-2 active:scale-95 shadow-xs backdrop-blur-xs ${
                  isRefreshing
                    ? 'bg-emerald-400 text-slate-950 border-emerald-300 font-black cursor-wait'
                    : 'bg-white/10 hover:bg-white/20 text-white border-white/20'
                }`}
              >
                <RotateCw
                  className={`w-4 h-4 ${isRefreshing ? 'animate-spin text-slate-950' : 'text-emerald-300'}`}
                />
                <span>{isRefreshing ? 'Refreshing Widgets...' : 'Refresh All Widgets'}</span>
              </button>

              <button
                id="btn-customize-dashboard"
                onClick={() => setIsCustomizeOpen(true)}
                className="px-3.5 py-2 rounded-2xl bg-white/10 hover:bg-white/20 text-white font-bold text-xs border border-white/20 transition-all flex items-center gap-2 active:scale-95 shadow-xs backdrop-blur-xs"
              >
                <Sliders className="w-4 h-4 text-emerald-300" />
                <span>Customize</span>
                {pinnedWidgets.length > 0 && (
                  <span className="px-1.5 py-0.2 rounded-full bg-emerald-400 text-slate-950 text-[10px] font-black">
                    {pinnedWidgets.length} pinned
                  </span>
                )}
              </button>
            </div>
          </div>

          {/* Quick Snapshot Bar */}
          <div id="dashboard-quick-snapshot-bar" className="mt-5 pt-4 border-t border-emerald-500/25">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-2">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-400"></span>
                </span>
                <span className="text-xs font-black uppercase tracking-wider text-emerald-300">
                  Quick Snapshot
                </span>
                <span className="text-[10px] text-emerald-200/70 font-medium hidden sm:inline">
                  · Real-time operational totals
                </span>
              </div>
              <span className="text-[10px] text-emerald-300/80 font-mono bg-emerald-950/70 px-2 py-0.5 rounded-full border border-emerald-400/20">
                Live Pulse
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
              {/* 1. Today's Revenue */}
              <div
                id="snapshot-today-revenue"
                onClick={() => setActiveTab('pos')}
                title="Click to launch POS counter & view daily invoices"
                className="group cursor-pointer p-4 rounded-2xl bg-gradient-to-br from-emerald-950/70 to-emerald-900/40 hover:from-emerald-900/80 hover:to-emerald-800/50 border border-emerald-400/30 hover:border-emerald-400/60 transition-all backdrop-blur-md shadow-sm relative overflow-hidden active:scale-[0.99]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-xl bg-emerald-400/20 text-emerald-300 border border-emerald-400/30 group-hover:scale-105 transition-transform">
                      <TrendingUp className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-200">
                      Today's Revenue
                    </span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-emerald-400/60 group-hover:text-emerald-300 group-hover:translate-x-0.5 transition-all" />
                </div>
                <div className="mt-2.5">
                  <div className="text-xl sm:text-2xl font-black tracking-tight text-white drop-shadow-xs">
                    {money(todayRevenue)}
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-emerald-200/80 mt-1">
                    <span>{todaySales.length} {todaySales.length === 1 ? 'sale' : 'sales'} today</span>
                    {todayRevenue > 0 && (
                      <span className="font-semibold text-emerald-300">
                        {money(todayGrossProfit)} gross profit
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* 2. Pending Orders */}
              <div
                id="snapshot-pending-orders"
                onClick={() => setActiveTab('distribution')}
                title="Click to view distribution orders & delivery dispatch"
                className="group cursor-pointer p-4 rounded-2xl bg-gradient-to-br from-emerald-950/70 to-emerald-900/40 hover:from-emerald-900/80 hover:to-emerald-800/50 border border-emerald-400/30 hover:border-emerald-400/60 transition-all backdrop-blur-md shadow-sm relative overflow-hidden active:scale-[0.99]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-xl bg-amber-400/20 text-amber-300 border border-amber-400/30 group-hover:scale-105 transition-transform">
                      <Truck className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-200">
                      Pending Orders
                    </span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-emerald-400/60 group-hover:text-emerald-300 group-hover:translate-x-0.5 transition-all" />
                </div>
                <div className="mt-2.5">
                  <div className="text-xl sm:text-2xl font-black tracking-tight text-white drop-shadow-xs flex items-baseline gap-2">
                    <span>{pendingOrders.length}</span>
                    <span className="text-xs font-semibold text-amber-300 uppercase tracking-normal">
                      {pendingOrders.length === 1 ? 'Order' : 'Orders'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-emerald-200/80 mt-1">
                    <span>{money(pendingOrdersBalance)} pending</span>
                    <span className="font-semibold text-amber-300">
                      {pendingOrders.filter((o) => o.status === 'OUT FOR DELIVERY' || o.status === 'OUT_FOR_DELIVERY').length > 0
                        ? `${pendingOrders.filter((o) => o.status === 'OUT FOR DELIVERY' || o.status === 'OUT_FOR_DELIVERY').length} in transit`
                        : 'Awaiting dispatch'}
                    </span>
                  </div>
                </div>
              </div>

              {/* 3. Total Active SKUs */}
              <div
                id="snapshot-active-skus"
                onClick={() => setActiveTab('inventory')}
                title="Click to view stock inventory & warehouse levels"
                className="group cursor-pointer p-4 rounded-2xl bg-gradient-to-br from-emerald-950/70 to-emerald-900/40 hover:from-emerald-900/80 hover:to-emerald-800/50 border border-emerald-400/30 hover:border-emerald-400/60 transition-all backdrop-blur-md shadow-sm relative overflow-hidden active:scale-[0.99]"
              >
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <div className="p-2 rounded-xl bg-teal-400/20 text-teal-300 border border-teal-400/30 group-hover:scale-105 transition-transform">
                      <Package className="w-4 h-4" />
                    </div>
                    <span className="text-xs font-extrabold uppercase tracking-wider text-emerald-200">
                      Total Active SKUs
                    </span>
                  </div>
                  <ArrowRight className="w-4 h-4 text-emerald-400/60 group-hover:text-emerald-300 group-hover:translate-x-0.5 transition-all" />
                </div>
                <div className="mt-2.5">
                  <div className="text-xl sm:text-2xl font-black tracking-tight text-white drop-shadow-xs flex items-baseline gap-2">
                    <span>{totalActiveSkus}</span>
                    <span className="text-xs font-semibold text-teal-300 uppercase tracking-normal">
                      Active SKUs
                    </span>
                  </div>
                  <div className="flex items-center justify-between text-[11px] text-emerald-200/80 mt-1">
                    <span>{inStockSkus} in stock</span>
                    <span className={`font-semibold ${lowStockSkus > 0 ? 'text-amber-300' : 'text-emerald-300'}`}>
                      {lowStockSkus > 0 ? `${lowStockSkus} low stock` : 'Healthy stock'}
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Quick Stats Bar */}
          <div className="mt-4 pt-3.5 border-t border-emerald-700/40 flex flex-wrap items-center justify-between gap-3 text-xs">
            <div>
              <span className="text-emerald-300/80 text-[10px] font-bold block uppercase tracking-wider">
                Current Working Capital
              </span>
              <span className="text-base sm:text-lg font-black text-white">
                {money(totals.workingCapital)}
              </span>
            </div>
            <div>
              <span className="text-emerald-300/80 text-[10px] font-bold block uppercase tracking-wider">
                Cash in Accounts
              </span>
              <span className="text-base sm:text-lg font-black text-emerald-200">
                {money(totals.cash)}
              </span>
            </div>
            <div>
              <span className="text-emerald-300/80 text-[10px] font-bold block uppercase tracking-wider">
                Stock Value (Cost)
              </span>
              <span className="text-base sm:text-lg font-black text-amber-200">
                {money(totals.stock)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* PINNED PRIORITY WIDGETS SECTION */}
      {pinnedWidgets.length > 0 && (
        <section className="space-y-3">
          <div className="flex items-center justify-between px-1">
            <div className="flex items-center gap-2">
              <div className="p-1 rounded-lg bg-emerald-600 text-white">
                <Pin className="w-3.5 h-3.5" />
              </div>
              <h2 className="text-xs font-black uppercase tracking-wider text-slate-800">
                Pinned Executive Focus
              </h2>
              <span className="px-2 py-0.2 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black">
                {pinnedWidgets.length} Priority {pinnedWidgets.length === 1 ? 'Chart' : 'Charts'}
              </span>
            </div>
            <span className="text-[11px] text-slate-400 hidden sm:inline">
              Your primary financial & inventory monitors
            </span>
          </div>

          <div className="space-y-4">
            {pinnedWidgets.map((widget, idx) => {
              const canMoveUp = idx > 0;
              const canMoveDown = idx < pinnedWidgets.length - 1;

              return (
                <WidgetCard
                  key={`pinned-${widget.id}-${refreshKey}`}
                  id={widget.id}
                  title={widget.title}
                  subtitle={widget.subtitle}
                  category={widget.category}
                  isPinned={true}
                  isRefreshing={isRefreshing}
                  onTogglePin={handleTogglePin}
                  onMoveUp={handleMoveUp}
                  onMoveDown={handleMoveDown}
                  canMoveUp={canMoveUp}
                  canMoveDown={canMoveDown}
                  icon={widgetIcons[widget.id]}
                  badge="PINNED FOCUS"
                  badgeColor="bg-emerald-600 text-white"
                >
                  {renderWidgetContent(widget.id)}
                </WidgetCard>
              );
            })}
          </div>
        </section>
      )}

      {/* ALL EXECUTIVE DASHBOARD MODULES (REORDERABLE) */}
      <section className="space-y-3 pt-2">
        <div className="flex items-center justify-between px-1">
          <div className="flex items-center gap-2">
            <h2 className="text-xs font-black uppercase tracking-wider text-slate-700">
              {pinnedWidgets.length > 0 ? 'All Dashboard Modules' : 'CEO Operations & Financials'}
            </h2>
            <span className="text-[11px] text-slate-400 font-medium">
              ({visibleWidgets.length} active cards)
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={handleRefreshAll}
              disabled={isRefreshing}
              title="Refresh all widgets"
              className="text-xs font-bold text-slate-500 hover:text-emerald-700 flex items-center gap-1 transition p-1 rounded-md"
            >
              <RotateCw className={`w-3.5 h-3.5 ${isRefreshing ? 'animate-spin text-emerald-600' : ''}`} />
              <span className="hidden sm:inline">Sync Data</span>
            </button>

            <button
              onClick={() => setIsCustomizeOpen(true)}
              className="text-xs font-bold text-emerald-700 hover:text-emerald-900 flex items-center gap-1 transition"
            >
              <Sliders className="w-3.5 h-3.5" />
              <span>Reorder & Filter</span>
            </button>
          </div>
        </div>

        <div className="space-y-4">
          {visibleWidgets.map((widget, idx) => {
            const canMoveUp = idx > 0;
            const canMoveDown = idx < visibleWidgets.length - 1;

            return (
              <WidgetCard
                key={`${widget.id}-${refreshKey}`}
                id={widget.id}
                title={widget.title}
                subtitle={widget.subtitle}
                category={widget.category}
                isPinned={widget.isPinned}
                isRefreshing={isRefreshing}
                onTogglePin={handleTogglePin}
                onMoveUp={handleMoveUp}
                onMoveDown={handleMoveDown}
                canMoveUp={canMoveUp}
                canMoveDown={canMoveDown}
                icon={widgetIcons[widget.id]}
              >
                {renderWidgetContent(widget.id)}
              </WidgetCard>
            );
          })}
        </div>
      </section>

      {/* Customize Dashboard Modal */}
      <CustomizeDashboardModal
        isOpen={isCustomizeOpen}
        onClose={() => setIsCustomizeOpen(false)}
        widgets={sortedWidgets}
        onTogglePin={handleTogglePin}
        onToggleVisibility={handleToggleVisibility}
        onMoveUp={handleMoveUp}
        onMoveDown={handleMoveDown}
        onResetLayout={handleResetLayout}
      />
    </div>
  );
};
