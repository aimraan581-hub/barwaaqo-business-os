import React, { useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { money } from '../utils/helpers';
import {
  BarChart3,
  Download,
  Upload,
  RefreshCw,
  TrendingUp,
  AlertCircle,
  FileSpreadsheet,
  Award,
  ShieldCheck,
  QrCode,
  Calendar,
  Settings,
  Receipt,
  FileCheck,
} from 'lucide-react';
import { generateMonthlyTaxReport, exportMonthlyTaxReportCSV } from '../utils/taxEngine';

export const ReportsView: React.FC = () => {
  const {
    db,
    totals,
    exportBackup,
    importBackup,
    resetToDefault,
    setProductQrModalId,
    setIsTaxModalOpen,
    setIsMonthlyTaxReportModalOpen,
    selectedTaxReportMonth,
    setSelectedTaxReportMonth,
    taxSettings,
  } = useStore();

  // Monthly Tax Report calculation for the selected month
  const monthlyTax = useMemo(() => {
    return generateMonthlyTaxReport(
      db.sales || [],
      selectedTaxReportMonth.year,
      selectedTaxReportMonth.month,
      taxSettings,
      db.products || []
    );
  }, [db.sales, selectedTaxReportMonth, taxSettings, db.products]);

  // P&L Metrics
  const pl = useMemo(() => {
    const totalRevenue = (db.sales || []).reduce((a, s) => a + (s.total || 0), 0);
    const grossProfit = (db.sales || []).reduce((a, s) => a + (s.profit || 0), 0);
    const cogs = Math.max(0, totalRevenue - grossProfit);
    const totalExpenses = (db.expenses || []).reduce((a, e) => a + (e.amount || 0), 0);
    const netProfit = grossProfit - totalExpenses;
    const marginPct = totalRevenue > 0 ? (netProfit / totalRevenue) * 100 : 0;

    return { totalRevenue, cogs, grossProfit, totalExpenses, netProfit, marginPct };
  }, [db.sales, db.expenses]);

  // Product sales performance ranking
  const productPerformance = useMemo(() => {
    const map: Record<
      string,
      { pid: string; name: string; qty: number; revenue: number; profit: number }
    > = {};

    (db.sales || []).forEach((s) => {
      (s.items || []).forEach((item) => {
        const key = item.pid || item.name;
        if (!map[key]) {
          map[key] = { pid: item.pid, name: item.name, qty: 0, revenue: 0, profit: 0 };
        }
        map[key].qty += item.qty || 0;
        map[key].revenue += (item.qty || 0) * (item.price || 0);
      });
    });

    return Object.values(map).sort((a, b) => b.revenue - a.revenue);
  }, [db.sales]);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      const content = event.target?.result as string;
      if (content) {
        importBackup(content);
      }
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900 text-white shadow-md border border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30">
              <BarChart3 className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white tracking-tight">
                Executive Reports & Intelligence
              </h2>
              <p className="text-[11px] text-slate-300">
                P&L Statement, Product Sales Ranking, Audit Integrity & Data Backup
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* Comprehensive Income Statement (P&L) */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <TrendingUp className="w-4 h-4 text-emerald-700" />
            <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
              Executive Profit & Loss Statement (P&L)
            </h3>
          </div>
          <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
            AUDITED
          </span>
        </div>

        <div className="divide-y divide-slate-100 text-xs">
          <div className="py-2.5 flex justify-between items-center text-slate-800 font-bold">
            <span>Total Sales Revenue:</span>
            <span className="text-sm font-black text-slate-900">{money(pl.totalRevenue)}</span>
          </div>

          <div className="py-2.5 flex justify-between items-center text-slate-600">
            <span>Cost of Goods Sold (Procurement Cost):</span>
            <span className="font-bold text-slate-800">−{money(pl.cogs)}</span>
          </div>

          <div className="py-2.5 flex justify-between items-center bg-slate-50/70 px-2 rounded-xl text-slate-900 font-black">
            <span>Gross Trading Profit:</span>
            <span className="text-emerald-700 font-black">{money(pl.grossProfit)}</span>
          </div>

          <div className="py-2.5 flex justify-between items-center text-slate-600">
            <span>Operating Overhead & Shop Expenses:</span>
            <span className="font-bold text-rose-600">−{money(pl.totalExpenses)}</span>
          </div>

          <div className="py-3 flex justify-between items-center bg-emerald-50 px-3 rounded-2xl text-emerald-950 font-black text-sm">
            <span>Net Operating Business Profit:</span>
            <div className="text-right">
              <span className="text-emerald-800 text-base">{money(pl.netProfit)}</span>
              <span className="text-[10px] block font-bold text-emerald-600">
                {pl.marginPct.toFixed(1)}% Net Margin
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Monthly Statutory Tax Summary & Compliance Report */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-100">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-xl bg-emerald-50 text-emerald-700 border border-emerald-200">
              <FileSpreadsheet className="w-5 h-5" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
                  Monthly Tax Summary & Audit Report
                </h3>
                <span className="text-[10px] font-black uppercase px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
                  {monthlyTax.taxLabel} Statutory
                </span>
              </div>
              <p className="text-[11px] text-slate-500">
                Multi-tier tax liability, net taxable turnover & fiscal audit reconciliation for {monthlyTax.periodLabel}
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="reports-open-tax-settings-btn"
              onClick={() => setIsTaxModalOpen(true)}
              className="px-2.5 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-semibold flex items-center gap-1.5 transition-colors"
              title="Configure Tax Rates & Tiers"
            >
              <Settings className="w-3.5 h-3.5 text-slate-500" />
              <span>Tax Settings</span>
            </button>
            <button
              id="reports-view-full-tax-report-btn"
              onClick={() => setIsMonthlyTaxReportModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold flex items-center gap-1.5 transition-colors shadow-xs"
            >
              <FileCheck className="w-3.5 h-3.5" />
              <span>Full Audit Report & Print</span>
            </button>
          </div>
        </div>

        {/* Tax Summary Metrics Cards */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          <div className="p-3 rounded-2xl bg-emerald-50/70 border border-emerald-200/80">
            <div className="text-[11px] font-bold text-emerald-900">Output Tax Collected</div>
            <div className="text-base sm:text-lg font-black text-emerald-800 mt-1">
              {money(monthlyTax.totalTaxCollected)}
            </div>
            <div className="text-[10px] text-emerald-700 mt-0.5">
              Net statutory liability
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="text-[11px] font-bold text-slate-700">Net Taxable Base</div>
            <div className="text-base sm:text-lg font-black text-slate-900 mt-1">
              {money(monthlyTax.totalNetTaxableBase)}
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">
              Subject to multi-tier rates
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-amber-50/70 border border-amber-200/80">
            <div className="text-[11px] font-bold text-amber-900">Zero-Rated / Exempt</div>
            <div className="text-base sm:text-lg font-black text-amber-900 mt-1">
              {money(monthlyTax.totalExemptSales)}
            </div>
            <div className="text-[10px] text-amber-800 mt-0.5">
              Essential staples (0%)
            </div>
          </div>

          <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200">
            <div className="text-[11px] font-bold text-slate-700">Effective Tax Rate</div>
            <div className="text-base sm:text-lg font-black text-slate-900 mt-1">
              {monthlyTax.effectiveTaxRate.toFixed(2)}%
            </div>
            <div className="text-[10px] text-slate-500 mt-0.5">
              Across {monthlyTax.totalTransactions} audited sales
            </div>
          </div>
        </div>

        {/* Multi-Tier Summary Breakdown Table */}
        <div className="border border-slate-100 rounded-2xl overflow-hidden">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="bg-slate-50 text-slate-600 font-bold border-b border-slate-100">
                <th className="py-2 px-3">Tax Tier Name</th>
                <th className="py-2 px-3">Statutory Code</th>
                <th className="py-2 px-3">Rate</th>
                <th className="py-2 px-3 text-right">Net Taxable Base</th>
                <th className="py-2 px-3 text-right">Tax Collected</th>
                <th className="py-2 px-3 text-right">Gross Sales</th>
                <th className="py-2 px-3 text-right">Share</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 text-[11px]">
              {monthlyTax.tierBreakdown.map((t) => (
                <tr key={t.tierId} className="hover:bg-slate-50/50">
                  <td className="py-2 px-3 font-semibold text-slate-900">
                    {t.name}
                    {t.isExempt && (
                      <span className="ml-1.5 px-1 py-0.2 rounded bg-amber-100 text-amber-800 text-[9px] font-bold">
                        EXEMPT
                      </span>
                    )}
                  </td>
                  <td className="py-2 px-3 font-mono text-slate-600">{t.code}</td>
                  <td className="py-2 px-3 font-bold text-slate-800">{t.rate}%</td>
                  <td className="py-2 px-3 text-right text-slate-700">{money(t.taxableBase)}</td>
                  <td className="py-2 px-3 text-right font-black text-emerald-700">{money(t.taxCollected)}</td>
                  <td className="py-2 px-3 text-right text-slate-800">{money(t.grossSales)}</td>
                  <td className="py-2 px-3 text-right font-bold text-slate-600">
                    {t.shareOfTotalTax.toFixed(1)}%
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {/* Export & Actions Footer */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 pt-2">
          <div className="text-xs text-slate-500">
            TIN: <strong className="font-mono text-slate-800">{monthlyTax.tin}</strong> · Entity: <strong className="text-slate-800">{monthlyTax.businessName}</strong>
          </div>
          <div className="flex items-center gap-2">
            <button
              id="reports-export-tax-csv-btn"
              onClick={() => exportMonthlyTaxReportCSV(monthlyTax)}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-slate-600" />
              <span>Download Tax CSV</span>
            </button>
            <button
              id="reports-open-monthly-tax-modal-btn"
              onClick={() => setIsMonthlyTaxReportModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 text-xs font-bold flex items-center gap-1.5 transition-colors"
            >
              <Receipt className="w-3.5 h-3.5 text-emerald-700" />
              <span>Inspect All Audited Invoices ({monthlyTax.totalTransactions})</span>
            </button>
          </div>
        </div>
      </div>

      {/* Product Contribution Ranking */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Award className="w-4 h-4 text-emerald-700" />
            <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
              Product Revenue & Volume Ranking
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">
            {productPerformance.length} products sold
          </span>
        </div>

        <div className="divide-y divide-slate-100 max-h-72 overflow-y-auto">
          {productPerformance.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              No sales recorded yet to build rankings. Complete sales in POS to view performance.
            </div>
          ) : (
            productPerformance.map((prod, idx) => (
              <div key={prod.name} className="py-2.5 flex items-center justify-between text-xs">
                <div className="flex items-center gap-2.5">
                  <span className="w-5 h-5 rounded-full bg-slate-100 flex items-center justify-center font-bold text-[10px] text-slate-600">
                    {idx + 1}
                  </span>
                  <div>
                    <span className="font-bold text-slate-900">{prod.name}</span>
                    <span className="text-[11px] text-slate-400 ml-2">
                      {prod.qty} units sold
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-3">
                  <div className="text-right">
                    <span className="font-black text-slate-900 block">
                      {money(prod.revenue)}
                    </span>
                  </div>
                  {prod.pid && (
                    <button
                      onClick={() => setProductQrModalId(prod.pid)}
                      className="p-1.5 rounded-lg bg-slate-100 hover:bg-emerald-100 text-slate-600 hover:text-emerald-900 transition"
                      title="View QR Label & Stock History Ledger"
                    >
                      <QrCode className="w-3.5 h-3.5 text-emerald-600" />
                    </button>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Data Protection & Backup / Restore */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
          <ShieldCheck className="w-4 h-4 text-emerald-700" />
          <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
            Database Backup & System Recovery
          </h3>
        </div>

        <p className="text-xs text-slate-500 leading-relaxed">
          Export your complete store database (inventory, accounts, ledgers, and transactions) into an offline JSON backup file, or restore from a previous save.
        </p>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
          <button
            onClick={exportBackup}
            className="p-3.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs flex items-center justify-center gap-2 shadow-xs transition-all active:scale-98"
          >
            <Download className="w-4 h-4" />
            <span>Download Backup (.json)</span>
          </button>

          <label className="p-3.5 rounded-2xl bg-emerald-50 hover:bg-emerald-100 text-emerald-900 font-bold text-xs flex items-center justify-center gap-2 border border-emerald-300/70 transition-all cursor-pointer text-center">
            <Upload className="w-4 h-4 text-emerald-700" />
            <span>Restore / Upload JSON</span>
            <input
              type="file"
              accept=".json"
              onChange={handleFileUpload}
              className="hidden"
            />
          </label>

          <button
            onClick={() => {
              if (
                window.confirm(
                  'Are you sure you want to reset the store database to initial defaults? All custom sales and inventory changes will be reset.'
                )
              ) {
                resetToDefault();
              }
            }}
            className="p-3.5 rounded-2xl bg-rose-50 hover:bg-rose-100 text-rose-800 font-bold text-xs flex items-center justify-center gap-2 border border-rose-200 transition-all active:scale-98"
          >
            <RefreshCw className="w-4 h-4 text-rose-600" />
            <span>Reset to Defaults</span>
          </button>
        </div>
      </div>
    </div>
  );
};
