import React, { useState, useMemo, useRef } from 'react';
import { useStore } from '../context/StoreContext';
import { useTranslation } from '../i18n/LanguageContext';
import { Product, UnitType } from '../types';
import { money, calculateStockMetrics, getDynamicSafetyStockAlerts } from '../utils/helpers';
import {
  Package,
  Plus,
  Search,
  Filter,
  SlidersHorizontal,
  Factory,
  Trash2,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Sparkles,
  Zap,
  QrCode,
  Printer,
  ArrowRight,
  Scan,
  Camera,
  Barcode,
  X,
} from 'lucide-react';
import { BatchQrPrintModal } from '../components/modals/BatchQrPrintModal';
import { BarcodeScannerModal } from '../components/modals/BarcodeScannerModal';
import { CustomLabelPrinterModal } from '../components/modals/CustomLabelPrinterModal';

export const InventoryView: React.FC = () => {
  const { t } = useTranslation();
  const {
    db,
    saveProduct,
    deleteProduct,
    setStockAdjustProductId,
    setActiveTab,
    setProductQrModalId,
    priceSuggestions,
    showToast,
  } = useStore();

  const [search, setSearch] = useState('');
  const [filter, setFilter] = useState<'all' | 'healthy' | 'safety' | 'low' | 'out'>('all');
  const [isBatchQrOpen, setIsBatchQrOpen] = useState(false);
  const [isCustomLabelModalOpen, setIsCustomLabelModalOpen] = useState(false);
  const [customLabelTargetProductId, setCustomLabelTargetProductId] = useState<string | null>(null);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [scannerMode, setScannerMode] = useState<'find' | 'add' | 'general'>('general');
  const [highlightedProductId, setHighlightedProductId] = useState<string | null>(null);

  // Form references for automated scroll & focus
  const formRef = useRef<HTMLFormElement | null>(null);
  const nameInputRef = useRef<HTMLInputElement | null>(null);
  const skuInputRef = useRef<HTMLInputElement | null>(null);

  // New product form state
  const [name, setName] = useState('');
  const [sku, setSku] = useState('');
  const [stock, setStock] = useState<number | ''>('');
  const [min, setMin] = useState<number | ''>(5);
  const [buy, setBuy] = useState<number | ''>('');
  const [sell, setSell] = useState<number | ''>('');
  const [wholesale, setWholesale] = useState<number | ''>('');
  const [unit, setUnit] = useState<UnitType | string>('pcs');

  // Scanner actions: add new product candidate
  const handleAddNewWithBarcode = (scannedBarcode: string) => {
    setSku(scannedBarcode);
    setStock('');
    setName('');
    setBuy('');
    setSell('');
    setWholesale('');
    setUnit('pcs');

    formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setTimeout(() => {
      nameInputRef.current?.focus();
    }, 300);
    showToast(`Barcode "${scannedBarcode}" applied to SKU. Enter product details to save.`);
  };

  // Scanner actions: product found
  const handleProductFound = (productId: string, product?: Product) => {
    const target = product || (db.products || []).find((p) => p.id === productId);
    if (!target) return;

    setFilter('all');
    setSearch(target.name);
    setHighlightedProductId(target.id);

    setTimeout(() => {
      const el = document.getElementById(`product-item-${target.id}`);
      if (el) {
        el.scrollIntoView({ behavior: 'smooth', block: 'center' });
      }
    }, 250);

    setTimeout(() => {
      setHighlightedProductId((prev) => (prev === target.id ? null : prev));
    }, 4500);

    showToast(`Found: ${target.name} (${target.stock} ${target.unit} on hand)`);
  };

  // Scanner actions: load existing product into form to restock or edit
  const handleLoadProductIntoForm = (product: Product) => {
    setName(product.name);
    setSku(product.sku || '');
    setStock('');
    setMin(product.min || 5);
    setBuy(product.buy || '');
    setSell(product.sell || '');
    setWholesale(product.wholesale || '');
    setUnit(product.unit || 'pcs');

    formRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
    setTimeout(() => {
      nameInputRef.current?.focus();
    }, 300);
    showToast(`Loaded ${product.name} into form (enter quantity to add stock)`);
  };

  // Metrics summary
  const summary = useMemo(() => {
    const products = db.products || [];
    const low = products.filter((p) => p.stock > 0 && p.stock <= p.min).length;
    const out = products.filter((p) => p.stock <= 0).length;
    const units = products.reduce((a, p) => a + (p.stock || 0), 0);
    const costValue = products.reduce((a, p) => a + (p.stock || 0) * (p.buy || 0), 0);
    const retailValue = products.reduce((a, p) => a + (p.stock || 0) * (p.sell || 0), 0);
    const potentialMargin = Math.max(0, retailValue - costValue);

    return { low, out, units, costValue, retailValue, potentialMargin, count: products.length };
  }, [db.products]);

  // Live preview for form inputs
  const liveBuy = Number(buy) || 0;
  const liveSell = Number(sell) || 0;
  const liveMargin = Math.max(0, liveSell - liveBuy);
  const liveMarkup = liveBuy > 0 ? ((liveSell - liveBuy) / liveBuy) * 100 : 0;

  const handleSaveProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim()) return;

    const ok = saveProduct({
      name: name.trim(),
      sku: sku.trim(),
      stock: Number(stock) || 0,
      buy: Number(buy) || 0,
      sell: Number(sell) || 0,
      wholesale: wholesale !== '' ? Number(wholesale) : Number(sell) || 0,
      min: Number(min) || 5,
      unit,
    });

    if (ok) {
      setName('');
      setSku('');
      setStock('');
      setMin(5);
      setBuy('');
      setSell('');
      setWholesale('');
      setUnit('pcs');
    }
  };

  // Dynamic safety stock metrics
  const safetyAlerts = useMemo(() => {
    return getDynamicSafetyStockAlerts(db);
  }, [db.products, db.sales]);

  // Actionable dynamic price adjustments
  const actionablePricing = useMemo(() => {
    return (priceSuggestions || []).filter((s) => Math.abs(s.priceChangeDelta) >= 1);
  }, [priceSuggestions]);

  // Filtered and sorted product list
  const filteredProducts = useMemo(() => {
    const q = search.trim().toLowerCase();
    return (db.products || [])
      .map((p) => ({
        p,
        m: calculateStockMetrics(p, db),
      }))
      .filter(({ p, m }) => {
        const text = `${p.name} ${p.sku} ${p.unit}`.toLowerCase();
        if (q && !text.includes(q)) return false;
        if (filter === 'healthy' && m.health !== 'good') return false;
        if (filter === 'safety' && !m.isBelowSafetyStock) return false;
        if (filter === 'low' && m.health !== 'low') return false;
        if (filter === 'out' && m.health !== 'out') return false;
        return true;
      })
      .sort((a, b) => {
        const rank = (m: typeof a.m) => {
          if (m.health === 'out') return 0;
          if (m.isVelocityTriggered) return 1;
          if (m.health === 'low') return 2;
          return 3;
        };
        return rank(a.m) - rank(b.m) || b.m.stockValue - a.m.stockValue;
      });
  }, [db, search, filter]);

  return (
    <div className="space-y-4 pb-12">
      {/* V18 Premium Inventory Hero */}
      <div className="relative overflow-hidden rounded-3xl p-5 sm:p-6 text-white bg-gradient-to-br from-[#031a11] via-[#075a36] to-[#0a462a] shadow-xl border border-emerald-700/50">
        <div className="absolute top-0 right-0 -mr-8 -mt-8 w-40 h-40 bg-emerald-400/10 rounded-full blur-2xl" />
        <div className="relative z-10 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <span className="text-[10px] font-black uppercase tracking-widest text-emerald-300">
                V18 · Smart Inventory Engine
              </span>
              <h2 className="text-xl sm:text-2xl font-black text-white mt-0.5 tracking-tight">
                {t('inventory')} & {t('products')}
              </h2>
            </div>
            <div className="text-right">
              <span className="text-[10px] uppercase font-bold text-emerald-200 block">
                {t('products')}
              </span>
              <span className="text-xl font-black text-white">{summary.count} {t('products')}</span>
            </div>
          </div>

          <p className="text-xs text-emerald-100/80 max-w-lg leading-relaxed">
            Real-time grocery valuation tracking on-hand units, procurement cost values, retail potential, and automated reorder alerts.
          </p>

          <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5 pt-2 border-t border-emerald-600/40 text-xs">
            <div className="p-2.5 rounded-xl bg-black/20 border border-white/10">
              <span className="text-[10px] font-bold text-emerald-300 uppercase block">
                {t('totalValue')} ({t('cost')})
              </span>
              <span className="text-base font-black text-white mt-0.5 block">
                {money(summary.costValue)}
              </span>
            </div>

            <div className="p-2.5 rounded-xl bg-black/20 border border-white/10">
              <span className="text-[10px] font-bold text-emerald-300 uppercase block">
                {t('retail')} Value
              </span>
              <span className="text-base font-black text-amber-200 mt-0.5 block">
                {money(summary.retailValue)}
              </span>
            </div>

            <div className="col-span-2 sm:col-span-1 p-2.5 rounded-xl bg-black/20 border border-white/10">
              <span className="text-[10px] font-bold text-emerald-300 uppercase block">
                Projected Gross Margin
              </span>
              <span className="text-base font-black text-emerald-300 mt-0.5 block">
                +{money(summary.potentialMargin)}
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Stats Grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-black uppercase text-slate-600 tracking-wider block">
            {t('stock')} Units
          </span>
          <span className="text-lg font-black text-slate-900 mt-1 block tabular-nums">
            {summary.units.toLocaleString()}
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-black uppercase text-slate-600 tracking-wider block">
            Healthy Stock
          </span>
          <span className="text-lg font-black text-emerald-800 mt-1 block tabular-nums">
            {Math.max(0, summary.count - safetyAlerts.totalBelowSafety)}
          </span>
        </div>

        <div
          onClick={() => setFilter(filter === 'safety' ? 'all' : 'safety')}
          className={`p-3.5 rounded-2xl border shadow-2xs cursor-pointer transition-all ${
            safetyAlerts.totalBelowSafety > 0
              ? 'bg-amber-50/70 border-amber-300/90 hover:bg-amber-100/70'
              : 'bg-white border-slate-200/90'
          }`}
        >
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-black uppercase text-amber-900 tracking-wider flex items-center gap-1">
              <Zap className="w-3.5 h-3.5 text-amber-600 fill-current" />
              {t('lowStock')}
            </span>
          </div>
          <div className="flex items-baseline gap-1.5 mt-1">
            <span className="text-lg font-black text-amber-800 tabular-nums">
              {safetyAlerts.totalBelowSafety}
            </span>
            {safetyAlerts.velocityTriggeredCount > 0 && (
              <span className="text-[10px] font-bold text-amber-900 bg-amber-200/80 px-1.5 py-0.2 rounded-md">
                {safetyAlerts.velocityTriggeredCount} velocity
              </span>
            )}
          </div>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-2xs">
          <span className="text-[11px] font-black uppercase text-slate-600 tracking-wider block">
            {t('outOfStock')}
          </span>
          <span className="text-lg font-black text-rose-700 mt-1 block tabular-nums">
            {summary.out}
          </span>
        </div>
      </div>

      {/* Dynamic Safety Stock Alert Banner */}
      {safetyAlerts.totalBelowSafety > 0 && (
        <div className="p-4 rounded-3xl bg-gradient-to-r from-slate-900 via-amber-950 to-slate-900 text-white border border-amber-500/40 shadow-lg flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-2xl bg-amber-500/20 border border-amber-400/30 text-amber-400 shrink-0 mt-0.5">
              <Zap className="w-5 h-5 fill-current animate-pulse" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-black text-sm tracking-tight text-white">
                  Dynamic Safety Stock Alert: {safetyAlerts.totalBelowSafety} SKUs At Risk
                </span>
                {safetyAlerts.velocityTriggeredCount > 0 && (
                  <span className="px-2 py-0.5 rounded-full bg-amber-400 text-slate-950 text-[10px] font-black uppercase tracking-wide">
                    {safetyAlerts.velocityTriggeredCount} High Velocity Lines
                  </span>
                )}
              </div>
              <p className="text-xs text-amber-100/80 mt-1 max-w-xl leading-relaxed">
                Thresholds are calibrated dynamically from recent 7-day sales rate with a 4-day supplier replenishment buffer. Prevents stockouts by flagging fast-selling items before static minimum thresholds are breached.
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
            <button
              onClick={() => setFilter(filter === 'safety' ? 'all' : 'safety')}
              className={`px-3 py-2 rounded-xl text-xs font-bold transition-all ${
                filter === 'safety'
                  ? 'bg-amber-400 text-slate-950 shadow-md font-black'
                  : 'bg-white/10 hover:bg-white/20 text-white border border-white/20'
              }`}
            >
              {filter === 'safety' ? 'Show All Products' : `Filter Below Safety (${safetyAlerts.totalBelowSafety})`}
            </button>
            <button
              onClick={() => setActiveTab('purchases')}
              className="px-3 py-2 rounded-xl bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold transition-all shadow-md active:scale-98"
            >
              Create Purchase Order
            </button>
          </div>
        </div>
      )}

      {/* Dynamic Pricing Recommendations Banner */}
      {actionablePricing.length > 0 && (
        <div className="p-4 rounded-3xl bg-white border border-emerald-300 shadow-xs flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-start gap-3">
            <div className="p-2.5 rounded-2xl bg-emerald-100 text-emerald-800 shrink-0 mt-0.5">
              <TrendingUp className="w-5 h-5 text-emerald-700" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <span className="font-extrabold text-sm text-slate-900">
                  Dynamic Pricing Engine: {actionablePricing.length} Price Adjustments Recommended
                </span>
                <span className="px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 text-[10px] font-black uppercase">
                  Margin Defense Active
                </span>
              </div>
              <p className="text-xs text-slate-500 mt-0.5">
                Real-time competitor tracking and COGS fluctuation analysis flagged opportunities to protect margins and capitalize on market demand.
              </p>
            </div>
          </div>

          <button
            onClick={() => setActiveTab('pricing')}
            className="px-4 py-2.5 rounded-xl bg-slate-900 hover:bg-slate-800 text-white text-xs font-bold transition-all shadow-xs shrink-0 flex items-center gap-1.5 self-start sm:self-auto"
          >
            <span>Review Price Suggestions</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>
      )}

      {/* Add / Update Product Form */}
      <form
        ref={formRef}
        onSubmit={handleSaveProduct}
        className="p-4 sm:p-5 rounded-3xl bg-white border border-emerald-200/80 shadow-xs space-y-4"
      >
        <div className="flex items-center justify-between pb-2 border-b border-slate-100 flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <Plus className="w-4 h-4 text-emerald-700" />
            <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
              {t('addProduct')}
            </h3>
          </div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              onClick={() => {
                setScannerMode('add');
                setIsScannerOpen(true);
              }}
              className="px-2.5 py-1 rounded-xl bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[11px] font-bold border border-emerald-200 transition-colors flex items-center gap-1.5 shadow-2xs active:scale-98"
              title="Open device camera to scan grocery barcode for instant cataloging"
            >
              <Camera className="w-3.5 h-3.5 text-emerald-700" />
              <span>{t('scanBarcode')}</span>
            </button>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800">
              AUTO-RECONCILE
            </span>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-3 text-xs">
          <div className="sm:col-span-2">
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Product Name *
            </label>
            <input
              ref={nameInputRef}
              id="pName"
              type="text"
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Pure Sunflower Cooking Oil 5L"
              required
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">SKU / Barcode</label>
            <div className="relative">
              <input
                ref={skuInputRef}
                id="pSku"
                type="text"
                value={sku}
                onChange={(e) => setSku(e.target.value)}
                placeholder="e.g. OIL-5L-01"
                className="w-full pl-3 pr-10 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
              />
              <button
                type="button"
                onClick={() => {
                  setScannerMode('add');
                  setIsScannerOpen(true);
                }}
                className="absolute right-1.5 top-1.5 p-1 rounded-lg bg-emerald-100 hover:bg-emerald-200 text-emerald-800 transition-colors"
                title="Scan barcode with camera"
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">Stock Unit</label>
            <select
              id="pUnit"
              value={unit}
              onChange={(e) => setUnit(e.target.value as any)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            >
              <option value="pcs">pcs (Pieces)</option>
              <option value="bag">bag (Bags)</option>
              <option value="carton">carton (Cartons)</option>
              <option value="box">box (Boxes)</option>
              <option value="kg">kg (Kilograms)</option>
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Stock Quantity
            </label>
            <input
              id="pStock"
              type="number"
              min="0"
              value={stock}
              onChange={(e) => setStock(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="e.g. 50"
              required
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Min Alert Level
            </label>
            <input
              id="pMin"
              type="number"
              min="0"
              value={min}
              onChange={(e) => setMin(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="e.g. 10"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Buy Cost (ETB) *
            </label>
            <input
              id="pBuy"
              type="number"
              min="0"
              step="any"
              value={buy}
              onChange={(e) => setBuy(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="e.g. 820"
              required
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Retail Price (ETB) *
            </label>
            <input
              id="pSell"
              type="number"
              min="0"
              step="any"
              value={sell}
              onChange={(e) => setSell(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="e.g. 980"
              required
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Wholesale Price (ETB)
            </label>
            <input
              id="pWholesale"
              type="number"
              min="0"
              step="any"
              value={wholesale}
              onChange={(e) => setWholesale(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="e.g. 930"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
          </div>
        </div>

        {/* Live Margin Calculation Preview */}
        {(liveBuy > 0 || liveSell > 0) && (
          <div className="p-3 rounded-2xl bg-slate-50 border border-dashed border-slate-300 flex items-center justify-between text-xs">
            <span className="text-slate-500">
              Unit Economics Preview: Buy <b>{money(liveBuy)}</b> → Retail <b>{money(liveSell)}</b>
            </span>
            <span className="font-extrabold text-emerald-800">
              +{money(liveMargin)} margin ({liveMarkup.toFixed(1)}% markup)
            </span>
          </div>
        )}

        <button
          type="submit"
          className="w-full py-2.5 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 font-extrabold text-xs text-white transition-all shadow-sm active:scale-98"
        >
          Save Product to Inventory
        </button>
      </form>

      {/* Inventory Search, Filters & Controls */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200/90 shadow-xs space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <div className="flex items-center gap-2">
            <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
              Inventory Portfolio ({filteredProducts.length})
            </h3>
            <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-emerald-100 text-emerald-800 flex items-center gap-1">
              <QrCode className="w-3 h-3" />
              QR Enabled
            </span>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={() => {
                setCustomLabelTargetProductId(null);
                setIsCustomLabelModalOpen(true);
              }}
              className="px-3.5 py-1.5 rounded-xl bg-gradient-to-r from-slate-900 via-emerald-950 to-slate-900 hover:from-slate-800 hover:to-emerald-900 text-white font-extrabold text-xs transition flex items-center gap-2 shadow-xs border border-emerald-500/40 active:scale-98 cursor-pointer"
              title="Print custom QR & 1D barcode labels for Zebra, Brother, Dymo, Xprinter & thermal roll printers"
            >
              <Barcode className="w-3.5 h-3.5 text-emerald-400" />
              <Printer className="w-3.5 h-3.5 text-amber-300" />
              <span>{t('printLabels')}</span>
            </button>
            <button
              onClick={() => setIsBatchQrOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-700 hover:from-emerald-500 hover:to-teal-600 text-white font-extrabold text-xs transition flex items-center gap-1.5 shadow-xs"
              title="Print standard shelf tags with QR codes for physical inventory"
            >
              <Printer className="w-3.5 h-3.5" />
              <span>{t('printQr')}</span>
            </button>
          </div>
        </div>

        <div className="flex items-center gap-1.5 flex-wrap">
          {[
            { id: 'all', label: `${t('filterAll')} (${db.products.length})`, highlight: false },
            {
              id: 'safety',
              label: `${t('lowStock')} (${safetyAlerts.totalBelowSafety})`,
              highlight: safetyAlerts.totalBelowSafety > 0,
            },
            { id: 'healthy', label: 'Healthy', highlight: false },
            { id: 'low', label: t('lowStock'), highlight: false },
            { id: 'out', label: t('outOfStock'), highlight: false },
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setFilter(tab.id as any)}
              className={`px-3 py-1 rounded-full text-xs font-bold transition-all capitalize ${
                filter === tab.id
                  ? tab.highlight
                    ? 'bg-amber-500 text-slate-950 shadow-xs font-black'
                    : 'bg-slate-900 text-white shadow-xs'
                  : tab.highlight
                  ? 'bg-amber-100 hover:bg-amber-200 text-amber-900 border border-amber-300'
                  : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Search input */}
        <div className="flex items-center gap-2">
          <div className="relative flex-1">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              id="invSearch"
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder={`${t('searchProducts')}...`}
              className="w-full pl-9 pr-8 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
            {search && (
              <button
                type="button"
                onClick={() => setSearch('')}
                className="absolute right-2.5 top-2.5 text-slate-400 hover:text-slate-700 p-0.5"
                title="Clear search"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            )}
          </div>
          <button
            onClick={() => {
              setScannerMode('find');
              setIsScannerOpen(true);
            }}
            className="flex items-center gap-2 px-4 py-2 bg-emerald-700 hover:bg-emerald-800 text-white rounded-xl font-bold text-xs transition-colors shadow-xs shrink-0 active:scale-98"
            title="Scan barcode or QR code with camera to find product or catalog new item"
          >
            <Scan className="w-4 h-4" />
            <span>{t('scanBarcode')}</span>
          </button>
        </div>

        {/* Product Cards Grid / List */}
        <div className="space-y-3">
          {filteredProducts.length === 0 ? (
            <div className="py-12 text-center text-slate-400 text-xs">
              No products found matching your search and filter criteria.
            </div>
          ) : (
            filteredProducts.map(({ p, m }) => {
              const cap = Math.max(m.dynamicSafetyThreshold * 2, (p.min || 0) * 2, 1);
              const barPct = Math.min(100, Math.max(0, (p.stock / cap) * 100));
              const markup = p.buy > 0 ? ((p.sell - p.buy) / p.buy) * 100 : 0;

              return (
                <div
                  id={`product-item-${p.id}`}
                  key={p.id}
                  className={`p-4 rounded-2xl border transition-all duration-300 ${
                    highlightedProductId === p.id
                      ? 'ring-4 ring-emerald-500/80 bg-emerald-50/70 border-emerald-500 shadow-xl scale-[1.01]'
                      : m.health === 'out'
                      ? 'bg-rose-50/40 border-rose-200 hover:border-rose-300'
                      : m.isVelocityTriggered
                      ? 'bg-amber-50/70 border-amber-300/90 ring-1 ring-amber-300/50 hover:border-amber-400'
                      : m.health === 'low'
                      ? 'bg-amber-50/40 border-amber-200 hover:border-amber-300'
                      : 'bg-white border-slate-200 hover:border-slate-300'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-extrabold text-sm text-slate-900">{p.name}</span>
                        <span
                          className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full flex items-center gap-1 ${
                            m.health === 'out'
                              ? 'bg-rose-100 text-rose-800'
                              : m.isVelocityTriggered
                              ? 'bg-gradient-to-r from-amber-500 to-orange-500 text-white shadow-xs'
                              : m.health === 'low'
                              ? 'bg-amber-100 text-amber-800'
                              : 'bg-emerald-100 text-emerald-800'
                          }`}
                        >
                          {m.health === 'out' ? (
                            'OUT OF STOCK'
                          ) : m.isVelocityTriggered ? (
                            <>
                              <Zap className="w-2.5 h-2.5 fill-current" />
                              VELOCITY RISK ({m.daysOfCover}D RUNWAY)
                            </>
                          ) : m.health === 'low' ? (
                            'LOW STOCK'
                          ) : (
                            'HEALTHY'
                          )}
                        </span>
                      </div>
                      <div className="text-[11px] text-slate-500 mt-1 flex items-center gap-2 flex-wrap">
                        <span className="inline-flex items-center gap-1 font-mono text-slate-700 bg-slate-100 px-1.5 py-0.5 rounded-md text-[10px] border border-slate-200/80">
                          <Barcode className="w-3 h-3 text-slate-500" />
                          <span>{p.sku || 'No Barcode'}</span>
                        </span>
                        <span>· Packaging: <b>{p.unit}</b></span>
                      </div>
                    </div>

                    <div className="text-right flex flex-col items-end gap-1">
                      <div>
                        <span className="text-xs text-slate-500 block">Stock Value</span>
                        <span className="font-extrabold text-xs text-slate-900">
                          {money(m.stockValue)}
                        </span>
                      </div>
                      <button
                        onClick={() => setProductQrModalId(p.id)}
                        className="px-2 py-0.5 rounded-lg bg-slate-100 hover:bg-emerald-100 hover:text-emerald-900 text-slate-700 text-[10px] font-extrabold transition flex items-center gap-1 border border-slate-200"
                        title="Auto-generated QR Code Label, Stock History & Margins"
                      >
                        <QrCode className="w-3 h-3 text-emerald-600" />
                        <span>QR Tag</span>
                      </button>
                    </div>
                  </div>

                  {/* Velocity & Dynamic Safety Threshold Indicator */}
                  <div className="mt-2.5 px-3.5 py-2.5 rounded-xl bg-slate-50 border border-slate-200 grid grid-cols-1 sm:grid-cols-3 gap-2 text-xs">
                    <div>
                      <span className="text-[10.5px] text-slate-600 font-bold block uppercase tracking-wider">
                        Recent 7-Day Velocity
                      </span>
                      <span className="font-extrabold text-slate-900 tabular-nums">
                        {m.recentSalesVelocity} {p.unit}/day
                      </span>
                    </div>
                    <div>
                      <span className="text-[10.5px] text-slate-600 font-bold block uppercase tracking-wider">
                        Dynamic Safety Threshold
                      </span>
                      <span
                        className={`font-black tabular-nums ${
                          m.isBelowSafetyStock ? 'text-amber-800' : 'text-slate-900'
                        }`}
                      >
                        {m.dynamicSafetyThreshold} {p.unit}{' '}
                        <span className="text-[10.5px] text-slate-500 font-medium">
                          (Static Min: {p.min})
                        </span>
                      </span>
                    </div>
                    <div>
                      <span className="text-[10.5px] text-slate-600 font-bold block uppercase tracking-wider">
                        Stock Runway
                      </span>
                      <span
                        className={`font-black tabular-nums ${
                          m.daysOfCover < 4
                            ? 'text-rose-700'
                            : m.daysOfCover < 7
                            ? 'text-amber-800'
                            : 'text-emerald-800'
                        }`}
                      >
                        {m.daysOfCover >= 999 ? '∞ Zero velocity' : `${m.daysOfCover} days buffer`}
                      </span>
                    </div>
                  </div>

                  {/* Metrics Row */}
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-2 mt-2 text-xs">
                    <div className="p-2 rounded-xl bg-white border border-slate-200/80">
                      <span className="text-[10px] text-slate-400 block font-semibold">ON HAND</span>
                      <span className="font-black text-slate-900">
                        {p.stock} {p.unit}
                      </span>
                    </div>
                    <div className="p-2 rounded-xl bg-white border border-slate-200/80">
                      <span className="text-[10px] text-slate-400 block font-semibold">COST / RETAIL</span>
                      <span className="font-bold text-slate-800">
                        {money(p.buy)} / {money(p.sell)}
                      </span>
                    </div>
                    <div className="p-2 rounded-xl bg-white border border-slate-200/80">
                      <span className="text-[10px] text-slate-400 block font-semibold">UNIT MARGIN</span>
                      <span className="font-black text-emerald-700">+{money(m.margin)}</span>
                    </div>
                    <div className="p-2 rounded-xl bg-white border border-slate-200/80">
                      <span className="text-[10px] text-slate-400 block font-semibold">MARKUP</span>
                      <span className="font-black text-amber-700">{markup.toFixed(1)}%</span>
                    </div>
                  </div>

                  {/* Stock Bar */}
                  <div className="mt-3 space-y-1">
                    <div className="flex justify-between text-[10px] text-slate-500">
                      <span>Stock Health Level</span>
                      <span>
                        Dynamic Safety {m.dynamicSafetyThreshold} · Static Min {p.min}
                      </span>
                    </div>
                    <div className="w-full h-1.5 rounded-full bg-slate-200 overflow-hidden">
                      <div
                        className={`h-full rounded-full ${
                          m.health === 'out'
                            ? 'bg-rose-500'
                            : m.isVelocityTriggered
                            ? 'bg-gradient-to-r from-amber-500 to-orange-500'
                            : m.health === 'low'
                            ? 'bg-amber-500'
                            : 'bg-emerald-600'
                        }`}
                        style={{ width: `${barPct}%` }}
                      />
                    </div>
                  </div>

                  {/* Action recommendation & Buttons */}
                  <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2 text-xs">
                    <div className="text-[11px] text-slate-600">
                      <b>CEO action:</b>{' '}
                      {m.health === 'out'
                        ? 'Blocked in POS. Immediate supplier replenishment required.'
                        : m.isVelocityTriggered
                        ? `Sales rate (${m.recentSalesVelocity}/day) threatens stockout in ${m.daysOfCover} days. Place purchase order.`
                        : m.health === 'low'
                        ? 'Buffer depleted below statutory minimum. Prepare restocking order.'
                        : 'Stock healthy. Adequate inventory covering 4-day vendor turnaround.'}
                    </div>

                    <div className="flex items-center gap-1.5 flex-wrap">
                      <button
                        onClick={() => {
                          setCustomLabelTargetProductId(p.id);
                          setIsCustomLabelModalOpen(true);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-emerald-950 hover:bg-slate-900 text-emerald-200 border border-emerald-600/50 font-extrabold text-[11px] transition-colors flex items-center gap-1 shadow-xs cursor-pointer"
                        title="Print custom barcode & QR label for standard thermal label printers"
                      >
                        <Printer className="w-3.5 h-3.5 text-amber-400" />
                        <span>Print Label</span>
                      </button>
                      <button
                        onClick={() => setProductQrModalId(p.id)}
                        className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-700 text-white font-extrabold text-[11px] transition-colors flex items-center gap-1 shadow-xs"
                        title="Auto-generated QR label, live stock history & profit margins"
                      >
                        <QrCode className="w-3.5 h-3.5" />
                        <span>QR & Margins</span>
                      </button>
                      <button
                        onClick={() => handleLoadProductIntoForm(p)}
                        className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-[11px] transition-colors"
                        title="Load into Add/Update form to edit or restock"
                      >
                        Edit
                      </button>
                      <button
                        onClick={() => setStockAdjustProductId(p.id)}
                        className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] transition-colors"
                      >
                        ↕ Adjust
                      </button>
                      <button
                        onClick={() => setActiveTab('purchases')}
                        className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-[11px] transition-colors"
                      >
                        ＋ Buy
                      </button>
                      <button
                        onClick={() => {
                          if (window.confirm(`Delete product ${p.name}?`)) {
                            deleteProduct(p.id);
                          }
                        }}
                        className="p-1 text-slate-300 hover:text-rose-600 transition-colors"
                        title="Delete product"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Batch QR Code Labels Modal */}
      <BatchQrPrintModal
        isOpen={isBatchQrOpen}
        onClose={() => setIsBatchQrOpen(false)}
        products={db.products || []}
      />

      {/* Custom Barcode & QR Label Printer Modal */}
      <CustomLabelPrinterModal
        isOpen={isCustomLabelModalOpen}
        onClose={() => {
          setIsCustomLabelModalOpen(false);
          setCustomLabelTargetProductId(null);
        }}
        products={db.products || []}
        initialProductId={customLabelTargetProductId}
      />

      {/* Barcode Scanner Modal */}
      <BarcodeScannerModal
        isOpen={isScannerOpen}
        onClose={() => setIsScannerOpen(false)}
        mode={scannerMode}
        onProductFound={handleProductFound}
        onAddNewWithBarcode={handleAddNewWithBarcode}
        onLoadProductToForm={handleLoadProductIntoForm}
      />
    </div>
  );
};
