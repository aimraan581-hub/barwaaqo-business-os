import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { OrderStatus, DistributionOrderStatus, SaleMode } from '../types';
import { money } from '../utils/helpers';
import {
  Truck,
  Plus,
  CheckCircle2,
  Clock,
  PackageCheck,
  AlertCircle,
  ArrowRight,
  Trash2,
  Navigation,
  UserCheck,
  MapPin,
  Car,
} from 'lucide-react';

const STANDARD_ROUTES = [
  'Route 1: Bole · Kazanchis · Piassa Corridor',
  'Route 2: Mercato · Autobus Tera · Teklehaimanot',
  'Route 3: Kaliti · Saris · Gotera Logistics Belt',
  'Route 4: Megenagna · CMC · Ayat Express',
  'Express Direct VIP Dispatch',
];

const STANDARD_DRIVERS = [
  { name: 'Dawit Tadesse', plate: '3-AA-84920', vehicle: 'Toyota Hilux Van' },
  { name: 'Abebe Kebede', plate: '3-AA-19402', vehicle: 'Isuzu NPR Truck' },
  { name: 'Daniel Mulugeta', plate: '3-AA-73812', vehicle: 'Hyundai H-100' },
  { name: 'Yonatan Girma', plate: '3-AA-95201', vehicle: 'TukTuk / Express Bike' },
];

export const DistributionView: React.FC = () => {
  const {
    db,
    createDistributionOrder,
    assignDeliveryRoute,
    updateOrderStatus,
    payOrderBalance,
    deleteOrder,
  } = useStore();

  const [customerId, setCustomerId] = useState('');
  const [productId, setProductId] = useState('');
  const [qty, setQty] = useState<number | ''>('');
  const [mode, setMode] = useState<SaleMode>('wholesale');
  const [deposit, setDeposit] = useState<number | ''>('');
  const [deliveryDate, setDeliveryDate] = useState('');
  const [selectedRoute, setSelectedRoute] = useState(STANDARD_ROUTES[0]);
  const [selectedDriver, setSelectedDriver] = useState(STANDARD_DRIVERS[0].name);
  const [vehiclePlate, setVehiclePlate] = useState(STANDARD_DRIVERS[0].plate);
  const [note, setNote] = useState('');

  const [statusFilter, setStatusFilter] = useState<'ALL' | OrderStatus>('ALL');
  const [routeFilter, setRouteFilter] = useState<string>('ALL');

  // Dispatch assignment modal/drawer
  const [dispatchModalOrderId, setDispatchModalOrderId] = useState<string | null>(null);
  const [modalDriver, setModalDriver] = useState(STANDARD_DRIVERS[0].name);
  const [modalRoute, setModalRoute] = useState(STANDARD_ROUTES[0]);
  const [modalPlate, setModalPlate] = useState(STANDARD_DRIVERS[0].plate);

  const selectedProduct = db.products.find((p) => p.id === productId);
  const activePrice = selectedProduct
    ? mode === 'wholesale'
      ? selectedProduct.wholesale
      : selectedProduct.sell
    : 0;

  const estimatedTotal = (Number(qty) || 0) * activePrice;

  const handleCreateOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!customerId || !productId || !qty) return;

    const ok = createDistributionOrder({
      customerId,
      productId,
      qty: Number(qty),
      mode,
      deposit: Number(deposit) || 0,
      deliveryDate: deliveryDate || undefined,
      note: note.trim(),
      driver: selectedDriver,
      route: selectedRoute,
      vehiclePlate: vehiclePlate,
    });

    if (ok) {
      setProductId('');
      setQty('');
      setDeposit('');
      setDeliveryDate('');
      setNote('');
    }
  };

  const handleAssignDispatch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!dispatchModalOrderId) return;
    assignDeliveryRoute(dispatchModalOrderId, {
      driver: modalDriver,
      route: modalRoute,
      vehiclePlate: modalPlate,
    });
    setDispatchModalOrderId(null);
  };

  const filteredOrders = useMemo(() => {
    return db.orders.filter((o) => {
      if (statusFilter !== 'ALL' && o.status !== statusFilter) return false;
      if (routeFilter !== 'ALL' && o.route !== routeFilter) return false;
      return true;
    });
  }, [db.orders, statusFilter, routeFilter]);

  const nextStatus = (curr: DistributionOrderStatus): DistributionOrderStatus | null => {
    switch (curr) {
      case 'BOOKED':
        return 'PACKED';
      case 'PACKED':
        return 'OUT_FOR_DELIVERY';
      case 'OUT_FOR_DELIVERY':
        return 'DELIVERED';
      case 'DELIVERED':
        return 'PAID';
      default:
        return null;
    }
  };

  // Route statistics
  const activeDispatches = db.orders.filter((o) => o.status === 'OUT_FOR_DELIVERY').length;
  const packedReady = db.orders.filter((o) => o.status === 'PACKED').length;

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900 text-white shadow-md border border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-blue-500/20 text-blue-400 border border-blue-400/30">
              <Truck className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white tracking-tight">
                Distribution & Delivery Route Fleet Logistics
              </h2>
              <p className="text-[11px] text-slate-300">
                Corridor Route Assignment, Dispatch Manifests, and Fleet Status
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 block">
            ACTIVE ORDERS
          </span>
          <span className="text-lg font-black text-slate-900 mt-0.5 block">
            {db.orders.filter((o) => o.status !== 'PAID').length}
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 block">
            OUT FOR DELIVERY
          </span>
          <span className="text-lg font-black text-blue-600 mt-0.5 block">
            {activeDispatches} on route
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 block">
            PACKED & STAGED
          </span>
          <span className="text-lg font-black text-amber-600 mt-0.5 block">
            {packedReady} orders
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 block">
            UNCOLLECTED BALANCE
          </span>
          <span className="text-lg font-black text-rose-600 mt-0.5 block">
            {money(db.orders.reduce((a, o) => a + (o.balance || 0), 0))}
          </span>
        </div>
      </div>

      {/* Book Distribution Order Form */}
      <form
        onSubmit={handleCreateOrder}
        className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4"
      >
        <div className="flex items-center justify-between pb-2 border-b border-slate-100">
          <div className="flex items-center gap-2">
            <Plus className="w-4 h-4 text-blue-600" />
            <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
              Book Wholesale Order & Assign Delivery Route
            </h3>
          </div>
          <div className="flex items-center gap-1">
            <button
              type="button"
              onClick={() => setMode('wholesale')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                mode === 'wholesale'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Wholesale Pricing
            </button>
            <button
              type="button"
              onClick={() => setMode('retail')}
              className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                mode === 'retail'
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Retail Pricing
            </button>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Select B2B Client *
            </label>
            <select
              id="distCust"
              value={customerId}
              onChange={(e) => setCustomerId(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            >
              <option value="">-- Choose Client --</option>
              {db.customers.map((c) => (
                <option key={c.id} value={c.id}>
                  {c.name} {c.customerType ? `(${c.customerType.replace('b2b_', '')})` : ''} · Debt: {money(c.credit)}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Select Inventory Item *
            </label>
            <select
              id="distProd"
              value={productId}
              onChange={(e) => setProductId(e.target.value)}
              required
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            >
              <option value="">-- Choose Product --</option>
              {db.products.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.name} ({p.stock} in stock)
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Quantity ({selectedProduct?.unit || 'units'}) *
            </label>
            <input
              id="distQty"
              type="number"
              min="1"
              max={selectedProduct?.stock || 99999}
              value={qty}
              onChange={(e) => setQty(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="e.g. 10"
              required
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Assigned Delivery Route Corridor
            </label>
            <select
              value={selectedRoute}
              onChange={(e) => setSelectedRoute(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            >
              {STANDARD_ROUTES.map((r) => (
                <option key={r} value={r}>
                  {r}
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Assigned Fleet Driver & Vehicle
            </label>
            <select
              value={selectedDriver}
              onChange={(e) => {
                setSelectedDriver(e.target.value);
                const d = STANDARD_DRIVERS.find((drv) => drv.name === e.target.value);
                if (d) setVehiclePlate(d.plate);
              }}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            >
              {STANDARD_DRIVERS.map((d) => (
                <option key={d.name} value={d.name}>
                  {d.name} ({d.vehicle} · {d.plate})
                </option>
              ))}
            </select>
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Deposit Paid Upfront (ETB)
            </label>
            <input
              id="distDeposit"
              type="number"
              min="0"
              value={deposit}
              onChange={(e) => setDeposit(e.target.value === '' ? '' : Number(e.target.value))}
              placeholder="0.00"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            />
          </div>

          <div>
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Target Delivery Date
            </label>
            <input
              id="distDate"
              type="date"
              value={deliveryDate}
              onChange={(e) => setDeliveryDate(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            />
          </div>

          <div className="sm:col-span-2">
            <label className="block text-[11px] font-bold text-slate-600 mb-1">
              Delivery Notes / Specific Gate Instructions
            </label>
            <input
              id="distNote"
              type="text"
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="e.g. Back door delivery, call receiver upon arrival"
              className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium focus:ring-2 focus:ring-blue-500 focus:outline-hidden"
            />
          </div>
        </div>

        {/* Live Estimate preview */}
        {estimatedTotal > 0 && (
          <div className="p-3 rounded-2xl bg-blue-50/60 border border-blue-200 flex items-center justify-between text-xs">
            <span className="text-slate-600">
              Total Order Value: <b>{money(estimatedTotal)}</b> · Deposit: <b>{money(Number(deposit) || 0)}</b>
            </span>
            <span className="font-extrabold text-blue-900">
              Balance Due: {money(Math.max(0, estimatedTotal - (Number(deposit) || 0)))}
            </span>
          </div>
        )}

        <button
          type="submit"
          disabled={!customerId || !productId || !qty}
          className="w-full py-2.5 px-4 rounded-xl bg-blue-600 hover:bg-blue-700 disabled:opacity-50 text-xs font-black uppercase tracking-wider text-white transition-all shadow-sm active:scale-98"
        >
          Book Distribution Order & Dispatch to Route
        </button>
      </form>

      {/* Order Directory & Route Board */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
        <div className="flex items-center justify-between flex-wrap gap-2">
          <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
            Delivery Manifests ({filteredOrders.length} orders)
          </h3>

          <div className="flex items-center gap-1.5 flex-wrap">
            {(['ALL', 'BOOKED', 'PACKED', 'OUT_FOR_DELIVERY', 'DELIVERED', 'PAID'] as const).map((st) => (
              <button
                key={st}
                onClick={() => setStatusFilter(st)}
                className={`px-2.5 py-1 rounded-lg text-[11px] font-bold transition-all ${
                  statusFilter === st
                    ? 'bg-slate-900 text-white'
                    : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                }`}
              >
                {st.replace(/_/g, ' ')}
              </button>
            ))}
          </div>
        </div>

        {/* Route Filter Tabs */}
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 text-xs">
          <span className="text-[10px] font-bold uppercase text-slate-400 shrink-0">Corridor:</span>
          <button
            onClick={() => setRouteFilter('ALL')}
            className={`px-2.5 py-1 rounded-lg font-bold text-[11px] whitespace-nowrap ${
              routeFilter === 'ALL'
                ? 'bg-blue-50 text-blue-800 border border-blue-200'
                : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
            }`}
          >
            All Corridors
          </button>
          {STANDARD_ROUTES.map((r) => (
            <button
              key={r}
              onClick={() => setRouteFilter(r)}
              className={`px-2.5 py-1 rounded-lg font-bold text-[11px] whitespace-nowrap ${
                routeFilter === r
                  ? 'bg-blue-50 text-blue-800 border border-blue-200'
                  : 'bg-slate-50 text-slate-500 hover:bg-slate-100'
              }`}
            >
              {r.split(':')[0]}
            </button>
          ))}
        </div>

        <div className="space-y-3">
          {filteredOrders.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              No orders found in this status or route category.
            </div>
          ) : (
            filteredOrders.map((ord) => {
              const nxt = nextStatus(ord.status);
              const statusColors: Record<string, string> = {
                NEW: 'bg-slate-100 text-slate-800',
                CONFIRMED: 'bg-blue-100 text-blue-800',
                PACKING: 'bg-amber-100 text-amber-800',
                BOOKED: 'bg-slate-100 text-slate-800',
                PACKED: 'bg-amber-100 text-amber-800',
                OUT_FOR_DELIVERY: 'bg-blue-100 text-blue-800',
                DELIVERED: 'bg-purple-100 text-purple-800',
                PAID: 'bg-emerald-100 text-emerald-800',
              };

              return (
                <div
                  key={ord.id}
                  className="p-4 rounded-2xl border border-slate-200 hover:border-slate-300 transition-all bg-white"
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <div className="flex items-center gap-2 flex-wrap">
                        <span className="font-black text-xs text-slate-900">{ord.number}</span>
                        <span
                          className={`text-[9px] font-black uppercase px-2 py-0.5 rounded-full ${
                            statusColors[ord.status] || 'bg-slate-100 text-slate-800'
                          }`}
                        >
                          {ord.status.replace(/_/g, ' ')}
                        </span>
                        <span className="text-[10px] text-slate-400">{ord.date}</span>
                        {ord.deliveryDate && (
                          <span className="text-[10px] font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded-md">
                            Due: {ord.deliveryDate}
                          </span>
                        )}
                      </div>
                      <h4 className="font-extrabold text-sm text-slate-900 mt-1">{ord.customer}</h4>
                      <div className="text-xs text-slate-500 mt-0.5">
                        Item: <b>{ord.product}</b> × {ord.qty} units ({ord.mode || 'wholesale'})
                      </div>

                      {/* Route & Driver details */}
                      <div className="mt-2 flex items-center gap-3 text-xs text-slate-600 flex-wrap">
                        {ord.route && (
                          <span className="flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-lg text-[11px] font-medium">
                            <Navigation className="w-3 h-3 text-blue-600" />
                            {ord.route}
                          </span>
                        )}
                        {ord.driver && (
                          <span className="flex items-center gap-1 bg-slate-100 px-2 py-0.5 rounded-lg text-[11px] font-medium">
                            <UserCheck className="w-3 h-3 text-slate-500" />
                            Driver: <b>{ord.driver}</b>
                            {ord.vehiclePlate && <span className="font-mono text-slate-400">({ord.vehiclePlate})</span>}
                          </span>
                        )}
                      </div>

                      {ord.note && (
                        <p className="text-[11px] text-slate-400 italic mt-1">"{ord.note}"</p>
                      )}
                    </div>

                    <div className="text-right">
                      <span className="text-xs text-slate-500 block">Total / Balance</span>
                      <span className="font-black text-sm text-slate-900 block">
                        {money(ord.total)}
                      </span>
                      <span
                        className={`text-xs font-extrabold ${
                          ord.balance > 0 ? 'text-rose-600' : 'text-emerald-700'
                        }`}
                      >
                        {ord.balance > 0 ? `Due: ${money(ord.balance)}` : 'Fully Paid'}
                      </span>
                    </div>
                  </div>

                  {/* Actions row */}
                  <div className="mt-3 pt-2.5 border-t border-slate-100 flex items-center justify-between flex-wrap gap-2 text-xs">
                    <div className="text-[11px] text-slate-500">
                      Deposit: <b>{money(ord.deposit || 0)}</b>
                    </div>

                    <div className="flex items-center gap-2">
                      <button
                        onClick={() => {
                          setDispatchModalOrderId(ord.id);
                          if (ord.driver) setModalDriver(ord.driver);
                          if (ord.route) setModalRoute(ord.route);
                          if (ord.vehiclePlate) setModalPlate(ord.vehiclePlate);
                        }}
                        className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-[11px] transition-colors flex items-center gap-1"
                      >
                        <Car className="w-3 h-3 text-blue-600" />
                        <span>Assign Fleet / Route</span>
                      </button>

                      {ord.balance > 0 && (
                        <button
                          onClick={() => {
                            const amt = prompt(
                              `Enter payment amount for order ${ord.number} (Balance: ${money(
                                ord.balance
                              )}):`,
                              ord.balance.toString()
                            );
                            if (amt && Number(amt) > 0) {
                              payOrderBalance(ord.id, Number(amt));
                            }
                          }}
                          className="px-2.5 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 font-bold text-[11px] transition-colors"
                        >
                          Collect Balance
                        </button>
                      )}

                      {nxt && (
                        <button
                          onClick={() => updateOrderStatus(ord.id, nxt)}
                          className="px-3 py-1 rounded-lg bg-blue-600 hover:bg-blue-700 text-white font-bold text-[11px] transition-all flex items-center gap-1 shadow-xs"
                        >
                          <span>Advance to {nxt.replace(/_/g, ' ')}</span>
                          <ArrowRight className="w-3 h-3" />
                        </button>
                      )}

                      <button
                        onClick={() => {
                          if (window.confirm(`Delete order ${ord.number}?`)) {
                            deleteOrder(ord.id);
                          }
                        }}
                        className="p-1 text-slate-300 hover:text-rose-600 transition-colors"
                        title="Delete order"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Modal for Assigning Route & Driver */}
      {dispatchModalOrderId && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-3xl p-5 max-w-md w-full shadow-2xl border border-slate-200 space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Truck className="w-5 h-5 text-blue-600" />
                <h3 className="font-extrabold text-sm text-slate-900">
                  Assign Delivery Corridor & Driver
                </h3>
              </div>
              <button
                onClick={() => setDispatchModalOrderId(null)}
                className="text-slate-400 hover:text-slate-600 text-xs font-bold"
              >
                ✕ Close
              </button>
            </div>

            <form onSubmit={handleAssignDispatch} className="space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Delivery Route Corridor
                </label>
                <select
                  value={modalRoute}
                  onChange={(e) => setModalRoute(e.target.value)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white"
                >
                  {STANDARD_ROUTES.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Assigned Driver
                </label>
                <select
                  value={modalDriver}
                  onChange={(e) => {
                    setModalDriver(e.target.value);
                    const d = STANDARD_DRIVERS.find((drv) => drv.name === e.target.value);
                    if (d) setModalPlate(d.plate);
                  }}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white"
                >
                  {STANDARD_DRIVERS.map((d) => (
                    <option key={d.name} value={d.name}>
                      {d.name} ({d.vehicle})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Vehicle Plate Number
                </label>
                <input
                  type="text"
                  value={modalPlate}
                  onChange={(e) => setModalPlate(e.target.value)}
                  placeholder="e.g. 3-AA-84920"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold"
                />
              </div>

              <div className="pt-2 flex justify-end gap-2">
                <button
                  type="button"
                  onClick={() => setDispatchModalOrderId(null)}
                  className="px-4 py-2 rounded-xl border border-slate-200 text-slate-600 font-bold"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 rounded-xl bg-blue-600 hover:bg-blue-700 text-white font-bold"
                >
                  Dispatch to Route
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
