import React, { useState } from 'react';
import { useStore } from '../context/StoreContext';
import { PaymentMethod } from '../types';
import { money } from '../utils/helpers';
import { Factory, Plus, CheckCircle, Truck, DollarSign, ArrowDownLeft, AlertCircle } from 'lucide-react';

export const PurchasesView: React.FC = () => {
  const { db, totals, recordPurchase, paySupplier } = useStore();

  const [supplier, setSupplier] = useState('');
  const [productId, setProductId] = useState('');
  const [qty, setQty] = useState<number | ''>('');
  const [unitCost, setUnitCost] = useState<number | ''>('');
  const [payment, setPayment] = useState<PaymentMethod>('Cash');
  const [note, setNote] = useState('');

  // Supplier payment form
  const [settleSupplier, setSettleSupplier] = useState('');
  const [settleAmount, setSettleAmount] = useState<number | ''>('');

  const selectedProduct = db.products.find((p) => p.id === productId);

  // Auto-fill cost if product is selected
  const handleProductSelect = (id: string) => {
    setProductId(id);
    const prod = db.products.find((p) => p.id === id);
    if (prod && unitCost === '') {
      setUnitCost(prod.buy);
    }
  };

  const calculatedTotal = (Number(qty) || 0) * (Number(unitCost) || 0);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!supplier.trim() || !productId || !qty || !unitCost) return;

    const ok = recordPurchase({
      supplier: supplier.trim(),
      productId,
      qty: Number(qty),
      unitCost: Number(unitCost),
      payment,
      note: note.trim(),
    });

    if (ok) {
      setSupplier('');
      setProductId('');
      setQty('');
      setUnitCost('');
      setNote('');
    }
  };

  const handleSettle = (e: React.FormEvent) => {
    e.preventDefault();
    if (!settleSupplier.trim() || !settleAmount || Number(settleAmount) <= 0) return;
    const ok = paySupplier(settleSupplier.trim(), Number(settleAmount));
    if (ok) {
      setSettleSupplier('');
      setSettleAmount('');
    }
  };

  // Unique suppliers with debt
  const supplierDebts = db.purchases.reduce((acc, p) => {
    if (p.payment === 'Credit') {
      acc[p.supplier] = (acc[p.supplier] || 0) + p.total;
    }
    return acc;
  }, {} as Record<string, number>);

  return (
    <div className="space-y-4 pb-12">
      {/* Header */}
      <div className="p-4 sm:p-5 rounded-3xl bg-slate-900 text-white shadow-md border border-slate-800">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-amber-500/20 text-amber-400 border border-amber-400/30">
              <Factory className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white tracking-tight">
                Purchases & Supplier Procurement
              </h2>
              <p className="text-[11px] text-slate-300">
                Restock Inventory, Record Vendor Invoices & Settle Accounts Payable
              </p>
            </div>
          </div>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 block">
            TOTAL PROCUREMENT INVOICES
          </span>
          <span className="text-lg font-black text-slate-900 mt-0.5 block">
            {db.purchases.length} deliveries
          </span>
        </div>

        <div className="p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 block">
            TOTAL PURCHASES SPENT
          </span>
          <span className="text-lg font-black text-blue-700 mt-0.5 block">
            {money(db.purchases.reduce((a, p) => a + (p.total || 0), 0))}
          </span>
        </div>

        <div className="col-span-2 sm:col-span-1 p-3.5 rounded-2xl bg-white border border-slate-200/90 shadow-xs">
          <span className="text-[10px] font-extrabold uppercase text-slate-400 block">
            SUPPLIER CREDIT PAYABLES
          </span>
          <span className="text-lg font-black text-amber-600 mt-0.5 block">
            {money(totals.supplierDebt)}
          </span>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Record Purchase Form (8 cols) */}
        <div className="lg:col-span-8">
          <form
            onSubmit={handleSubmit}
            className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <Plus className="w-4 h-4 text-emerald-700" />
                <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
                  Record Stock Inward Delivery
                </h3>
              </div>
              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-100 text-amber-800">
                AUTO-INCREMENTS STOCK
              </span>
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Supplier / Vendor Name *
                </label>
                <input
                  id="purSupplier"
                  type="text"
                  value={supplier}
                  onChange={(e) => setSupplier(e.target.value)}
                  placeholder="e.g. Al-Noor Wholesalers"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Select Product to Restock *
                </label>
                <select
                  id="purProduct"
                  value={productId}
                  onChange={(e) => handleProductSelect(e.target.value)}
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                >
                  <option value="">-- Choose Product --</option>
                  {db.products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} (Current: {p.stock} {p.unit})
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Quantity Received ({selectedProduct?.unit || 'units'}) *
                </label>
                <input
                  id="purQty"
                  type="number"
                  min="1"
                  value={qty}
                  onChange={(e) => setQty(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="e.g. 20"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Unit Cost (ETB) *
                </label>
                <input
                  id="purUnitCost"
                  type="number"
                  min="0"
                  step="any"
                  value={unitCost}
                  onChange={(e) => setUnitCost(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="e.g. 450"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Payment Method
                </label>
                <select
                  id="purPayment"
                  value={payment}
                  onChange={(e) => setPayment(e.target.value as PaymentMethod)}
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                >
                  <option value="Cash">Cash on Delivery</option>
                  <option value="Bank">Bank Transfer (CBE/Awash)</option>
                  <option value="Mobile Money">Mobile Money (Telebirr)</option>
                  <option value="Credit">Supplier Credit (Payable Later)</option>
                </select>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Invoice / Batch Ref
                </label>
                <input
                  id="purNote"
                  type="text"
                  value={note}
                  onChange={(e) => setNote(e.target.value)}
                  placeholder="e.g. Invoice #9021"
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                />
              </div>
            </div>

            {/* Total invoice preview */}
            <div className="p-3 rounded-2xl bg-slate-50 border border-slate-200 flex items-center justify-between text-xs">
              <span className="text-slate-500">
                Calculated Invoice Total ({qty || 0} × {money(Number(unitCost) || 0)}):
              </span>
              <span className="font-black text-sm text-slate-900">
                {money(calculatedTotal)}
              </span>
            </div>

            <button
              type="submit"
              disabled={!supplier || !productId || !qty || !unitCost}
              className="w-full py-3 px-4 rounded-xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-xs font-black uppercase tracking-wider text-white transition-all shadow-md active:scale-98"
            >
              Confirm Purchase & Restock Inventory
            </button>
          </form>
        </div>

        {/* Settle Supplier Debt Side-box (4 cols) */}
        <div className="lg:col-span-4">
          <form
            onSubmit={handleSettle}
            className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4"
          >
            <div className="flex items-center gap-2 pb-2 border-b border-slate-100">
              <DollarSign className="w-4 h-4 text-amber-600" />
              <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
                Settle Supplier Debt
              </h3>
            </div>

            <p className="text-[11px] text-slate-500">
              Pay vendor outstanding credit directly from your cash balance.
            </p>

            <div className="space-y-3 text-xs">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Supplier Name
                </label>
                <input
                  id="settleSupplier"
                  type="text"
                  value={settleSupplier}
                  onChange={(e) => setSettleSupplier(e.target.value)}
                  placeholder="e.g. Al-Noor Wholesalers"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-semibold focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Amount to Pay (ETB)
                </label>
                <input
                  id="settleAmount"
                  type="number"
                  min="1"
                  step="any"
                  value={settleAmount}
                  onChange={(e) => setSettleAmount(e.target.value === '' ? '' : Number(e.target.value))}
                  placeholder="e.g. 5000"
                  required
                  className="w-full px-3 py-2 rounded-xl border border-slate-300 font-bold focus:ring-2 focus:ring-amber-500 focus:outline-hidden"
                />
              </div>

              <button
                type="submit"
                disabled={!settleSupplier || !settleAmount || Number(settleAmount) <= 0}
                className="w-full py-2.5 px-4 rounded-xl bg-amber-600 hover:bg-amber-700 disabled:opacity-50 text-xs font-black uppercase tracking-wider text-white transition-all shadow-xs active:scale-98"
              >
                Record Supplier Payment
              </button>
            </div>
          </form>
        </div>
      </div>

      {/* Procurement History */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
            Procurement & Supplier Invoices ({db.purchases.length})
          </h3>
        </div>

        <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
          {db.purchases.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              No supplier purchases recorded yet.
            </div>
          ) : (
            db.purchases.map((pur) => (
              <div key={pur.id} className="py-3 flex items-center justify-between gap-2 text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-slate-900">{pur.supplier}</span>
                    <span
                      className={`text-[9px] font-bold px-1.5 py-0.2 rounded-full ${
                        pur.payment === 'Credit'
                          ? 'bg-amber-100 text-amber-800'
                          : 'bg-slate-100 text-slate-700'
                      }`}
                    >
                      {pur.payment}
                    </span>
                    <span className="text-[10px] text-slate-400">{pur.date}</span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    <b>{pur.product}</b> · {pur.qty} units @ {money(pur.unitCost)}
                    {pur.note ? ` · ${pur.note}` : ''}
                  </div>
                </div>

                <div className="text-right">
                  <span className="font-black text-sm text-slate-900">
                    {money(pur.total)}
                  </span>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
