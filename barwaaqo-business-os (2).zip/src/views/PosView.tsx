import React, { useState, useMemo, useEffect } from 'react';
import { useStore } from '../context/StoreContext';
import { useTranslation } from '../i18n/LanguageContext';
import { SaleMode, PaymentMethod } from '../types';
import { money } from '../utils/helpers';
import {
  Receipt,
  ShoppingCart,
  Trash2,
  CheckCircle,
  Users,
  CreditCard,
  Tag,
  Plus,
  Minus,
  Sparkles,
  Search,
  QrCode,
  ShieldCheck,
  Settings,
  Keyboard,
  Sliders,
  Zap,
  CornerDownLeft,
} from 'lucide-react';
import { calculateCartTaxes } from '../utils/taxEngine';
import { PosShortcutsModal } from '../components/pos/PosShortcutsModal';
import { QuickTapCustomizerModal } from '../components/pos/QuickTapCustomizerModal';

export const PosView: React.FC = () => {
  const { t } = useTranslation();
  const {
    db,
    cart,
    addToCart,
    updateCartQty,
    removeFromCart,
    clearCart,
    completeSale,
    setActiveTab,
    setProductQrModalId,
    taxSettings,
    setIsTaxModalOpen,
    updateCartItemTaxTier,
    showToast,
  } = useStore();

  const [selectedCustomerId, setSelectedCustomerId] = useState<string>('');
  const [mode, setMode] = useState<SaleMode>('retail');
  const [selectedProductId, setSelectedProductId] = useState<string>('');
  const [qty, setQty] = useState<number>(1);
  const [paymentMethod, setPaymentMethod] = useState<PaymentMethod>('Cash');
  const [discount, setDiscount] = useState<number>(0);

  // Quick-Tap and Keyboard Shortcut state
  const [isShortcutsModalOpen, setIsShortcutsModalOpen] = useState<boolean>(false);
  const [isCustomizeModalOpen, setIsCustomizeModalOpen] = useState<boolean>(false);
  const [quickTapPids, setQuickTapPids] = useState<string[]>(() => {
    try {
      const saved = localStorage.getItem('barwaaqo_pos_quick_tap_pids');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) return parsed;
      }
    } catch {
      // fallback
    }
    return db.products.slice(0, 8).map((p) => p.id);
  });
  const [directAddToCart, setDirectAddToCart] = useState<boolean>(() => {
    try {
      const saved = localStorage.getItem('barwaaqo_pos_quick_tap_direct');
      return saved !== 'false';
    } catch {
      return true;
    }
  });

  const selectedProduct = db.products.find((p) => p.id === selectedProductId);
  const selectedCustomer = db.customers.find((c) => c.id === selectedCustomerId);

  const activeUnitPrice = selectedProduct
    ? mode === 'wholesale'
      ? selectedProduct.wholesale
      : selectedProduct.sell
    : 0;

  // Real-time multi-tier statutory tax calculation
  const cartTaxCalc = useMemo(() => {
    return calculateCartTaxes(cart, discount || 0, taxSettings);
  }, [cart, discount, taxSettings]);

  const subtotal = cartTaxCalc.subtotal;
  const total = cartTaxCalc.totalPayable;
  const totalItemsCount = cart.reduce((acc, item) => acc + item.qty, 0);

  const handleAddToCart = (e: React.FormEvent) => {
    e.preventDefault();
    if (!selectedProductId) return;
    const ok = addToCart(selectedProductId, qty, mode);
    if (ok) {
      setQty(1);
    }
  };

  const handleCheckout = () => {
    completeSale(discount, paymentMethod, selectedCustomerId);
  };

  // Quick tap product handler
  const handleQuickTapItem = (p: typeof db.products[0], keyIndex?: number) => {
    if (p.stock <= 0) {
      showToast(`⚠️ ${p.name} is out of stock!`);
      return;
    }
    if (directAddToCart) {
      const ok = addToCart(p.id, 1, mode);
      if (ok) {
        const keyLabel = keyIndex !== undefined ? ` [Key ${keyIndex + 1}]` : '';
        showToast(`⚡ Added 1x ${p.name} to cart${keyLabel}`);
      }
    } else {
      setSelectedProductId(p.id);
      setQty(1);
      showToast(`Selected ${p.name} · Choose qty & add`);
    }
  };

  const handleSaveQuickTapConfig = (ids: string[], direct: boolean) => {
    setQuickTapPids(ids);
    setDirectAddToCart(direct);
    try {
      localStorage.setItem('barwaaqo_pos_quick_tap_pids', JSON.stringify(ids));
      localStorage.setItem('barwaaqo_pos_quick_tap_direct', String(direct));
    } catch {
      // ignore
    }
    showToast(`Saved ${ids.length} Quick-Tap shortcut buttons`);
  };

  // Global Cashier Keyboard Shortcut Listener
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const activeEl = document.activeElement;
      const isInput =
        activeEl instanceof HTMLInputElement ||
        activeEl instanceof HTMLTextAreaElement ||
        activeEl instanceof HTMLSelectElement;

      // Escape: Dismiss active modals or clear selection
      if (e.key === 'Escape') {
        if (isShortcutsModalOpen) {
          setIsShortcutsModalOpen(false);
          return;
        }
        if (isCustomizeModalOpen) {
          setIsCustomizeModalOpen(false);
          return;
        }
        if (isInput) {
          (activeEl as HTMLElement).blur();
          return;
        }
        setSelectedProductId('');
        return;
      }

      // Complete Checkout with F9 or Ctrl+Enter (always active)
      if (e.key === 'F9' || (e.ctrlKey && e.key === 'Enter')) {
        e.preventDefault();
        if (cart.length > 0) {
          if (paymentMethod === 'Credit' && !selectedCustomerId) {
            showToast('⚠️ Credit sale requires selecting a customer account');
          } else {
            completeSale(discount, paymentMethod, selectedCustomerId);
          }
        } else {
          showToast('Cart is empty. Add products before checkout.');
        }
        return;
      }

      // Do NOT trigger alphanumeric shortcuts if user is typing text in an input or select
      if (isInput) return;

      // Help Guide: ? or /
      if (e.key === '?' || e.key === '/') {
        e.preventDefault();
        setIsShortcutsModalOpen((prev) => !prev);
        return;
      }

      // Mode toggle: F8 or Alt+W
      if (e.key === 'F8' || (e.altKey && (e.key === 'w' || e.key === 'W'))) {
        e.preventDefault();
        setMode((prev) => {
          const next = prev === 'retail' ? 'wholesale' : 'retail';
          showToast(`Pricing Mode: ${next.toUpperCase()}`);
          return next;
        });
        return;
      }

      // Payment method cycle: F10 or Alt+P
      if (e.key === 'F10' || (e.altKey && (e.key === 'p' || e.key === 'P'))) {
        e.preventDefault();
        const methods: PaymentMethod[] = ['Cash', 'Bank', 'Mobile Money', 'Credit'];
        setPaymentMethod((prev) => {
          const nextIdx = (methods.indexOf(prev) + 1) % methods.length;
          const next = methods[nextIdx];
          showToast(`Payment Method: ${next}`);
          return next;
        });
        return;
      }

      // Clear Cart: F4 or Alt+C
      if (e.key === 'F4' || (e.altKey && (e.key === 'c' || e.key === 'C'))) {
        e.preventDefault();
        if (cart.length > 0) {
          clearCart();
          showToast('Active sales cart cleared');
        }
        return;
      }

      // Focus product search picker: F2 or Ctrl+K
      if (e.key === 'F2' || (e.ctrlKey && (e.key === 'k' || e.key === 'K'))) {
        e.preventDefault();
        const prodSelect = document.getElementById('posProduct');
        if (prodSelect) prodSelect.focus();
        return;
      }

      // Number keys 1-9: Instant Quick Add from Quick-Tap shelf!
      if (/^[1-9]$/.test(e.key) && !e.ctrlKey && !e.altKey && !e.metaKey) {
        const index = parseInt(e.key, 10) - 1;
        const targetPid = quickTapPids[index];
        if (targetPid) {
          const prod = db.products.find((p) => p.id === targetPid);
          if (prod) {
            e.preventDefault();
            handleQuickTapItem(prod, index);
          }
        }
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [
    cart,
    discount,
    paymentMethod,
    selectedCustomerId,
    quickTapPids,
    db.products,
    mode,
    directAddToCart,
    isShortcutsModalOpen,
    isCustomizeModalOpen,
  ]);

  return (
    <div className="space-y-4 pb-12">
      {/* Header card */}
      <div className="p-4 sm:p-5 rounded-3xl bg-gradient-to-r from-slate-900 to-slate-800 text-white shadow-md border border-slate-700/60">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div className="p-2.5 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30">
              <Receipt className="w-5 h-5" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-extrabold text-white tracking-tight">
                POS · Smart Sales Terminal
              </h2>
              <p className="text-[11px] text-slate-300">
                Retail & Wholesale Checkout with Instant Inventory Deduction
              </p>
            </div>
          </div>
          <div className="flex items-center gap-2 flex-wrap">
            <button
              id="pos-shortcuts-btn"
              type="button"
              onClick={() => setIsShortcutsModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 border border-amber-400/40 text-amber-300 text-xs font-bold transition-all shadow-xs"
              title="View Cashier Keyboard Shortcuts Cheat Sheet (?)"
            >
              <Keyboard className="w-3.5 h-3.5 text-amber-400" />
              <span>Shortcuts [?]</span>
            </button>
            <button
              id="pos-tax-config-btn"
              type="button"
              onClick={() => setIsTaxModalOpen(true)}
              className="flex items-center gap-1.5 px-3 py-1 rounded-xl bg-slate-800 hover:bg-slate-700 border border-emerald-500/40 text-emerald-300 text-xs font-bold transition-all shadow-xs"
              title="Configure Multi-Tier Tax Rates"
            >
              <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" />
              <span>{taxSettings.taxLabel} ({taxSettings.calculationMethod})</span>
              <Settings className="w-3 h-3 text-slate-400 ml-0.5" />
            </button>
            <span
              className={`text-xs font-bold px-3 py-1 rounded-xl uppercase tracking-wider ${
                mode === 'wholesale'
                  ? 'bg-amber-400 text-amber-950 font-black'
                  : 'bg-emerald-400 text-emerald-950 font-black'
              }`}
            >
              {mode} MODE
            </span>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">
        {/* Left Column: Product Selection & Configuration (7 cols) */}
        <div className="lg:col-span-7 space-y-4">
          <form
            onSubmit={handleAddToCart}
            className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4"
          >
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <span className="font-extrabold text-xs uppercase tracking-wider text-slate-700">
                1. Transaction Settings
              </span>
              <div className="flex items-center bg-slate-100 p-0.5 rounded-xl border border-slate-200">
                <button
                  type="button"
                  id="pos-retail-btn"
                  onClick={() => setMode('retail')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    mode === 'retail'
                      ? 'bg-white text-emerald-700 shadow-xs'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                  title="Switch to Retail Price (Alt+W)"
                >
                  <span>{t('retail')}</span>
                  <kbd className="text-[9px] font-mono px-1 py-0.2 rounded bg-slate-200/70 text-slate-700">
                    Alt+W
                  </kbd>
                </button>
                <button
                  type="button"
                  id="pos-wholesale-btn"
                  onClick={() => setMode('wholesale')}
                  className={`px-3 py-1 rounded-lg text-xs font-bold transition-all flex items-center gap-1.5 ${
                    mode === 'wholesale'
                      ? 'bg-white text-amber-700 shadow-xs'
                      : 'text-slate-500 hover:text-slate-900'
                  }`}
                  title="Switch to Wholesale Price (Alt+W)"
                >
                  <span>{t('wholesale')}</span>
                  <kbd className="text-[9px] font-mono px-1 py-0.2 rounded bg-slate-200/70 text-slate-700">
                    Alt+W
                  </kbd>
                </button>
              </div>
            </div>

            {/* Customer select */}
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                {t('customerAccount')}
              </label>
              <div className="flex gap-2">
                <select
                  id="posCustomer"
                  value={selectedCustomerId}
                  onChange={(e) => setSelectedCustomerId(e.target.value)}
                  className="flex-1 px-3 py-2.5 rounded-xl border border-slate-300 text-xs font-semibold bg-slate-50/50 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                >
                  <option value="">{t('walkInCustomer')}</option>
                  {db.customers.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name} {c.credit > 0 ? `· (Debt: ${money(c.credit)})` : ''}
                    </option>
                  ))}
                </select>
                <button
                  type="button"
                  onClick={() => setActiveTab('customers')}
                  className="px-2.5 py-2 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs"
                  title="Add customer"
                >
                  <Plus className="w-4 h-4" />
                </button>
              </div>
              {selectedCustomer && selectedCustomer.credit > 0 && (
                <div className="mt-1 text-[11px] text-rose-600 font-semibold flex items-center gap-1">
                  <span>Outstanding customer balance: {money(selectedCustomer.credit)}</span>
                </div>
              )}
            </div>

            {/* Product select */}
            <div>
              <label className="block text-[11px] font-bold text-slate-600 mb-1">
                Select Grocery Product
              </label>
              <select
                id="posProduct"
                value={selectedProductId}
                onChange={(e) => {
                  setSelectedProductId(e.target.value);
                  setQty(1);
                }}
                required
                className="w-full px-3.5 py-2.5 rounded-xl border border-slate-300 text-xs font-bold bg-white focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
              >
                <option value="">-- Choose Product from Inventory --</option>
                {db.products.map((p) => (
                  <option key={p.id} value={p.id} disabled={p.stock <= 0}>
                    {p.name} · {p.stock} {p.unit} in stock ·{' '}
                    {mode === 'wholesale' ? money(p.wholesale) : money(p.sell)}
                    {p.stock <= 0 ? ' (OUT OF STOCK)' : ''}
                  </option>
                ))}
              </select>
            </div>

            {/* Selected Product Live Details Card */}
            {selectedProduct && (
              <div className="p-3.5 rounded-2xl bg-emerald-50/70 border border-emerald-200/80 space-y-2">
                <div className="flex justify-between items-center text-xs">
                  <span className="font-extrabold text-slate-900">{selectedProduct.name}</span>
                  <span
                    className={`font-black px-2 py-0.5 rounded-full text-[10px] ${
                      selectedProduct.stock <= 0
                        ? 'bg-rose-100 text-rose-700'
                        : selectedProduct.stock <= selectedProduct.min
                        ? 'bg-amber-100 text-amber-800'
                        : 'bg-emerald-100 text-emerald-800'
                    }`}
                  >
                    {selectedProduct.stock} {selectedProduct.unit} available
                  </span>
                </div>
                <div className="grid grid-cols-3 gap-2 text-[11px] pt-1 border-t border-emerald-200/60">
                  <div>
                    <span className="text-slate-500 block">Unit Cost</span>
                    <span className="font-bold text-slate-700">{money(selectedProduct.buy)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">{mode} Price</span>
                    <span className="font-black text-emerald-700">{money(activeUnitPrice)}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block">Unit Margin</span>
                    <span className="font-bold text-emerald-800">
                      +{money(activeUnitPrice - selectedProduct.buy)}
                    </span>
                  </div>
                </div>
                <div className="flex items-center justify-between pt-1 border-t border-emerald-200/60 text-[10px]">
                  <span className="text-slate-500">
                    SKU: <b className="font-mono text-slate-700">{selectedProduct.sku || 'N/A'}</b>
                  </span>
                  <button
                    type="button"
                    onClick={() => setProductQrModalId(selectedProduct.id)}
                    className="flex items-center gap-1 font-bold text-emerald-800 hover:text-emerald-950 underline"
                    title="View auto-generated QR code, stock movements & profit margins"
                  >
                    <QrCode className="w-3 h-3 text-emerald-600" />
                    <span>View QR & Stock Ledger</span>
                  </button>
                </div>
              </div>
            )}

            {/* Quantity Selector */}
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Quantity ({selectedProduct?.unit || 'units'})
                </label>
                <div className="flex items-center gap-1.5">
                  <button
                    type="button"
                    onClick={() => setQty((q) => Math.max(1, q - 1))}
                    className="p-2 rounded-xl border border-slate-300 bg-slate-100 hover:bg-slate-200 text-slate-700 font-black"
                  >
                    <Minus className="w-3.5 h-3.5" />
                  </button>
                  <input
                    id="posQty"
                    type="number"
                    min="1"
                    max={selectedProduct?.stock || 99999}
                    value={qty}
                    onChange={(e) => setQty(Math.max(1, Number(e.target.value)))}
                    className="w-full text-center py-2 rounded-xl border border-slate-300 text-sm font-black focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
                  />
                  <button
                    type="button"
                    onClick={() =>
                      setQty((q) => (selectedProduct ? Math.min(selectedProduct.stock, q + 1) : q + 1))
                    }
                    className="p-2 rounded-xl border border-slate-300 bg-slate-100 hover:bg-slate-200 text-slate-700 font-black"
                  >
                    <Plus className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-bold text-slate-600 mb-1">
                  Line Preview
                </label>
                <div className="py-2 px-3 rounded-xl bg-slate-100 border border-slate-200 text-xs flex flex-col justify-center">
                  <span className="text-[10px] text-slate-500">
                    {qty} × {money(activeUnitPrice)}
                  </span>
                  <span className="font-black text-sm text-slate-900 mt-0.5">
                    {money(qty * activeUnitPrice)}
                  </span>
                </div>
              </div>
            </div>

            <button
              type="submit"
              disabled={!selectedProduct || selectedProduct.stock <= 0 || qty <= 0}
              className="w-full py-3 px-4 rounded-2xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-xs font-black uppercase tracking-wider text-white transition-all shadow-md active:scale-98 flex items-center justify-center gap-2"
            >
              <ShoppingCart className="w-4 h-4" />
              <span>{t('addToCart')}</span>
            </button>
          </form>

          {/* Customizable Quick-Tap Shelf & Numpad Keys (1–9) */}
          <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
            <div className="flex items-center justify-between gap-2 flex-wrap pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <div className="p-1.5 rounded-lg bg-amber-400/20 text-amber-700">
                  <Zap className="w-4 h-4 fill-amber-500" />
                </div>
                <div>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-black text-slate-900 uppercase tracking-wider">
                      {t('quickTapShelf')}
                    </span>
                    <span className="text-[10px] font-mono font-bold px-1.5 py-0.5 rounded bg-slate-900 text-amber-300">
                      Keys 1–9
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-500">
                    {directAddToCart ? '1-Tap instant add to cart' : 'Select to configure qty'}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() =>
                    setDirectAddToCart((prev) => {
                      const next = !prev;
                      try {
                        localStorage.setItem('barwaaqo_pos_quick_tap_direct', String(next));
                      } catch {
                        // ignore
                      }
                      showToast(next ? '1-Tap Quick Add: Enabled' : '1-Tap Quick Add: Select Mode');
                      return next;
                    })
                  }
                  className={`px-2 py-1 rounded-lg text-[10px] font-bold border transition flex items-center gap-1 ${
                    directAddToCart
                      ? 'bg-emerald-50 text-emerald-800 border-emerald-300'
                      : 'bg-slate-100 text-slate-600 border-slate-300'
                  }`}
                  title="Toggle 1-Tap direct add vs selecting item"
                >
                  <Zap className="w-3 h-3" />
                  <span>1-Tap Add: {directAddToCart ? 'ON' : 'OFF'}</span>
                </button>

                <button
                  type="button"
                  id="pos-customize-quick-keys-btn"
                  onClick={() => setIsCustomizeModalOpen(true)}
                  className="px-2.5 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 text-xs font-bold transition flex items-center gap-1.5 shadow-2xs"
                  title="Customize which products appear as Quick-Tap buttons"
                >
                  <Sliders className="w-3.5 h-3.5 text-slate-600" />
                  <span>Customize</span>
                </button>
              </div>
            </div>

            {/* Quick Tap Buttons Grid */}
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
              {quickTapPids.map((pid, idx) => {
                const p = db.products.find((prod) => prod.id === pid);
                if (!p) return null;
                const unitPrice = mode === 'wholesale' ? p.wholesale : p.sell;
                const keyNum = idx < 9 ? idx + 1 : null;
                const isOutOfStock = p.stock <= 0;
                const isSelected = selectedProductId === p.id;

                return (
                  <button
                    key={p.id}
                    type="button"
                    onClick={() => handleQuickTapItem(p, idx)}
                    disabled={isOutOfStock}
                    className={`relative p-2.5 rounded-2xl border text-left transition-all group flex flex-col justify-between ${
                      isSelected
                        ? 'bg-emerald-50/90 border-emerald-500 shadow-sm ring-2 ring-emerald-500/20'
                        : isOutOfStock
                        ? 'bg-slate-50 text-slate-400 border-slate-200 opacity-60 cursor-not-allowed'
                        : 'bg-slate-50/70 hover:bg-emerald-50/50 hover:border-emerald-300 text-slate-800 border-slate-200/90 active:scale-97'
                    }`}
                  >
                    <div className="flex items-start justify-between gap-1 w-full mb-1">
                      {keyNum !== null ? (
                        <span className="w-5 h-5 rounded-lg bg-slate-900 text-amber-300 font-mono text-[11px] font-black flex items-center justify-center shadow-xs shrink-0">
                          {keyNum}
                        </span>
                      ) : (
                        <span className="w-2 h-2 rounded-full bg-emerald-400 mt-1.5" />
                      )}
                      <span
                        className={`text-[10px] font-bold px-1.5 py-0.2 rounded-md shrink-0 ${
                          isOutOfStock
                            ? 'bg-rose-100 text-rose-700'
                            : p.stock <= p.min
                            ? 'bg-amber-100 text-amber-800'
                            : 'bg-slate-200/80 text-slate-700'
                        }`}
                      >
                        {isOutOfStock ? '0' : p.stock} {p.unit}
                      </span>
                    </div>

                    <div className="font-extrabold text-xs text-slate-900 line-clamp-1 group-hover:text-emerald-900">
                      {p.name}
                    </div>

                    <div className="flex items-center justify-between mt-1 pt-1 border-t border-slate-200/60 w-full text-[11px]">
                      <span className="font-black text-emerald-800 tabular-nums">
                        {money(unitPrice)}
                      </span>
                      <span className="text-[10px] font-bold text-slate-400 group-hover:text-emerald-700 flex items-center">
                        +1
                      </span>
                    </div>
                  </button>
                );
              })}
            </div>

            {/* Quick Keyboard Helper Strip */}
            <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
              <span className="flex items-center gap-1.5">
                <kbd className="px-1.5 py-0.5 rounded bg-slate-100 border border-slate-300 font-mono font-bold text-slate-700 text-[10px]">
                  1–9
                </kbd>
                <span>Press numpad keys for instant item entry</span>
              </span>
              <button
                type="button"
                onClick={() => setIsShortcutsModalOpen(true)}
                className="text-emerald-700 hover:text-emerald-900 font-bold underline text-[11px]"
              >
                All Shortcuts (?)
              </button>
            </div>
          </div>
        </div>

        {/* Right Column: Active Cart & Checkout (5 cols) */}
        <div className="lg:col-span-5 space-y-4">
          <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
            <div className="flex items-center justify-between pb-2 border-b border-slate-100">
              <div className="flex items-center gap-2">
                <ShoppingCart className="w-4 h-4 text-emerald-700" />
                <span className="font-extrabold text-xs uppercase tracking-wider text-slate-900">
                  {t('activeCart')} ({totalItemsCount})
                </span>
              </div>
              {cart.length > 0 && (
                <button
                  onClick={clearCart}
                  className="text-[11px] text-rose-600 hover:text-rose-800 font-bold transition-colors flex items-center gap-1"
                  title="Clear Cart (Alt+C or F4)"
                >
                  <span>{t('clearCart')}</span>
                  <kbd className="text-[9px] font-mono px-1 py-0.2 rounded bg-rose-50 border border-rose-200 text-rose-700">
                    Alt+C
                  </kbd>
                </button>
              )}
            </div>

            {/* Cart Items List */}
            <div className="max-h-64 overflow-y-auto divide-y divide-slate-100">
              {cart.length === 0 ? (
                <div className="py-10 text-center text-slate-400 text-xs">
                  <ShoppingCart className="w-8 h-8 mx-auto text-slate-300 mb-2" />
                  {t('emptyCart')}
                </div>
              ) : (
                cart.map((item, idx) => (
                  <div key={`${item.pid}-${item.mode}`} className="py-2.5 flex items-center justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="font-bold text-xs text-slate-900 truncate">
                        {item.name}
                      </div>
                      <div className="flex items-center gap-1.5 text-[11px] text-slate-500 mt-0.5 flex-wrap">
                        <span className="uppercase text-[9px] font-extrabold px-1.5 rounded bg-slate-100 text-slate-700">
                          {item.mode}
                        </span>
                        <span>{money(item.price)} each</span>
                        {taxSettings.tiers.length > 0 && (
                          <select
                            value={item.taxTierId || taxSettings.defaultTierId}
                            onChange={(e) => updateCartItemTaxTier(idx, e.target.value)}
                            className="text-[9px] font-mono font-bold bg-slate-100 hover:bg-slate-200 text-emerald-800 border border-slate-300 rounded px-1 py-0.2 focus:outline-hidden"
                            title="Tax Tier Bracket"
                          >
                            {taxSettings.tiers.map((t) => (
                              <option key={t.id} value={t.id}>
                                {t.code} ({t.rate}%)
                              </option>
                            ))}
                          </select>
                        )}
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <div className="flex items-center bg-slate-100 rounded-lg p-0.5 border border-slate-200">
                        <button
                          onClick={() => updateCartQty(idx, Math.max(1, item.qty - 1))}
                          className="px-1.5 py-0.5 text-xs font-bold text-slate-600 hover:bg-white rounded"
                        >
                          −
                        </button>
                        <span className="px-2 text-xs font-black text-slate-800">
                          {item.qty}
                        </span>
                        <button
                          onClick={() => updateCartQty(idx, item.qty + 1)}
                          className="px-1.5 py-0.5 text-xs font-bold text-slate-600 hover:bg-white rounded"
                        >
                          ＋
                        </button>
                      </div>

                      <span className="font-black text-xs text-slate-900 min-w-[70px] text-right">
                        {money(item.qty * item.price)}
                      </span>

                      <button
                        onClick={() => removeFromCart(idx)}
                        className="p-1 text-slate-300 hover:text-rose-600 transition-colors"
                        title="Remove item"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>

            {/* Subtotal, Discount & Total with Multi-Tier Tax Breakdown */}
            <div className="p-3.5 rounded-2xl bg-slate-50 border border-slate-200/80 space-y-2 text-xs">
              <div className="flex justify-between items-center text-slate-600">
                <span>{t('subtotal')}:</span>
                <span className="font-bold text-slate-800">{money(cartTaxCalc.subtotal)}</span>
              </div>

              <div className="flex justify-between items-center text-slate-600">
                <span className="flex items-center gap-1">
                  <Tag className="w-3.5 h-3.5 text-slate-400" />
                  {t('discount')} (ETB):
                </span>
                <input
                  id="posDiscount"
                  type="number"
                  min="0"
                  max={cartTaxCalc.subtotal}
                  value={discount || ''}
                  onChange={(e) => setDiscount(Math.max(0, Number(e.target.value)))}
                  placeholder="0.00"
                  className="w-24 px-2 py-1 rounded-lg border border-slate-300 text-right font-bold text-xs bg-white focus:outline-hidden focus:ring-1 focus:ring-emerald-500"
                />
              </div>

              {/* Statutory Tax Breakdown */}
              {taxSettings.enabled && (
                <div className="pt-2 border-t border-slate-200 space-y-1.5">
                  <div className="flex justify-between items-center text-slate-700 font-semibold">
                    <span className="flex items-center gap-1">
                      <ShieldCheck className="w-3.5 h-3.5 text-emerald-600" />
                      <span>{taxSettings.taxLabel} Tax:</span>
                      <span className="text-[10px] font-normal text-slate-400">
                        ({taxSettings.calculationMethod})
                      </span>
                    </span>
                    <span className="font-bold text-emerald-700">
                      {taxSettings.calculationMethod === 'exclusive' ? '+' : ''}
                      {money(cartTaxCalc.taxAmount)}
                    </span>
                  </div>

                  {/* Itemized Tiers Breakdown */}
                  {cartTaxCalc.tierBreakdown.map((tb) => (
                    <div
                      key={tb.tierId}
                      className="flex justify-between items-center text-xs text-slate-600 pl-4 font-medium"
                    >
                      <span className="flex items-center gap-1">
                        <span className="font-mono font-bold text-slate-700">{tb.code}</span>
                        <span>({tb.rate}% on {money(tb.taxableAmount)}):</span>
                      </span>
                      <span className="font-bold text-slate-800 tabular-nums">{money(tb.taxCollected)}</span>
                    </div>
                  ))}

                  {taxSettings.calculationMethod === 'inclusive' && (
                    <div className="text-[11px] text-slate-500 italic pl-4">
                      * Tax is included in shelf price
                    </div>
                  )}
                </div>
              )}

              <div className="pt-2 border-t border-slate-200 flex justify-between items-center">
                <span className="font-extrabold text-sm text-slate-900">{t('totalPayable')}:</span>
                <span className="font-black text-xl text-emerald-800 tracking-tight tabular-nums">
                  {money(cartTaxCalc.totalPayable)}
                </span>
              </div>
            </div>

            {/* Payment Method Selector */}
            <div className="space-y-1.5">
              <div className="flex items-center justify-between">
                <label className="block text-[11px] font-bold text-slate-700">
                  {t('paymentChannel')}
                </label>
                <span className="text-[10px] text-slate-400 font-mono">
                  Cycle: <kbd className="bg-slate-100 border border-slate-300 px-1 py-0.2 rounded text-slate-700">Alt+P</kbd>
                </span>
              </div>
              <div className="grid grid-cols-2 gap-2">
                {(['Cash', 'Bank', 'Mobile Money', 'Credit'] as PaymentMethod[]).map((pm) => (
                  <button
                    key={pm}
                    type="button"
                    onClick={() => setPaymentMethod(pm)}
                    className={`py-2 px-3 rounded-xl text-xs font-extrabold border transition-all text-center ${
                      paymentMethod === pm
                        ? 'bg-slate-900 text-white border-slate-900 shadow-sm'
                        : 'bg-white text-slate-700 border-slate-200 hover:bg-slate-50'
                    }`}
                  >
                    {pm}
                  </button>
                ))}
              </div>
              {paymentMethod === 'Credit' && !selectedCustomerId && (
                <p className="text-[11px] text-rose-600 font-semibold mt-1">
                  ⚠️ Credit sale requires selecting a customer from the account dropdown.
                </p>
              )}
            </div>

            {/* Complete Sale Button */}
            <button
              id="pos-complete-sale"
              onClick={handleCheckout}
              disabled={cart.length === 0 || (paymentMethod === 'Credit' && !selectedCustomerId)}
              className="w-full py-3.5 px-4 rounded-2xl bg-emerald-700 hover:bg-emerald-800 disabled:opacity-50 text-xs font-black uppercase tracking-wider text-white transition-all shadow-lg active:scale-98 flex items-center justify-center gap-2"
              title="Complete Sale (F9 or Ctrl+Enter)"
            >
              <CheckCircle className="w-4 h-4" />
              <span>{t('completeSale')} · {money(total)}</span>
              <kbd className="ml-1 text-[10px] font-mono px-2 py-0.5 rounded-lg bg-emerald-900/70 border border-emerald-500/40 text-emerald-200 uppercase">
                F9 / Ctrl+↵
              </kbd>
            </button>
          </div>
        </div>
      </div>

      {/* Recent Transactions List */}
      <div className="p-4 sm:p-5 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Receipt className="w-4 h-4 text-emerald-700" />
            <h3 className="font-extrabold text-sm text-slate-900 tracking-tight">
              Recent Sales Transactions ({db.sales.length})
            </h3>
          </div>
          <span className="text-[11px] text-slate-400">Past orders and invoices</span>
        </div>

        <div className="divide-y divide-slate-100 max-h-80 overflow-y-auto">
          {db.sales.length === 0 ? (
            <div className="py-8 text-center text-xs text-slate-400">
              No sales transactions completed yet.
            </div>
          ) : (
            db.sales.slice(0, 15).map((sale) => (
              <div key={sale.id} className="py-3 flex items-center justify-between gap-3 text-xs">
                <div>
                  <div className="flex items-center gap-2">
                    <span className="font-extrabold text-slate-900">{sale.invoice}</span>
                    <span className="text-[10px] font-bold px-1.5 py-0.2 rounded bg-slate-100 text-slate-700">
                      {sale.payment}
                    </span>
                    <span className="text-[10px] text-slate-400">
                      {sale.date} {sale.time}
                    </span>
                  </div>
                  <div className="text-[11px] text-slate-500 mt-0.5">
                    <b>{sale.customer}</b> ·{' '}
                    {sale.items.map((it) => `${it.name} (${it.qty})`).join(', ')}
                  </div>
                </div>

                <div className="text-right">
                  <div className="font-black text-sm text-slate-900 tracking-tight">
                    {money(sale.total)}
                  </div>
                  <div className="text-[10px] text-emerald-700 font-bold">
                    +{money(sale.profit)} profit
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      </div>

      {/* Cashier Speed Keyboard Shortcuts Modal */}
      <PosShortcutsModal
        isOpen={isShortcutsModalOpen}
        onClose={() => setIsShortcutsModalOpen(false)}
      />

      {/* Quick-Tap Buttons Customizer Modal */}
      <QuickTapCustomizerModal
        isOpen={isCustomizeModalOpen}
        onClose={() => setIsCustomizeModalOpen(false)}
        products={db.products}
        selectedProductIds={quickTapPids}
        onSave={handleSaveQuickTapConfig}
        directAddToCart={directAddToCart}
      />
    </div>
  );
};
