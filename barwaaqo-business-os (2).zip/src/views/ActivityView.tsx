import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import { money } from '../utils/helpers';
import { ActivityCategory, ActivityLog, SystemUser } from '../types';
import {
  History,
  Search,
  ShieldCheck,
  AlertTriangle,
  SlidersHorizontal,
  ArrowUpRight,
  ArrowDownRight,
  User,
  DollarSign,
  Package,
  Calendar,
  Clock,
  Filter,
  Download,
  CheckCircle2,
  Trash2,
  ChevronDown,
  Layers,
  Settings2,
  Lock,
  KeyRound,
  FileEdit,
  Landmark,
  ShieldAlert,
  Sparkles,
  Tag,
  Plus,
  X,
  Mic,
} from 'lucide-react';
import { FinancialLedgerModal } from '../components/modals/FinancialLedgerModal';
import { PinSettingsModal } from '../components/modals/PinSettingsModal';
import { AuditNoteModal } from '../components/modals/AuditNoteModal';
import { PinVerificationModal } from '../components/modals/PinVerificationModal';
import { VoiceNoteModal } from '../components/modals/VoiceNoteModal';

export const ActivityView: React.FC = () => {
  const {
    db,
    clearActivityLog,
    currentUser,
    setCurrentUser,
    availableUsers,
    highValueThreshold,
    setHighValueThreshold,
    setStockAdjustProductId,
    showToast,
  } = useStore();

  const [search, setSearch] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [selectedUserId, setSelectedUserId] = useState<string>('all');
  const [showThresholdConfig, setShowThresholdConfig] = useState(false);
  const [tempThreshold, setTempThreshold] = useState(String(highValueThreshold));

  // Modal dialog states
  const [isFinancialModalOpen, setIsFinancialModalOpen] = useState(false);
  const [isPinSettingsOpen, setIsPinSettingsOpen] = useState(false);
  const [isProductPickerOpen, setIsProductPickerOpen] = useState(false);
  const [isVoiceNoteModalOpen, setIsVoiceNoteModalOpen] = useState(false);
  const [productSearch, setProductSearch] = useState('');
  const [auditNoteLog, setAuditNoteLog] = useState<ActivityLog | null>(null);
  const [showPurgePinModal, setShowPurgePinModal] = useState(false);

  const allLogs = useMemo(() => db.activity || [], [db.activity]);

  // Quick stats calculation
  const stats = useMemo(() => {
    let highValueCount = 0;
    let highValueTotal = 0;
    let stockAdjustmentCount = 0;
    let financialLedgerCount = 0;
    let pinVerifiedCount = 0;
    const uniqueUsers = new Set<string>();

    for (const log of allLogs) {
      if (log.userId) uniqueUsers.add(log.userId);
      if (log.isHighValue || log.category === 'high_value_transaction') {
        highValueCount += 1;
        if (typeof log.amount === 'number') highValueTotal += log.amount;
      }
      if (
        log.category === 'inventory_adjustment' ||
        log.action.includes('ADJUSTMENT') ||
        log.action.includes('STOCK')
      ) {
        stockAdjustmentCount += 1;
      }
      if (
        log.category === 'financial_ledger' ||
        log.action.includes('FINANCIAL') ||
        log.action.includes('CAPITAL') ||
        log.action.includes('LEDGER')
      ) {
        financialLedgerCount += 1;
      }
      if (log.verifiedByPin) {
        pinVerifiedCount += 1;
      }
    }

    return {
      total: allLogs.length,
      highValueCount,
      highValueTotal,
      stockAdjustmentCount,
      financialLedgerCount,
      pinVerifiedCount,
      uniqueUsersCount: uniqueUsers.size,
    };
  }, [allLogs]);

  // Filtering logic
  const filteredLogs = useMemo(() => {
    const q = search.trim().toLowerCase();

    return allLogs.filter((log) => {
      // Category filter
      if (selectedCategory === 'high_value') {
        if (!log.isHighValue && log.category !== 'high_value_transaction') return false;
      } else if (selectedCategory === 'inventory') {
        if (
          log.category !== 'inventory_adjustment' &&
          !log.action.includes('ADJUSTMENT') &&
          !log.action.includes('STOCK')
        ) {
          return false;
        }
      } else if (selectedCategory === 'financial_ledger') {
        if (
          log.category !== 'financial_ledger' &&
          !log.action.includes('FINANCIAL') &&
          !log.action.includes('CAPITAL') &&
          !log.action.includes('LEDGER')
        ) {
          return false;
        }
      } else if (selectedCategory === 'pin_verified') {
        if (!log.verifiedByPin) return false;
      } else if (selectedCategory === 'sales') {
        if (log.category !== 'sale' && !log.action.includes('SALE')) return false;
      } else if (selectedCategory === 'purchases') {
        if (log.category !== 'purchase' && !log.action.includes('PURCHASE')) return false;
      }

      // User filter
      if (selectedUserId !== 'all' && log.userId !== selectedUserId) {
        return false;
      }

      // Search keyword filter
      if (!q) return true;

      const searchableText = [
        log.action,
        log.detail,
        log.date,
        log.time,
        log.userId || '',
        log.userName || '',
        log.userRole || '',
        log.productName || '',
        log.referenceId || '',
        log.reason || '',
        log.auditNote || '',
        log.authorizedByUserName || '',
      ]
        .join(' ')
        .toLowerCase();

      return searchableText.includes(q);
    });
  }, [allLogs, selectedCategory, selectedUserId, search]);

  const handleSaveThreshold = (e: React.FormEvent) => {
    e.preventDefault();
    const val = Number(tempThreshold);
    if (!isNaN(val) && val > 0) {
      setHighValueThreshold(val);
      setShowThresholdConfig(false);
      showToast(`High-value transaction threshold updated to ${money(val)}`);
    }
  };

  const handlePurgeSuccess = (authorizedUser: SystemUser) => {
    clearActivityLog({
      verifiedByPin: true,
      authorizedByUserId: authorizedUser.id,
      authorizedByUserName: authorizedUser.name,
      authorizedByUserRole: authorizedUser.role,
    });
    setShowPurgePinModal(false);
    showToast('Audit trail purged and certified with PIN verification.');
  };

  const exportAuditTrailCSV = () => {
    if (filteredLogs.length === 0) {
      showToast('No audit entries to export');
      return;
    }

    const headers = [
      'Log ID',
      'Timestamp',
      'Date',
      'Time',
      'Action',
      'Category',
      'User ID',
      'User Name',
      'User Role',
      'PIN Verified',
      'Authorized By User ID',
      'Authorized By User Name',
      'Authorized By Role',
      'Audit Note',
      'High Value Flag',
      'Amount',
      'Product Name',
      'Product ID',
      'Adjustment Qty',
      'Adjustment Type',
      'Previous Stock',
      'New Stock',
      'Reason',
      'Reference ID',
      'Detail',
    ];

    const rows = filteredLogs.map((log) => [
      `"${log.id}"`,
      `"${log.timestamp || `${log.date} ${log.time}`}"`,
      `"${log.date}"`,
      `"${log.time}"`,
      `"${log.action.replace(/"/g, '""')}"`,
      `"${log.category || 'general'}"`,
      `"${log.userId || 'N/A'}"`,
      `"${log.userName || 'System'}"`,
      `"${log.userRole || 'N/A'}"`,
      log.verifiedByPin ? 'YES' : 'NO',
      `"${log.authorizedByUserId || ''}"`,
      `"${log.authorizedByUserName || ''}"`,
      `"${log.authorizedByUserRole || ''}"`,
      `"${(log.auditNote || '').replace(/"/g, '""')}"`,
      log.isHighValue ? 'TRUE' : 'FALSE',
      log.amount ?? '',
      `"${(log.productName || '').replace(/"/g, '""')}"`,
      `"${log.productId || ''}"`,
      log.adjustmentQty ?? '',
      log.adjustmentType ?? '',
      log.previousStock ?? '',
      log.newStock ?? '',
      `"${(log.reason || '').replace(/"/g, '""')}"`,
      `"${log.referenceId || ''}"`,
      `"${log.detail.replace(/"/g, '""')}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute(
      'download',
      `Audit_Trail_Export_${new Date().toISOString().slice(0, 10)}.csv`
    );
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    showToast('Audit trail exported to CSV');
  };

  const filteredProductsForAdjust = useMemo(() => {
    if (!productSearch) return db.products;
    const q = productSearch.toLowerCase();
    return db.products.filter(
      (p) =>
        p.name.toLowerCase().includes(q) ||
        (p.sku && p.sku.toLowerCase().includes(q)) ||
        (p.category && p.category.toLowerCase().includes(q))
    );
  }, [db.products, productSearch]);

  return (
    <div className="space-y-5 pb-16">
      {/* Top Banner & Active User Bar */}
      <div className="p-5 sm:p-6 rounded-3xl bg-slate-900 text-white shadow-lg border border-slate-800">
        <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
          <div className="flex items-start sm:items-center gap-3.5">
            <div className="p-3 rounded-2xl bg-emerald-500/20 text-emerald-400 border border-emerald-400/30 shrink-0">
              <History className="w-6 h-6" />
            </div>
            <div>
              <div className="flex items-center gap-2 flex-wrap">
                <h2 className="text-lg sm:text-xl font-black text-white tracking-tight">
                  Activity Audit Trail & Security Log
                </h2>
                <span className="px-2 py-0.5 rounded-full text-[10px] font-extrabold bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 flex items-center gap-1">
                  <Lock className="w-3 h-3" />
                  4-DIGIT PIN AUDIT SECURITY ACTIVE
                </span>
              </div>
              <p className="text-xs text-slate-300 mt-1 max-w-2xl">
                Monitors high-value transactions (&ge; {money(highValueThreshold)}), physical stock adjustments, and financial ledger edits with cryptographic 4-digit PIN verification.
              </p>
            </div>
          </div>

          {/* Quick Security & Operator Actions */}
          <div className="flex items-center gap-2 flex-wrap">
            {/* Operator switch */}
            <div className="flex items-center gap-2 bg-slate-800/90 border border-slate-700/80 rounded-2xl p-2 px-3">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 rounded-xl bg-emerald-600/30 border border-emerald-500/40 flex items-center justify-center text-emerald-400 font-extrabold text-xs">
                  <User className="w-4 h-4" />
                </div>
                <div>
                  <div className="text-[10px] text-slate-400 font-semibold uppercase tracking-wider">
                    Logged Operator
                  </div>
                  <div className="text-xs font-bold text-white flex items-center gap-1">
                    <span>{currentUser.name}</span>
                    <span className="text-[10px] text-emerald-300 font-mono">({currentUser.id})</span>
                  </div>
                </div>
              </div>

              <select
                aria-label="Switch Logged Operator"
                value={currentUser.id}
                onChange={(e) => {
                  const target = availableUsers.find((u) => u.id === e.target.value);
                  if (target) {
                    setCurrentUser(target);
                    showToast(`Active operator switched to ${target.name} (${target.id})`);
                  }
                }}
                className="ml-2 bg-slate-900 text-slate-200 border border-slate-700 text-[11px] rounded-xl px-2.5 py-1.5 font-medium focus:ring-1 focus:ring-emerald-500 focus:outline-hidden"
              >
                {availableUsers.map((u) => (
                  <option key={u.id} value={u.id}>
                    {u.name} · {u.role}
                  </option>
                ))}
              </select>
            </div>

            {/* PIN Settings button */}
            <button
              onClick={() => setIsPinSettingsOpen(true)}
              className="px-3 py-2 rounded-2xl bg-emerald-600/20 hover:bg-emerald-600/30 text-emerald-300 border border-emerald-500/30 text-xs font-bold transition-all flex items-center gap-1.5"
              title="Manage Operator PINs and security credentials"
            >
              <KeyRound className="w-4 h-4" />
              <span>PIN Credentials</span>
            </button>
          </div>
        </div>

        {/* Action shortcut bar for Sensitive Operations */}
        <div className="mt-4 pt-4 border-t border-slate-800 flex items-center justify-between gap-3 flex-wrap">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-wider">
              Audited Actions:
            </span>
            {/* Quick Stock Adjustment */}
            <button
              onClick={() => setIsProductPickerOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-600 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              <span>Stock Adjustment (PIN)</span>
            </button>

            {/* Financial Ledger Edit */}
            <button
              onClick={() => setIsFinancialModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
            >
              <Landmark className="w-3.5 h-3.5" />
              <span>Financial Ledger Edit (PIN)</span>
            </button>

            {/* Voice Note Quick Trigger */}
            <button
              onClick={() => setIsVoiceNoteModalOpen(true)}
              className="px-3 py-1.5 rounded-xl bg-amber-600 hover:bg-amber-500 text-white text-xs font-bold flex items-center gap-1.5 transition-all shadow-xs"
            >
              <Mic className="w-3.5 h-3.5" />
              <span>Voice Note</span>
            </button>
          </div>

          <div className="flex items-center gap-2 text-[11px] text-slate-400 font-medium">
            <ShieldCheck className="w-4 h-4 text-emerald-400" />
            <span>Default Test PINs: Aimraan <b>1234</b> · Sara <b>5678</b> · Dawit <b>4321</b></span>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3.5">
        {/* Total Events */}
        <div className="p-4 rounded-2xl bg-white border border-slate-200/80 shadow-xs flex items-center justify-between">
          <div>
            <span className="text-[11px] font-bold text-slate-500 uppercase tracking-wider">
              Total Logged Events
            </span>
            <div className="text-2xl font-black text-slate-900 mt-1 font-mono">{stats.total}</div>
            <span className="text-[11px] text-slate-400 mt-0.5 block">Across all operations</span>
          </div>
          <div className="p-3 rounded-2xl bg-slate-100 text-slate-600">
            <Layers className="w-5 h-5" />
          </div>
        </div>

        {/* High-Value Transactions */}
        <div
          onClick={() => setSelectedCategory('high_value')}
          className={`p-4 rounded-2xl border shadow-xs flex items-center justify-between cursor-pointer transition-all ${
            selectedCategory === 'high_value'
              ? 'bg-amber-50/90 border-amber-400 ring-2 ring-amber-400/40'
              : 'bg-white border-amber-200/90 hover:border-amber-300'
          }`}
        >
          <div>
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-bold text-amber-900 uppercase tracking-wider">
                High-Value Logs
              </span>
              <span className="w-2 h-2 rounded-full bg-amber-500 animate-pulse" />
            </div>
            <div className="text-2xl font-black text-amber-950 mt-1 font-mono">
              {stats.highValueCount}
            </div>
            <span className="text-[11px] font-bold text-amber-800/90 mt-0.5 block">
              Sum: {money(stats.highValueTotal)}
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-amber-100 text-amber-700">
            <AlertTriangle className="w-5 h-5" />
          </div>
        </div>

        {/* Inventory Adjustments */}
        <div
          onClick={() => setSelectedCategory('inventory')}
          className={`p-4 rounded-2xl border shadow-xs flex items-center justify-between cursor-pointer transition-all ${
            selectedCategory === 'inventory'
              ? 'bg-indigo-50/90 border-indigo-400 ring-2 ring-indigo-400/40'
              : 'bg-white border-indigo-200/90 hover:border-indigo-300'
          }`}
        >
          <div>
            <span className="text-[11px] font-bold text-indigo-900 uppercase tracking-wider">
              Inventory Adjustments
            </span>
            <div className="text-2xl font-black text-indigo-950 mt-1 font-mono">
              {stats.stockAdjustmentCount}
            </div>
            <span className="text-[11px] text-indigo-700 font-medium mt-0.5 block">
              Physical audits & counts
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-indigo-100 text-indigo-700">
            <SlidersHorizontal className="w-5 h-5" />
          </div>
        </div>

        {/* PIN Verified Entries */}
        <div
          onClick={() => setSelectedCategory('pin_verified')}
          className={`p-4 rounded-2xl border shadow-xs flex items-center justify-between cursor-pointer transition-all ${
            selectedCategory === 'pin_verified'
              ? 'bg-emerald-50/90 border-emerald-400 ring-2 ring-emerald-400/40'
              : 'bg-white border-slate-200/80 hover:border-emerald-300'
          }`}
        >
          <div>
            <span className="text-[11px] font-bold text-emerald-900 uppercase tracking-wider">
              PIN-Verified Audits
            </span>
            <div className="text-2xl font-black text-emerald-800 mt-1 font-mono">
              {stats.pinVerifiedCount}
            </div>
            <span className="text-[11px] font-semibold text-emerald-700 mt-0.5 block">
              Cryptographically verified
            </span>
          </div>
          <div className="p-3 rounded-2xl bg-emerald-100 text-emerald-700">
            <ShieldCheck className="w-5 h-5" />
          </div>
        </div>
      </div>

      {/* Threshold Modal / Inline Box if active */}
      {showThresholdConfig && (
        <div className="p-4 rounded-2xl bg-emerald-50/80 border border-emerald-200 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 animate-in fade-in">
          <div>
            <h4 className="text-xs font-bold text-emerald-950 flex items-center gap-1.5">
              <Settings2 className="w-4 h-4 text-emerald-700" />
              Configure Automated High-Value Transaction Alert Threshold
            </h4>
            <p className="text-[11px] text-emerald-800 mt-0.5">
              Any sale, purchase, payment, or distribution order equal to or exceeding this threshold will automatically be flagged and classified as a High-Value Transaction.
            </p>
          </div>
          <form onSubmit={handleSaveThreshold} className="flex items-center gap-2 w-full sm:w-auto">
            <input
              type="number"
              min="100"
              step="100"
              value={tempThreshold}
              onChange={(e) => setTempThreshold(e.target.value)}
              className="px-3 py-1.5 rounded-xl border border-emerald-300 text-xs font-bold bg-white w-32 focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
            <button
              type="submit"
              className="px-3 py-1.5 rounded-xl bg-emerald-700 hover:bg-emerald-800 text-white text-xs font-bold transition-all shadow-xs"
            >
              Apply
            </button>
            <button
              type="button"
              onClick={() => setShowThresholdConfig(false)}
              className="px-2.5 py-1.5 rounded-xl border border-emerald-300 text-emerald-800 text-xs font-semibold hover:bg-emerald-100 transition-colors"
            >
              Close
            </button>
          </form>
        </div>
      )}

      {/* Main Audit Log Container */}
      <div className="p-4 sm:p-6 rounded-3xl bg-white border border-slate-200 shadow-xs space-y-4">
        {/* Controls: Search, Category Filters, User filter, Export */}
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3 flex-wrap">
          {/* Filter Pills */}
          <div className="flex items-center gap-1.5 flex-wrap">
            <button
              onClick={() => setSelectedCategory('all')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                selectedCategory === 'all'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              All Events ({allLogs.length})
            </button>

            <button
              onClick={() => setSelectedCategory('high_value')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                selectedCategory === 'high_value'
                  ? 'bg-amber-500 text-white shadow-xs'
                  : 'bg-amber-50 text-amber-800 hover:bg-amber-100 border border-amber-200'
              }`}
            >
              <AlertTriangle className="w-3.5 h-3.5" />
              High-Value ({stats.highValueCount})
            </button>

            <button
              onClick={() => setSelectedCategory('inventory')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                selectedCategory === 'inventory'
                  ? 'bg-indigo-600 text-white shadow-xs'
                  : 'bg-indigo-50 text-indigo-800 hover:bg-indigo-100 border border-indigo-200'
              }`}
            >
              <SlidersHorizontal className="w-3.5 h-3.5" />
              Stock Adjustments ({stats.stockAdjustmentCount})
            </button>

            <button
              onClick={() => setSelectedCategory('financial_ledger')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                selectedCategory === 'financial_ledger'
                  ? 'bg-emerald-800 text-white shadow-xs'
                  : 'bg-emerald-50 text-emerald-800 hover:bg-emerald-100 border border-emerald-200'
              }`}
            >
              <Landmark className="w-3.5 h-3.5" />
              Financial Ledger ({stats.financialLedgerCount})
            </button>

            <button
              onClick={() => setSelectedCategory('pin_verified')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all flex items-center gap-1.5 ${
                selectedCategory === 'pin_verified'
                  ? 'bg-emerald-700 text-white shadow-xs'
                  : 'bg-slate-100 text-emerald-800 hover:bg-slate-200 border border-emerald-300'
              }`}
            >
              <Lock className="w-3.5 h-3.5" />
              PIN-Verified ({stats.pinVerifiedCount})
            </button>

            <button
              onClick={() => setSelectedCategory('sales')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                selectedCategory === 'sales'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Sales
            </button>

            <button
              onClick={() => setSelectedCategory('purchases')}
              className={`px-3 py-1.5 rounded-xl text-xs font-bold transition-all ${
                selectedCategory === 'purchases'
                  ? 'bg-slate-900 text-white shadow-xs'
                  : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
              }`}
            >
              Purchases
            </button>
          </div>

          {/* Action buttons: Export & Clear (PIN protected) */}
          <div className="flex items-center gap-2">
            <button
              onClick={exportAuditTrailCSV}
              className="px-3 py-1.5 rounded-xl bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs flex items-center gap-1.5 transition-colors border border-slate-200"
            >
              <Download className="w-3.5 h-3.5" />
              Export CSV
            </button>

            {allLogs.length > 0 && (
              <button
                onClick={() => setShowPurgePinModal(true)}
                className="px-3 py-1.5 rounded-xl bg-rose-50 hover:bg-rose-100 text-rose-700 font-bold text-xs flex items-center gap-1.5 transition-colors border border-rose-200"
                title="Purge audit logs (Requires 4-Digit Security PIN)"
              >
                <Trash2 className="w-3.5 h-3.5" />
                Clear Logs (PIN)
              </button>
            )}
          </div>
        </div>

        {/* Search and User Filter Bar */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-2.5">
          <div className="sm:col-span-2 relative">
            <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
            <input
              type="text"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search by action, product, user ID, invoice ID, or reason..."
              className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-hidden"
            />
          </div>

          <div className="relative">
            <select
              aria-label="Filter by User ID"
              value={selectedUserId}
              onChange={(e) => setSelectedUserId(e.target.value)}
              className="w-full px-3 py-2 rounded-xl border border-slate-300 text-xs font-medium focus:ring-2 focus:ring-emerald-500 focus:outline-hidden bg-white"
            >
              <option value="all">All User IDs (Operators)</option>
              {availableUsers.map((u) => (
                <option key={u.id} value={u.id}>
                  {u.id} · {u.name} ({u.role})
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Audit Log Items */}
        <div className="divide-y divide-slate-100 max-h-[65vh] overflow-y-auto pr-1">
          {filteredLogs.length === 0 ? (
            <div className="py-16 text-center">
              <ShieldCheck className="w-10 h-10 text-slate-300 mx-auto mb-2" />
              <p className="text-xs font-semibold text-slate-500">
                No audit log entries found matching current filter criteria.
              </p>
              {(search || selectedCategory !== 'all' || selectedUserId !== 'all') && (
                <button
                  onClick={() => {
                    setSearch('');
                    setSelectedCategory('all');
                    setSelectedUserId('all');
                  }}
                  className="mt-2 text-xs text-emerald-700 hover:text-emerald-800 font-bold underline"
                >
                  Reset all filters
                </button>
              )}
            </div>
          ) : (
            filteredLogs.map((entry) => {
              const isHighVal =
                entry.isHighValue ||
                entry.category === 'high_value_transaction' ||
                entry.action.includes('HIGH-VALUE');

              const isInventoryAdj =
                entry.category === 'inventory_adjustment' ||
                entry.action.includes('ADJUSTMENT') ||
                entry.action.includes('STOCK');

              const isFinancialLedger =
                entry.category === 'financial_ledger' ||
                entry.action.includes('FINANCIAL') ||
                entry.action.includes('CAPITAL') ||
                entry.action.includes('LEDGER');

              const isCeoNote = entry.category === 'ceo_note';

              return (
                <div
                  key={entry.id}
                  className={`py-3.5 px-3 rounded-2xl my-1.5 transition-colors border ${
                    entry.verifiedByPin
                      ? 'bg-emerald-50/30 border-emerald-200/80 shadow-xs'
                      : isHighVal
                      ? 'bg-amber-50/40 border-amber-200/90'
                      : isInventoryAdj
                      ? 'bg-indigo-50/30 border-indigo-100'
                      : isFinancialLedger
                      ? 'bg-emerald-50/20 border-emerald-100'
                      : isCeoNote
                      ? 'bg-amber-50/50 border-amber-200/80 shadow-xs'
                      : 'bg-white hover:bg-slate-50 border-transparent'
                  }`}
                >
                  <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                    {/* Left: Category Icon, Action Name, Badges */}
                    <div className="flex items-start sm:items-center gap-2.5">
                      <div
                        className={`p-2 rounded-xl shrink-0 ${
                          entry.verifiedByPin
                            ? 'bg-emerald-700 text-white'
                            : isHighVal
                            ? 'bg-amber-500 text-white'
                            : isCeoNote
                            ? 'bg-amber-600 text-white'
                            : isInventoryAdj
                            ? 'bg-indigo-600 text-white'
                            : isFinancialLedger
                            ? 'bg-emerald-800 text-white'
                            : entry.action.includes('SALE')
                            ? 'bg-emerald-600 text-white'
                            : 'bg-slate-700 text-white'
                        }`}
                      >
                        {entry.verifiedByPin ? (
                          <Lock className="w-4 h-4" />
                        ) : isHighVal ? (
                          <AlertTriangle className="w-4 h-4" />
                        ) : isCeoNote ? (
                          <Mic className="w-4 h-4" />
                        ) : isInventoryAdj ? (
                          <SlidersHorizontal className="w-4 h-4" />
                        ) : isFinancialLedger ? (
                          <Landmark className="w-4 h-4" />
                        ) : (
                          <DollarSign className="w-4 h-4" />
                        )}
                      </div>

                      <div>
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-extrabold text-xs sm:text-sm text-slate-900 tracking-tight">
                            {entry.action}
                          </span>

                          {/* 4-Digit PIN Security Badge */}
                          {entry.verifiedByPin && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-emerald-100 text-emerald-900 uppercase tracking-wider border border-emerald-300 flex items-center gap-1">
                              <ShieldCheck className="w-3 h-3 text-emerald-700" />
                              PIN Verified · {entry.authorizedByUserName || entry.userName}
                            </span>
                          )}

                          {isHighVal && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-black bg-amber-200 text-amber-950 uppercase tracking-wider border border-amber-300 flex items-center gap-1">
                              <AlertTriangle className="w-3 h-3" />
                              High-Value Alert
                            </span>
                          )}

                          {isInventoryAdj && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-indigo-100 text-indigo-800 border border-indigo-200">
                              Stock Audit
                            </span>
                          )}

                          {isFinancialLedger && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-emerald-100 text-emerald-800 border border-emerald-200">
                              Ledger Edit
                            </span>
                          )}

                          {isCeoNote && (
                            <span className="px-2 py-0.5 rounded-full text-[10px] font-bold bg-amber-100 text-amber-800 border border-amber-200 flex items-center gap-1">
                              <Mic className="w-3 h-3" />
                              Dictation
                            </span>
                          )}
                        </div>

                        {/* Detail text */}
                        <p className="text-xs text-slate-700 mt-1 leading-relaxed">
                          {entry.detail}
                        </p>

                        {/* Audit Note Annotation if present */}
                        {entry.auditNote && (
                          <div className="mt-1.5 p-2 rounded-xl bg-indigo-50/80 border border-indigo-200 text-indigo-950 text-xs flex items-start gap-1.5">
                            <FileEdit className="w-3.5 h-3.5 text-indigo-600 shrink-0 mt-0.5" />
                            <div>
                              <span className="font-bold text-[10px] uppercase tracking-wider text-indigo-800 block">
                                Auditor Memo / Note:
                              </span>
                              <p className="text-[11px] leading-relaxed font-medium">
                                {entry.auditNote}
                              </p>
                            </div>
                          </div>
                        )}
                      </div>
                    </div>

                    {/* Right: Timestamp, User ID Attribution, and Action Buttons */}
                    <div className="flex flex-row sm:flex-col sm:items-end justify-between items-center sm:text-right shrink-0 pt-1 sm:pt-0 border-t sm:border-t-0 border-slate-100 gap-2">
                      {/* Timestamp with Clock */}
                      <div className="flex items-center gap-1.5 text-[11px] font-mono text-slate-500">
                        <Calendar className="w-3 h-3 text-slate-400" />
                        <span>{entry.date}</span>
                        <Clock className="w-3 h-3 text-slate-400 ml-0.5" />
                        <span className="font-semibold text-slate-700">{entry.time}</span>
                      </div>

                      {/* User ID Tag */}
                      <div className="flex items-center gap-1 px-2 py-0.5 rounded-lg bg-slate-100 text-slate-700 text-[10px] font-mono font-bold border border-slate-200">
                        <User className="w-3 h-3 text-slate-400" />
                        <span>{entry.userId ? entry.userId : 'SYS-AUTO'}</span>
                        {entry.userRole && (
                          <span className="text-slate-400 font-sans">· {entry.userRole}</span>
                        )}
                      </div>

                      {/* Annotate Note button */}
                      <div className="flex items-center gap-1">
                        <button
                          onClick={() => setAuditNoteLog(entry)}
                          className="px-2 py-1 rounded-lg bg-slate-100 hover:bg-slate-200 text-slate-700 text-[10px] font-bold flex items-center gap-1 border border-slate-200 transition-colors"
                          title="Add or update audited note (PIN protected)"
                        >
                          <FileEdit className="w-3 h-3 text-slate-500" />
                          <span>{entry.auditNote ? 'Edit Note' : 'Add Note'}</span>
                        </button>

                        {/* If this entry has a product ID, quick link to adjust stock */}
                        {entry.productId && (
                          <button
                            onClick={() => setStockAdjustProductId(entry.productId!)}
                            className="px-2 py-1 rounded-lg bg-emerald-50 hover:bg-emerald-100 text-emerald-800 text-[10px] font-bold flex items-center gap-1 border border-emerald-200 transition-colors"
                            title="Adjust stock for this product (PIN protected)"
                          >
                            <SlidersHorizontal className="w-3 h-3 text-emerald-600" />
                            <span>Adjust</span>
                          </button>
                        )}
                      </div>
                    </div>
                  </div>

                  {/* Enhanced Metadata Chips for Adjustments and High-Value */}
                  {(entry.adjustmentQty !== undefined ||
                    entry.previousStock !== undefined ||
                    entry.amount !== undefined ||
                    entry.reason ||
                    entry.authorizedByUserId) && (
                    <div className="mt-2.5 pt-2 border-t border-slate-200/60 flex items-center gap-2 flex-wrap text-[11px]">
                      {entry.authorizedByUserId && (
                        <div className="px-2 py-0.5 rounded-md bg-emerald-50 border border-emerald-200 text-emerald-900 font-semibold flex items-center gap-1">
                          <Lock className="w-3 h-3 text-emerald-600" />
                          PIN Signoff: <span className="font-bold">{entry.authorizedByUserName || entry.authorizedByUserId}</span> ({entry.authorizedByUserRole || 'Manager'})
                        </div>
                      )}

                      {entry.userId && !entry.authorizedByUserId && (
                        <div className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-600 font-medium">
                          Operator: <span className="font-bold text-slate-900">{entry.userName || entry.userId}</span>
                        </div>
                      )}

                      {entry.productName && (
                        <div className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-600 font-medium">
                          Product: <span className="font-bold text-slate-900">{entry.productName}</span>
                        </div>
                      )}

                      {entry.adjustmentQty !== undefined && (
                        <div className="px-2 py-0.5 rounded-md bg-indigo-50 border border-indigo-200 text-indigo-900 font-bold">
                          Qty Shift:{' '}
                          <span
                            className={
                              entry.adjustmentType === 'decrease'
                                ? 'text-rose-600'
                                : 'text-emerald-700'
                            }
                          >
                            {entry.adjustmentType === 'decrease' ? '−' : '+'}
                            {entry.adjustmentQty} {entry.unit || ''}
                          </span>
                        </div>
                      )}

                      {entry.previousStock !== undefined && entry.newStock !== undefined && (
                        <div className="px-2 py-0.5 rounded-md bg-white border border-slate-200 text-slate-600 font-mono">
                          Stock Level: <span className="text-slate-400">{entry.previousStock}</span> &rarr;{' '}
                          <span className="font-bold text-slate-900">{entry.newStock}</span>
                        </div>
                      )}

                      {entry.amount !== undefined && (
                        <div
                          className={`px-2 py-0.5 rounded-md font-mono font-bold ${
                            isHighVal
                              ? 'bg-amber-100 text-amber-950 border border-amber-300'
                              : 'bg-emerald-50 text-emerald-900 border border-emerald-200'
                          }`}
                        >
                          Valuation: {money(entry.amount)}
                        </div>
                      )}

                      {entry.reason && (
                        <div className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-600 italic">
                          Reason: {entry.reason}
                        </div>
                      )}

                      {entry.referenceId && (
                        <div className="px-2 py-0.5 rounded-md bg-slate-50 text-slate-500 font-mono text-[10px]">
                          Ref: {entry.referenceId}
                        </div>
                      )}

                      {entry.timestamp && (
                        <div
                          title={entry.timestamp}
                          className="px-2 py-0.5 rounded-md bg-slate-50 text-slate-400 font-mono text-[9px] ml-auto"
                        >
                          ISO: {entry.timestamp.slice(0, 19).replace('T', ' ')}
                        </div>
                      )}
                    </div>
                  )}
                </div>
              );
            })
          )}
        </div>
      </div>

      {/* Product Picker Modal for Stock Adjustment Trigger */}
      {isProductPickerOpen && (
        <div className="fixed inset-0 z-50 bg-slate-950/75 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4">
          <div className="bg-white rounded-3xl w-full max-w-lg shadow-2xl overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150 max-h-[85vh] flex flex-col">
            <div className="p-4 bg-emerald-950 text-white flex items-center justify-between shrink-0">
              <div className="flex items-center gap-2">
                <SlidersHorizontal className="w-5 h-5 text-emerald-400" />
                <div>
                  <h3 className="font-bold text-sm">Select Product for Stock Adjustment</h3>
                  <p className="text-[10px] text-emerald-300">Protected by 4-Digit Security PIN Verification</p>
                </div>
              </div>
              <button
                onClick={() => setIsProductPickerOpen(false)}
                className="p-1 rounded-lg text-slate-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-4 border-b border-slate-200 bg-slate-50 shrink-0">
              <div className="relative">
                <Search className="w-4 h-4 text-slate-400 absolute left-3 top-2.5" />
                <input
                  type="text"
                  value={productSearch}
                  onChange={(e) => setProductSearch(e.target.value)}
                  placeholder="Search products by name or SKU..."
                  className="w-full pl-9 pr-3 py-2 rounded-xl border border-slate-300 text-xs font-semibold focus:ring-2 focus:ring-emerald-500 bg-white"
                />
              </div>
            </div>

            <div className="p-4 overflow-y-auto space-y-2 divide-y divide-slate-100 flex-1">
              {filteredProductsForAdjust.map((prod) => (
                <div
                  key={prod.id}
                  onClick={() => {
                    setStockAdjustProductId(prod.id);
                    setIsProductPickerOpen(false);
                  }}
                  className="pt-2 first:pt-0 pb-2 flex items-center justify-between cursor-pointer hover:bg-slate-50 p-2.5 rounded-xl transition-colors"
                >
                  <div>
                    <div className="text-xs font-bold text-slate-900">{prod.name}</div>
                    <div className="text-[11px] text-slate-500">
                      SKU: {prod.sku || 'N/A'} · Cost: {money(prod.buy)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-xs font-extrabold text-emerald-700">
                      {prod.stock} {prod.unit}
                    </div>
                    <span className="text-[10px] text-slate-400 font-semibold">Click to adjust</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {/* Financial Ledger Modal */}
      <FinancialLedgerModal
        isOpen={isFinancialModalOpen}
        onClose={() => setIsFinancialModalOpen(false)}
      />

      {/* PIN Settings Modal */}
      <PinSettingsModal
        isOpen={isPinSettingsOpen}
        onClose={() => setIsPinSettingsOpen(false)}
      />

      {/* Audit Note Annotation Modal */}
      <AuditNoteModal
        log={auditNoteLog}
        isOpen={Boolean(auditNoteLog)}
        onClose={() => setAuditNoteLog(null)}
      />

      {/* Purge Audit Trail PIN Verification Gate */}
      <PinVerificationModal
        isOpen={showPurgePinModal}
        onClose={() => setShowPurgePinModal(false)}
        onSuccess={handlePurgeSuccess}
        actionTitle="Authorize Audit Trail Purge"
        actionDescription="Purging historical audit logs is a high-impact administrative action. An immutable PURGE certification log entry will be preserved."
        targetUserId={currentUser.id}
        actionDetails={[
          { label: 'Event Count', value: `${allLogs.length} events to be purged` },
          { label: 'Warning', value: 'This action cannot be undone.' },
        ]}
      />

      {/* Voice Note Modal */}
      <VoiceNoteModal
        isOpen={isVoiceNoteModalOpen}
        onClose={() => setIsVoiceNoteModalOpen(false)}
      />
    </div>
  );
};
