import React, { useState, useMemo } from 'react';
import { useStore } from '../context/StoreContext';
import {
  PriceAdjustmentSuggestion,
  CompetitorQuote,
  PricingStrategy,
  PricingUrgency,
  PricingDriver,
  Product,
} from '../types';
import { money } from '../utils/helpers';
import {
  TrendingUp,
  TrendingDown,
  AlertTriangle,
  Zap,
  Sliders,
  CheckCircle2,
  RefreshCw,
  Plus,
  Trash2,
  Edit2,
  ChevronDown,
  ChevronUp,
  Search,
  Filter,
  Layers,
  ArrowUpDown,
  Building2,
  Check,
  X,
  ExternalLink,
  ShieldAlert,
  Sparkles,
  Info,
  DollarSign,
  Tag,
  Package,
} from 'lucide-react';

export const PricingView: React.FC = () => {
  const {
    db,
    pricingSettings,
    competitorQuotes,
    priceSuggestions,
    applyPriceAdjustment,
    applyAllPriceAdjustments,
    updatePricingSettings,
    addCompetitorQuote,
    updateCompetitorQuote,
    deleteCompetitorQuote,
    simulateMarketPriceShift,
    showToast,
  } = useStore();

  // Local UI states
  const [activeSubTab, setActiveSubTab] = useState<'suggestions' | 'competitors' | 'settings'>('suggestions');
  const [searchQuery, setSearchQuery] = useState('');
  const [filterUrgency, setFilterUrgency] = useState<string>('all');
  const [sortBy, setSortBy] = useState<'urgency' | 'delta_high' | 'delta_low' | 'margin_low' | 'name'>('urgency');
  const [expandedProductId, setExpandedProductId] = useState<string | null>(null);

  // Custom Price Modal state
  const [customAdjustTarget, setCustomAdjustTarget] = useState<PriceAdjustmentSuggestion | null>(null);
  const [customRetailPrice, setCustomRetailPrice] = useState<number>(0);
  const [customWholesalePrice, setCustomWholesalePrice] = useState<number>(0);
  const [customReason, setCustomReason] = useState<string>('');

  // Add Competitor Quote Modal state
  const [isAddQuoteOpen, setIsAddQuoteOpen] = useState(false);
  const [newQuoteProductId, setNewQuoteProductId] = useState<string>(db.products[0]?.id || '');
  const [newQuoteCompetitor, setNewQuoteCompetitor] = useState<string>('');
  const [newQuotePrice, setNewQuotePrice] = useState<number>(0);
  const [newQuoteInStock, setNewQuoteInStock] = useState<boolean>(true);
  const [newQuotePromo, setNewQuotePromo] = useState<boolean>(false);
  const [newQuoteSource, setNewQuoteSource] = useState<string>('Market Survey');

  // Simulation dropdown open
  const [isSimMenuOpen, setIsSimMenuOpen] = useState(false);

  // Strategy description lookup
  const STRATEGY_INFO: Record<
    PricingStrategy,
    { label: string; tag: string; description: string; color: string }
  > = {
    margin_guardrail: {
      label: 'Margin Guardrail',
      tag: 'COGS Protection',
      description: 'Guarantees minimum gross margins against COGS inflation while staying market-competitive.',
      color: 'bg-emerald-50 text-emerald-700 border-emerald-300',
    },
    competitor_undercut: {
      label: 'Competitor Undercut',
      tag: 'Volume Driver',
      description: 'Tracks lowest in-stock competitor prices and undercuts by safety margin to win consumer volume.',
      color: 'bg-blue-50 text-blue-700 border-blue-300',
    },
    market_match: {
      label: 'Market Match',
      tag: 'Consensus',
      description: 'Harmonizes price with market average across active in-stock competitors.',
      color: 'bg-indigo-50 text-indigo-700 border-indigo-300',
    },
    premium_brand: {
      label: 'Premium Brand',
      tag: 'Margin Capture',
      description: 'Leverages store positioning, reliability, and stock readiness with a premium over market average.',
      color: 'bg-purple-50 text-purple-700 border-purple-300',
    },
    velocity_demand: {
      label: 'Velocity & Demand',
      tag: 'Inventory Balancing',
      description: 'Dynamically shifts prices based on sales speed and stock scarcity to balance inventory cover.',
      color: 'bg-amber-50 text-amber-700 border-amber-300',
    },
  };

  // Metrics summary
  const metrics = useMemo(() => {
    const totalProducts = db.products.length;
    const actionable = priceSuggestions.filter((s) => Math.abs(s.priceChangeDelta) >= 1);
    const criticalCount = priceSuggestions.filter((s) => s.urgency === 'critical').length;
    const warningCount = priceSuggestions.filter((s) => s.urgency === 'warning').length;
    const opportunityCount = priceSuggestions.filter((s) => s.urgency === 'opportunity').length;
    const cogsSpikes = priceSuggestions.filter((s) => s.costChangePercent > 5).length;
    const stockoutGains = priceSuggestions.filter((s) => s.primaryDriver === 'competitor_stockout').length;

    // Potential profit delta calculation
    const potentialMonthlyUplift = actionable.reduce((acc, s) => {
      const prod = db.products.find((p) => p.id === s.productId);
      const estMonthlyUnits = Math.max(10, (prod?.stock || 5) * 1.5);
      return acc + s.priceChangeDelta * estMonthlyUnits;
    }, 0);

    const currentAvgMargin =
      db.products.reduce((acc, p) => {
        const margin = p.sell > 0 ? ((p.sell - p.buy) / p.sell) * 100 : 0;
        return acc + margin;
      }, 0) / (db.products.length || 1);

    const projectedAvgMargin =
      priceSuggestions.reduce((acc, s) => acc + s.suggestedMarginPercent, 0) /
      (priceSuggestions.length || 1);

    return {
      totalProducts,
      actionableCount: actionable.length,
      criticalCount,
      warningCount,
      opportunityCount,
      cogsSpikes,
      stockoutGains,
      potentialMonthlyUplift: Math.round(potentialMonthlyUplift),
      currentAvgMargin: Math.round(currentAvgMargin * 10) / 10,
      projectedAvgMargin: Math.round(projectedAvgMargin * 10) / 10,
    };
  }, [db.products, priceSuggestions]);

  // Filtered and sorted suggestions
  const filteredSuggestions = useMemo(() => {
    return priceSuggestions
      .filter((s) => {
        if (searchQuery.trim()) {
          const q = searchQuery.toLowerCase();
          const matchName = s.productName.toLowerCase().includes(q);
          const matchRule = s.ruleApplied.toLowerCase().includes(q);
          const matchDriver = s.reasoning.toLowerCase().includes(q);
          if (!matchName && !matchRule && !matchDriver) return false;
        }

        if (filterUrgency === 'critical') return s.urgency === 'critical';
        if (filterUrgency === 'warning') return s.urgency === 'warning';
        if (filterUrgency === 'opportunity') return s.urgency === 'opportunity';
        if (filterUrgency === 'optimal') return s.urgency === 'optimal';
        if (filterUrgency === 'increase') return s.priceChangeDelta > 0;
        if (filterUrgency === 'decrease') return s.priceChangeDelta < 0;
        if (filterUrgency === 'cogs_spike') return s.costChangePercent > 5;
        if (filterUrgency === 'stockout') return s.primaryDriver === 'competitor_stockout';
        return true;
      })
      .sort((a, b) => {
        if (sortBy === 'urgency') {
          const rank: Record<PricingUrgency, number> = {
            critical: 0,
            warning: 1,
            opportunity: 2,
            optimal: 3,
          };
          return rank[a.urgency] - rank[b.urgency] || Math.abs(b.priceChangeDelta) - Math.abs(a.priceChangeDelta);
        }
        if (sortBy === 'delta_high') return b.priceChangeDelta - a.priceChangeDelta;
        if (sortBy === 'delta_low') return a.priceChangeDelta - b.priceChangeDelta;
        if (sortBy === 'margin_low') return a.currentMarginPercent - b.currentMarginPercent;
        if (sortBy === 'name') return a.productName.localeCompare(b.productName);
        return 0;
      });
  }, [priceSuggestions, searchQuery, filterUrgency, sortBy]);

  // Quick Open Custom Adjustment Modal
  const handleOpenCustom = (suggestion: PriceAdjustmentSuggestion) => {
    setCustomAdjustTarget(suggestion);
    setCustomRetailPrice(suggestion.suggestedPrice);
    setCustomWholesalePrice(suggestion.suggestedWholesalePrice);
    setCustomReason(`Manual fine-tune based on ${STRATEGY_INFO[pricingSettings.activeStrategy].label}`);
  };

  const handleSaveCustom = () => {
    if (!customAdjustTarget) return;
    if (customRetailPrice <= 0) {
      showToast('Retail price must be greater than zero');
      return;
    }
    applyPriceAdjustment(
      customAdjustTarget.productId,
      customRetailPrice,
      customWholesalePrice,
      customReason || 'Manual custom price override'
    );
    setCustomAdjustTarget(null);
  };

  // Submit New Competitor Quote
  const handleAddQuoteSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newQuoteProductId || !newQuoteCompetitor.trim() || newQuotePrice <= 0) {
      showToast('Please enter all required competitor fields');
      return;
    }

    const prod = db.products.find((p) => p.id === newQuoteProductId);
    addCompetitorQuote({
      productId: newQuoteProductId,
      productName: prod?.name || 'Product',
      competitorName: newQuoteCompetitor.trim(),
      price: Number(newQuotePrice),
      inStock: newQuoteInStock,
      promoActive: newQuotePromo,
      source: newQuoteSource,
      confidenceScore: 95,
    });

    setIsAddQuoteOpen(false);
    setNewQuoteCompetitor('');
    setNewQuotePrice(0);
  };

  return (
    <div className="space-y-6 pb-20">
      {/* Top Banner Header */}
      <div className="bg-white rounded-3xl p-5 sm:p-6 border border-slate-200/80 shadow-xs relative overflow-hidden">
        <div className="absolute -right-8 -top-8 w-44 h-44 bg-gradient-to-br from-emerald-100 to-teal-100 rounded-full blur-2xl pointer-events-none opacity-60" />

        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 relative z-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <span className="px-2.5 py-0.5 rounded-full text-xs font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-emerald-600" />
                Autonomous Engine
              </span>
              <span className="text-xs text-slate-500 font-medium">
                Live Competitor Feeds & COGS Protection
              </span>
            </div>
            <h1 className="text-2xl sm:text-3xl font-black text-slate-900 tracking-tight">
              Dynamic Pricing Engine
            </h1>
            <p className="text-sm text-slate-600 mt-1 max-w-xl">
              Algorithmic price adjustments balancing real-time competitor prices, supplier purchase cost
              fluctuations, and safety gross margins.
            </p>
          </div>

          {/* Action Button Group */}
          <div className="flex flex-wrap items-center gap-2">
            {/* Simulation Sandbox Trigger */}
            <div className="relative">
              <button
                id="btn-simulate-scenarios"
                onClick={() => setIsSimMenuOpen((prev) => !prev)}
                className="flex items-center gap-2 px-3.5 py-2.5 rounded-2xl bg-slate-900 hover:bg-slate-800 text-white font-bold text-xs shadow-xs transition-all active:scale-95"
              >
                <Zap className="w-4 h-4 text-amber-400 fill-amber-400" />
                <span>Simulate Market</span>
                <ChevronDown className="w-3.5 h-3.5 text-slate-400" />
              </button>

              {isSimMenuOpen && (
                <div className="absolute right-0 top-full mt-2 w-72 bg-white border border-slate-200 rounded-2xl shadow-xl p-2 z-50 animate-in fade-in-50 zoom-in-95">
                  <div className="px-2.5 py-1.5 text-[11px] font-bold uppercase tracking-wider text-slate-400 border-b border-slate-100">
                    Market Shock Simulations
                  </div>
                  <div className="mt-1 space-y-1">
                    <button
                      onClick={() => {
                        simulateMarketPriceShift('inflation_spike');
                        setIsSimMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-rose-50 text-slate-700 hover:text-rose-900 transition-colors flex items-center justify-between"
                    >
                      <span className="font-semibold">COGS Inflation Wave (+14%)</span>
                      <span className="text-[10px] bg-rose-100 text-rose-800 px-1.5 py-0.5 rounded font-bold">
                        Staples
                      </span>
                    </button>
                    <button
                      onClick={() => {
                        simulateMarketPriceShift('competitor_discount_war');
                        setIsSimMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-blue-50 text-slate-700 hover:text-blue-900 transition-colors flex items-center justify-between"
                    >
                      <span className="font-semibold">Competitor Price War (-8%)</span>
                      <span className="text-[10px] bg-blue-100 text-blue-800 px-1.5 py-0.5 rounded font-bold">
                        Promo
                      </span>
                    </button>
                    <button
                      onClick={() => {
                        simulateMarketPriceShift('competitor_stockouts');
                        setIsSimMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-amber-50 text-slate-700 hover:text-amber-900 transition-colors flex items-center justify-between"
                    >
                      <span className="font-semibold">Rival Stockout Crisis</span>
                      <span className="text-[10px] bg-amber-100 text-amber-800 px-1.5 py-0.5 rounded font-bold">
                        Scarcity
                      </span>
                    </button>
                    <button
                      onClick={() => {
                        simulateMarketPriceShift('supplier_cogs_drop');
                        setIsSimMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-emerald-50 text-slate-700 hover:text-emerald-900 transition-colors flex items-center justify-between"
                    >
                      <span className="font-semibold">Supplier COGS Relief (-9%)</span>
                      <span className="text-[10px] bg-emerald-100 text-emerald-800 px-1.5 py-0.5 rounded font-bold">
                        Discount
                      </span>
                    </button>
                    <button
                      onClick={() => {
                        simulateMarketPriceShift('random');
                        setIsSimMenuOpen(false);
                      }}
                      className="w-full text-left px-3 py-2 rounded-xl text-xs hover:bg-slate-100 text-slate-700 transition-colors flex items-center justify-between border-t border-slate-100 pt-2"
                    >
                      <span className="font-medium text-slate-600">Scrape Live Market Feeds</span>
                      <RefreshCw className="w-3 h-3 text-slate-400" />
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Batch Apply Button */}
            <button
              id="btn-apply-all-pricing"
              onClick={() => applyAllPriceAdjustments(priceSuggestions)}
              disabled={metrics.actionableCount === 0}
              className={`flex items-center gap-2 px-4 py-2.5 rounded-2xl font-bold text-xs shadow-sm transition-all active:scale-95 ${
                metrics.actionableCount > 0
                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer ring-2 ring-emerald-400/30'
                  : 'bg-slate-100 text-slate-400 cursor-not-allowed'
              }`}
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>Apply All Suggestions</span>
              {metrics.actionableCount > 0 && (
                <span className="px-2 py-0.5 rounded-full bg-emerald-800 text-white text-[10px] font-black">
                  {metrics.actionableCount}
                </span>
              )}
            </button>
          </div>
        </div>

        {/* Strategy Bar & Quick Switcher */}
        <div className="mt-5 pt-4 border-t border-slate-100 flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-2 flex-wrap">
            <span className="text-xs font-bold text-slate-500 uppercase tracking-wider flex items-center gap-1">
              <Sliders className="w-3.5 h-3.5 text-slate-400" /> Strategy:
            </span>
            {(
              [
                'margin_guardrail',
                'competitor_undercut',
                'market_match',
                'premium_brand',
                'velocity_demand',
              ] as PricingStrategy[]
            ).map((strat) => {
              const info = STRATEGY_INFO[strat];
              const isCurrent = pricingSettings.activeStrategy === strat;
              return (
                <button
                  key={strat}
                  onClick={() => updatePricingSettings({ activeStrategy: strat })}
                  className={`px-3 py-1 rounded-xl text-xs font-bold transition-all ${
                    isCurrent
                      ? 'bg-slate-900 text-white shadow-xs'
                      : 'bg-slate-100 hover:bg-slate-200 text-slate-600'
                  }`}
                >
                  {info.label}
                </button>
              );
            })}
          </div>

          <div className="text-xs text-slate-500 flex items-center gap-2">
            <span className="inline-block w-2 h-2 rounded-full bg-emerald-500 animate-ping" />
            <span>
              Target Margin: <strong className="text-slate-800">{pricingSettings.targetRetailMargin}%</strong> · Floor:{' '}
              <strong className="text-slate-800">{pricingSettings.minAllowedMargin}%</strong>
            </span>
          </div>
        </div>
      </div>

      {/* KPI Metric Strip */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-3.5">
        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Pending Adjustments
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">{metrics.actionableCount}</span>
            <span className="text-xs text-slate-500">/ {metrics.totalProducts} items</span>
          </div>
          <div className="mt-1 text-[11px] font-medium text-slate-600 flex items-center gap-1">
            {metrics.criticalCount > 0 ? (
              <span className="text-rose-600 font-bold flex items-center gap-0.5">
                <AlertTriangle className="w-3 h-3" /> {metrics.criticalCount} urgent margin risks
              </span>
            ) : (
              <span className="text-emerald-600 font-bold flex items-center gap-0.5">
                <Check className="w-3 h-3" /> Catalog margin protected
              </span>
            )}
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Gross Margin Defense
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-black text-slate-900">{metrics.currentAvgMargin}%</span>
            <span className="text-xs font-bold text-emerald-600">→ {metrics.projectedAvgMargin}%</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-500">
            Target benchmark: {pricingSettings.targetRetailMargin}% gross margin
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Rival Stockout Gains
          </div>
          <div className="mt-1 flex items-baseline gap-2">
            <span className="text-2xl font-black text-indigo-900">{metrics.stockoutGains}</span>
            <span className="text-xs text-indigo-600 font-bold">Uncontested items</span>
          </div>
          <div className="mt-1 text-[11px] text-slate-500">
            Competitor out of stock, capture premium pricing
          </div>
        </div>

        <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs">
          <div className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
            Est. Monthly Profit Uplift
          </div>
          <div className="mt-1 flex items-baseline gap-1.5">
            <span
              className={`text-2xl font-black ${
                metrics.potentialMonthlyUplift >= 0 ? 'text-emerald-700' : 'text-slate-900'
              }`}
            >
              {metrics.potentialMonthlyUplift >= 0 ? '+' : ''}
              {money(metrics.potentialMonthlyUplift)}
            </span>
          </div>
          <div className="mt-1 text-[11px] text-slate-500">
            Based on current inventory turnover velocity
          </div>
        </div>
      </div>

      {/* Navigation Sub-Tabs */}
      <div className="flex items-center justify-between border-b border-slate-200 pb-2">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setActiveSubTab('suggestions')}
            className={`px-4 py-2 rounded-xl font-bold text-sm transition-all flex items-center gap-2 ${
              activeSubTab === 'suggestions'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <TrendingUp className="w-4 h-4" />
            <span>Price Suggestions</span>
            {metrics.actionableCount > 0 && (
              <span className="px-1.5 py-0.2 rounded-full bg-emerald-500 text-slate-950 text-[10px] font-black">
                {metrics.actionableCount}
              </span>
            )}
          </button>

          <button
            onClick={() => setActiveSubTab('competitors')}
            className={`px-4 py-2 rounded-xl font-bold text-sm transition-all flex items-center gap-2 ${
              activeSubTab === 'competitors'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Building2 className="w-4 h-4" />
            <span>Competitor Quotes</span>
            <span className="px-1.5 py-0.2 rounded-full bg-slate-200 text-slate-700 text-[10px] font-bold">
              {competitorQuotes.length}
            </span>
          </button>

          <button
            onClick={() => setActiveSubTab('settings')}
            className={`px-4 py-2 rounded-xl font-bold text-sm transition-all flex items-center gap-2 ${
              activeSubTab === 'settings'
                ? 'bg-slate-900 text-white shadow-xs'
                : 'text-slate-600 hover:text-slate-900 hover:bg-slate-100'
            }`}
          >
            <Sliders className="w-4 h-4" />
            <span>Engine Parameters</span>
          </button>
        </div>

        {activeSubTab === 'competitors' && (
          <button
            onClick={() => setIsAddQuoteOpen(true)}
            className="flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs transition-all"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Competitor Quote</span>
          </button>
        )}
      </div>

      {/* SUB-TAB 1: SUGGESTIONS LIST */}
      {activeSubTab === 'suggestions' && (
        <div className="space-y-4">
          {/* Filters Bar */}
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col md:flex-row md:items-center justify-between gap-3">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
              <input
                type="text"
                placeholder="Search products, strategies, rules..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-9 pr-4 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs focus:bg-white focus:outline-none focus:ring-2 focus:ring-emerald-500 transition-all"
              />
            </div>

            <div className="flex items-center gap-2 flex-wrap">
              {/* Urgency / Driver Filter */}
              <div className="flex items-center gap-1.5 bg-slate-50 border border-slate-200 rounded-xl p-1">
                <span className="text-[10px] font-bold uppercase text-slate-400 px-2">Filter:</span>
                {[
                  { id: 'all', label: 'All' },
                  { id: 'critical', label: 'Urgent', badge: metrics.criticalCount },
                  { id: 'increase', label: 'Need Increase' },
                  { id: 'decrease', label: 'Need Decrease' },
                  { id: 'cogs_spike', label: 'COGS Spike' },
                  { id: 'stockout', label: 'Stockout Opps' },
                ].map((item) => (
                  <button
                    key={item.id}
                    onClick={() => setFilterUrgency(item.id)}
                    className={`px-2.5 py-1 rounded-lg text-xs font-bold transition-all ${
                      filterUrgency === item.id
                        ? 'bg-white text-slate-900 shadow-xs'
                        : 'text-slate-500 hover:text-slate-800'
                    }`}
                  >
                    {item.label}
                    {item.badge !== undefined && item.badge > 0 && (
                      <span className="ml-1 px-1 py-0.2 rounded-full bg-rose-500 text-white text-[9px]">
                        {item.badge}
                      </span>
                    )}
                  </button>
                ))}
              </div>

              {/* Sort By */}
              <div className="flex items-center gap-1 text-xs">
                <ArrowUpDown className="w-3.5 h-3.5 text-slate-400" />
                <select
                  value={sortBy}
                  onChange={(e) => setSortBy(e.target.value as any)}
                  className="bg-slate-50 border border-slate-200 rounded-xl py-1.5 px-2.5 text-xs text-slate-700 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  <option value="urgency">Sort by Urgency</option>
                  <option value="delta_high">Highest Price Increase</option>
                  <option value="delta_low">Highest Price Decrease</option>
                  <option value="margin_low">Lowest Margin First</option>
                  <option value="name">Product Name</option>
                </select>
              </div>
            </div>
          </div>

          {/* Product Suggestions List */}
          <div className="space-y-3">
            {filteredSuggestions.length === 0 ? (
              <div className="bg-white rounded-3xl p-10 text-center border border-slate-200">
                <CheckCircle2 className="w-12 h-12 text-emerald-500 mx-auto mb-3" />
                <h3 className="text-base font-bold text-slate-800">All Prices Are Optimal</h3>
                <p className="text-xs text-slate-500 mt-1 max-w-sm mx-auto">
                  No price adjustments required for the current filter criteria under{' '}
                  {STRATEGY_INFO[pricingSettings.activeStrategy].label}.
                </p>
              </div>
            ) : (
              filteredSuggestions.map((s) => {
                const prod = db.products.find((p) => p.id === s.productId);
                const isExpanded = expandedProductId === s.productId;
                const isPriceChange = Math.abs(s.priceChangeDelta) >= 1;
                const isIncrease = s.priceChangeDelta > 0;

                return (
                  <div
                    key={s.id}
                    className={`bg-white rounded-2xl border transition-all shadow-xs ${
                      s.urgency === 'critical'
                        ? 'border-rose-300 ring-1 ring-rose-200'
                        : s.urgency === 'warning'
                        ? 'border-amber-300'
                        : s.urgency === 'opportunity'
                        ? 'border-indigo-300'
                        : 'border-slate-200'
                    }`}
                  >
                    <div className="p-4 sm:p-5">
                      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                        {/* Product Core Details */}
                        <div className="flex items-start gap-3.5 flex-1">
                          <div
                            className={`w-10 h-10 rounded-xl flex items-center justify-center font-bold text-sm shrink-0 ${
                              isPriceChange
                                ? isIncrease
                                  ? 'bg-emerald-100 text-emerald-800'
                                  : 'bg-blue-100 text-blue-800'
                                : 'bg-slate-100 text-slate-600'
                            }`}
                          >
                            {isPriceChange ? (
                              isIncrease ? (
                                <TrendingUp className="w-5 h-5 text-emerald-600" />
                              ) : (
                                <TrendingDown className="w-5 h-5 text-blue-600" />
                              )
                            ) : (
                              <Check className="w-5 h-5 text-slate-500" />
                            )}
                          </div>

                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap">
                              <h3 className="font-extrabold text-slate-900 text-base leading-tight">
                                {s.productName}
                              </h3>
                              <span className="text-xs text-slate-400 font-medium">/{s.unit}</span>

                              {/* Urgency Chip */}
                              {s.urgency === 'critical' && (
                                <span className="px-2 py-0.5 rounded-md bg-rose-100 text-rose-800 text-[10px] font-black uppercase flex items-center gap-1">
                                  <AlertTriangle className="w-3 h-3 text-rose-600" /> Critical Margin Risk
                                </span>
                              )}
                              {s.urgency === 'warning' && (
                                <span className="px-2 py-0.5 rounded-md bg-amber-100 text-amber-800 text-[10px] font-bold uppercase">
                                  Underpriced
                                </span>
                              )}
                              {s.urgency === 'opportunity' && (
                                <span className="px-2 py-0.5 rounded-md bg-indigo-100 text-indigo-800 text-[10px] font-bold uppercase flex items-center gap-1">
                                  <Sparkles className="w-3 h-3 text-indigo-600" /> Stockout Opportunity
                                </span>
                              )}
                              {s.costChangePercent > 5 && (
                                <span className="px-2 py-0.5 rounded-md bg-orange-100 text-orange-800 text-[10px] font-bold">
                                  COGS +{s.costChangePercent}%
                                </span>
                              )}
                            </div>

                            <p className="text-xs text-slate-500 mt-1 line-clamp-1">
                              {s.reasoning}
                            </p>

                            <div className="mt-2 flex items-center gap-4 text-xs text-slate-600 flex-wrap">
                              <span>
                                In Stock:{' '}
                                <strong className="text-slate-800">{prod?.stock || 0}</strong> {s.unit}
                              </span>
                              <span>
                                Cost (Buy):{' '}
                                <strong className="text-slate-800">{money(s.currentCost)}</strong>
                              </span>
                              <span>
                                Current Retail:{' '}
                                <strong className="text-slate-800">{money(s.currentPrice)}</strong> (
                                {s.currentMarginPercent}% margin)
                              </span>
                            </div>
                          </div>
                        </div>

                        {/* Recommendation & Delta Highlight */}
                        <div className="flex items-center gap-4 shrink-0 bg-slate-50/80 p-3 rounded-2xl border border-slate-100">
                          <div>
                            <div className="text-[10px] font-bold uppercase text-slate-400 tracking-wider">
                              Suggested Retail
                            </div>
                            <div className="flex items-baseline gap-2 mt-0.5">
                              <span className="text-xl font-black text-slate-900">
                                {money(s.suggestedPrice)}
                              </span>
                              {isPriceChange && (
                                <span
                                  className={`text-xs font-bold px-1.5 py-0.5 rounded ${
                                    isIncrease
                                      ? 'bg-emerald-100 text-emerald-800'
                                      : 'bg-blue-100 text-blue-800'
                                  }`}
                                >
                                  {isIncrease ? '+' : ''}
                                  {money(s.priceChangeDelta)} ({s.priceChangePercent > 0 ? '+' : ''}
                                  {s.priceChangePercent}%)
                                </span>
                              )}
                            </div>
                            <div className="text-[10px] text-slate-500 mt-0.5">
                              Wholesale: {money(s.suggestedWholesalePrice)} · Margin:{' '}
                              <strong className="text-emerald-700">{s.suggestedMarginPercent}%</strong>
                            </div>
                          </div>

                          {/* Quick Action Buttons */}
                          <div className="flex flex-col gap-1.5 pl-2 border-l border-slate-200">
                            <button
                              onClick={() =>
                                applyPriceAdjustment(
                                  s.productId,
                                  s.suggestedPrice,
                                  s.suggestedWholesalePrice,
                                  s.reasoning
                                )
                              }
                              disabled={!isPriceChange}
                              className={`px-3 py-1.5 rounded-xl font-bold text-xs shadow-xs transition-all flex items-center justify-center gap-1 ${
                                isPriceChange
                                  ? 'bg-emerald-600 hover:bg-emerald-700 text-white cursor-pointer active:scale-95'
                                  : 'bg-slate-200 text-slate-400 cursor-not-allowed'
                              }`}
                            >
                              <Check className="w-3.5 h-3.5" />
                              <span>Apply</span>
                            </button>

                            <button
                              onClick={() => handleOpenCustom(s)}
                              className="px-3 py-1 bg-white hover:bg-slate-100 border border-slate-200 text-slate-700 font-semibold text-[11px] rounded-xl transition-all"
                            >
                              Custom
                            </button>
                          </div>
                        </div>
                      </div>

                      {/* Expand Details Trigger */}
                      <div className="mt-3 pt-3 border-t border-slate-100 flex items-center justify-between text-xs text-slate-500">
                        <div className="flex items-center gap-3">
                          <span className="font-semibold text-slate-700">Market Intelligence:</span>
                          <span>
                            Cheapest:{' '}
                            <strong className="text-slate-900">
                              {money(s.competitorMetrics.minPrice)}
                            </strong>{' '}
                            ({s.competitorMetrics.cheapestCompetitor})
                          </span>
                          <span>
                            Avg: <strong>{money(s.competitorMetrics.avgPrice)}</strong>
                          </span>
                          <span className="text-indigo-600 font-semibold">
                            {s.competitorMetrics.inStockCompetitorsCount}/
                            {s.competitorMetrics.totalCompetitorsCount} competitors in stock
                          </span>
                        </div>

                        <button
                          onClick={() => setExpandedProductId(isExpanded ? null : s.productId)}
                          className="flex items-center gap-1 font-bold text-slate-600 hover:text-slate-900"
                        >
                          <span>{isExpanded ? 'Hide Details' : 'View Breakdown'}</span>
                          {isExpanded ? (
                            <ChevronUp className="w-3.5 h-3.5" />
                          ) : (
                            <ChevronDown className="w-3.5 h-3.5" />
                          )}
                        </button>
                      </div>

                      {/* Expanded Section */}
                      {isExpanded && (
                        <div className="mt-4 pt-4 border-t border-dashed border-slate-200 bg-slate-50/50 -mx-4 sm:-mx-5 -mb-4 sm:-mb-5 p-4 sm:p-5 rounded-b-2xl">
                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            {/* Algorithmic Rationale */}
                            <div className="bg-white p-3.5 rounded-xl border border-slate-200">
                              <div className="text-xs font-bold text-slate-700 flex items-center gap-1.5 mb-2">
                                <Sparkles className="w-4 h-4 text-emerald-600" />
                                Algorithmic Rationale & Math
                              </div>
                              <ul className="text-xs text-slate-600 space-y-1.5">
                                <li>
                                  • Rule Applied: <strong className="text-slate-800">{s.ruleApplied}</strong>
                                </li>
                                <li>
                                  • Current Margin:{' '}
                                  <span
                                    className={`font-bold ${
                                      s.currentMarginPercent < pricingSettings.minAllowedMargin
                                        ? 'text-rose-600'
                                        : 'text-slate-800'
                                    }`}
                                  >
                                    {s.currentMarginPercent}%
                                  </span>{' '}
                                  (Floor: {pricingSettings.minAllowedMargin}%, Target:{' '}
                                  {pricingSettings.targetRetailMargin}%)
                                </li>
                                <li>
                                  • Projected Margin Post-Update:{' '}
                                  <strong className="text-emerald-700">{s.suggestedMarginPercent}%</strong>
                                </li>
                                <li>• Driver: {s.reasoning}</li>
                              </ul>
                            </div>

                            {/* Competitor Price Benchmarks */}
                            <div className="bg-white p-3.5 rounded-xl border border-slate-200">
                              <div className="text-xs font-bold text-slate-700 flex items-center gap-1.5 mb-2">
                                <Building2 className="w-4 h-4 text-blue-600" />
                                Tracked Competitor Quotes
                              </div>
                              <div className="space-y-1.5 max-h-36 overflow-y-auto">
                                {competitorQuotes
                                  .filter((q) => q.productId === s.productId)
                                  .map((q) => (
                                    <div
                                      key={q.id}
                                      className="flex items-center justify-between text-xs py-1 px-2 rounded-lg bg-slate-50 border border-slate-100"
                                    >
                                      <div>
                                        <span className="font-semibold text-slate-800">
                                          {q.competitorName}
                                        </span>
                                        <span className="text-[10px] text-slate-400 ml-1.5">
                                          ({q.source})
                                        </span>
                                      </div>
                                      <div className="flex items-center gap-2">
                                        <span className="font-bold text-slate-900">{money(q.price)}</span>
                                        <span
                                          className={`px-1.5 py-0.2 rounded text-[9px] font-bold ${
                                            q.inStock
                                              ? 'bg-emerald-100 text-emerald-800'
                                              : 'bg-rose-100 text-rose-800'
                                          }`}
                                        >
                                          {q.inStock ? 'In Stock' : 'Stockout'}
                                        </span>
                                      </div>
                                    </div>
                                  ))}
                              </div>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                );
              })
            )}
          </div>
        </div>
      )}

      {/* SUB-TAB 2: COMPETITORS DATA FEED */}
      {activeSubTab === 'competitors' && (
        <div className="space-y-4">
          <div className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex items-center justify-between">
            <div>
              <h2 className="text-base font-bold text-slate-900">Tracked Market Competitors</h2>
              <p className="text-xs text-slate-500">
                Real-time competitor quotes scraped via POS networks, receipt scans, and market surveys.
              </p>
            </div>

            <button
              onClick={() => setIsAddQuoteOpen(true)}
              className="flex items-center gap-1.5 px-3.5 py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-bold text-xs rounded-xl shadow-xs transition-all"
            >
              <Plus className="w-4 h-4" />
              <span>Record Competitor Quote</span>
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3.5">
            {competitorQuotes.map((quote) => {
              const ourProduct = db.products.find((p) => p.id === quote.productId);
              const priceDiff = ourProduct ? ourProduct.sell - quote.price : 0;
              const isWeMoreExpensive = priceDiff > 0;

              return (
                <div
                  key={quote.id}
                  className="bg-white p-4 rounded-2xl border border-slate-200/80 shadow-xs flex flex-col justify-between"
                >
                  <div>
                    <div className="flex items-start justify-between gap-2">
                      <span className="px-2 py-0.5 rounded-md bg-slate-100 text-slate-700 text-[10px] font-bold uppercase tracking-wider">
                        {quote.competitorName}
                      </span>
                      <button
                        onClick={() => deleteCompetitorQuote(quote.id)}
                        className="text-slate-400 hover:text-rose-600 p-1 transition-colors"
                        title="Delete Quote"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <h4 className="font-bold text-slate-900 text-sm mt-2">{quote.productName}</h4>

                    <div className="mt-3 flex items-baseline justify-between">
                      <div>
                        <div className="text-[10px] uppercase text-slate-400 font-bold">Rival Price</div>
                        <div className="text-xl font-black text-slate-900">{money(quote.price)}</div>
                      </div>

                      {ourProduct && (
                        <div className="text-right">
                          <div className="text-[10px] uppercase text-slate-400 font-bold">Our Price</div>
                          <div className="text-sm font-bold text-slate-700">{money(ourProduct.sell)}</div>
                          <div
                            className={`text-[10px] font-bold ${
                              isWeMoreExpensive ? 'text-rose-600' : 'text-emerald-600'
                            }`}
                          >
                            {isWeMoreExpensive
                              ? `+${money(priceDiff)} higher`
                              : `${money(Math.abs(priceDiff))} cheaper`}
                          </div>
                        </div>
                      )}
                    </div>
                  </div>

                  <div className="mt-4 pt-3 border-t border-slate-100 flex items-center justify-between text-[11px] text-slate-500">
                    <span
                      className={`px-2 py-0.5 rounded font-bold ${
                        quote.inStock ? 'bg-emerald-100 text-emerald-800' : 'bg-rose-100 text-rose-800'
                      }`}
                    >
                      {quote.inStock ? 'In Stock' : 'Stockout'}
                    </span>
                    <span>Source: {quote.source}</span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      )}

      {/* SUB-TAB 3: ENGINE SETTINGS */}
      {activeSubTab === 'settings' && (
        <div className="bg-white rounded-3xl p-6 border border-slate-200/80 shadow-xs max-w-2xl mx-auto space-y-6">
          <div>
            <h2 className="text-lg font-bold text-slate-900">Pricing Engine Guardrails & Rules</h2>
            <p className="text-xs text-slate-500 mt-0.5">
              Customize gross margin thresholds, wholesale discount percentages, and automated rounding rules.
            </p>
          </div>

          <div className="space-y-4">
            {/* Target Gross Margin */}
            <div>
              <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                <span>Target Gross Retail Margin (%)</span>
                <span className="text-emerald-700">{pricingSettings.targetRetailMargin}%</span>
              </div>
              <input
                type="range"
                min={15}
                max={50}
                step={1}
                value={pricingSettings.targetRetailMargin}
                onChange={(e) =>
                  updatePricingSettings({ targetRetailMargin: Number(e.target.value) })
                }
                className="w-full accent-emerald-600"
              />
              <p className="text-[11px] text-slate-400 mt-0.5">
                The baseline gross profit margin the algorithm aims to achieve when pricing products.
              </p>
            </div>

            {/* Minimum Allowed Margin Floor */}
            <div>
              <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                <span>Statutory Margin Floor (%)</span>
                <span className="text-rose-700">{pricingSettings.minAllowedMargin}%</span>
              </div>
              <input
                type="range"
                min={5}
                max={25}
                step={1}
                value={pricingSettings.minAllowedMargin}
                onChange={(e) => updatePricingSettings({ minAllowedMargin: Number(e.target.value) })}
                className="w-full accent-rose-600"
              />
              <p className="text-[11px] text-slate-400 mt-0.5">
                Absolute safety floor. The engine will NEVER undercut competitors below this threshold.
              </p>
            </div>

            {/* Wholesale Discount Rate */}
            <div>
              <div className="flex justify-between text-xs font-bold text-slate-700 mb-1">
                <span>Wholesale Discount vs Retail (%)</span>
                <span className="text-blue-700">{pricingSettings.wholesaleDiscountPercent}%</span>
              </div>
              <input
                type="range"
                min={3}
                max={20}
                step={1}
                value={pricingSettings.wholesaleDiscountPercent}
                onChange={(e) =>
                  updatePricingSettings({ wholesaleDiscountPercent: Number(e.target.value) })
                }
                className="w-full accent-blue-600"
              />
              <p className="text-[11px] text-slate-400 mt-0.5">
                Wholesale bulk prices are automatically indexed below retail by this percentage.
              </p>
            </div>

            {/* Rounding Rule */}
            <div>
              <label className="block text-xs font-bold text-slate-700 mb-1.5">
                Currency Rounding Rule
              </label>
              <select
                value={pricingSettings.roundingRule}
                onChange={(e) => updatePricingSettings({ roundingRule: e.target.value as any })}
                className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-xs font-semibold text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
              >
                <option value="nearest_5.00">Round to nearest 5.00 ETB (Clean Cash/Bills)</option>
                <option value="nearest_1.00">Round to nearest 1.00 ETB (Standard Integer)</option>
                <option value="nearest_0.50">Round to nearest 0.50 ETB (Fifty cents)</option>
                <option value="charm_99">Psychological Charm (.99 endings)</option>
                <option value="none">No Rounding (Exact Float)</option>
              </select>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 1: CUSTOM ADJUSTMENT */}
      {customAdjustTarget && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 animate-in zoom-in-95">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-extrabold text-slate-900">Custom Price Override</h3>
                <p className="text-xs text-slate-500">{customAdjustTarget.productName}</p>
              </div>
              <button
                onClick={() => setCustomAdjustTarget(null)}
                className="text-slate-400 hover:text-slate-700 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Retail Price (ETB)
                </label>
                <input
                  type="number"
                  value={customRetailPrice}
                  onChange={(e) => {
                    const val = Number(e.target.value);
                    setCustomRetailPrice(val);
                    // auto calculate wholesale
                    setCustomWholesalePrice(
                      Math.round(val * (1 - pricingSettings.wholesaleDiscountPercent / 100))
                    );
                  }}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Wholesale Price (ETB)
                </label>
                <input
                  type="number"
                  value={customWholesalePrice}
                  onChange={(e) => setCustomWholesalePrice(Number(e.target.value))}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-sm font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Reason for Override
                </label>
                <input
                  type="text"
                  value={customReason}
                  onChange={(e) => setCustomReason(e.target.value)}
                  placeholder="e.g. Special merchant agreement, seasonal shift"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs text-slate-800 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>
            </div>

            <div className="mt-6 flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                onClick={() => setCustomAdjustTarget(null)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                onClick={handleSaveCustom}
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs"
              >
                Apply Custom Price
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: ADD COMPETITOR QUOTE */}
      {isAddQuoteOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-xs flex items-center justify-center p-4">
          <form
            onSubmit={handleAddQuoteSubmit}
            className="bg-white rounded-3xl p-6 max-w-md w-full shadow-2xl border border-slate-200 animate-in zoom-in-95"
          >
            <div className="flex items-center justify-between pb-3 border-b border-slate-100">
              <div>
                <h3 className="text-base font-extrabold text-slate-900">Record Competitor Intel</h3>
                <p className="text-xs text-slate-500">Add live quote from rival supermarket or wholesale depot</p>
              </div>
              <button
                type="button"
                onClick={() => setIsAddQuoteOpen(false)}
                className="text-slate-400 hover:text-slate-700 p-1"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3.5">
              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">Select Product</label>
                <select
                  value={newQuoteProductId}
                  onChange={(e) => setNewQuoteProductId(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                >
                  {db.products.map((p) => (
                    <option key={p.id} value={p.id}>
                      {p.name} ({p.unit}) · Cost: {money(p.buy)}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Competitor / Store Name
                </label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Mercato Bulk Traders, Bambis Supermarket"
                  value={newQuoteCompetitor}
                  onChange={(e) => setNewQuoteCompetitor(e.target.value)}
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-slate-700 mb-1">
                  Rival Selling Price (ETB)
                </label>
                <input
                  type="number"
                  required
                  min={1}
                  value={newQuotePrice || ''}
                  onChange={(e) => setNewQuotePrice(Number(e.target.value))}
                  placeholder="e.g. 4950"
                  className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-bold text-slate-900 focus:outline-none focus:ring-2 focus:ring-emerald-500"
                />
              </div>

              <div className="grid grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Stock Status</label>
                  <select
                    value={newQuoteInStock ? 'true' : 'false'}
                    onChange={(e) => setNewQuoteInStock(e.target.value === 'true')}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900"
                  >
                    <option value="true">In Stock</option>
                    <option value="false">Out of Stock (Stockout)</option>
                  </select>
                </div>

                <div>
                  <label className="block text-xs font-bold text-slate-700 mb-1">Source / Verification</label>
                  <select
                    value={newQuoteSource}
                    onChange={(e) => setNewQuoteSource(e.target.value)}
                    className="w-full px-3 py-2 bg-slate-50 border border-slate-200 rounded-xl text-xs font-semibold text-slate-900"
                  >
                    <option value="Market Survey">Physical Market Survey</option>
                    <option value="Live Web Scrape">Online / Web Scrape</option>
                    <option value="POS Network">POS Network Telemetry</option>
                    <option value="Customer Receipt">Customer Receipt Verification</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="mt-6 flex items-center justify-end gap-2 pt-3 border-t border-slate-100">
              <button
                type="button"
                onClick={() => setIsAddQuoteOpen(false)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-100 rounded-xl"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl shadow-xs"
              >
                Save Competitor Quote
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
};
