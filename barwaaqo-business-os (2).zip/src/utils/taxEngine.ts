import { TaxTier, TaxSettings, CartItem, Sale, SaleTaxTierSummary, Product } from '../types';

export const DEFAULT_TAX_TIERS: TaxTier[] = [
  {
    id: 'TIER-STD',
    name: 'Standard VAT',
    code: 'VAT-15',
    rate: 15,
    description: 'Standard 15% VAT on commercial groceries, confectionery & packaged consumer goods',
    isDefault: true,
    isExempt: false,
  },
  {
    id: 'TIER-RED',
    name: 'Reduced Rate',
    code: 'RED-5',
    rate: 5,
    description: '5% Reduced rate for essential processed agricultural produce & edible oils',
    isDefault: false,
    isExempt: false,
  },
  {
    id: 'TIER-EXEMPT',
    name: 'Zero-Rated / Exempt',
    code: 'EXEMPT-0',
    rate: 0,
    description: '0% Exempt basic raw grain staples, unprocessed wheat flour, salt, and fresh bread',
    isDefault: false,
    isExempt: true,
  },
  {
    id: 'TIER-TOT',
    name: 'Turnover Tax (TOT)',
    code: 'TOT-10',
    rate: 10,
    description: '10% Turnover Tax on standard trade goods and non-VAT registered commercial sales',
    isDefault: false,
    isExempt: false,
  },
  {
    id: 'TIER-LUX',
    name: 'Luxury / Surtax',
    code: 'LUX-20',
    rate: 20,
    description: '20% Combined luxury & excise surtax on specialty imported roasts, confectionery & imports',
    isDefault: false,
    isExempt: false,
  },
];

export const DEFAULT_TAX_SETTINGS: TaxSettings = {
  enabled: true,
  calculationMethod: 'exclusive',
  defaultTierId: 'TIER-STD',
  taxLabel: 'VAT',
  taxIdentificationNumber: 'TIN-00941829-ET',
  registeredBusinessName: 'Aimraan Supreme Wholesale & Retail Grocery',
  roundPerItem: false,
  tiers: DEFAULT_TAX_TIERS,
};

export interface TaxPreset {
  id: string;
  name: string;
  region: string;
  taxLabel: string;
  calculationMethod: 'exclusive' | 'inclusive';
  defaultTierId?: string;
  description: string;
  tiers: TaxTier[];
}

export const REGIONAL_TAX_PRESETS: TaxPreset[] = [
  {
    id: 'ethiopia-standard',
    name: 'Ethiopian Revenue & Customs (ERCA / MOR)',
    region: 'Ethiopia',
    taxLabel: 'VAT',
    calculationMethod: 'exclusive',
    description: '15% Standard VAT, 5% Reduced Agricultural, 0% Zero-Rated Staple Food, 10% TOT, 20% Luxury',
    tiers: [
      { id: 'TIER-STD', name: 'Standard VAT', code: 'VAT-15', rate: 15, isDefault: true, isExempt: false, description: '15% Standard VAT on general commodities' },
      { id: 'TIER-RED', name: 'Reduced Rate', code: 'RED-5', rate: 5, isDefault: false, isExempt: false, description: '5% Reduced rate on local agro produce' },
      { id: 'TIER-EXEMPT', name: 'Zero-Rated / Exempt', code: 'EXEMPT-0', rate: 0, isDefault: false, isExempt: true, description: '0% Exempt essential staples & raw grain' },
      { id: 'TIER-TOT', name: 'Turnover Tax', code: 'TOT-10', rate: 10, isDefault: false, isExempt: false, description: '10% Turnover Tax on standard trade items' },
      { id: 'TIER-LUX', name: 'Luxury / Surtax', code: 'LUX-20', rate: 20, isDefault: false, isExempt: false, description: '20% Luxury & excise surtax on imports' },
    ],
  },
  {
    id: 'eu-standard',
    name: 'European Union Standard VAT',
    region: 'Europe / International',
    taxLabel: 'VAT',
    calculationMethod: 'inclusive',
    description: '20% Standard VAT (tax-inclusive shelf prices), 5% Reduced Groceries, 0% Exempt',
    tiers: [
      { id: 'TIER-STD', name: 'Standard VAT', code: 'VAT-20', rate: 20, isDefault: true, isExempt: false, description: '20% Standard VAT on general merchandise' },
      { id: 'TIER-RED', name: 'Reduced Rate Groceries', code: 'RED-5', rate: 5, isDefault: false, isExempt: false, description: '5% Reduced rate for foodstuffs & dairy' },
      { id: 'TIER-EXEMPT', name: 'Zero-Rated / Exempt', code: 'ZERO-0', rate: 0, isDefault: false, isExempt: true, description: '0% Exempt medical & basic flour' },
    ],
  },
  {
    id: 'us-retail',
    name: 'US State & Local Sales Tax',
    region: 'United States',
    taxLabel: 'Sales Tax',
    calculationMethod: 'exclusive',
    description: '8.25% Combined State & City Sales Tax, 2.5% Prepared Foods, 0% Unprepared Food Groceries Exempt',
    tiers: [
      { id: 'TIER-STD', name: 'General Merchandise Sales Tax', code: 'TAX-8.25', rate: 8.25, isDefault: true, isExempt: false, description: 'Standard state & municipal combined sales tax' },
      { id: 'TIER-RED', name: 'Prepared Food / Beverage', code: 'FOOD-2.5', rate: 2.5, isDefault: false, isExempt: false, description: 'Special municipal prepared foods levy' },
      { id: 'TIER-EXEMPT', name: 'Unprepared Food Grocery Exempt', code: 'EXEMPT-0', rate: 0, isDefault: false, isExempt: true, description: 'Tax-exempt essential grocery items' },
    ],
  },
  {
    id: 'gcc-standard',
    name: 'Gulf GCC Unified VAT',
    region: 'Middle East',
    taxLabel: 'VAT',
    calculationMethod: 'exclusive',
    description: '15% Standard Unified VAT, 0% Zero-Rated / Exempt essentials',
    tiers: [
      { id: 'TIER-STD', name: 'Standard VAT', code: 'VAT-15', rate: 15, isDefault: true, isExempt: false, description: '15% Unified GCC VAT' },
      { id: 'TIER-EXEMPT', name: 'Zero-Rated / Exempt', code: 'EXEMPT-0', rate: 0, isDefault: false, isExempt: true, description: '0% Exempt basic supply items' },
    ],
  },
];

/**
 * Returns the effective tax tier matching the ID or fallback to default
 */
export function getTaxTier(settings: TaxSettings, tierId?: string): TaxTier {
  const tiers = settings.tiers || DEFAULT_TAX_TIERS;
  if (tierId) {
    const match = tiers.find((t) => t.id === tierId || t.code === tierId);
    if (match) return match;
  }
  const defaultTier = tiers.find((t) => t.id === settings.defaultTierId || t.isDefault);
  if (defaultTier) return defaultTier;
  return tiers[0] || DEFAULT_TAX_TIERS[0];
}

/**
 * Calculates tax breakdown for an individual line item
 */
export function calculateLineTax(
  price: number,
  qty: number,
  tier: TaxTier,
  settings: TaxSettings,
  discountProportion: number = 0
) {
  const grossLineTotal = price * qty;
  const lineDiscount = Math.min(grossLineTotal, discountProportion);
  const netLineTotal = Math.max(0, grossLineTotal - lineDiscount);

  if (!settings.enabled || tier.isExempt || tier.rate <= 0) {
    return {
      tier,
      rate: 0,
      grossAmount: grossLineTotal,
      taxableAmount: netLineTotal,
      taxAmount: 0,
      totalAmount: grossLineTotal,
    };
  }

  const rate = tier.rate;
  if (settings.calculationMethod === 'inclusive') {
    // Price includes tax: Taxable = Gross / (1 + rate/100)
    const taxableAmount = netLineTotal / (1 + rate / 100);
    const taxAmount = netLineTotal - taxableAmount;
    return {
      tier,
      rate,
      grossAmount: grossLineTotal,
      taxableAmount,
      taxAmount,
      totalAmount: netLineTotal,
    };
  } else {
    // Price is exclusive of tax: Tax = Net * (rate/100)
    const taxableAmount = netLineTotal;
    const taxAmount = taxableAmount * (rate / 100);
    const totalAmount = taxableAmount + taxAmount;
    return {
      tier,
      rate,
      grossAmount: grossLineTotal,
      taxableAmount,
      taxAmount,
      totalAmount,
    };
  }
}

export interface CartTaxCalculationResult {
  subtotal: number;
  discount: number;
  taxableAmount: number;
  taxAmount: number;
  totalPayable: number;
  tierBreakdown: SaleTaxTierSummary[];
  effectiveTaxRate: number;
  isInclusive: boolean;
  totalItemsCount: number;
  exemptAmount: number;
  taxablePortionAmount: number;
  taxSummaryMap: Record<
    string,
    { tier: TaxTier; taxableAmount: number; taxAmount: number; itemCount: number }
  >;
}

/**
 * Multi-tier calculation for entire cart with proportional discount distribution
 */
export function calculateCartTaxes(
  cart: CartItem[],
  discount: number,
  settings: TaxSettings
): CartTaxCalculationResult {
  const grossSubtotal = cart.reduce((acc, item) => acc + item.qty * item.price, 0);
  const validDiscount = Math.max(0, Math.min(discount, grossSubtotal));
  const isInclusive = settings.calculationMethod === 'inclusive';

  const tierMap: Record<
    string,
    {
      tier: TaxTier;
      taxableAmount: number;
      taxAmount: number;
      itemCount: number;
    }
  > = {};

  // Initialize for all tiers in settings
  settings.tiers.forEach((t) => {
    tierMap[t.id] = {
      tier: t,
      taxableAmount: 0,
      taxAmount: 0,
      itemCount: 0,
    };
  });

  let totalTaxAmount = 0;
  let totalTaxableAmount = 0;
  let exemptAmount = 0;
  let taxablePortionAmount = 0;

  cart.forEach((item) => {
    const tier = getTaxTier(settings, item.taxTierId);
    const itemGross = item.qty * item.price;
    const itemDiscount = grossSubtotal > 0 ? (itemGross / grossSubtotal) * validDiscount : 0;

    const lineCalc = calculateLineTax(item.price, item.qty, tier, settings, itemDiscount);

    if (!tierMap[tier.id]) {
      tierMap[tier.id] = {
        tier,
        taxableAmount: 0,
        taxAmount: 0,
        itemCount: 0,
      };
    }

    tierMap[tier.id].taxableAmount += lineCalc.taxableAmount;
    tierMap[tier.id].taxAmount += lineCalc.taxAmount;
    tierMap[tier.id].itemCount += item.qty;

    totalTaxAmount += lineCalc.taxAmount;
    totalTaxableAmount += lineCalc.taxableAmount;

    if (tier.isExempt || tier.rate <= 0) {
      exemptAmount += lineCalc.taxableAmount;
    } else {
      taxablePortionAmount += lineCalc.taxableAmount;
    }
  });

  // Calculate final total payable
  let totalPayable: number;
  if (!settings.enabled) {
    totalPayable = Math.max(0, grossSubtotal - validDiscount);
    totalTaxAmount = 0;
  } else if (isInclusive) {
    totalPayable = Math.max(0, grossSubtotal - validDiscount);
  } else {
    // Exclusive: Total = Net Base + Tax
    totalPayable = Math.max(0, grossSubtotal - validDiscount) + totalTaxAmount;
  }

  const tierBreakdown: SaleTaxTierSummary[] = Object.values(tierMap)
    .filter((entry) => entry.itemCount > 0)
    .map((entry) => ({
      tierId: entry.tier.id,
      tierName: entry.tier.name,
      code: entry.tier.code,
      rate: entry.tier.rate,
      taxableAmount: entry.taxableAmount,
      taxAmount: entry.taxAmount,
      itemCount: entry.itemCount,
    }));

  const effectiveTaxRate = totalTaxableAmount > 0 ? (totalTaxAmount / totalTaxableAmount) * 100 : 0;
  const totalItemsCount = cart.reduce((acc, item) => acc + item.qty, 0);

  return {
    subtotal: grossSubtotal,
    discount: validDiscount,
    taxableAmount: totalTaxableAmount,
    taxAmount: totalTaxAmount,
    totalPayable,
    tierBreakdown,
    effectiveTaxRate,
    isInclusive,
    totalItemsCount,
    exemptAmount,
    taxablePortionAmount,
    taxSummaryMap: tierMap,
  };
}

// -------------------------------------------------------------
// MONTHLY TAX SUMMARY REPORT GENERATION
// -------------------------------------------------------------

export interface MonthlyTaxTierSummary {
  tierId: string;
  name: string;
  code: string;
  rate: number;
  isExempt: boolean;
  taxableBase: number;
  taxCollected: number;
  grossSales: number;
  transactionsCount: number;
  itemsCount: number;
  shareOfTotalTax: number;
}

export interface MonthlyTaxDailyBreakdown {
  date: string;
  dayNumber: number;
  invoiceCount: number;
  grossSales: number;
  taxableBase: number;
  taxCollected: number;
}

export interface MonthlyTaxTransactionAudit {
  id: string;
  invoice: string;
  date: string;
  time: string;
  customer: string;
  mode: string;
  payment: string;
  taxableBase: number;
  taxCollected: number;
  total: number;
  tiersApplied: string[];
}

export interface MonthlyTaxReport {
  periodLabel: string;
  year: number;
  month: number; // 1-12
  monthName: string;
  businessName: string;
  tin: string;
  taxLabel: string;
  calculationMethod: 'exclusive' | 'inclusive';

  totalGrossSales: number;
  totalNetTaxableBase: number;
  totalTaxCollected: number;
  totalExemptSales: number;
  totalDiscounts: number;
  totalTransactions: number;
  averageTaxPerTx: number;
  effectiveTaxRate: number;

  tierBreakdown: MonthlyTaxTierSummary[];
  dailyBreakdown: MonthlyTaxDailyBreakdown[];
  paymentBreakdown: { payment: string; sales: number; tax: number; count: number }[];
  modeBreakdown: { mode: string; sales: number; tax: number; count: number }[];
  transactions: MonthlyTaxTransactionAudit[];
}

const MONTH_NAMES = [
  'January', 'February', 'March', 'April', 'May', 'June',
  'July', 'August', 'September', 'October', 'November', 'December'
];

/**
 * Compiles a comprehensive Monthly Tax Summary Report from sales transactions
 */
export function generateMonthlyTaxReport(
  sales: Sale[],
  year: number,
  month: number, // 1-12
  settings: TaxSettings,
  products: Product[] = []
): MonthlyTaxReport {
  const monthStr = String(month).padStart(2, '0');
  const periodPrefix = `${year}-${monthStr}`;
  const monthName = MONTH_NAMES[month - 1] || `Month ${month}`;
  const periodLabel = `${monthName} ${year}`;

  const productTaxMap: Record<string, string> = {};
  products.forEach((p) => {
    if (p.taxTierId) productTaxMap[p.id] = p.taxTierId;
  });

  // Filter sales for the selected month
  const monthSales = (sales || []).filter((s) => {
    if (!s.date) return false;
    return s.date.startsWith(periodPrefix);
  });

  const tierMap: Record<
    string,
    {
      tier: TaxTier;
      taxableBase: number;
      taxCollected: number;
      grossSales: number;
      transactionsCount: number;
      itemsCount: number;
    }
  > = {};

  // Prepopulate tierMap with all configured tiers
  settings.tiers.forEach((t) => {
    tierMap[t.id] = {
      tier: t,
      taxableBase: 0,
      taxCollected: 0,
      grossSales: 0,
      transactionsCount: 0,
      itemsCount: 0,
    };
  });

  const dailyMap: Record<
    string,
    { date: string; dayNumber: number; invoiceCount: number; grossSales: number; taxableBase: number; taxCollected: number }
  > = {};

  const paymentMap: Record<string, { payment: string; sales: number; tax: number; count: number }> = {};
  const modeMap: Record<string, { mode: string; sales: number; tax: number; count: number }> = {
    retail: { mode: 'Retail', sales: 0, tax: 0, count: 0 },
    wholesale: { mode: 'Wholesale', sales: 0, tax: 0, count: 0 },
  };

  let totalGrossSales = 0;
  let totalNetTaxableBase = 0;
  let totalTaxCollected = 0;
  let totalExemptSales = 0;
  let totalDiscounts = 0;

  const transactionAudits: MonthlyTaxTransactionAudit[] = [];

  monthSales.forEach((sale) => {
    totalGrossSales += sale.total || 0;
    totalDiscounts += sale.discount || 0;

    const pm = sale.payment || 'Cash';
    if (!paymentMap[pm]) {
      paymentMap[pm] = { payment: pm, sales: 0, tax: 0, count: 0 };
    }
    paymentMap[pm].sales += sale.total || 0;
    paymentMap[pm].count += 1;

    const smode = sale.mode || 'retail';
    if (modeMap[smode]) {
      modeMap[smode].sales += sale.total || 0;
      modeMap[smode].count += 1;
    }

    const dayNum = parseInt(sale.date.split('-')[2] || '1', 10);
    if (!dailyMap[sale.date]) {
      dailyMap[sale.date] = {
        date: sale.date,
        dayNumber: dayNum,
        invoiceCount: 0,
        grossSales: 0,
        taxableBase: 0,
        taxCollected: 0,
      };
    }
    dailyMap[sale.date].invoiceCount += 1;
    dailyMap[sale.date].grossSales += sale.total || 0;

    let saleTaxableBase = 0;
    let saleTaxCollected = 0;
    const tiersAppliedSet = new Set<string>();

    if (sale.taxSummary && sale.taxSummary.length > 0) {
      // Sale has recorded tax breakdown
      sale.taxSummary.forEach((ts) => {
        const tier = getTaxTier(settings, ts.tierId);
        if (!tierMap[tier.id]) {
          tierMap[tier.id] = {
            tier,
            taxableBase: 0,
            taxCollected: 0,
            grossSales: 0,
            transactionsCount: 0,
            itemsCount: 0,
          };
        }
        tierMap[tier.id].taxableBase += ts.taxableAmount;
        tierMap[tier.id].taxCollected += ts.taxAmount;
        tierMap[tier.id].grossSales += ts.taxableAmount + ts.taxAmount;
        tierMap[tier.id].itemsCount += ts.itemCount || 0;
        tierMap[tier.id].transactionsCount += 1;

        saleTaxableBase += ts.taxableAmount;
        saleTaxCollected += ts.taxAmount;
        tiersAppliedSet.add(ts.code || tier.code);

        if (tier.isExempt || tier.rate <= 0) {
          totalExemptSales += ts.taxableAmount;
        }
      });
    } else {
      // Re-evaluate tax based on items and products
      const saleItems: CartItem[] = (sale.items || []).map((it) => ({
        pid: it.pid,
        name: it.name,
        qty: it.qty,
        price: it.price,
        mode: it.mode || sale.mode || 'retail',
        buy: it.buy,
        taxTierId: it.taxTierId || productTaxMap[it.pid] || settings.defaultTierId,
      }));

      const calc = calculateCartTaxes(saleItems, sale.discount || 0, settings);
      saleTaxableBase = calc.taxableAmount;
      saleTaxCollected = calc.taxAmount;

      calc.tierBreakdown.forEach((ts) => {
        const tier = getTaxTier(settings, ts.tierId);
        if (!tierMap[tier.id]) {
          tierMap[tier.id] = {
            tier,
            taxableBase: 0,
            taxCollected: 0,
            grossSales: 0,
            transactionsCount: 0,
            itemsCount: 0,
          };
        }
        tierMap[tier.id].taxableBase += ts.taxableAmount;
        tierMap[tier.id].taxCollected += ts.taxAmount;
        tierMap[tier.id].grossSales += ts.taxableAmount + ts.taxAmount;
        tierMap[tier.id].itemsCount += ts.itemCount || 0;
        tierMap[tier.id].transactionsCount += 1;
        tiersAppliedSet.add(ts.code);

        if (tier.isExempt || tier.rate <= 0) {
          totalExemptSales += ts.taxableAmount;
        }
      });
    }

    totalNetTaxableBase += saleTaxableBase;
    totalTaxCollected += saleTaxCollected;
    dailyMap[sale.date].taxableBase += saleTaxableBase;
    dailyMap[sale.date].taxCollected += saleTaxCollected;
    paymentMap[pm].tax += saleTaxCollected;
    if (modeMap[smode]) modeMap[smode].tax += saleTaxCollected;

    transactionAudits.push({
      id: sale.id,
      invoice: sale.invoice,
      date: sale.date,
      time: sale.time,
      customer: sale.customer || 'Walk-in Customer',
      mode: sale.mode || 'retail',
      payment: sale.payment,
      taxableBase: saleTaxableBase,
      taxCollected: saleTaxCollected,
      total: sale.total,
      tiersApplied: Array.from(tiersAppliedSet),
    });
  });

  const tierBreakdown: MonthlyTaxTierSummary[] = Object.values(tierMap)
    .filter((entry) => entry.grossSales > 0 || entry.tier.isDefault)
    .map((entry) => ({
      tierId: entry.tier.id,
      name: entry.tier.name,
      code: entry.tier.code,
      rate: entry.tier.rate,
      isExempt: !!entry.tier.isExempt,
      taxableBase: entry.taxableBase,
      taxCollected: entry.taxCollected,
      grossSales: entry.grossSales,
      transactionsCount: entry.transactionsCount,
      itemsCount: entry.itemsCount,
      shareOfTotalTax: totalTaxCollected > 0 ? (entry.taxCollected / totalTaxCollected) * 100 : 0,
    }))
    .sort((a, b) => b.taxCollected - a.taxCollected);

  const dailyBreakdown = Object.values(dailyMap).sort((a, b) => a.dayNumber - b.dayNumber);
  const paymentBreakdown = Object.values(paymentMap).sort((a, b) => b.sales - a.sales);
  const modeBreakdown = Object.values(modeMap);

  const totalTransactions = monthSales.length;
  const averageTaxPerTx = totalTransactions > 0 ? totalTaxCollected / totalTransactions : 0;
  const effectiveTaxRate = totalNetTaxableBase > 0 ? (totalTaxCollected / totalNetTaxableBase) * 100 : 0;

  return {
    periodLabel,
    year,
    month,
    monthName,
    businessName: settings.registeredBusinessName || 'IMRUU Grocery Store',
    tin: settings.taxIdentificationNumber || 'TIN-00000000',
    taxLabel: settings.taxLabel || 'VAT',
    calculationMethod: settings.calculationMethod,
    totalGrossSales,
    totalNetTaxableBase,
    totalTaxCollected,
    totalExemptSales,
    totalDiscounts,
    totalTransactions,
    averageTaxPerTx,
    effectiveTaxRate,
    tierBreakdown,
    dailyBreakdown,
    paymentBreakdown,
    modeBreakdown,
    transactions: transactionAudits.sort((a, b) => b.invoice.localeCompare(a.invoice)),
  };
}

/**
 * Generates and triggers download of an official CSV Tax Summary Report
 */
export function exportMonthlyTaxReportCSV(report: MonthlyTaxReport) {
  const lines: string[] = [];

  lines.push(`MONTHLY TAX SUMMARY REPORT · ${report.periodLabel.toUpperCase()}`);
  lines.push(`Taxpayer / Business Name,"${report.businessName}"`);
  lines.push(`Tax Identification Number (TIN),"${report.tin}"`);
  lines.push(`Tax Regime / Label,"${report.taxLabel}"`);
  lines.push(`Pricing Tax Application Mode,"${report.calculationMethod.toUpperCase()}"`);
  lines.push(`Generated Date,"${new Date().toISOString().slice(0, 10)}"`);
  lines.push('');

  lines.push('--- EXECUTIVE TAX LIABILITIES SUMMARY ---');
  lines.push(`Total Gross Sales Revenue,${report.totalGrossSales.toFixed(2)}`);
  lines.push(`Net Taxable Sales Base,${report.totalNetTaxableBase.toFixed(2)}`);
  lines.push(`Total Output Tax Collected,${report.totalTaxCollected.toFixed(2)}`);
  lines.push(`Zero-Rated / Exempt Sales,${report.totalExemptSales.toFixed(2)}`);
  lines.push(`Total Discounts Accorded,${report.totalDiscounts.toFixed(2)}`);
  lines.push(`Effective Monthly Tax Rate,${report.effectiveTaxRate.toFixed(2)}%`);
  lines.push(`Total Transactions Audited,${report.totalTransactions}`);
  lines.push(`Average Tax Collected Per Transaction,${report.averageTaxPerTx.toFixed(2)}`);
  lines.push('');

  lines.push('--- MULTI-TIER TAX BREAKDOWN ---');
  lines.push('Tax Tier Name,Code,Rate (%),Taxable Base (ETB),Tax Collected (ETB),Gross Sales (ETB),Items Count,Tax Share (%)');
  report.tierBreakdown.forEach((tb) => {
    lines.push(
      `"${tb.name}","${tb.code}",${tb.rate}%,${tb.taxableBase.toFixed(2)},${tb.taxCollected.toFixed(2)},${tb.grossSales.toFixed(2)},${tb.itemsCount},${tb.shareOfTotalTax.toFixed(1)}%`
    );
  });
  lines.push('');

  lines.push('--- DAILY TAX COLLECTIONS LEDGER ---');
  lines.push('Date,Day,Invoices,Gross Sales (ETB),Taxable Base (ETB),Tax Collected (ETB)');
  report.dailyBreakdown.forEach((db) => {
    lines.push(
      `"${db.date}",${db.dayNumber},${db.invoiceCount},${db.grossSales.toFixed(2)},${db.taxableBase.toFixed(2)},${db.taxCollected.toFixed(2)}`
    );
  });
  lines.push('');

  lines.push('--- TRANSACTION AUDIT LOG ---');
  lines.push('Invoice,Date,Time,Customer,Mode,Payment Channel,Taxable Base (ETB),Tax Collected (ETB),Total (ETB),Tiers Applied');
  report.transactions.forEach((tx) => {
    lines.push(
      `"${tx.invoice}","${tx.date}","${tx.time}","${tx.customer}","${tx.mode}","${tx.payment}",${tx.taxableBase.toFixed(2)},${tx.taxCollected.toFixed(2)},${tx.total.toFixed(2)},"${tx.tiersApplied.join('; ')}"`
    );
  });

  const csvContent = 'data:text/csv;charset=utf-8,' + encodeURIComponent(lines.join('\n'));
  const link = document.createElement('a');
  link.setAttribute('href', csvContent);
  link.setAttribute('download', `Monthly_Tax_Report_${report.year}_${String(report.month).padStart(2, '0')}.csv`);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
}
