import { DbState, Product, Sale, Purchase, DistributionOrder, ActivityLog, StockMetrics } from '../types';
import { calculateStockMetrics } from './helpers';

export interface StockHistoryMovement {
  id: string;
  date: string;
  time?: string;
  timestamp: string;
  type: 'opening' | 'purchase' | 'sale' | 'adjustment' | 'distribution';
  typeLabel: string;
  direction: 'in' | 'out' | 'adjust';
  qty: number;
  signedQty: number; // + or -
  reference: string;
  party?: string;
  unitPrice?: number;
  totalAmount?: number;
  reason?: string;
  user?: string;
}

export interface ProductSaleRecord {
  id: string;
  invoice: string;
  date: string;
  time: string;
  customer: string;
  mode: 'retail' | 'wholesale';
  qty: number;
  unitPrice: number;
  unitCost: number;
  unitProfit: number;
  totalRevenue: number;
  totalCost: number;
  totalProfit: number;
  marginPct: number;
  markupPct: number;
}

export interface ProductProfitMetrics {
  buyPrice: number;
  sellPrice: number;
  wholesalePrice: number;
  
  // Unit Economics
  retailMargin: number;
  retailMarginPct: number;
  retailMarkupPct: number;
  
  wholesaleMargin: number;
  wholesaleMarginPct: number;
  wholesaleMarkupPct: number;
  
  // Cumulative Performance
  totalUnitsSold: number;
  retailUnitsSold: number;
  wholesaleUnitsSold: number;
  
  totalSalesRevenue: number;
  totalSalesCost: number;
  totalRealizedGrossProfit: number;
  overallGrossMarginPct: number;
  averageSellingPrice: number;
  
  // Inventory Value & Unrealized Margins
  currentStock: number;
  currentStockCostValue: number;
  currentStockRetailValue: number;
  unrealizedPotentialProfit: number;
  
  // Detailed sale transactions
  salesRecords: ProductSaleRecord[];
}

export interface ProductFullLedger {
  product: Product;
  metrics: StockMetrics;
  history: StockHistoryMovement[];
  profit: ProductProfitMetrics;
  qrPayloadUrl: string;
  qrCodeDataText: string;
}

export function getProductFullLedger(productId: string, db: DbState): ProductFullLedger | null {
  const product = (db.products || []).find((p) => p.id === productId);
  if (!product) return null;

  const metrics = calculateStockMetrics(product, db);
  const buyCost = Number(product.buy) || 0;
  const sellPrice = Number(product.sell) || 0;
  const wholesalePrice = Number(product.wholesale) || sellPrice;

  // 1. Compile Stock History Movements
  const history: StockHistoryMovement[] = [];

  // (a) Opening Stock (if specified and non-zero)
  if (product.openingStock && product.openingStock > 0) {
    history.push({
      id: `open-${product.id}`,
      date: 'Initial Setup',
      timestamp: '2026-01-01T00:00:00Z',
      type: 'opening',
      typeLabel: 'Opening Inventory Baseline',
      direction: 'in',
      qty: product.openingStock,
      signedQty: product.openingStock,
      reference: 'BASELINE',
      party: 'Store Initialization',
      unitPrice: buyCost,
      totalAmount: product.openingStock * buyCost,
      reason: 'Initial stock intake recorded at shop launch',
    });
  }

  // (b) Purchases (Inflow)
  (db.purchases || []).forEach((pur) => {
    if (pur.productId === product.id) {
      const q = Number(pur.qty) || 0;
      const cost = Number(pur.unitCost) || buyCost;
      history.push({
        id: pur.id || `pur-${pur.number}`,
        date: pur.date || 'Unknown Date',
        timestamp: pur.date ? `${pur.date}T10:00:00Z` : '2026-01-01T00:00:00Z',
        type: 'purchase',
        typeLabel: 'Vendor Restock Received',
        direction: 'in',
        qty: q,
        signedQty: q,
        reference: pur.number || 'PO-RESTOCK',
        party: pur.supplier || 'Vendor',
        unitPrice: cost,
        totalAmount: Number(pur.total) || q * cost,
        reason: pur.note || 'Inventory replenishment',
      });
    }
  });

  // (c) Sales (Outflow) & Compile Profit Records
  const salesRecords: ProductSaleRecord[] = [];
  let totalUnitsSold = 0;
  let retailUnitsSold = 0;
  let wholesaleUnitsSold = 0;
  let totalSalesRevenue = 0;
  let totalSalesCost = 0;
  let totalRealizedGrossProfit = 0;

  (db.sales || []).forEach((sale) => {
    (sale.items || []).forEach((it) => {
      if (it.pid === product.id) {
        const q = Number(it.qty) || 0;
        const soldUnitPrice = Number(it.price) || (it.mode === 'wholesale' ? wholesalePrice : sellPrice);
        const itemCost = Number(it.buy) || buyCost;
        const itemRevenue = q * soldUnitPrice;
        const itemTotalCost = q * itemCost;
        const itemProfit = itemRevenue - itemTotalCost;
        const marginPct = itemRevenue > 0 ? (itemProfit / itemRevenue) * 100 : 0;
        const markupPct = itemCost > 0 ? ((soldUnitPrice - itemCost) / itemCost) * 100 : 0;

        totalUnitsSold += q;
        if (it.mode === 'wholesale') {
          wholesaleUnitsSold += q;
        } else {
          retailUnitsSold += q;
        }
        totalSalesRevenue += itemRevenue;
        totalSalesCost += itemTotalCost;
        totalRealizedGrossProfit += itemProfit;

        salesRecords.push({
          id: `${sale.id}-${it.pid}`,
          invoice: sale.invoice || 'INV',
          date: sale.date || 'Unknown Date',
          time: sale.time || '12:00:00',
          customer: sale.customer || 'Walk-in Customer',
          mode: it.mode || 'retail',
          qty: q,
          unitPrice: soldUnitPrice,
          unitCost: itemCost,
          unitProfit: soldUnitPrice - itemCost,
          totalRevenue: itemRevenue,
          totalCost: itemTotalCost,
          totalProfit: itemProfit,
          marginPct,
          markupPct,
        });

        history.push({
          id: `sale-${sale.id}-${it.pid}`,
          date: sale.date || 'Unknown Date',
          time: sale.time,
          timestamp: sale.date ? `${sale.date}T${sale.time || '12:00:00'}` : '2026-01-01T00:00:00Z',
          type: 'sale',
          typeLabel: it.mode === 'wholesale' ? 'Wholesale Customer Sale' : 'Retail POS Sale',
          direction: 'out',
          qty: q,
          signedQty: -q,
          reference: sale.invoice || 'POS-RECEIPT',
          party: sale.customer || 'Counter Client',
          unitPrice: soldUnitPrice,
          totalAmount: itemRevenue,
          reason: `${it.mode === 'wholesale' ? 'Bulk distribution' : 'Retail checkout'} · Margin: ${marginPct.toFixed(1)}%`,
        });
      }
    });
  });

  // (d) Distribution Orders (Outflow/Reserved)
  (db.orders || []).forEach((ord) => {
    if (ord.productId === product.id) {
      const q = Number(ord.qty) || 0;
      history.push({
        id: ord.id || `ord-${ord.number}`,
        date: ord.date || 'Unknown Date',
        timestamp: ord.date ? `${ord.date}T09:00:00Z` : '2026-01-01T00:00:00Z',
        type: 'distribution',
        typeLabel: `Distribution Order (${ord.status})`,
        direction: 'out',
        qty: q,
        signedQty: -q,
        reference: ord.number || 'DIS-ORDER',
        party: ord.customer || 'Distribution Client',
        unitPrice: ord.unitPrice,
        totalAmount: ord.total,
        reason: ord.note || `Driver: ${ord.driver || 'Pending dispatch'}`,
      });
    }
  });

  // (e) Stock Adjustments & Activity Audit Shifts
  (db.activity || []).forEach((act) => {
    if (act.productId === product.id && act.category === 'inventory_adjustment') {
      const adjQty = Number(act.adjustmentQty) || 0;
      const isIncrease = act.adjustmentType === 'increase' || adjQty > 0;
      const absQty = Math.abs(adjQty);
      history.push({
        id: act.id,
        date: act.date || 'Unknown Date',
        time: act.time,
        timestamp: act.timestamp || '2026-01-01T00:00:00Z',
        type: 'adjustment',
        typeLabel: isIncrease ? 'Stock Count Inflow (+)' : 'Stock Write-off / Outflow (−)',
        direction: isIncrease ? 'in' : 'out',
        qty: absQty,
        signedQty: isIncrease ? absQty : -absQty,
        reference: act.referenceId || 'AUDIT-ADJ',
        party: act.userName ? `${act.userName} (${act.userId || 'STAFF'})` : act.userId || 'Operator',
        unitPrice: buyCost,
        totalAmount: act.amount || absQty * buyCost,
        reason: act.reason || act.detail || 'Manual physical inventory count adjustment',
        user: act.userId,
      });
    }
  });

  // Sort history chronologically (latest movements first)
  history.sort((a, b) => {
    const tA = a.timestamp || a.date;
    const tB = b.timestamp || b.date;
    return tB.localeCompare(tA);
  });

  // Sort sales records chronologically (latest first)
  salesRecords.sort((a, b) => {
    const tA = `${a.date}T${a.time}`;
    const tB = `${b.date}T${b.time}`;
    return tB.localeCompare(tA);
  });

  // Unit Margin Calculations
  const retailMargin = Math.max(0, sellPrice - buyCost);
  const retailMarginPct = sellPrice > 0 ? (retailMargin / sellPrice) * 100 : 0;
  const retailMarkupPct = buyCost > 0 ? (retailMargin / buyCost) * 100 : 0;

  const wholesaleMargin = Math.max(0, wholesalePrice - buyCost);
  const wholesaleMarginPct = wholesalePrice > 0 ? (wholesaleMargin / wholesalePrice) * 100 : 0;
  const wholesaleMarkupPct = buyCost > 0 ? (wholesaleMargin / buyCost) * 100 : 0;

  const overallGrossMarginPct =
    totalSalesRevenue > 0 ? (totalRealizedGrossProfit / totalSalesRevenue) * 100 : retailMarginPct;
  const averageSellingPrice = totalUnitsSold > 0 ? totalSalesRevenue / totalUnitsSold : sellPrice;

  const currentStock = product.stock || 0;
  const currentStockCostValue = currentStock * buyCost;
  const currentStockRetailValue = currentStock * sellPrice;
  const unrealizedPotentialProfit = currentStock * retailMargin;

  const profit: ProductProfitMetrics = {
    buyPrice: buyCost,
    sellPrice,
    wholesalePrice,
    retailMargin,
    retailMarginPct,
    retailMarkupPct,
    wholesaleMargin,
    wholesaleMarginPct,
    wholesaleMarkupPct,
    totalUnitsSold,
    retailUnitsSold,
    wholesaleUnitsSold,
    totalSalesRevenue,
    totalSalesCost,
    totalRealizedGrossProfit,
    overallGrossMarginPct,
    averageSellingPrice,
    currentStock,
    currentStockCostValue,
    currentStockRetailValue,
    unrealizedPotentialProfit,
    salesRecords,
  };

  // Build deep link URL
  const baseUrl = typeof window !== 'undefined' ? window.location.origin + window.location.pathname : 'https://barwaaqo-shop.app/';
  const qrPayloadUrl = `${baseUrl}?product=${encodeURIComponent(product.id)}`;
  const qrCodeDataText = `BARWAAQO:${product.id}|SKU:${product.sku || 'NONE'}|PRICE:${sellPrice}|URL:${qrPayloadUrl}`;

  return {
    product,
    metrics,
    history,
    profit,
    qrPayloadUrl,
    qrCodeDataText,
  };
}
