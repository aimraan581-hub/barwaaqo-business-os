/**
 * Utility for managing permanent browser storage and offline persistence
 */

export interface StorageStatus {
  isSupported: boolean;
  isPersisted: boolean;
  quotaBytes?: number;
  usageBytes?: number;
  usageFormatted?: string;
  quotaFormatted?: string;
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  const kb = bytes / 1024;
  if (kb < 1024) return `${kb.toFixed(1)} KB`;
  const mb = kb / 1024;
  if (mb < 1024) return `${mb.toFixed(1)} MB`;
  const gb = mb / 1024;
  return `${gb.toFixed(2)} GB`;
}

export async function checkStoragePersistence(): Promise<StorageStatus> {
  if (typeof window === 'undefined' || !navigator?.storage) {
    return { isSupported: false, isPersisted: false };
  }

  try {
    const isPersisted = navigator.storage.persisted
      ? await navigator.storage.persisted()
      : false;

    let quotaBytes: number | undefined;
    let usageBytes: number | undefined;

    if (navigator.storage.estimate) {
      const estimate = await navigator.storage.estimate();
      quotaBytes = estimate.quota;
      usageBytes = estimate.usage;
    }

    return {
      isSupported: true,
      isPersisted,
      quotaBytes,
      usageBytes,
      quotaFormatted: quotaBytes !== undefined ? formatBytes(quotaBytes) : undefined,
      usageFormatted: usageBytes !== undefined ? formatBytes(usageBytes) : undefined,
    };
  } catch (error) {
    console.warn('Could not check storage persistence:', error);
    return { isSupported: true, isPersisted: false };
  }
}

export async function requestStoragePersistence(): Promise<boolean> {
  if (typeof window === 'undefined' || !navigator?.storage?.persist) {
    return false;
  }

  try {
    const isPersisted = await navigator.storage.persist();
    return isPersisted;
  } catch (error) {
    console.warn('Storage persistence request error:', error);
    return false;
  }
}
