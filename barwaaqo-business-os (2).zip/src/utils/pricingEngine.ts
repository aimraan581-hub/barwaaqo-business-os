import {
  Product,
  CompetitorQuote,
  PricingEngineSettings,
  PriceAdjustmentSuggestion,
  PricingStrategy,
  DbState,
} from '../types';
import { money } from './helpers';

export const DEFAULT_PRICING_SETTINGS: PricingEngineSettings = {
  targetRetailMargin: 25, // 25% target gross margin
  minAllowedMargin: 15, // 15% safety floor guardrail
  wholesaleDiscountPercent: 10, // wholesale is ~10% below retail
  maxPriceChangeStepPercent: 25, // max +/- 25% shift per adjustment
  activeStrategy: 'margin_guardrail',
  roundingRule: 'nearest_5.00',
  undercutMarginPercent: 2, // 2% under cheapest in-stock rival
};

export const INITIAL_COMPETITOR_QUOTES: CompetitorQuote[] = [
  // White Refined Sugar 50kg (Cost: 4200, Our Sell: 4800, Margin: 12.5% -> compressed!)
  {
    id: 'CQ-sug-01',
    competitorName: 'Mercato Bulk Traders',
    productId: 'P-sug-01',
    productName: 'White Refined Sugar 50kg',
    price: 4950,
    inStock: true,
    promoActive: false,
    lastChecked: '10 mins ago',
    source: 'Live Web Scrape',
    confidenceScore: 96,
  },
  {
    id: 'CQ-sug-02',
    competitorName: 'Addis Super Mart',
    productId: 'P-sug-01',
    productName: 'White Refined Sugar 50kg',
    price: 5100,
    inStock: true,
    promoActive: false,
    lastChecked: '25 mins ago',
    source: 'POS Network',
    confidenceScore: 92,
  },
  {
    id: 'CQ-sug-03',
    competitorName: 'Piassa Wholesale Direct',
    productId: 'P-sug-01',
    productName: 'White Refined Sugar 50kg',
    price: 4850,
    inStock: false, // Rival is out of stock!
    promoActive: false,
    lastChecked: '1 hour ago',
    source: 'Market Survey',
    confidenceScore: 89,
  },

  // Super Basmati Rice 25kg (Cost: 3100, Our Sell: 3600)
  {
    id: 'CQ-ric-01',
    competitorName: 'Mercato Bulk Traders',
    productId: 'P-ric-02',
    productName: 'Super Basmati Rice 25kg',
    price: 3750,
    inStock: true,
    promoActive: false,
    lastChecked: '15 mins ago',
    source: 'Live Web Scrape',
    confidenceScore: 95,
  },
  {
    id: 'CQ-ric-02',
    competitorName: 'Shola Wholesale Depot',
    productId: 'P-ric-02',
    productName: 'Super Basmati Rice 25kg',
    price: 3650,
    inStock: true,
    promoActive: true,
    lastChecked: '40 mins ago',
    source: 'Market Survey',
    confidenceScore: 91,
  },

  // Pure Sunflower Cooking Oil 5L (Cost: 820, Our Sell: 980)
  {
    id: 'CQ-oil-01',
    competitorName: 'Mercato Bulk Traders',
    productId: 'P-oil-03',
    productName: 'Pure Sunflower Cooking Oil 5L',
    price: 1050,
    inStock: true,
    promoActive: false,
    lastChecked: '5 mins ago',
    source: 'Live Web Scrape',
    confidenceScore: 98,
  },
  {
    id: 'CQ-oil-02',
    competitorName: 'Addis Super Mart',
    productId: 'P-oil-03',
    productName: 'Pure Sunflower Cooking Oil 5L',
    price: 1100,
    inStock: false, // Out of stock
    promoActive: false,
    lastChecked: '30 mins ago',
    source: 'POS Network',
    confidenceScore: 94,
  },
  {
    id: 'CQ-oil-03',
    competitorName: 'Bole Fresh Mart',
    productId: 'P-oil-03',
    productName: 'Pure Sunflower Cooking Oil 5L',
    price: 1080,
    inStock: true,
    promoActive: false,
    lastChecked: '2 hours ago',
    source: 'Manual Feed',
    confidenceScore: 88,
  },

  // First Grade Wheat Flour 25kg (Cost: 1950, Our Sell: 2350)
  {
    id: 'CQ-flr-01',
    competitorName: 'Shola Wholesale Depot',
    productId: 'P-flr-04',
    productName: 'First Grade Wheat Flour 25kg',
    price: 2450,
    inStock: true,
    promoActive: false,
    lastChecked: '12 mins ago',
    source: 'Market Survey',
    confidenceScore: 93,
  },
  {
    id: 'CQ-flr-02',
    competitorName: 'Piassa Wholesale Direct',
    productId: 'P-flr-04',
    productName: 'First Grade Wheat Flour 25kg',
    price: 2400,
    inStock: true,
    promoActive: false,
    lastChecked: '45 mins ago',
    source: 'Live Web Scrape',
    confidenceScore: 90,
  },

  // Spaghetti Pasta Carton (Cost: 920, Our Sell: 1150)
  {
    id: 'CQ-pas-01',
    competitorName: 'Mercato Bulk Traders',
    productId: 'P-pas-05',
    productName: 'Spaghetti Pasta Carton (20x500g)',
    price: 1120,
    inStock: true,
    promoActive: true,
    lastChecked: '18 mins ago',
    source: 'Live Web Scrape',
    confidenceScore: 94,
  },
  {
    id: 'CQ-pas-02',
    competitorName: 'Addis Super Mart',
    productId: 'P-pas-05',
    productName: 'Spaghetti Pasta Carton (20x500g)',
    price: 1200,
    inStock: true,
    promoActive: false,
    lastChecked: '1 hour ago',
    source: 'POS Network',
    confidenceScore: 87,
  },

  // Instant Full Cream Milk Powder (Cost: 750, Our Sell: 920)
  {
    id: 'CQ-mlk-01',
    competitorName: 'Bole Fresh Mart',
    productId: 'P-mlk-06',
    productName: 'Instant Full Cream Milk Powder 900g',
    price: 990,
    inStock: true,
    promoActive: false,
    lastChecked: '8 mins ago',
    source: 'Live Web Scrape',
    confidenceScore: 97,
  },
  {
    id: 'CQ-mlk-02',
    competitorName: 'Addis Super Mart',
    productId: 'P-mlk-06',
    productName: 'Instant Full Cream Milk Powder 900g',
    price: 1020,
    inStock: false,
    promoActive: false,
    lastChecked: '35 mins ago',
    source: 'Market Survey',
    confidenceScore: 90,
  },

  // Yirgacheffe Roast Coffee Beans 1kg (Cost: 550, Our Sell: 720)
  {
    id: 'CQ-cof-01',
    competitorName: 'Bole Fresh Mart',
    productId: 'P-cof-07',
    productName: 'Yirgacheffe Roast Coffee Beans 1kg',
    price: 790,
    inStock: true,
    promoActive: false,
    lastChecked: '22 mins ago',
    source: 'Market Survey',
    confidenceScore: 95,
  },
  {
    id: 'CQ-cof-02',
    competitorName: 'Mercato Bulk Traders',
    productId: 'P-cof-07',
    productName: 'Yirgacheffe Roast Coffee Beans 1kg',
    price: 750,
    inStock: true,
    promoActive: false,
    lastChecked: '55 mins ago',
    source: 'Live Web Scrape',
    confidenceScore: 93,
  },

  // Black Tea Bags 100s (Cost: 180, Our Sell: 250)
  {
    id: 'CQ-tea-01',
    competitorName: 'Shola Wholesale Depot',
    productId: 'P-tea-08',
    productName: 'Black Tea Bags (100 Bags/Box)',
    price: 260,
    inStock: true,
    promoActive: false,
    lastChecked: '14 mins ago',
    source: 'POS Network',
    confidenceScore: 92,
  },

  // Natural Spring Mineral Water (Cost: 210, Our Sell: 280)
  {
    id: 'CQ-wat-01',
    competitorName: 'Mercato Bulk Traders',
    productId: 'P-wat-09',
    productName: 'Natural Spring Mineral Water (12x1L)',
    price: 290,
    inStock: true,
    promoActive: false,
    lastChecked: '3 mins ago',
    source: 'Live Web Scrape',
    confidenceScore: 99,
  },
  {
    id: 'CQ-wat-02',
    competitorName: 'Shola Wholesale Depot',
    productId: 'P-wat-09',
    productName: 'Natural Spring Mineral Water (12x1L)',
    price: 275,
    inStock: true,
    promoActive: true,
    lastChecked: '30 mins ago',
    source: 'Market Survey',
    confidenceScore: 91,
  },

  // Rich Tomato Paste (Cost: 360, Our Sell: 480)
  {
    id: 'CQ-tom-01',
    competitorName: 'Addis Super Mart',
    productId: 'P-tom-10',
    productName: 'Rich Tomato Paste (Pack of 12)',
    price: 520,
    inStock: true,
    promoActive: false,
    lastChecked: '7 mins ago',
    source: 'Live Web Scrape',
    confidenceScore: 96,
  },
  {
    id: 'CQ-tom-02',
    competitorName: 'Piassa Wholesale Direct',
    productId: 'P-tom-10',
    productName: 'Rich Tomato Paste (Pack of 12)',
    price: 510,
    inStock: false,
    promoActive: false,
    lastChecked: '45 mins ago',
    source: 'Market Survey',
    confidenceScore: 89,
  },
];

/**
 * Apply rounding rule to candidate price
 */
export function roundPrice(
  price: number,
  rule: PricingEngineSettings['roundingRule']
): number {
  if (rule === 'none') return Math.round(price * 100) / 100;
  if (rule === 'nearest_0.50') return Math.round(price * 2) / 2;
  if (rule === 'nearest_1.00') return Math.round(price);
  if (rule === 'nearest_5.00') return Math.round(price / 5) * 5;
  if (rule === 'charm_99') {
    const base = Math.floor(price);
    return base + 0.99;
  }
  return Math.round(price);
}

/**
 * Calculates competitor metrics for a single product
 */
export function getProductCompetitorMetrics(
  productId: string,
  quotes: CompetitorQuote[]
) {
  const prodQuotes = quotes.filter((q) => q.productId === productId);
  if (prodQuotes.length === 0) {
    return {
      minPrice: 0,
      avgPrice: 0,
      maxPrice: 0,
      cheapestCompetitor: 'No data',
      inStockCompetitorsCount: 0,
      totalCompetitorsCount: 0,
      inStockQuotes: [],
      allQuotes: [],
    };
  }

  const inStockQuotes = prodQuotes.filter((q) => q.inStock);
  const quotesToCalc = inStockQuotes.length > 0 ? inStockQuotes : prodQuotes;

  const prices = quotesToCalc.map((q) => q.price);
  const minPrice = Math.min(...prices);
  const maxPrice = Math.max(...prices);
  const avgPrice = Math.round(prices.reduce((a, b) => a + b, 0) / prices.length);
  const cheapest = quotesToCalc.find((q) => q.price === minPrice)?.competitorName || 'Market';

  return {
    minPrice,
    avgPrice,
    maxPrice,
    cheapestCompetitor: cheapest,
    inStockCompetitorsCount: inStockQuotes.length,
    totalCompetitorsCount: prodQuotes.length,
    inStockQuotes,
    allQuotes: prodQuotes,
  };
}

/**
 * Calculates historical or baseline purchase COGS for a product
 */
export function getProductCogsFluctuation(product: Product, db: DbState) {
  const purchases = (db.purchases || []).filter((p) => p.productId === product.id);
  const currentCost = product.buy || 0;

  if (purchases.length >= 2) {
    // Previous purchase cost
    const prevCost = purchases[1].unitCost || purchases[0].unitCost;
    const change = currentCost - prevCost;
    const pct = prevCost > 0 ? (change / prevCost) * 100 : 0;
    return {
      previousCost: prevCost,
      currentCost,
      costChange: change,
      costChangePercent: Math.round(pct * 10) / 10,
      hasRecentPurchase: true,
      lastPurchaseDate: purchases[0].date,
    };
  }

  if (purchases.length === 1) {
    const prevCost = product.openingStock > 0 ? product.buy * 0.92 : purchases[0].unitCost;
    const change = currentCost - prevCost;
    const pct = prevCost > 0 ? (change / prevCost) * 100 : 0;
    return {
      previousCost: Math.round(prevCost),
      currentCost,
      costChange: change,
      costChangePercent: Math.round(pct * 10) / 10,
      hasRecentPurchase: true,
      lastPurchaseDate: purchases[0].date,
    };
  }

  // Baseline synthesis if no purchase records
  const syntheticPrev = Math.round(currentCost * 0.94);
  const change = currentCost - syntheticPrev;
  const pct = syntheticPrev > 0 ? (change / syntheticPrev) * 100 : 0;

  return {
    previousCost: syntheticPrev,
    currentCost,
    costChange: change,
    costChangePercent: Math.round(pct * 10) / 10,
    hasRecentPurchase: false,
    lastPurchaseDate: undefined,
  };
}

/**
 * Master Dynamic Pricing Engine
 * Generates actionable price suggestions based on COGS fluctuations and competitor data
 */
export function generateDynamicPriceSuggestions(
  db: DbState,
  competitorQuotes: CompetitorQuote[],
  settings: PricingEngineSettings = DEFAULT_PRICING_SETTINGS
): PriceAdjustmentSuggestion[] {
  const suggestions: PriceAdjustmentSuggestion[] = [];

  for (const product of db.products) {
    const costData = getProductCogsFluctuation(product, db);
    const compMetrics = getProductCompetitorMetrics(product.id, competitorQuotes);

    const currentCost = product.buy || 1;
    const currentPrice = product.sell || currentCost * 1.2;
    const currentWholesale = product.wholesale || currentPrice * 0.95;

    // Current gross margin: (sell - cost) / sell
    const currentMargin = currentPrice > 0 ? ((currentPrice - currentCost) / currentPrice) * 100 : 0;

    // Strategic target calculation
    let rawCandidatePrice = currentPrice;
    let urgency: PriceAdjustmentSuggestion['urgency'] = 'optimal';
    let primaryDriver: PriceAdjustmentSuggestion['primaryDriver'] = 'cogs_increase';
    let ruleApplied = '';
    let reasoning = '';
    let confidence = 85;

    const minAllowedPrice = currentCost / (1 - settings.minAllowedMargin / 100);
    const targetMarginPrice = currentCost / (1 - settings.targetRetailMargin / 100);

    // 1. Check for Critical Margin Compression (COGS Spike)
    if (currentMargin < settings.minAllowedMargin) {
      urgency = 'critical';
      primaryDriver = 'cogs_increase';
      ruleApplied = `Margin Floor Defense (Min ${settings.minAllowedMargin}% Guardrail)`;

      // Target to recover target margin, bounded if competitor is lower
      if (compMetrics.avgPrice > 0 && targetMarginPrice > compMetrics.avgPrice * 1.15) {
        // Competitor price is notably lower, aim to meet min margin + small buffer
        rawCandidatePrice = Math.max(minAllowedPrice, compMetrics.minPrice > 0 ? compMetrics.minPrice : minAllowedPrice);
        reasoning = `COGS rose to ${money(currentCost)}, compressing margin to a critical ${currentMargin.toFixed(1)}% (below ${settings.minAllowedMargin}% safety floor). Adjusted to ${money(rawCandidatePrice)} to defend baseline gross margin while tracking market benchmarks.`;
        confidence = 94;
      } else {
        rawCandidatePrice = targetMarginPrice;
        reasoning = `COGS increased by ${costData.costChangePercent > 0 ? '+' : ''}${costData.costChangePercent}%. Current margin ${currentMargin.toFixed(1)}% is below safety floor. Restoring target margin of ${settings.targetRetailMargin}%.`;
        confidence = 96;
      }
    }
    // 2. Competitor Stockout / High-Demand Opportunity
    else if (
      compMetrics.totalCompetitorsCount > 0 &&
      compMetrics.inStockCompetitorsCount === 0 &&
      product.stock > 0
    ) {
      urgency = 'opportunity';
      primaryDriver = 'competitor_stockout';
      ruleApplied = 'Market Scarcity Surcharge';
      const scarcityMarkup = 1.08; // 8% markup when all competitors are out of stock
      rawCandidatePrice = Math.max(currentPrice * scarcityMarkup, targetMarginPrice);
      reasoning = `All surveyed market competitors (${compMetrics.totalCompetitorsCount}) are currently stockout. Capture premium margin while rationing local inventory.`;
      confidence = 92;
    }
    // 3. Active Strategy Execution
    else {
      switch (settings.activeStrategy) {
        case 'competitor_undercut': {
          if (compMetrics.minPrice > 0) {
            const undercutCandidate = compMetrics.minPrice * (1 - settings.undercutMarginPercent / 100);
            if (undercutCandidate >= minAllowedPrice) {
              rawCandidatePrice = undercutCandidate;
              urgency = Math.abs(currentPrice - rawCandidatePrice) > 5 ? 'warning' : 'optimal';
              primaryDriver = 'competitor_undercut';
              ruleApplied = `Aggressive Undercut (${settings.undercutMarginPercent}% below ${compMetrics.cheapestCompetitor})`;
              reasoning = `Positioned ${settings.undercutMarginPercent}% below lowest in-stock rival (${compMetrics.cheapestCompetitor} at ${money(compMetrics.minPrice)}) to drive retail market share while holding safe ${((rawCandidatePrice - currentCost) / rawCandidatePrice * 100).toFixed(1)}% margin.`;
              confidence = 91;
            } else {
              rawCandidatePrice = minAllowedPrice;
              urgency = 'warning';
              primaryDriver = 'competitor_undercut';
              ruleApplied = 'Competitor Price War Clamp (Margin Guardrail)';
              reasoning = `Lowest competitor is aggressively discounting (${money(compMetrics.minPrice)}). Price clamped at ${money(rawCandidatePrice)} to prevent negative margin breach below ${settings.minAllowedMargin}%.`;
              confidence = 93;
            }
          } else {
            rawCandidatePrice = targetMarginPrice;
            ruleApplied = 'Target Margin Baseline';
            reasoning = `No active competitor quotes found. Maintaining baseline ${settings.targetRetailMargin}% target margin.`;
          }
          break;
        }

        case 'market_match': {
          if (compMetrics.avgPrice > 0) {
            const matchCandidate = Math.max(compMetrics.avgPrice, minAllowedPrice);
            rawCandidatePrice = matchCandidate;
            urgency = Math.abs(currentPrice - rawCandidatePrice) / currentPrice > 0.05 ? 'warning' : 'optimal';
            primaryDriver = 'market_premium';
            ruleApplied = 'Market Consensus Match';
            reasoning = `Harmonizing price with market average (${money(compMetrics.avgPrice)}) across ${compMetrics.inStockCompetitorsCount} in-stock competitors.`;
            confidence = 88;
          } else {
            rawCandidatePrice = targetMarginPrice;
            ruleApplied = 'Target Margin Baseline';
            reasoning = `Maintaining ${settings.targetRetailMargin}% target margin.`;
          }
          break;
        }

        case 'premium_brand': {
          const premiumMarkup = 1.06; // 6% premium
          const marketBase = compMetrics.avgPrice > 0 ? compMetrics.avgPrice : targetMarginPrice;
          rawCandidatePrice = Math.max(marketBase * premiumMarkup, targetMarginPrice);
          urgency = Math.abs(currentPrice - rawCandidatePrice) / currentPrice > 0.06 ? 'opportunity' : 'optimal';
          primaryDriver = 'market_premium';
          ruleApplied = 'Premium Value Positioning (+6% above market)';
          reasoning = `Leveraging prime store location, reliable packaging, and immediate availability with a 6% premium over market consensus (${money(marketBase)}).`;
          confidence = 89;
          break;
        }

        case 'velocity_demand': {
          // If stock is below min, raise price slightly to conserve stock
          if (product.stock <= product.min && product.stock > 0) {
            rawCandidatePrice = Math.max(currentPrice * 1.07, targetMarginPrice);
            urgency = 'warning';
            primaryDriver = 'velocity_surge';
            ruleApplied = 'Low Stock Preservation';
            reasoning = `Inventory is critically low (${product.stock} ${product.unit}). Increased price to throttle depletion velocity until next supplier replenishment.`;
            confidence = 90;
          } else if (product.stock > product.min * 4 && compMetrics.minPrice > 0) {
            // Overstocked - stimulate turnover
            const promoPrice = Math.max(compMetrics.minPrice * 0.98, minAllowedPrice);
            rawCandidatePrice = promoPrice;
            urgency = 'opportunity';
            primaryDriver = 'cogs_decrease';
            ruleApplied = 'Excess Stock Velocity Stimulation';
            reasoning = `Inventory is plentiful (${product.stock} ${product.unit}). Applied promotional price to accelerate turnover and release tied-up working capital.`;
            confidence = 87;
          } else {
            rawCandidatePrice = targetMarginPrice;
            ruleApplied = 'Velocity-Normalized Target Margin';
            reasoning = `Stock levels are healthy. Balanced for consistent sales velocity at ${settings.targetRetailMargin}% target margin.`;
          }
          break;
        }

        case 'margin_guardrail':
        default: {
          // If current price is within 3% of target margin price, it's optimal
          const deltaPct = Math.abs(currentPrice - targetMarginPrice) / currentPrice;
          if (deltaPct < 0.03) {
            rawCandidatePrice = currentPrice;
            urgency = 'optimal';
            ruleApplied = 'Optimal Margin Equilibrium';
            reasoning = `Current pricing yields ${currentMargin.toFixed(1)}% margin, aligned with business targets and market consensus.`;
          } else if (currentPrice < targetMarginPrice) {
            rawCandidatePrice = targetMarginPrice;
            urgency = 'warning';
            primaryDriver = 'cogs_increase';
            ruleApplied = 'Margin Recovery Alignment';
            reasoning = `Price adjusted from ${money(currentPrice)} to ${money(rawCandidatePrice)} to lift current margin (${currentMargin.toFixed(1)}%) to the ${settings.targetRetailMargin}% target.`;
          } else {
            // Price is notably higher than target margin; if competitor is much cheaper, we might lose volume
            if (compMetrics.minPrice > 0 && currentPrice > compMetrics.minPrice * 1.15) {
              rawCandidatePrice = Math.max(compMetrics.avgPrice, targetMarginPrice);
              urgency = 'opportunity';
              primaryDriver = 'competitor_undercut';
              ruleApplied = 'Overpriced Volume Correction';
              reasoning = `Product is priced 15%+ above competitors (${money(compMetrics.minPrice)}). Re-centering price near market average ${money(compMetrics.avgPrice)} to protect sales volume.`;
            } else {
              rawCandidatePrice = currentPrice;
              urgency = 'optimal';
              ruleApplied = 'Premium Margin Retained';
              reasoning = `Enjoying healthy ${currentMargin.toFixed(1)}% margin with acceptable market positioning.`;
            }
          }
          break;
        }
      }
    }

    // Step Limit Check: Bound max single shift to avoid customer sticker shock
    const maxAllowedUp = currentPrice * (1 + settings.maxPriceChangeStepPercent / 100);
    const maxAllowedDown = currentPrice * (1 - settings.maxPriceChangeStepPercent / 100);
    const boundedPrice = Math.min(maxAllowedUp, Math.max(maxAllowedDown, rawCandidatePrice));

    // Apply Rounding Rule
    const finalSuggestedPrice = roundPrice(boundedPrice, settings.roundingRule);

    // Compute wholesale price (e.g. 10% below suggested retail, bounded above cost)
    const rawWholesale = finalSuggestedPrice * (1 - settings.wholesaleDiscountPercent / 100);
    const finalSuggestedWholesale = roundPrice(Math.max(rawWholesale, currentCost * 1.05), settings.roundingRule);

    const priceDelta = finalSuggestedPrice - currentPrice;
    const priceChangePct = currentPrice > 0 ? (priceDelta / currentPrice) * 100 : 0;
    const projectedMargin = finalSuggestedPrice > 0 ? ((finalSuggestedPrice - currentCost) / finalSuggestedPrice) * 100 : 0;

    // If change is negligible (< 1%), mark as optimal
    if (Math.abs(priceDelta) < 1 && urgency !== 'critical') {
      urgency = 'optimal';
    }

    suggestions.push({
      id: `SUGG-${product.id}`,
      productId: product.id,
      productName: product.name,
      unit: product.unit,
      currentCost,
      previousCost: costData.previousCost,
      costChangePercent: costData.costChangePercent,
      currentPrice,
      currentWholesalePrice: currentWholesale,
      currentMarginPercent: Math.round(currentMargin * 10) / 10,
      suggestedPrice: finalSuggestedPrice,
      suggestedWholesalePrice: finalSuggestedWholesale,
      suggestedMarginPercent: Math.round(projectedMargin * 10) / 10,
      priceChangeDelta: Math.round(priceDelta * 100) / 100,
      priceChangePercent: Math.round(priceChangePct * 10) / 10,
      urgency,
      primaryDriver,
      reasoning,
      ruleApplied,
      competitorMetrics: {
        minPrice: compMetrics.minPrice,
        avgPrice: compMetrics.avgPrice,
        maxPrice: compMetrics.maxPrice,
        cheapestCompetitor: compMetrics.cheapestCompetitor,
        inStockCompetitorsCount: compMetrics.inStockCompetitorsCount,
        totalCompetitorsCount: compMetrics.totalCompetitorsCount,
      },
      confidence,
    });
  }

  // Sort: critical first, then warning, then opportunity, then optimal
  const urgencyWeight = { critical: 4, warning: 3, opportunity: 2, optimal: 1 };
  return suggestions.sort((a, b) => urgencyWeight[b.urgency] - urgencyWeight[a.urgency]);
}
