export async function registerBiometrics(userId: string, userName: string): Promise<string | null> {
  if (!window.PublicKeyCredential) {
    throw new Error('WebAuthn is not supported in this browser.');
  }

  const userIdBuffer = new TextEncoder().encode(userId);
  const challenge = crypto.getRandomValues(new Uint8Array(32));

  const publicKey: PublicKeyCredentialCreationOptions = {
    challenge,
    rp: { name: 'Imruu CEO OS' },
    user: {
      id: userIdBuffer,
      name: userName,
      displayName: userName,
    },
    pubKeyCredParams: [{ alg: -7, type: 'public-key' }],
    authenticatorSelection: {
      authenticatorAttachment: 'platform',
      userVerification: 'required',
    },
    timeout: 60000,
    attestation: 'none',
  };

  try {
    const credential = (await navigator.credentials.create({
      publicKey,
    })) as PublicKeyCredential;

    if (credential) {
      return bufferToBase64url(credential.rawId);
    }
  } catch (error) {
    console.warn('Biometric registration failed:', error);
    throw error;
  }
  return null;
}

export async function authenticateBiometrics(credentialIdStr: string): Promise<boolean> {
  if (!window.PublicKeyCredential) {
    throw new Error('WebAuthn is not supported in this browser.');
  }

  const challenge = crypto.getRandomValues(new Uint8Array(32));
  
  const publicKey: PublicKeyCredentialRequestOptions = {
    challenge,
    allowCredentials: [
      {
        id: base64urlToBuffer(credentialIdStr),
        type: 'public-key',
      },
    ],
    userVerification: 'required',
    timeout: 60000,
  };

  try {
    const assertion = await navigator.credentials.get({
      publicKey,
    });
    if (assertion) {
      return true;
    }
  } catch (error) {
    console.warn('Biometric authentication failed:', error);
    throw error;
  }
  return false;
}

function bufferToBase64url(buffer: ArrayBuffer): string {
  const bytes = new Uint8Array(buffer);
  let str = '';
  for (const charCode of bytes) {
    str += String.fromCharCode(charCode);
  }
  return btoa(str).replace(/\+/g, '-').replace(/\//g, '_').replace(/=/g, '');
}

function base64urlToBuffer(base64url: string): ArrayBuffer {
  const padding = '='.repeat((4 - (base64url.length % 4)) % 4);
  const base64 = (base64url + padding).replace(/-/g, '+').replace(/_/g, '/');
  const str = atob(base64);
  const buffer = new ArrayBuffer(str.length);
  const bytes = new Uint8Array(buffer);
  for (let i = 0; i < str.length; i++) {
    bytes[i] = str.charCodeAt(i);
  }
  return buffer;
}
