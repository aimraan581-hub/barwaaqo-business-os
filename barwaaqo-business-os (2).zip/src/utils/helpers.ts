import { DbState, Totals, StockMetrics, Product } from '../types';

export const KEY = 'imruu_grocery_shop_v18';
export const VERSION = 'V18';

export const money = (n: number | string | undefined | null): string => {
  const val = Number(n || 0);
  return 'ETB ' + val.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
};

export const formatCompactMoney = (n: number): string => {
  if (Math.abs(n) >= 1_000_000) {
    return 'ETB ' + (n / 1_000_000).toFixed(2) + 'M';
  }
  if (Math.abs(n) >= 1_000) {
    return 'ETB ' + (n / 1_000).toFixed(1) + 'K';
  }
  return money(n);
};

export const day = (): string => {
  const d = new Date();
  const p = (n: number) => String(n).padStart(2, '0');
  return `${d.getFullYear()}-${p(d.getMonth() + 1)}-${p(d.getDate())}`;
};

export const todayLabel = (): string => {
  return new Date().toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
};

export const uid = (prefix: string): string => {
  return `${prefix}-${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 7)}`;
};

export const calculateTotals = (db: DbState): Totals => {
  const rev = (db.sales || []).reduce((a, s) => a + (s.total || 0), 0);
  const gross = (db.sales || []).reduce((a, s) => a + (s.profit || 0), 0);
  const exp = (db.expenses || []).reduce((a, e) => a + (e.amount || 0), 0);
  const debt = (db.customers || []).reduce((a, c) => a + (c.credit || 0), 0);

  const supplierPurchases = (db.purchases || []).reduce(
    (a, p) => a + (p.payment === 'Credit' ? p.total || 0 : 0),
    0
  );
  const supplierPaid = (db.supplierPayments || []).reduce((a, p) => a + (p.amount || 0), 0);
  const supplierDebt = Math.max(0, supplierPurchases - supplierPaid);

  const stock = (db.products || []).reduce((a, p) => a + (p.stock || 0) * (p.buy || 0), 0);
  const net = gross - exp;
  const cash = Object.values(db.accounts || {}).reduce((a, v) => a + (Number(v) || 0), 0);
  const workingCapital = cash + stock + debt - supplierDebt;
  const capitalSpent = (db.capitalSpending || []).reduce((a, x) => a + (Number(x.amount) || 0), 0);
  const capitalRemaining = (db.capital || 200000) - capitalSpent;
  const value = Math.max(0, capitalRemaining + stock + net - supplierDebt);

  return {
    rev,
    gross,
    exp,
    net,
    debt,
    supplierDebt,
    stock,
    value,
    cash,
    workingCapital,
    capitalSpent,
    capitalRemaining,
  };
};

export const calculateStockMetrics = (p: Product, db: DbState): StockMetrics => {
  const sold = (db.sales || []).reduce(
    (a, s) => a + (s.items || []).filter((x) => x.pid === p.id).reduce((n, x) => n + (Number(x.qty) || 0), 0),
    0
  );
  const purchased = (db.purchases || [])
    .filter((x) => x.productId === p.id)
    .reduce((a, x) => a + (Number(x.qty) || 0), 0);
  const stockValue = (p.stock || 0) * (p.buy || 0);
  const margin = Math.max(0, (p.sell || 0) - (p.buy || 0));
  const health: 'out' | 'low' | 'good' = p.stock <= 0 ? 'out' : p.stock <= p.min ? 'low' : 'good';

  // Dynamic safety stock calculation based on recent sales velocity
  const now = new Date();
  const windowDays = 7;
  const windowMs = windowDays * 24 * 60 * 60 * 1000;

  let soldInWindow = 0;
  let hasDatedSalesInWindow = false;

  for (const s of db.sales || []) {
    if (!s.date) continue;
    const sDate = new Date(s.date + 'T23:59:59');
    const ageMs = now.getTime() - sDate.getTime();
    if (ageMs >= -86400000 && ageMs <= windowMs) {
      hasDatedSalesInWindow = true;
      for (const it of s.items || []) {
        if (it.pid === p.id) {
          soldInWindow += Number(it.qty) || 0;
        }
      }
    }
  }

  // If no sales had dates inside the calendar window, evaluate overall velocity normalized over 7 days
  if (!hasDatedSalesInWindow && sold > 0) {
    soldInWindow = sold;
  }

  const dailyVelocity = soldInWindow / windowDays;
  const recentSalesVelocity = Number(dailyVelocity.toFixed(2));

  // Lead time buffer: 4 days (covers typical 2.5-day supplier turnaround + 1.5-day safety cushion)
  const leadTimeBufferDays = 4;
  const velocityStockThreshold = Math.ceil(dailyVelocity * leadTimeBufferDays);
  const dynamicSafetyThreshold = Math.max(p.min || 1, velocityStockThreshold);

  const isBelowSafetyStock = (p.stock || 0) <= dynamicSafetyThreshold;
  const isVelocityTriggered = isBelowSafetyStock && (p.stock || 0) > (p.min || 0);
  const daysOfCover = dailyVelocity > 0 ? Number(((p.stock || 0) / dailyVelocity).toFixed(1)) : 999;
  const reorder = Math.max(0, dynamicSafetyThreshold * 2 - (p.stock || 0));

  return {
    sold,
    purchased,
    stockValue,
    margin,
    health,
    reorder,
    recentSalesVelocity,
    dynamicSafetyThreshold,
    isBelowSafetyStock,
    isVelocityTriggered,
    daysOfCover,
  };
};

export interface DynamicSafetyStockSummary {
  totalBelowSafety: number;
  velocityTriggeredCount: number;
  criticalMinCount: number;
  outOfStockCount: number;
  alerts: { product: Product; metrics: StockMetrics }[];
}

export const getDynamicSafetyStockAlerts = (db: DbState): DynamicSafetyStockSummary => {
  const alerts: { product: Product; metrics: StockMetrics }[] = [];
  let velocityTriggeredCount = 0;
  let criticalMinCount = 0;
  let outOfStockCount = 0;

  for (const p of db.products || []) {
    const m = calculateStockMetrics(p, db);
    if (m.isBelowSafetyStock) {
      alerts.push({ product: p, metrics: m });
      if (p.stock <= 0) {
        outOfStockCount++;
      } else if (m.isVelocityTriggered) {
        velocityTriggeredCount++;
      } else if (p.stock <= p.min) {
        criticalMinCount++;
      }
    }
  }

  return {
    totalBelowSafety: alerts.length,
    velocityTriggeredCount,
    criticalMinCount,
    outOfStockCount,
    alerts,
  };
};

export const capitalData = (db: DbState) => {
  const t = calculateTotals(db);
  const by: Record<string, number> = {};
  (db.capitalSpending || []).forEach((x) => {
    by[x.category] = (by[x.category] || 0) + (Number(x.amount) || 0);
  });
  return { t, by };
};
