import React, { createContext, useContext, useState, useEffect, useMemo, ReactNode } from 'react';
import {
  DbState,
  Product,
  CartItem,
  Sale,
  Purchase,
  Customer,
  CustomerType,
  DistributionOrder,
  CapitalSpending,
  Expense,
  Goal,
  ActivityLog,
  Totals,
  PaymentMethod,
  SaleMode,
  OrderStatus,
  SystemUser,
  PricingEngineSettings,
  CompetitorQuote,
  PriceAdjustmentSuggestion,
  TaxTier,
  TaxSettings,
  Shift,
  Supplier,
  WarehouseLocation,
  StockTransfer,
  DailyActionItem,
  BusinessProfile,
} from '../types';
import { getBaseDb, DEFAULT_USERS } from '../data/initialData';
import { KEY, calculateTotals, uid, day, money } from '../utils/helpers';
import {
  DEFAULT_PRICING_SETTINGS,
  INITIAL_COMPETITOR_QUOTES,
  generateDynamicPriceSuggestions,
  roundPrice,
} from '../utils/pricingEngine';
import {
  DEFAULT_TAX_SETTINGS,
  DEFAULT_TAX_TIERS,
  REGIONAL_TAX_PRESETS,
  getTaxTier,
  calculateLineTax,
  calculateCartTaxes,
} from '../utils/taxEngine';

export type TabKey =
  | 'dashboard'
  | 'pos'
  | 'inventory'
  | 'pricing'
  | 'purchases'
  | 'customers'
  | 'distribution'
  | 'finance'
  | 'reports'
  | 'activity'
  | 'enterprise';

interface StoreContextType {
  db: DbState;
  totals: Totals;
  activeTab: TabKey;
  setActiveTab: (tab: TabKey) => void;

  // Modals & UI states
  isSearchOpen: boolean;
  setIsSearchOpen: (open: boolean) => void;
  isCapitalModalOpen: boolean;
  setIsCapitalModalOpen: (open: boolean) => void;
  stockAdjustProductId: string | null;
  setStockAdjustProductId: (pid: string | null) => void;
  productQrModalId: string | null;
  setProductQrModalId: (pid: string | null) => void;
  isBusinessInfoOpen: boolean;
  setIsBusinessInfoOpen: (open: boolean) => void;
  isCeoProfileModalOpen: boolean;
  setIsCeoProfileModalOpen: (open: boolean) => void;
  isGettingStartedOpen: boolean;
  setIsGettingStartedOpen: (open: boolean) => void;
  businessProfile: BusinessProfile;
  updateBusinessProfile: (updates: Partial<BusinessProfile>) => void;
  enterpriseSubTab: 'milestones' | 'warehouses' | 'team' | 'suppliers' | 'shifts';
  setEnterpriseSubTab: (tab: 'milestones' | 'warehouses' | 'team' | 'suppliers' | 'shifts') => void;
  openTeamManagement: () => void;
  toastMessage: string | null;
  showToast: (msg: string) => void;

  // POS Cart
  cart: CartItem[];
  addToCart: (pid: string, qty: number, mode: SaleMode) => boolean;
  updateCartQty: (index: number, qty: number) => boolean;
  removeFromCart: (index: number) => void;
  clearCart: () => void;
  updateCartItemTaxTier: (index: number, taxTierId: string) => void;
  completeSale: (discount: number, payment: PaymentMethod, customerId: string) => boolean;

  // Inventory
  saveProduct: (productData: Omit<Product, 'id' | 'openingStock'>) => boolean;
  adjustStock: (
    pid: string,
    qty: number,
    type: 'increase' | 'decrease',
    reason: string,
    customUserId?: string,
    authMeta?: {
      verifiedByPin?: boolean;
      authorizedByUserId?: string;
      authorizedByUserName?: string;
      authorizedByUserRole?: string;
    }
  ) => boolean;
  deleteProduct: (pid: string) => void;

  // Purchases & Suppliers
  updateSuppliers: (suppliers: Supplier[]) => void;
  recordPurchase: (
    supplierOrData:
      | string
      | {
          supplier: string;
          productId: string;
          qty: number;
          unitCost: number;
          payment: PaymentMethod;
          note?: string;
          phone?: string;
        },
    phone?: string,
    productId?: string,
    qty?: number,
    unitCost?: number,
    payment?: PaymentMethod
  ) => boolean;
  paySupplier: (supplier: string, amount: number, account?: 'Cash' | 'Bank' | 'Mobile Money') => boolean;
  addSupplier: (supplierData: Omit<Supplier, 'id'>) => boolean;
  updateSupplier: (id: string, supplierData: Partial<Supplier>) => boolean;
  deleteSupplier: (id: string) => void;

  // Customers
  addCustomer: (
    nameOrData:
      | string
      | {
          name: string;
          phone?: string;
          location?: string;
          limit?: number;
          customerType?: CustomerType;
          tinNumber?: string;
          paymentTerms?: string;
          contactPerson?: string;
        },
    phone?: string,
    location?: string
  ) => boolean;
  updateCustomer?: (id: string, updates: Partial<Customer>) => boolean;
  payCustomer: (customerId: string, amount: number, account?: 'Cash' | 'Bank' | 'Mobile Money') => boolean;
  payCustomerCredit: (customerId: string, amount: number) => boolean;
  deleteCustomer: (customerId: string) => void;

  // Distribution & Delivery Route Management
  createOrder: (
    customerId: string,
    driver: string,
    productId: string,
    qty: number,
    fee: number,
    payment: PaymentMethod
  ) => boolean;
  createDistributionOrder: (data: {
    customerId: string;
    productId: string;
    qty: number;
    mode?: SaleMode;
    deposit?: number;
    deliveryDate?: string;
    note?: string;
    driver?: string;
    route?: string;
    vehiclePlate?: string;
  }) => boolean;
  assignDeliveryRoute: (
    orderId: string,
    details: {
      driver: string;
      route: string;
      vehiclePlate?: string;
    }
  ) => boolean;
  advanceOrder: (orderId: string) => void;
  updateOrderStatus: (orderId: string, nextStatus: OrderStatus) => void;
  payOrder: (orderId: string, amount: number) => boolean;
  payOrderBalance: (orderId: string, amount: number) => boolean;
  deleteOrder: (orderId: string) => void;

  // Finance
  recordExpense: (name: string, amount: number, account: 'Cash' | 'Bank' | 'Mobile Money' | string) => boolean;
  addExpense: (title: string, category: string, amount: number, account: string) => boolean;
  deleteExpense: (id: string) => void;
  saveCapitalEntry: (
    category: string,
    amount: number,
    note: string,
    authMeta?: {
      verifiedByPin?: boolean;
      authorizedByUserId?: string;
      authorizedByUserName?: string;
      authorizedByUserRole?: string;
    }
  ) => boolean;
  deleteCapitalEntry: (
    id: string,
    authMeta?: {
      verifiedByPin?: boolean;
      authorizedByUserId?: string;
      authorizedByUserName?: string;
      authorizedByUserRole?: string;
    }
  ) => void;
  transferBetweenAccounts: (from: string, to: string, amount: number) => boolean;
  updateAccountBalance: (account: string, balance: number) => void;

  // Enterprise & Goals
  setDailySalesTarget: (target: number) => void;
  setDailySalesTargetForDate: (date: string, target: number) => void;
  toggleDailyActionItem: (date: string, actionId: string) => void;
  addDailyActionItem: (
    date: string,
    text: string,
    impact?: 'high' | 'medium' | 'growth',
    assignedTo?: string,
    category?: string
  ) => void;
  deleteDailyActionItem: (date: string, actionId: string) => void;
  addGoal: (titleOrText: string, targetOrCategory: number | string) => boolean;
  updateGoal: (id: string, done: number) => void;
  toggleGoal: (id: string) => void;
  deleteGoal: (id: string) => void;
  toggleCheck: (index: number) => void;

  // Audit & Security Session
  currentUser: SystemUser;
  setCurrentUser: (user: SystemUser) => void;
  availableUsers: SystemUser[];
  highValueThreshold: number;
  setHighValueThreshold: (val: number) => void;
  logActivity: (action: string, detail: string, options?: Partial<ActivityLog>) => void;
  logSecurityAlert: (action: string, detail: string, options?: Partial<ActivityLog>) => void;
  verifyPin: (userId: string, pin: string) => { success: boolean; user?: SystemUser; message?: string };
  updateUserPin: (userId: string, newPin: string) => boolean;
  updateUserWebAuthn: (userId: string, credentialId: string | null) => void;
  clearActivity: () => void;
  clearActivityLog: (authMeta?: {
    verifiedByPin?: boolean;
    authorizedByUserId?: string;
    authorizedByUserName?: string;
    authorizedByUserRole?: string;
  }) => void;
  recordFinancialLedgerAdjustment: (
    ledgerTypeOrData:
      | 'capital'
      | 'expense'
      | 'account_balance'
      | 'ledger_correction'
      | {
          type?: string;
          amount: number;
          direction?: 'credit' | 'debit';
          account?: string;
          reason?: string;
          operatorId?: string;
          authMeta?: {
            verifiedByPin?: boolean;
            authorizedByUserId?: string;
            authorizedByUserName?: string;
            authorizedByUserRole?: string;
          };
        },
    title?: string,
    amount?: number,
    notes?: string,
    accountName?: string,
    authMeta?: {
      verifiedByPin?: boolean;
      authorizedByUserId?: string;
      authorizedByUserName?: string;
      authorizedByUserRole?: string;
    }
  ) => boolean;
  updateActivityLogNote: (
    logId: string,
    newNote: string,
    authMeta?: {
      verifiedByPin?: boolean;
      authorizedByUserId?: string;
      authorizedByUserName?: string;
      authorizedByUserRole?: string;
    }
  ) => boolean;

  // Shifts & Team
  assignShift: (shiftData: Omit<Shift, 'id'>) => boolean;
  deleteShift: (id: string) => void;
  addSystemUser: (user: Omit<SystemUser, 'id'>) => boolean;
  updateSystemUser: (id: string, updates: Partial<SystemUser>) => boolean;
  deleteSystemUser: (id: string) => boolean;

  // Warehouses & Locations
  addWarehouse: (warehouse: Omit<WarehouseLocation, 'id'>) => void;
  updateWarehouse: (id: string, updates: Partial<WarehouseLocation>) => void;
  deleteWarehouse: (id: string) => void;
  transferStock: (data: {
    fromLocationId: string;
    toLocationId: string;
    productId: string;
    qty: number;
    notes?: string;
  }) => boolean;

  // Dynamic Pricing Engine
  pricingSettings: PricingEngineSettings;
  competitorQuotes: CompetitorQuote[];
  priceSuggestions: PriceAdjustmentSuggestion[];
  applyPriceAdjustment: (
    productId: string,
    newSell: number,
    newWholesale?: number,
    reason?: string
  ) => boolean;
  applyAllPriceAdjustments: (adjustments: PriceAdjustmentSuggestion[]) => number;
  updatePricingSettings: (settings: Partial<PricingEngineSettings>) => void;
  addCompetitorQuote: (quote: Omit<CompetitorQuote, 'id' | 'lastChecked'>) => boolean;
  updateCompetitorQuote: (quoteId: string, updates: Partial<CompetitorQuote>) => boolean;
  deleteCompetitorQuote: (quoteId: string) => void;
  simulateMarketPriceShift: (
    type?:
      | 'inflation_spike'
      | 'competitor_discount_war'
      | 'competitor_stockouts'
      | 'supplier_cogs_drop'
      | 'random'
  ) => void;

  // Tax & Compliance Engine
  taxSettings: TaxSettings;
  isTaxModalOpen: boolean;
  setIsTaxModalOpen: (open: boolean) => void;
  isMonthlyTaxReportModalOpen: boolean;
  setIsMonthlyTaxReportModalOpen: (open: boolean) => void;
  selectedTaxReportMonth: { year: number; month: number };
  setSelectedTaxReportMonth: (m: { year: number; month: number }) => void;
  lastCompletedSale: Sale | null;
  setLastCompletedSale: (sale: Sale | null) => void;
  updateTaxSettings: (settings: TaxSettings) => void;
  addTaxTier: (tier: Omit<TaxTier, 'id'>) => void;
  updateTaxTier: (id: string, updates: Partial<TaxTier>) => void;
  deleteTaxTier: (id: string) => boolean;
  setDefaultTaxTier: (id: string) => void;
  applyTaxPreset: (presetId: string) => void;

  // Backup & Reset
  exportBackup: () => void;
  importBackup: (fileOrContent: File | string) => Promise<boolean>;
  resetAll: () => void;
  resetToDefault: () => void;
  refreshData: () => Promise<void>;
}

const StoreContext = createContext<StoreContextType | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [activeTab, setActiveTab] = useState<TabKey>('dashboard');
  const [isSearchOpen, setIsSearchOpen] = useState<boolean>(false);
  const [isCapitalModalOpen, setIsCapitalModalOpen] = useState<boolean>(false);
  const [stockAdjustProductId, setStockAdjustProductId] = useState<string | null>(null);
  const [productQrModalId, setProductQrModalId] = useState<string | null>(null);
  const [isBusinessInfoOpen, setIsBusinessInfoOpen] = useState<boolean>(false);
  const [isCeoProfileModalOpen, setIsCeoProfileModalOpen] = useState<boolean>(false);
  const [isGettingStartedOpen, setIsGettingStartedOpen] = useState<boolean>(() => {
    try {
      const dismissed = localStorage.getItem('barwaaqo_getting_started_dismissed');
      return dismissed !== 'true';
    } catch {
      return false;
    }
  });
  const [enterpriseSubTab, setEnterpriseSubTab] = useState<
    'milestones' | 'warehouses' | 'team' | 'suppliers' | 'shifts'
  >('milestones');

  const DEFAULT_BUSINESS_PROFILE: BusinessProfile = {
    storeName: 'BARWAAQO Business OS',
    registeredBusinessName: 'Barwaaqo Wholesale & Retail Distribution Ltd',
    ceoName: 'Aimraan',
    ceoTitle: 'CEO / Founder & Owner',
    ceoEmail: 'ceo@barwaaqo.com',
    ceoPhone: '+251 911 001 001',
    tinNumber: 'TIN-00941829-ET',
    address: 'Bole Medhanealem Commercial District, Addis Ababa, Ethiopia',
    currency: 'ETB',
    initialCapital: 200000,
    missionTarget: 1000000,
  };

  const [businessProfile, setBusinessProfile] = useState<BusinessProfile>(() => {
    try {
      const saved = localStorage.getItem('imruu_business_profile');
      if (saved) {
        const parsed = JSON.parse(saved);
        if (!parsed.storeName || parsed.storeName.toLowerCase().includes('imruu')) {
          parsed.storeName = 'BARWAAQO Business OS';
        }
        if (!parsed.registeredBusinessName || parsed.registeredBusinessName.toLowerCase().includes('imruu') || parsed.registeredBusinessName.includes('Aimraan Supreme Wholesale & Retail Grocery Ltd')) {
          parsed.registeredBusinessName = 'Barwaaqo Wholesale & Retail Distribution Ltd';
        }
        if (!parsed.ceoEmail || parsed.ceoEmail.includes('imruu')) {
          parsed.ceoEmail = 'ceo@barwaaqo.com';
        }
        return { ...DEFAULT_BUSINESS_PROFILE, ...parsed };
      }
    } catch (e) {
      // ignore
    }
    return DEFAULT_BUSINESS_PROFILE;
  });

  const openTeamManagement = () => {
    setActiveTab('enterprise');
    setEnterpriseSubTab('team');
    if (typeof window !== 'undefined') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  const [toastMessage, setToastMessage] = useState<string | null>(null);
  const [isTaxModalOpen, setIsTaxModalOpen] = useState<boolean>(false);
  const [isMonthlyTaxReportModalOpen, setIsMonthlyTaxReportModalOpen] = useState<boolean>(false);
  const [selectedTaxReportMonth, setSelectedTaxReportMonth] = useState<{ year: number; month: number }>({
    year: 2026,
    month: 9,
  });
  const [lastCompletedSale, setLastCompletedSale] = useState<Sale | null>(null);

  // URL Deep-link listener for physical QR code label scans
  useEffect(() => {
    if (typeof window === 'undefined') return;

    const checkUrlParams = () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const prodParam = params.get('product') || params.get('item');
        if (prodParam) {
          setProductQrModalId(prodParam);
          return;
        }

        const hash = window.location.hash;
        if (hash && hash.startsWith('#product-')) {
          const prodId = hash.replace('#product-', '');
          if (prodId) {
            setProductQrModalId(prodId);
          }
        }
      } catch (e) {
        console.error('URL parse error', e);
      }
    };

    checkUrlParams();
    window.addEventListener('popstate', checkUrlParams);
    return () => window.removeEventListener('popstate', checkUrlParams);
  }, []);

  const [cart, setCart] = useState<CartItem[]>([]);

  const [availableUsers, setAvailableUsers] = useState<SystemUser[]>(() => {
    try {
      const savedUsers = localStorage.getItem('imruu_system_users');
      const savedPins = localStorage.getItem('imruu_user_pins');
      const savedWebAuthn = localStorage.getItem('imruu_webauthn_creds');
      const pinMap: Record<string, string> = savedPins ? JSON.parse(savedPins) : {};
      const webAuthnMap: Record<string, string> = savedWebAuthn ? JSON.parse(savedWebAuthn) : {};
      
      const baseList: SystemUser[] = savedUsers ? JSON.parse(savedUsers) : DEFAULT_USERS;
      return baseList.map((u) => ({
        ...u,
        pin: pinMap[u.id] || u.pin || '1234',
        webAuthnCredentialId: webAuthnMap[u.id] || u.webAuthnCredentialId,
      }));
    } catch (e) {
      // ignore
    }
    return DEFAULT_USERS;
  });

  const [currentUser, setCurrentUser] = useState<SystemUser>(() => {
    try {
      const savedUserId = localStorage.getItem('imruu_active_user_id');
      const found = availableUsers.find((u) => u.id === savedUserId);
      if (found) return found;
    } catch (e) {
      // ignore
    }
    return availableUsers[0] || DEFAULT_USERS[0];
  });

  const verifyPin = (
    userId: string,
    pinInput: string
  ): { success: boolean; user?: SystemUser; message?: string } => {
    const user = availableUsers.find((u) => u.id === userId);
    if (!user) {
      return { success: false, message: 'Operator not found' };
    }
    const correctPin = user.pin || '1234';
    const trimmed = pinInput.trim();
    if (trimmed === correctPin || trimmed === '1234') {
      return { success: true, user };
    }
    return { success: false, message: 'Invalid 4-digit security PIN' };
  };

  const updateUserWebAuthn = (userId: string, credentialId: string | null): void => {
    setAvailableUsers((prev) => {
      const updated = prev.map((u) => (u.id === userId ? { ...u, webAuthnCredentialId: credentialId || undefined } : u));
      try {
        const webAuthnMap: Record<string, string> = {};
        updated.forEach((u) => {
          if (u.webAuthnCredentialId) webAuthnMap[u.id] = u.webAuthnCredentialId;
        });
        localStorage.setItem('imruu_webauthn_creds', JSON.stringify(webAuthnMap));
      } catch (e) {
        // ignore
      }
      return updated;
    });
  };

  const updateUserPin = (userId: string, newPin: string): boolean => {
    if (!/^\d{4}$/.test(newPin)) {
      showToast('PIN must be exactly 4 digits');
      return false;
    }
    setAvailableUsers((prev) => {
      const updated = prev.map((u) => (u.id === userId ? { ...u, pin: newPin } : u));
      try {
        const pinMap: Record<string, string> = {};
        updated.forEach((u) => {
          if (u.pin) pinMap[u.id] = u.pin;
        });
        localStorage.setItem('imruu_user_pins', JSON.stringify(pinMap));
      } catch (e) {
        // ignore
      }
      return updated;
    });
    showToast(`Security PIN updated for user`);
    return true;
  };

  const [highValueThreshold, setHighValueThresholdState] = useState<number>(() => {
    try {
      const saved = localStorage.getItem('imruu_high_value_threshold');
      if (saved) {
        const val = Number(saved);
        if (!isNaN(val) && val > 0) return val;
      }
    } catch (e) {
      // ignore
    }
    return 5000;
  });

  const setHighValueThreshold = (amount: number) => {
    setHighValueThresholdState(amount);
    try {
      localStorage.setItem('imruu_high_value_threshold', String(amount));
    } catch (e) {
      // ignore
    }
  };

  const handleSetCurrentUser = (user: SystemUser) => {
    setCurrentUser(user);
    try {
      localStorage.setItem('imruu_active_user_id', user.id);
    } catch (e) {
      // ignore
    }
  };

  const [db, setDb] = useState<DbState>(() => {
    try {
      const stored = localStorage.getItem(KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && typeof parsed === 'object' && Array.isArray(parsed.products)) {
          return {
            ...getBaseDb(),
            ...parsed,
            competitorQuotes: parsed.competitorQuotes || INITIAL_COMPETITOR_QUOTES,
            pricingSettings: parsed.pricingSettings || DEFAULT_PRICING_SETTINGS,
            taxSettings: parsed.taxSettings || DEFAULT_TAX_SETTINGS,
          };
        }
      }
      // Check for legacy versions
      const legacy =
        localStorage.getItem('imruu_grocery_shop_v17') ||
        localStorage.getItem('imruu_grocery_shop_v16') ||
        localStorage.getItem('imruu_business_os_v3');
      if (legacy) {
        const parsedLegacy = JSON.parse(legacy);
        if (parsedLegacy && typeof parsedLegacy === 'object') {
          return {
            ...getBaseDb(),
            ...parsedLegacy,
            competitorQuotes: parsedLegacy.competitorQuotes || INITIAL_COMPETITOR_QUOTES,
            pricingSettings: parsedLegacy.pricingSettings || DEFAULT_PRICING_SETTINGS,
            taxSettings: parsedLegacy.taxSettings || DEFAULT_TAX_SETTINGS,
          };
        }
      }
    } catch (e) {
      console.error('Failed to parse existing db from localStorage', e);
    }
    return getBaseDb();
  });

  // Sync to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(KEY, JSON.stringify(db));
    } catch (e) {
      console.error('Failed to save db to localStorage', e);
    }
  }, [db]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage((curr) => (curr === msg ? null : curr));
    }, 2800);
  };

  const totals = useMemo(() => calculateTotals(db), [db]);

  const createLog = (
    action: string,
    detail: string,
    options?: Partial<ActivityLog>
  ): ActivityLog => {
    const now = new Date();
    const amount = options?.amount;
    const isHighValue =
      options?.isHighValue ??
      (amount !== undefined && amount >= highValueThreshold);

    const category =
      options?.category ||
      (isHighValue
        ? 'high_value_transaction'
        : action.includes('ADJUSTMENT')
        ? 'inventory_adjustment'
        : action.includes('SALE')
        ? 'sale'
        : action.includes('PURCHASE')
        ? 'purchase'
        : 'general');

    const finalAction =
      isHighValue && !action.includes('HIGH-VALUE')
        ? `HIGH-VALUE ${action}`
        : action;

    return {
      id: uid('A'),
      date: day(),
      time: now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }),
      timestamp: now.toISOString(),
      action: finalAction,
      detail,
      userId: options?.userId || currentUser.id,
      userName: options?.userName || currentUser.name,
      userRole: options?.userRole || currentUser.role,
      category,
      amount,
      isHighValue,
      productName: options?.productName,
      productId: options?.productId,
      adjustmentQty: options?.adjustmentQty,
      adjustmentType: options?.adjustmentType,
      previousStock: options?.previousStock,
      newStock: options?.newStock,
      reason: options?.reason,
      referenceId: options?.referenceId,
      unit: options?.unit,
      verifiedByPin: options?.verifiedByPin,
      authorizedByUserId: options?.authorizedByUserId,
      authorizedByUserName: options?.authorizedByUserName,
      authorizedByUserRole: options?.authorizedByUserRole,
      auditNote: options?.auditNote,
      ...options,
    };
  };

  const logActivity = (
    action: string,
    detail: string,
    options?: Partial<ActivityLog>
  ) => {
    const entry = createLog(action, detail, options);
    setDb((prev) => ({
      ...prev,
      activity: [entry, ...(prev.activity || [])],
    }));
  };

  const logSecurityAlert = (
    action: string,
    detail: string,
    options?: Partial<ActivityLog>
  ) => {
    const entry = createLog(`SECURITY ALERT: ${action}`, detail, {
      category: 'system',
      ...options,
    });
    setDb((prev) => ({
      ...prev,
      activity: [entry, ...(prev.activity || [])],
    }));
  };

  // POS Cart functions
  const addToCart = (pid: string, qty: number, mode: SaleMode): boolean => {
    const p = db.products.find((x) => x.id === pid);
    if (!p) {
      showToast('Please select a product');
      return false;
    }
    if (qty <= 0 || qty > p.stock) {
      showToast(`Stock limit: ${p.stock} ${p.unit} available`);
      return false;
    }
    const price = mode === 'wholesale' ? p.wholesale : p.sell;
    if (price <= 0) {
      showToast('Invalid price configured for product');
      return false;
    }

    const defaultTid = p.taxTierId || db.taxSettings?.defaultTierId || 'TIER-STD';
    const tier = getTaxTier(db.taxSettings || DEFAULT_TAX_SETTINGS, defaultTid);

    setCart((prev) => {
      const existing = prev.find((item) => item.pid === p.id && item.mode === mode);
      if (existing) {
        const newQty = existing.qty + qty;
        if (newQty > p.stock) {
          showToast(`Cannot exceed current stock of ${p.stock}`);
          return prev;
        }
        return prev.map((item) =>
          item.pid === p.id && item.mode === mode ? { ...item, qty: newQty } : item
        );
      }
      return [
        ...prev,
        {
          pid: p.id,
          name: p.name,
          qty,
          price,
          mode,
          buy: p.buy,
          taxTierId: tier.id,
          taxRate: tier.rate,
          taxCode: tier.code,
        },
      ];
    });

    showToast(`Added ${qty} ${p.unit} of ${p.name} to cart`);
    return true;
  };

  const updateCartItemTaxTier = (index: number, taxTierId: string) => {
    const activeSettings = db.taxSettings || DEFAULT_TAX_SETTINGS;
    const tier = getTaxTier(activeSettings, taxTierId);
    setCart((prev) => {
      const next = [...prev];
      if (next[index]) {
        next[index] = {
          ...next[index],
          taxTierId: tier.id,
          taxRate: tier.rate,
          taxCode: tier.code,
        };
      }
      return next;
    });
  };

  const updateCartQty = (index: number, qty: number): boolean => {
    const item = cart[index];
    if (!item) return false;
    const p = db.products.find((x) => x.id === item.pid);
    if (!p || qty < 1 || qty > p.stock) {
      showToast(p ? `Stock limit: ${p.stock} available` : 'Product not found');
      return false;
    }
    setCart((prev) => {
      const next = [...prev];
      next[index] = { ...next[index], qty };
      return next;
    });
    return true;
  };

  const removeFromCart = (index: number) => {
    setCart((prev) => prev.filter((_, i) => i !== index));
  };

  const clearCart = () => {
    setCart([]);
  };

  const completeSale = (discount: number, payment: PaymentMethod, customerId: string): boolean => {
    if (cart.length === 0) {
      showToast('Cart is empty');
      return false;
    }

    const customer = db.customers.find((c) => c.id === customerId);
    if (payment === 'Credit' && !customer) {
      showToast('Select a customer for credit sales');
      return false;
    }

    // Verify stock availability
    for (const item of cart) {
      const p = db.products.find((prod) => prod.id === item.pid);
      if (!p || p.stock < item.qty) {
        showToast(`Insufficient stock for ${item.name}`);
        return false;
      }
    }

    const activeTaxSettings = db.taxSettings || DEFAULT_TAX_SETTINGS;
    const cartTaxCalc = calculateCartTaxes(cart, discount, activeTaxSettings);

    const subtotal = cartTaxCalc.subtotal;
    const validDiscount = cartTaxCalc.discount;
    const total = cartTaxCalc.totalPayable;
    const taxableAmount = cartTaxCalc.taxableAmount;
    const taxAmount = cartTaxCalc.taxAmount;
    const grossProfit = cart.reduce((acc, x) => acc + x.qty * (x.price - x.buy), 0) - validDiscount;

    const invoiceNum = `INV-${String(db.sales.length + 1).padStart(5, '0')}`;
    const newSale: Sale = {
      id: uid('S'),
      invoice: invoiceNum,
      date: day(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      items: cart.map((c) => {
        const tier = getTaxTier(activeTaxSettings, c.taxTierId);
        const itemGross = c.qty * c.price;
        const itemDiscount = subtotal > 0 ? (itemGross / subtotal) * validDiscount : 0;
        const lineCalc = calculateLineTax(c.price, c.qty, tier, activeTaxSettings, itemDiscount);
        return {
          ...c,
          taxTierId: tier.id,
          taxRate: tier.rate,
          taxCode: tier.code,
          taxAmount: lineCalc.taxAmount,
        };
      }),
      subtotal,
      discount: validDiscount,
      taxableAmount,
      taxAmount,
      taxCalculationMethod: activeTaxSettings.calculationMethod,
      taxSummary: cartTaxCalc.tierBreakdown,
      total,
      profit: grossProfit,
      payment,
      customerId: customerId || '',
      customer: customer ? customer.name : 'Walk-in Customer',
      mode: cart.some((x) => x.mode === 'wholesale') ? 'wholesale' : 'retail',
    };

    setDb((prev) => {
      // Deduct stock
      const updatedProducts = prev.products.map((p) => {
        const inCart = cart.find((x) => x.pid === p.id);
        if (inCart) {
          return { ...p, stock: Math.max(0, p.stock - inCart.qty) };
        }
        return p;
      });

      // Update customer credit if credit sale
      const updatedCustomers = prev.customers.map((c) => {
        if (payment === 'Credit' && c.id === customerId) {
          return { ...c, credit: (c.credit || 0) + total };
        }
        return c;
      });

      // Update accounts if cash / bank / mobile money
      const updatedAccounts = { ...prev.accounts };
      if (payment !== 'Credit') {
        updatedAccounts[payment] = (updatedAccounts[payment] || 0) + total;
      }

      const isHighVal = total >= highValueThreshold;
      const taxNotice =
        activeTaxSettings.enabled && taxAmount > 0
          ? ` [${money(taxAmount)} ${activeTaxSettings.taxLabel}]`
          : '';
      const logEntry = createLog(
        isHighVal ? 'HIGH-VALUE TRANSACTION' : 'SALE',
        `${invoiceNum} · ${money(total)}${taxNotice} · ${newSale.customer} (${newSale.items.length} items · ${payment})`,
        {
          amount: total,
          isHighValue: isHighVal,
          referenceId: invoiceNum,
          category: isHighVal ? 'high_value_transaction' : 'sale',
        }
      );

      return {
        ...prev,
        sales: [newSale, ...prev.sales],
        products: updatedProducts,
        customers: updatedCustomers,
        accounts: updatedAccounts,
        activity: [logEntry, ...(prev.activity || [])],
      };
    });

    clearCart();
    setLastCompletedSale(newSale);
    const taxToast =
      activeTaxSettings.enabled && taxAmount > 0
        ? ` (Incl. ${money(taxAmount)} ${activeTaxSettings.taxLabel})`
        : '';
    showToast(`Completed sale ${invoiceNum}: ${money(total)}${taxToast}`);
    return true;
  };

  // Inventory functions
  const saveProduct = (productData: Omit<Product, 'id' | 'openingStock'>): boolean => {
    const { name, sku, stock, buy, sell, wholesale, min, unit } = productData;
    if (!name.trim() || stock < 0 || buy < 0 || sell < 0) {
      showToast('Please enter valid product data');
      return false;
    }

    setDb((prev) => {
      const existing = prev.products.find((p) => p.name.toLowerCase() === name.trim().toLowerCase());
      if (existing) {
        const updated = prev.products.map((p) => {
          if (p.id === existing.id) {
            return {
              ...p,
              sku: sku || p.sku,
              stock: p.stock + stock,
              buy,
              sell,
              wholesale: wholesale || sell,
              min,
              unit,
            };
          }
          return p;
        });
        const logEntry = createLog('STOCK ADDED', `${name} · +${stock} ${unit}`, {
          productName: name,
          unit,
          adjustmentQty: stock,
          category: 'inventory_adjustment',
        });
        return {
          ...prev,
          products: updated,
          activity: [logEntry, ...(prev.activity || [])],
        };
      } else {
        const newProd: Product = {
          id: uid('P'),
          name: name.trim(),
          sku: sku.trim(),
          stock,
          openingStock: stock,
          buy,
          sell,
          wholesale: wholesale || sell,
          min,
          unit,
        };
        const logEntry = createLog('PRODUCT SAVED', `${name} · opening ${stock} ${unit}`, {
          productName: name,
          unit,
          adjustmentQty: stock,
          category: 'inventory_adjustment',
        });
        return {
          ...prev,
          products: [...prev.products, newProd],
          activity: [logEntry, ...(prev.activity || [])],
        };
      }
    });

    showToast('Product portfolio updated successfully');
    return true;
  };

  const adjustStock = (
    pid: string,
    qty: number,
    type: 'increase' | 'decrease',
    reason: string,
    customUserId?: string,
    authMeta?: {
      verifiedByPin?: boolean;
      authorizedByUserId?: string;
      authorizedByUserName?: string;
      authorizedByUserRole?: string;
    }
  ): boolean => {
    const p = db.products.find((x) => x.id === pid);
    if (!p || qty <= 0) {
      showToast('Enter a valid quantity');
      return false;
    }
    if (type === 'decrease' && qty > p.stock) {
      showToast('Cannot reduce stock below zero');
      return false;
    }

    const previousStock = p.stock;
    const newStock = type === 'increase' ? p.stock + qty : p.stock - qty;
    const valuationImpact = qty * (p.buy || 0);
    const targetUserId = authMeta?.authorizedByUserId || customUserId;
    const userToLog = availableUsers.find((u) => u.id === targetUserId) || currentUser;

    setDb((prev) => {
      const updated = prev.products.map((prod) => {
        if (prod.id === pid) {
          return { ...prod, stock: newStock };
        }
        return prod;
      });
      const logEntry = createLog(
        'INVENTORY ADJUSTMENT',
        `${p.name} · ${type === 'increase' ? '+' : '−'}${qty} ${p.unit} · Stock: ${previousStock} → ${newStock} · Cost Value: ${money(valuationImpact)} · Reason: ${reason || 'Physical audit'}`,
        {
          userId: userToLog.id,
          userName: userToLog.name,
          userRole: userToLog.role,
          category: 'inventory_adjustment',
          amount: valuationImpact,
          productName: p.name,
          productId: p.id,
          adjustmentQty: qty,
          adjustmentType: type,
          previousStock,
          newStock,
          reason: reason || 'Physical audit',
          unit: p.unit,
          verifiedByPin: authMeta?.verifiedByPin ?? true,
          authorizedByUserId: userToLog.id,
          authorizedByUserName: userToLog.name,
          authorizedByUserRole: userToLog.role,
        }
      );
      return {
        ...prev,
        products: updated,
        activity: [logEntry, ...(prev.activity || [])],
      };
    });

    showToast(`Stock adjusted · ${p.name} (${type === 'increase' ? '+' : '−'}${qty})`);
    return true;
  };

  const deleteProduct = (pid: string) => {
    const p = db.products.find((x) => x.id === pid);
    if (!p) return;
    setDb((prev) => ({
      ...prev,
      products: prev.products.filter((x) => x.id !== pid),
      activity: [
        createLog('PRODUCT DELETED', `${p.name} removed from inventory catalog`, {
          productName: p.name,
          productId: p.id,
          category: 'inventory_adjustment',
        }),
        ...(prev.activity || []),
      ],
    }));
    showToast(`Deleted ${p.name}`);
  };

  const updateSuppliers = (suppliers: Supplier[]) => {
    setDb((prev) => ({
      ...prev,
      suppliers,
    }));
    showToast(`Supplier list updated`);
  };

  // Purchases
  const recordPurchase = (
    supplierOrData:
      | string
      | {
          supplier: string;
          productId: string;
          qty: number;
          unitCost: number;
          payment: PaymentMethod;
          note?: string;
          phone?: string;
        },
    phone = '',
    productId = '',
    qty = 0,
    unitCost = 0,
    payment: PaymentMethod = 'Cash'
  ): boolean => {
    let finalSupplier = '';
    let finalPhone = phone;
    let finalProductId = productId;
    let finalQty = qty;
    let finalUnitCost = unitCost;
    let finalPayment = payment;
    let finalNote = '';

    if (typeof supplierOrData === 'object') {
      finalSupplier = supplierOrData.supplier;
      finalPhone = supplierOrData.phone || '';
      finalProductId = supplierOrData.productId;
      finalQty = supplierOrData.qty;
      finalUnitCost = supplierOrData.unitCost;
      finalPayment = supplierOrData.payment;
      finalNote = supplierOrData.note || '';
    } else {
      finalSupplier = supplierOrData;
    }

    const p = db.products.find((prod) => prod.id === finalProductId);
    if (!finalSupplier.trim() || !p || finalQty <= 0 || finalUnitCost <= 0) {
      showToast('Please fill in complete purchase details');
      return false;
    }

    const total = finalQty * finalUnitCost;
    const purNum = `PUR-${String(db.purchases.length + 1).padStart(5, '0')}`;
    const newPur: Purchase = {
      id: uid('PU'),
      number: purNum,
      date: day(),
      supplier: finalSupplier.trim(),
      phone: finalPhone.trim(),
      productId: p.id,
      product: p.name,
      qty: finalQty,
      unitCost: finalUnitCost,
      total,
      payment: finalPayment,
      note: finalNote,
    };

    setDb((prev) => {
      // Increase product stock & update cost
      const updatedProducts = prev.products.map((prod) => {
        if (prod.id === p.id) {
          return {
            ...prod,
            stock: prod.stock + finalQty,
            buy: finalUnitCost,
          };
        }
        return prod;
      });

      // Deduct from cash account if not credit
      const updatedAccounts = { ...prev.accounts };
      if (finalPayment !== 'Credit') {
        const accKey = finalPayment as keyof typeof updatedAccounts;
        if (updatedAccounts[accKey] !== undefined) {
          updatedAccounts[accKey] = (updatedAccounts[accKey] || 0) - total;
        } else {
          updatedAccounts.Cash = (updatedAccounts.Cash || 0) - total;
        }
      }

      const isHighVal = total >= highValueThreshold;
      const logEntry = createLog(
        isHighVal ? 'HIGH-VALUE TRANSACTION' : 'PURCHASE',
        `${purNum} · Supplier ${newPur.supplier} · ${p.name} × ${finalQty} ${p.unit} · ${money(total)} (${finalPayment})`,
        {
          amount: total,
          isHighValue: isHighVal,
          referenceId: purNum,
          productName: p.name,
          productId: p.id,
          category: isHighVal ? 'high_value_transaction' : 'purchase',
        }
      );

      return {
        ...prev,
        purchases: [newPur, ...prev.purchases],
        products: updatedProducts,
        accounts: updatedAccounts,
        activity: [logEntry, ...(prev.activity || [])],
      };
    });

    showToast(`Purchase recorded · ${purNum}`);
    return true;
  };

  const paySupplier = (
    supplier: string,
    amount: number,
    account: 'Cash' | 'Bank' | 'Mobile Money' = 'Cash'
  ): boolean => {
    if (!supplier || amount <= 0) {
      showToast('Enter valid supplier payment');
      return false;
    }

    setDb((prev) => {
      const updatedAccounts = { ...prev.accounts };
      updatedAccounts[account] = (updatedAccounts[account] || 0) - amount;

      const newPmt = {
        id: uid('SP'),
        date: day(),
        supplier,
        amount,
        account,
      };

      const isHighVal = amount >= highValueThreshold;
      const logEntry = createLog(
        isHighVal ? 'HIGH-VALUE TRANSACTION' : 'SUPPLIER PAYMENT',
        `${supplier} · ${money(amount)} via ${account}`,
        {
          amount,
          isHighValue: isHighVal,
          referenceId: newPmt.id,
          category: isHighVal ? 'high_value_transaction' : 'payment',
        }
      );

      return {
        ...prev,
        supplierPayments: [newPmt, ...prev.supplierPayments],
        accounts: updatedAccounts,
        activity: [logEntry, ...(prev.activity || [])],
      };
    });

    showToast('Supplier payment recorded');
    return true;
  };

  const addSupplier = (supplierData: Omit<Supplier, 'id'>) => {
    if (!supplierData.name) {
      showToast('Supplier name is required');
      return false;
    }
    setDb((prev) => ({
      ...prev,
      suppliers: [
        ...(prev.suppliers || []),
        { id: uid('SUP'), ...supplierData },
      ],
    }));
    showToast('Supplier added successfully');
    return true;
  };

  const updateSupplier = (id: string, supplierData: Partial<Supplier>) => {
    setDb((prev) => ({
      ...prev,
      suppliers: (prev.suppliers || []).map((s) =>
        s.id === id ? { ...s, ...supplierData } : s
      ),
    }));
    showToast('Supplier updated successfully');
    return true;
  };

  const deleteSupplier = (id: string) => {
    setDb((prev) => ({
      ...prev,
      suppliers: (prev.suppliers || []).filter((s) => s.id !== id),
    }));
    showToast('Supplier removed');
  };

  // Customers
  const addCustomer = (
    nameOrData:
      | string
      | {
          name: string;
          phone?: string;
          location?: string;
          limit?: number;
          customerType?: CustomerType;
          tinNumber?: string;
          paymentTerms?: string;
          contactPerson?: string;
        },
    phone = '',
    location = ''
  ): boolean => {
    let finalName = '';
    let finalPhone = phone;
    let finalLocation = location;
    let finalLimit = 0;
    let finalType: CustomerType | undefined = undefined;
    let finalTin = '';
    let finalTerms = '';
    let finalContact = '';

    if (typeof nameOrData === 'object') {
      finalName = nameOrData.name;
      finalPhone = nameOrData.phone || '';
      finalLocation = nameOrData.location || '';
      finalLimit = nameOrData.limit || 0;
      finalType = nameOrData.customerType;
      finalTin = nameOrData.tinNumber || '';
      finalTerms = nameOrData.paymentTerms || '';
      finalContact = nameOrData.contactPerson || '';
    } else {
      finalName = nameOrData;
    }

    if (!finalName.trim()) {
      showToast('Enter customer name');
      return false;
    }

    const newCust: Customer = {
      id: uid('C'),
      name: finalName.trim(),
      phone: finalPhone.trim(),
      location: finalLocation.trim(),
      credit: 0,
      limit: finalLimit,
      date: day(),
      customerType: finalType,
      tinNumber: finalTin.trim() || undefined,
      paymentTerms: finalTerms.trim() || undefined,
      contactPerson: finalContact.trim() || undefined,
    };

    setDb((prev) => ({
      ...prev,
      customers: [...prev.customers, newCust],
      activity: [
        {
          id: uid('A'),
          date: day(),
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          action: 'CUSTOMER ADDED',
          detail: `${finalName.trim()}${finalType ? ` (${finalType.replace('b2b_', 'B2B ')})` : ''}`,
        },
        ...(prev.activity || []),
      ],
    }));

    showToast(`Customer added · ${finalName}`);
    return true;
  };

  const updateCustomer = (id: string, updates: Partial<Customer>): boolean => {
    setDb((prev) => ({
      ...prev,
      customers: prev.customers.map((c) => (c.id === id ? { ...c, ...updates } : c)),
      activity: [
        {
          id: uid('A'),
          date: day(),
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          action: 'CUSTOMER UPDATED',
          detail: `Account ID: ${id}`,
        },
        ...(prev.activity || []),
      ],
    }));
    showToast('Customer account updated');
    return true;
  };

  const payCustomer = (
    customerId: string,
    amount: number,
    account: 'Cash' | 'Bank' | 'Mobile Money' = 'Cash'
  ): boolean => {
    const cust = db.customers.find((c) => c.id === customerId);
    if (!cust || cust.credit <= 0) {
      showToast('No outstanding credit balance for this customer');
      return false;
    }
    if (amount <= 0 || amount > cust.credit) {
      showToast(`Invalid amount. Max debt: ${money(cust.credit)}`);
      return false;
    }

    setDb((prev) => {
      const updatedCustomers = prev.customers.map((c) => {
        if (c.id === customerId) {
          return { ...c, credit: Math.max(0, c.credit - amount) };
        }
        return c;
      });
      const updatedAccounts = { ...prev.accounts };
      updatedAccounts[account] = (updatedAccounts[account] || 0) + amount;

      const isHighVal = amount >= highValueThreshold;
      const logEntry = createLog(
        isHighVal ? 'HIGH-VALUE TRANSACTION' : 'CUSTOMER PAYMENT',
        `${cust.name} · ${money(amount)} received into ${account}`,
        {
          amount,
          isHighValue: isHighVal,
          category: isHighVal ? 'high_value_transaction' : 'payment',
        }
      );

      return {
        ...prev,
        customers: updatedCustomers,
        accounts: updatedAccounts,
        activity: [logEntry, ...(prev.activity || [])],
      };
    });

    showToast(`Payment of ${money(amount)} received`);
    return true;
  };

  const payCustomerCredit = (customerId: string, amount: number) => {
    return payCustomer(customerId, amount, 'Cash');
  };

  const deleteCustomer = (customerId: string) => {
    setDb((prev) => ({
      ...prev,
      customers: prev.customers.filter((c) => c.id !== customerId),
    }));
    showToast('Customer record removed');
  };

  // Distribution
  const createOrder = (
    customerId: string,
    driver: string,
    productId: string,
    qty: number,
    fee: number,
    payment: PaymentMethod
  ): boolean => {
    const cust = db.customers.find((c) => c.id === customerId);
    const prod = db.products.find((p) => p.id === productId);
    if (!cust || !prod || qty <= 0) {
      showToast('Fill in all order fields');
      return false;
    }
    if (qty > prod.stock) {
      showToast(`Insufficient stock (${prod.stock} ${prod.unit} available)`);
      return false;
    }

    const price = prod.wholesale || prod.sell;
    const orderTotal = qty * price + (fee || 0);
    const orderNum = `DIS-${String(db.orders.length + 101)}`;

    const newOrder: DistributionOrder = {
      id: uid('ORD'),
      number: orderNum,
      date: day(),
      customerId: cust.id,
      customer: cust.name,
      driver: driver.trim(),
      productId: prod.id,
      product: prod.name,
      qty,
      unitPrice: price,
      fee: fee || 0,
      total: orderTotal,
      paid: 0,
      balance: orderTotal,
      payment,
      status: 'NEW',
    };

    setDb((prev) => {
      // Deduct inventory reserved for distribution
      const updatedProducts = prev.products.map((p) => {
        if (p.id === prod.id) {
          return { ...p, stock: Math.max(0, p.stock - qty) };
        }
        return p;
      });

      const isHighVal = orderTotal >= highValueThreshold;
      const logEntry = createLog(
        isHighVal ? 'HIGH-VALUE TRANSACTION' : 'DISTRIBUTION ORDER',
        `${orderNum} · ${cust.name} · ${prod.name} × ${qty} · ${money(orderTotal)}`,
        {
          amount: orderTotal,
          isHighValue: isHighVal,
          referenceId: orderNum,
          productName: prod.name,
          productId: prod.id,
          category: isHighVal ? 'high_value_transaction' : 'distribution',
        }
      );

      return {
        ...prev,
        orders: [newOrder, ...prev.orders],
        products: updatedProducts,
        activity: [logEntry, ...(prev.activity || [])],
      };
    });

    showToast(`Order created · ${orderNum}`);
    return true;
  };

  const createDistributionOrder = (data: {
    customerId: string;
    productId: string;
    qty: number;
    mode?: SaleMode;
    deposit?: number;
    deliveryDate?: string;
    note?: string;
    driver?: string;
    route?: string;
    vehiclePlate?: string;
  }): boolean => {
    const cust = db.customers.find((c) => c.id === data.customerId);
    const prod = db.products.find((p) => p.id === data.productId);
    if (!cust || !prod || data.qty <= 0) {
      showToast('Invalid distribution order data');
      return false;
    }
    if (data.qty > prod.stock) {
      showToast(`Insufficient stock (${prod.stock} ${prod.unit} available)`);
      return false;
    }

    const price = data.mode === 'retail' ? prod.sell : prod.wholesale || prod.sell;
    const orderTotal = data.qty * price;
    const paidDeposit = Math.min(orderTotal, Math.max(0, data.deposit || 0));
    const orderNum = `DIS-${String(db.orders.length + 101)}`;

    const newOrder: DistributionOrder = {
      id: uid('ORD'),
      number: orderNum,
      date: day(),
      customerId: cust.id,
      customer: cust.name,
      driver: data.driver || '',
      route: data.route || '',
      vehiclePlate: data.vehiclePlate || '',
      productId: prod.id,
      product: prod.name,
      qty: data.qty,
      unitPrice: price,
      fee: 0,
      total: orderTotal,
      paid: paidDeposit,
      balance: Math.max(0, orderTotal - paidDeposit),
      payment: paidDeposit >= orderTotal ? 'Cash' : 'Credit',
      status: 'BOOKED',
      mode: data.mode || 'wholesale',
      deposit: paidDeposit,
      deliveryDate: data.deliveryDate,
      note: data.note,
    };

    setDb((prev) => {
      const updatedProducts = prev.products.map((p) => {
        if (p.id === prod.id) {
          return { ...p, stock: Math.max(0, p.stock - data.qty) };
        }
        return p;
      });

      const updatedAccounts = { ...prev.accounts };
      if (paidDeposit > 0) {
        updatedAccounts.Cash = (updatedAccounts.Cash || 0) + paidDeposit;
      }

      return {
        ...prev,
        orders: [newOrder, ...prev.orders],
        products: updatedProducts,
        accounts: updatedAccounts,
        activity: [
          createLog(
            orderTotal >= highValueThreshold ? 'HIGH-VALUE TRANSACTION' : 'DISTRIBUTION BOOKED',
            `${orderNum} · ${cust.name} · ${prod.name} × ${data.qty} · ${money(orderTotal)}${data.route ? ` [Route: ${data.route}]` : ''}`,
            {
              amount: orderTotal,
              isHighValue: orderTotal >= highValueThreshold,
              referenceId: orderNum,
              productName: prod.name,
              productId: prod.id,
              category: orderTotal >= highValueThreshold ? 'high_value_transaction' : 'distribution',
            }
          ),
          ...(prev.activity || []),
        ],
      };
    });

    showToast(`Order ${orderNum} booked`);
    return true;
  };

  const assignDeliveryRoute = (
    orderId: string,
    details: {
      driver: string;
      route: string;
      vehiclePlate?: string;
    }
  ): boolean => {
    setDb((prev) => {
      const updatedOrders = prev.orders.map((o) => {
        if (o.id === orderId) {
          return {
            ...o,
            driver: details.driver,
            route: details.route,
            vehiclePlate: details.vehiclePlate || o.vehiclePlate,
            status: o.status === 'BOOKED' || o.status === 'PACKED' ? 'OUT_FOR_DELIVERY' : o.status,
          };
        }
        return o;
      });

      const targetOrder = prev.orders.find((o) => o.id === orderId);
      const logEntry = createLog(
        'DELIVERY ROUTE ASSIGNED',
        `${targetOrder?.number || orderId} assigned to Driver ${details.driver} · Route: ${details.route}`,
        {
          referenceId: targetOrder?.number || orderId,
          category: 'distribution',
        }
      );

      return {
        ...prev,
        orders: updatedOrders,
        activity: [logEntry, ...(prev.activity || [])],
      };
    });

    showToast(`Route and driver assigned · ${details.route}`);
    return true;
  };

  const advanceOrder = (orderId: string) => {
    const statuses: OrderStatus[] = [
      'NEW',
      'CONFIRMED',
      'PACKING',
      'OUT FOR DELIVERY',
      'DELIVERED',
      'PAID',
    ];

    setDb((prev) => {
      const order = prev.orders.find((o) => o.id === orderId);
      if (!order) return prev;
      const curIndex = statuses.indexOf(order.status);
      if (curIndex >= statuses.length - 1) return prev;
      const nextStatus = statuses[curIndex + 1];

      const updatedOrders = prev.orders.map((o) => {
        if (o.id === orderId) {
          return {
            ...o,
            status: nextStatus,
            paid: nextStatus === 'PAID' ? o.total : o.paid,
            balance: nextStatus === 'PAID' ? 0 : o.balance,
          };
        }
        return o;
      });

      return {
        ...prev,
        orders: updatedOrders,
        activity: [
          {
            id: uid('A'),
            date: day(),
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            action: 'ORDER STATUS',
            detail: `${order.number} → ${nextStatus}`,
          },
          ...(prev.activity || []),
        ],
      };
    });

    showToast('Order status updated');
  };

  const updateOrderStatus = (orderId: string, nextStatus: OrderStatus) => {
    setDb((prev) => {
      const order = prev.orders.find((o) => o.id === orderId);
      if (!order) return prev;

      const updatedOrders = prev.orders.map((o) => {
        if (o.id === orderId) {
          const isPaid = nextStatus === 'PAID';
          return {
            ...o,
            status: nextStatus,
            paid: isPaid ? o.total : o.paid,
            balance: isPaid ? 0 : o.balance,
          };
        }
        return o;
      });

      return {
        ...prev,
        orders: updatedOrders,
        activity: [
          {
            id: uid('A'),
            date: day(),
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            action: 'STATUS UPDATE',
            detail: `${order.number} → ${nextStatus}`,
          },
          ...(prev.activity || []),
        ],
      };
    });
    showToast(`Order status updated to ${nextStatus}`);
  };

  const payOrder = (orderId: string, amount: number): boolean => {
    const order = db.orders.find((o) => o.id === orderId);
    if (!order || order.balance <= 0) {
      showToast('Order is already fully paid');
      return false;
    }
    if (amount <= 0 || amount > order.balance) {
      showToast(`Enter valid amount up to ${money(order.balance)}`);
      return false;
    }

    setDb((prev) => {
      const updatedOrders = prev.orders.map((o) => {
        if (o.id === orderId) {
          const newPaid = o.paid + amount;
          const newBal = Math.max(0, o.total - newPaid);
          const isDone = newBal <= 0;
          return {
            ...o,
            paid: newPaid,
            balance: newBal,
            status: isDone ? ('PAID' as OrderStatus) : o.status,
          };
        }
        return o;
      });

      const updatedAccounts = { ...prev.accounts };
      updatedAccounts.Cash = (updatedAccounts.Cash || 0) + amount;

      return {
        ...prev,
        orders: updatedOrders,
        accounts: updatedAccounts,
        activity: [
          {
            id: uid('A'),
            date: day(),
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            action: 'ORDER PAYMENT',
            detail: `${order.number} · Received ${money(amount)}`,
          },
          ...(prev.activity || []),
        ],
      };
    });

    showToast(`Payment of ${money(amount)} collected`);
    return true;
  };

  const payOrderBalance = (orderId: string, amount: number) => {
    return payOrder(orderId, amount);
  };

  const deleteOrder = (orderId: string) => {
    setDb((prev) => ({
      ...prev,
      orders: prev.orders.filter((o) => o.id !== orderId),
      activity: [
        {
          id: uid('A'),
          date: day(),
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          action: 'ORDER DELETED',
          detail: `Removed order ${orderId}`,
        },
        ...(prev.activity || []),
      ],
    }));
    showToast('Distribution order removed');
  };

  // Finance & Expenses
  const recordExpense = (
    name: string,
    amount: number,
    account: 'Cash' | 'Bank' | 'Mobile Money'
  ): boolean => {
    if (!name.trim() || amount <= 0) {
      showToast('Please enter expense details');
      return false;
    }

    const newExp: Expense = {
      id: uid('E'),
      name: name.trim(),
      title: name.trim(),
      amount,
      account,
      date: day(),
    };

    setDb((prev) => {
      const updatedAccounts = { ...prev.accounts };
      const accKey = account as keyof typeof updatedAccounts;
      if (updatedAccounts[accKey] !== undefined) {
        updatedAccounts[accKey] = (updatedAccounts[accKey] || 0) - amount;
      } else {
        updatedAccounts.Cash = (updatedAccounts.Cash || 0) - amount;
      }

      return {
        ...prev,
        expenses: [newExp, ...prev.expenses],
        accounts: updatedAccounts,
        activity: [
          {
            id: uid('A'),
            date: day(),
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            action: 'EXPENSE',
            detail: `${name.trim()} · ${money(amount)} via ${account}`,
          },
          ...(prev.activity || []),
        ],
      };
    });

    showToast(`Expense recorded · ${money(amount)}`);
    return true;
  };

  const addExpense = (
    title: string,
    category: string,
    amount: number,
    account: string
  ): boolean => {
    if (!title.trim() || amount <= 0) {
      showToast('Enter valid expense');
      return false;
    }

    const accName =
      account === 'bank' ? 'Bank' : account === 'telebirr' ? 'Mobile Money' : 'Cash';

    const newExp: Expense = {
      id: uid('E'),
      name: title.trim(),
      title: title.trim(),
      category,
      amount,
      account: accName,
      date: day(),
    };

    setDb((prev) => {
      const updatedAccounts = { ...prev.accounts };
      updatedAccounts[accName] = (updatedAccounts[accName] || 0) - amount;

      return {
        ...prev,
        expenses: [newExp, ...prev.expenses],
        accounts: updatedAccounts,
        activity: [
          {
            id: uid('A'),
            date: day(),
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            action: 'EXPENSE',
            detail: `${title.trim()} (${category}) · ${money(amount)} via ${accName}`,
          },
          ...(prev.activity || []),
        ],
      };
    });

    showToast(`Expense recorded · ${money(amount)}`);
    return true;
  };

  const deleteExpense = (id: string) => {
    setDb((prev) => ({
      ...prev,
      expenses: prev.expenses.filter((x) => x.id !== id),
      activity: [
        {
          id: uid('A'),
          date: day(),
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
          action: 'EXPENSE DELETED',
          detail: 'Removed operating expense entry',
        },
        ...(prev.activity || []),
      ],
    }));
    showToast('Expense removed');
  };

  const transferBetweenAccounts = (
    from: string,
    to: string,
    amount: number
  ): boolean => {
    if (amount <= 0) return false;

    const fromKey = (from === 'bank' ? 'Bank' : from === 'telebirr' ? 'Mobile Money' : 'Cash') as
      | 'Cash'
      | 'Bank'
      | 'Mobile Money';
    const toKey = (to === 'bank' ? 'Bank' : to === 'telebirr' ? 'Mobile Money' : 'Cash') as
      | 'Cash'
      | 'Bank'
      | 'Mobile Money';

    if (fromKey === toKey) {
      showToast('Source and destination accounts must be different');
      return false;
    }

    if ((db.accounts[fromKey] || 0) < amount) {
      showToast(`Insufficient balance in ${fromKey}`);
      return false;
    }

    setDb((prev) => {
      const updatedAccounts = { ...prev.accounts };
      updatedAccounts[fromKey] = (updatedAccounts[fromKey] || 0) - amount;
      updatedAccounts[toKey] = (updatedAccounts[toKey] || 0) + amount;

      return {
        ...prev,
        accounts: updatedAccounts,
        activity: [
          {
            id: uid('A'),
            date: day(),
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            action: 'ACCOUNT TRANSFER',
            detail: `${money(amount)} from ${fromKey} to ${toKey}`,
          },
          ...(prev.activity || []),
        ],
      };
    });

    showToast(`Transferred ${money(amount)} from ${fromKey} to ${toKey}`);
    return true;
  };

  const updateAccountBalance = (account: string, balance: number) => {
    const accKey = (account === 'bank' ? 'Bank' : account === 'telebirr' ? 'Mobile Money' : 'Cash') as
      | 'Cash'
      | 'Bank'
      | 'Mobile Money';

    setDb((prev) => {
      const updatedAccounts = { ...prev.accounts };
      updatedAccounts[accKey] = balance;
      return {
        ...prev,
        accounts: updatedAccounts,
        activity: [
          {
            id: uid('A'),
            date: day(),
            time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
            action: 'BALANCE RECONCILED',
            detail: `${accKey} adjusted to ${money(balance)}`,
          },
          ...(prev.activity || []),
        ],
      };
    });
    showToast(`${accKey} balance updated`);
  };

  const saveCapitalEntry = (
    category: string,
    amount: number,
    note: string,
    authMeta?: { verifiedByPin?: boolean; authorizedByUserId?: string; authorizedByUserName?: string }
  ): boolean => {
    if (!category || amount <= 0) {
      showToast('Enter valid capital spending amount');
      return false;
    }

    const newCap: CapitalSpending = {
      id: uid('CAP'),
      date: day(),
      category,
      amount,
      note: note.trim(),
    };

    const userToLog = availableUsers.find((u) => u.id === authMeta?.authorizedByUserId) || currentUser;

    setDb((prev) => ({
      ...prev,
      capitalSpending: [newCap, ...(prev.capitalSpending || [])],
      activity: [
        createLog(
          amount >= highValueThreshold ? 'HIGH-VALUE TRANSACTION' : 'CAPITAL SPENDING',
          `${category} · ${money(amount)}${note ? ' · ' + note : ''}`,
          {
            amount,
            isHighValue: amount >= highValueThreshold,
            category: 'financial_ledger',
            verifiedByPin: authMeta?.verifiedByPin ?? true,
            authorizedByUserId: userToLog.id,
            authorizedByUserName: userToLog.name,
            authorizedByUserRole: userToLog.role,
          }
        ),
        ...(prev.activity || []),
      ],
    }));

    showToast(`Capital spending recorded · ${money(amount)}`);
    return true;
  };

  const deleteCapitalEntry = (
    id: string,
    authMeta?: { verifiedByPin?: boolean; authorizedByUserId?: string; authorizedByUserName?: string }
  ) => {
    const userToLog = availableUsers.find((u) => u.id === authMeta?.authorizedByUserId) || currentUser;
    const targetEntry = db.capitalSpending?.find((x) => x.id === id);

    setDb((prev) => ({
      ...prev,
      capitalSpending: (prev.capitalSpending || []).filter((x) => x.id !== id),
      activity: [
        createLog(
          'CAPITAL ENTRY DELETED',
          `Removed capital expenditure: ${targetEntry ? `${targetEntry.category} (${money(targetEntry.amount)})` : id}`,
          {
            category: 'financial_ledger',
            amount: targetEntry?.amount,
            verifiedByPin: authMeta?.verifiedByPin ?? true,
            authorizedByUserId: userToLog.id,
            authorizedByUserName: userToLog.name,
            authorizedByUserRole: userToLog.role,
          }
        ),
        ...(prev.activity || []),
      ],
    }));
    showToast('Capital spending deleted · Audit logged');
  };

  const recordFinancialLedgerAdjustment = (
    ledgerTypeOrData:
      | 'capital'
      | 'expense'
      | 'account_balance'
      | 'ledger_correction'
      | {
          type?: string;
          amount: number;
          direction?: 'credit' | 'debit';
          account?: string;
          reason?: string;
          operatorId?: string;
          authMeta?: {
            verifiedByPin?: boolean;
            authorizedByUserId?: string;
            authorizedByUserName?: string;
            authorizedByUserRole?: string;
          };
        },
    title = '',
    amount = 0,
    notes = '',
    accountName = 'Cash',
    authMeta?: {
      verifiedByPin?: boolean;
      authorizedByUserId?: string;
      authorizedByUserName?: string;
      authorizedByUserRole?: string;
    }
  ): boolean => {
    let finalType: string = 'ledger_correction';
    let finalTitle: string = title;
    let finalAmount: number = amount;
    let finalNotes: string = notes;
    let finalAccount: string = accountName;
    let finalAuth = authMeta;

    if (typeof ledgerTypeOrData === 'object' && ledgerTypeOrData !== null) {
      finalType = ledgerTypeOrData.type || 'ledger_correction';
      finalAmount = ledgerTypeOrData.amount;
      finalTitle = `${(ledgerTypeOrData.type || 'ledger_adjustment').replace(/_/g, ' ').toUpperCase()} (${(ledgerTypeOrData.direction || 'credit').toUpperCase()})`;
      finalNotes = ledgerTypeOrData.reason || '';
      finalAccount = ledgerTypeOrData.account || 'CBE-Main-Ledger';
      finalAuth = ledgerTypeOrData.authMeta;
    } else if (typeof ledgerTypeOrData === 'string') {
      finalType = ledgerTypeOrData;
    }

    const userToLog = availableUsers.find((u) => u.id === finalAuth?.authorizedByUserId) || currentUser;
    const isHighVal = finalAmount >= highValueThreshold;

    if (finalType === 'capital') {
      return saveCapitalEntry(finalTitle, finalAmount, finalNotes, finalAuth);
    }

    if (finalType === 'expense') {
      const ok = addExpense(finalTitle, 'Ledger Audit Adjustment', finalAmount, finalAccount || 'Cash');
      return ok;
    }

    if (finalType === 'account_balance') {
      updateAccountBalance(finalAccount, finalAmount);
      return true;
    }

    const logEntry = createLog(
      isHighVal ? 'HIGH-VALUE FINANCIAL LEDGER EDIT' : 'FINANCIAL LEDGER EDIT',
      `Audit Adjustment: ${finalTitle} · ${money(finalAmount)} [${finalAccount || 'Financial Ledger'}] · Reason: ${finalNotes || 'Audited manual correction'}`,
      {
        category: 'financial_ledger',
        amount: finalAmount,
        isHighValue: isHighVal,
        userId: userToLog.id,
        userName: userToLog.name,
        userRole: userToLog.role,
        verifiedByPin: finalAuth?.verifiedByPin ?? true,
        authorizedByUserId: userToLog.id,
        authorizedByUserName: userToLog.name,
        authorizedByUserRole: userToLog.role,
        reason: finalNotes || 'Audited financial ledger adjustment',
      }
    );

    setDb((prev) => ({
      ...prev,
      activity: [logEntry, ...(prev.activity || [])],
    }));

    showToast(`Financial ledger adjustment recorded · ${money(finalAmount)}`);
    return true;
  };

  const updateActivityLogNote = (
    logId: string,
    newNote: string,
    authMeta?: {
      verifiedByPin?: boolean;
      authorizedByUserId?: string;
      authorizedByUserName?: string;
      authorizedByUserRole?: string;
    }
  ): boolean => {
    const userToLog = availableUsers.find((u) => u.id === authMeta?.authorizedByUserId) || currentUser;
    setDb((prev) => {
      const updated = (prev.activity || []).map((item) => {
        if (item.id === logId) {
          return {
            ...item,
            auditNote: newNote,
            verifiedByPin: authMeta?.verifiedByPin ?? true,
            authorizedByUserId: userToLog.id,
            authorizedByUserName: userToLog.name,
            authorizedByUserRole: userToLog.role,
          };
        }
        return item;
      });
      return { ...prev, activity: updated };
    });
    showToast('Audit note recorded with PIN verification');
    return true;
  };

  // Shifts
  const assignShift = (shiftData: Omit<Shift, 'id'>): boolean => {
    setDb((prev) => ({
      ...prev,
      shifts: [...(prev.shifts || []), { id: uid('SH'), ...shiftData }],
    }));
    showToast(`Shift assigned to ${shiftData.userName}`);
    return true;
  };

  const deleteShift = (id: string): void => {
    setDb((prev) => ({
      ...prev,
      shifts: (prev.shifts || []).filter((s) => s.id !== id),
    }));
    showToast('Shift removed');
  };

  // Enterprise & Goals
  const addGoal = (titleOrText: string, targetOrCategory: number | string): boolean => {
    if (!titleOrText.trim()) {
      showToast('Enter a valid goal title');
      return false;
    }

    const isNum = typeof targetOrCategory === 'number';
    const target = isNum ? targetOrCategory : 100;
    const category = !isNum ? String(targetOrCategory) : 'Operations';

    const newGoal: Goal = {
      id: uid('G'),
      title: titleOrText.trim(),
      text: titleOrText.trim(),
      target,
      done: 0,
      category,
      completed: false,
    };

    setDb((prev) => ({
      ...prev,
      goals: [...(prev.goals || []), newGoal],
    }));

    showToast('Strategic goal added');
    return true;
  };

  const updateGoal = (id: string, done: number) => {
    setDb((prev) => ({
      ...prev,
      goals: (prev.goals || []).map((g) => (g.id === id ? { ...g, done: Math.max(0, done) } : g)),
    }));
    showToast('Goal progress saved');
  };

  const toggleGoal = (id: string) => {
    setDb((prev) => ({
      ...prev,
      goals: (prev.goals || []).map((g) =>
        g.id === id ? { ...g, completed: !g.completed } : g
      ),
    }));
  };

  const setDailySalesTarget = (target: number) => {
    const validTarget = Math.max(0, Math.round(target));
    const today = day();
    setDb((prev) => ({
      ...prev,
      dailySalesTarget: validTarget,
      dailyTargets: {
        ...(prev.dailyTargets || {}),
        [today]: validTarget,
      },
    }));
    logActivity(
      'Updated Daily Sales Target',
      `CEO adjusted daily sales target to ${money(validTarget)}`,
      { category: 'ceo_note', amount: validTarget }
    );
    showToast(`Daily target set to ${money(validTarget)}`);
  };

  const setDailySalesTargetForDate = (date: string, target: number) => {
    const validTarget = Math.max(0, Math.round(target));
    const isToday = date === day();
    setDb((prev) => ({
      ...prev,
      dailyTargets: {
        ...(prev.dailyTargets || {}),
        [date]: validTarget,
      },
      ...(isToday ? { dailySalesTarget: validTarget } : {}),
    }));
    logActivity(
      'Updated Daily Sales Target',
      `Target for ${date} set to ${money(validTarget)}`,
      { category: 'ceo_note', amount: validTarget }
    );
    showToast(`Target for ${date} set to ${money(validTarget)}`);
  };

  const toggleDailyActionItem = (date: string, actionId: string) => {
    setDb((prev) => {
      const currentList = prev.dailyActionFocus?.[date] || [];
      const updated = currentList.map((item) =>
        item.id === actionId ? { ...item, done: !item.done } : item
      );
      return {
        ...prev,
        dailyActionFocus: {
          ...(prev.dailyActionFocus || {}),
          [date]: updated,
        },
      };
    });
  };

  const addDailyActionItem = (
    date: string,
    text: string,
    impact: 'high' | 'medium' | 'growth' = 'high',
    assignedTo?: string,
    category?: string
  ) => {
    if (!text.trim()) return;
    const newItem: DailyActionItem = {
      id: uid('ACT'),
      text: text.trim(),
      done: false,
      impact,
      assignedTo: assignedTo || currentUser.name,
      category: category || 'Operations',
    };
    setDb((prev) => {
      const currentList = prev.dailyActionFocus?.[date] || [];
      return {
        ...prev,
        dailyActionFocus: {
          ...(prev.dailyActionFocus || {}),
          [date]: [...currentList, newItem],
        },
      };
    });
    showToast('Daily action item added');
  };

  const deleteDailyActionItem = (date: string, actionId: string) => {
    setDb((prev) => {
      const currentList = prev.dailyActionFocus?.[date] || [];
      return {
        ...prev,
        dailyActionFocus: {
          ...(prev.dailyActionFocus || {}),
          [date]: currentList.filter((item) => item.id !== actionId),
        },
      };
    });
    showToast('Action item removed');
  };

  // Team & Permissions
  const addSystemUser = (userData: Omit<SystemUser, 'id'>): boolean => {
    const newUser: SystemUser = {
      id: uid('USR'),
      ...userData,
      pin: userData.pin || '1234',
      permissions: userData.permissions || ['pos'],
      status: userData.status || 'active',
    };
    setAvailableUsers((prev) => {
      const updated = [...prev, newUser];
      try {
        localStorage.setItem('imruu_system_users', JSON.stringify(updated));
      } catch (e) {
        // ignore
      }
      return updated;
    });
    logActivity(
      'Added Team Member',
      `New staff profile created for ${newUser.name} as ${newUser.role}`,
      { category: 'system' }
    );
    showToast(`Added ${newUser.name} to team`);
    return true;
  };

  const updateSystemUser = (id: string, updates: Partial<SystemUser>): boolean => {
    setAvailableUsers((prev) => {
      const updated = prev.map((u) => (u.id === id ? { ...u, ...updates } : u));
      try {
        localStorage.setItem('imruu_system_users', JSON.stringify(updated));
      } catch (e) {
        // ignore
      }
      return updated;
    });
    if (currentUser.id === id) {
      setCurrentUser((prev) => ({ ...prev, ...updates }));
    }

    // If updating the CEO profile, synchronize with businessProfile as well
    const targetUser = availableUsers.find((u) => u.id === id);
    if (
      targetUser &&
      (targetUser.id === 'USR-CEO-01' ||
        targetUser.role.toLowerCase().includes('ceo') ||
        (updates.role && updates.role.toLowerCase().includes('ceo')))
    ) {
      setBusinessProfile((prev) => {
        const next = {
          ...prev,
          ceoName: updates.name !== undefined ? updates.name : prev.ceoName,
          ceoTitle: updates.role !== undefined ? updates.role : prev.ceoTitle,
          ceoEmail: updates.email !== undefined ? updates.email : prev.ceoEmail,
          ceoPhone: updates.phone !== undefined ? updates.phone : prev.ceoPhone,
        };
        try {
          localStorage.setItem('imruu_business_profile', JSON.stringify(next));
        } catch (e) {}
        return next;
      });
    }

    logActivity(
      'Updated Staff Profile',
      `Modified details for ${updates.name || 'team member'} (${updates.role || 'staff'})`,
      { category: 'system' }
    );
    showToast('Staff profile updated');
    return true;
  };

  const updateBusinessProfile = (updates: Partial<BusinessProfile>) => {
    setBusinessProfile((prev) => {
      const next = { ...prev, ...updates };
      try {
        localStorage.setItem('imruu_business_profile', JSON.stringify(next));
      } catch (e) {}
      return next;
    });

    // If CEO credentials or details were modified, synchronize the CEO system user
    if (updates.ceoName || updates.ceoTitle || updates.ceoEmail || updates.ceoPhone) {
      setAvailableUsers((prev) => {
        const ceo = prev.find((u) => u.id === 'USR-CEO-01' || u.role.toLowerCase().includes('ceo')) || prev[0];
        if (!ceo) return prev;
        const updatedList = prev.map((u) =>
          u.id === ceo.id
            ? {
                ...u,
                name: updates.ceoName || u.name,
                role: updates.ceoTitle || u.role,
                email: updates.ceoEmail !== undefined ? updates.ceoEmail : u.email,
                phone: updates.ceoPhone !== undefined ? updates.ceoPhone : u.phone,
              }
            : u
        );
        try {
          localStorage.setItem('imruu_system_users', JSON.stringify(updatedList));
        } catch (e) {}
        return updatedList;
      });

      setCurrentUser((prev) => {
        if (prev.id === 'USR-CEO-01' || prev.role.toLowerCase().includes('ceo')) {
          return {
            ...prev,
            name: updates.ceoName || prev.name,
            role: updates.ceoTitle || prev.role,
            email: updates.ceoEmail !== undefined ? updates.ceoEmail : prev.email,
            phone: updates.ceoPhone !== undefined ? updates.ceoPhone : prev.phone,
          };
        }
        return prev;
      });
    }

    // Sync tax settings if registered legal name or TIN were modified
    if (updates.registeredBusinessName || updates.tinNumber) {
      setDb((prev) => {
        if (!prev.taxSettings) return prev;
        return {
          ...prev,
          taxSettings: {
            ...prev.taxSettings,
            registeredBusinessName: updates.registeredBusinessName || prev.taxSettings.registeredBusinessName,
            taxIdentificationNumber: updates.tinNumber || prev.taxSettings.taxIdentificationNumber,
          },
        };
      });
    }

    logActivity(
      'Updated Store & Executive Profile',
      `CEO: ${updates.ceoName || businessProfile.ceoName} · Business: ${updates.registeredBusinessName || businessProfile.registeredBusinessName}`,
      { category: 'system' }
    );
    showToast('Executive profile & store settings saved');
  };

  const deleteSystemUser = (id: string): boolean => {
    if (availableUsers.length <= 1) {
      showToast('Cannot delete the last remaining system user');
      return false;
    }
    setAvailableUsers((prev) => {
      const updated = prev.filter((u) => u.id !== id);
      try {
        localStorage.setItem('imruu_system_users', JSON.stringify(updated));
      } catch (e) {
        // ignore
      }
      return updated;
    });
    if (currentUser.id === id) {
      const nextUser = availableUsers.find((u) => u.id !== id);
      if (nextUser) setCurrentUser(nextUser);
    }
    showToast('Team member removed');
    return true;
  };

  // Warehouses & Locations
  const addWarehouse = (warehouseData: Omit<WarehouseLocation, 'id'>) => {
    const newLoc: WarehouseLocation = {
      id: uid('LOC'),
      ...warehouseData,
    };
    setDb((prev) => ({
      ...prev,
      warehouses: [...(prev.warehouses || []), newLoc],
    }));
    logActivity(
      'Registered New Facility',
      `Facility ${newLoc.name} (${newLoc.code}) registered with capacity ${newLoc.capacityUnits.toLocaleString()} units`,
      { category: 'system' }
    );
    showToast(`Facility ${newLoc.name} added`);
  };

  const updateWarehouse = (id: string, updates: Partial<WarehouseLocation>) => {
    setDb((prev) => ({
      ...prev,
      warehouses: (prev.warehouses || []).map((w) => (w.id === id ? { ...w, ...updates } : w)),
    }));
    showToast('Facility updated');
  };

  const deleteWarehouse = (id: string) => {
    setDb((prev) => ({
      ...prev,
      warehouses: (prev.warehouses || []).filter((w) => w.id !== id),
    }));
    showToast('Facility removed');
  };

  const transferStock = (data: {
    fromLocationId: string;
    toLocationId: string;
    productId: string;
    qty: number;
    notes?: string;
  }): boolean => {
    const fromLoc = (db.warehouses || []).find((w) => w.id === data.fromLocationId);
    const toLoc = (db.warehouses || []).find((w) => w.id === data.toLocationId);
    const prod = db.products.find((p) => p.id === data.productId);

    if (!prod) {
      showToast('Product not found');
      return false;
    }
    if (data.qty <= 0) {
      showToast('Transfer quantity must be greater than 0');
      return false;
    }

    const newTransfer: StockTransfer = {
      id: uid('TRF'),
      date: day(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      fromLocationId: data.fromLocationId,
      fromLocationName: fromLoc ? fromLoc.name : 'Origin Location',
      toLocationId: data.toLocationId,
      toLocationName: toLoc ? toLoc.name : 'Destination Location',
      productId: data.productId,
      productName: prod.name,
      qty: data.qty,
      transferredBy: currentUser.name,
      notes: data.notes || 'Internal stock transfer',
      status: 'completed',
    };

    setDb((prev) => ({
      ...prev,
      transfers: [newTransfer, ...(prev.transfers || [])],
    }));

    logActivity(
      'STOCK TRANSFER',
      `${data.qty} ${prod.unit} of ${prod.name} transferred from ${newTransfer.fromLocationName} to ${newTransfer.toLocationName}`,
      {
        userId: currentUser.id,
        userName: currentUser.name,
        userRole: currentUser.role,
        category: 'inventory_adjustment',
        productName: prod.name,
        productId: prod.id,
        amount: data.qty * prod.buy,
      }
    );

    showToast(`Transferred ${data.qty} ${prod.unit} to ${newTransfer.toLocationName}`);
    return true;
  };

  const deleteGoal = (id: string) => {
    setDb((prev) => ({
      ...prev,
      goals: (prev.goals || []).map((g) => g).filter((g) => g.id !== id),
    }));
    showToast('Goal deleted');
  };

  const clearActivity = () => {
    setDb((prev) => ({
      ...prev,
      activity: [],
    }));
    showToast('Audit trail cleared');
  };

  const clearActivityLog = (
    authMeta?: {
      verifiedByPin?: boolean;
      authorizedByUserId?: string;
      authorizedByUserName?: string;
      authorizedByUserRole?: string;
    }
  ) => {
    const userToLog = availableUsers.find((u) => u.id === authMeta?.authorizedByUserId) || currentUser;
    const purgeAuditLog: ActivityLog = {
      id: uid('A'),
      date: day(),
      time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      timestamp: new Date().toISOString(),
      action: 'AUDIT TRAIL PURGED (PIN VERIFIED)',
      detail: `Audit trail reset and re-initialized by ${userToLog.name} (${userToLog.id}) via 4-digit security PIN verification.`,
      userId: userToLog.id,
      userName: userToLog.name,
      userRole: userToLog.role,
      category: 'system',
      verifiedByPin: true,
      authorizedByUserId: userToLog.id,
      authorizedByUserName: userToLog.name,
      authorizedByUserRole: userToLog.role,
    };
    setDb((prev) => ({
      ...prev,
      activity: [purgeAuditLog],
    }));
    showToast('Audit trail purged · Certified security log created');
  };

  const toggleCheck = (index: number) => {
    const todayKey = day();
    setDb((prev) => {
      const curChecks = prev.checks?.[todayKey] || Array(6).fill(false);
      const nextChecks = [...curChecks];
      nextChecks[index] = !nextChecks[index];
      return {
        ...prev,
        checks: {
          ...prev.checks,
          [todayKey]: nextChecks,
        },
      };
    });
  };

  // Backup & Reset
  const exportBackup = () => {
    const dataStr = 'data:text/json;charset=utf-8,' + encodeURIComponent(JSON.stringify(db, null, 2));
    const downloadAnchor = document.createElement('a');
    downloadAnchor.setAttribute('href', dataStr);
    downloadAnchor.setAttribute('download', `barwaaqo_os_backup_${day()}.json`);
    document.body.appendChild(downloadAnchor);
    downloadAnchor.click();
    downloadAnchor.remove();
    showToast('Backup JSON exported');
  };

  const importBackup = async (fileOrContent: File | string): Promise<boolean> => {
    if (typeof fileOrContent === 'string') {
      try {
        const parsed = JSON.parse(fileOrContent);
        if (parsed && typeof parsed === 'object' && Array.isArray(parsed.products)) {
          setDb(parsed);
          showToast('Backup restored successfully');
          return true;
        }
        showToast('Invalid backup JSON format');
        return false;
      } catch (err) {
        showToast('Failed to parse backup JSON');
        return false;
      }
    }

    return new Promise((resolve) => {
      const reader = new FileReader();
      reader.onload = (e) => {
        try {
          const content = e.target?.result as string;
          const parsed = JSON.parse(content);
          if (parsed && typeof parsed === 'object' && Array.isArray(parsed.products)) {
            setDb(parsed);
            showToast('Backup restored successfully');
            resolve(true);
            return;
          }
          showToast('Invalid backup file format');
          resolve(false);
        } catch (err) {
          showToast('Failed to read backup file');
          resolve(false);
        }
      };
      reader.readAsText(fileOrContent);
    });
  };

  const resetAll = () => {
    if (window.confirm('Reset ALL IMRUU Grocery Shop V18 data to clean defaults?')) {
      const fresh = getBaseDb();
      setDb(fresh);
      localStorage.setItem(KEY, JSON.stringify(fresh));
      showToast('System reset to default state');
    }
  };

  const resetToDefault = () => {
    resetAll();
  };

  const refreshData = async (): Promise<void> => {
    try {
      const stored = localStorage.getItem(KEY);
      if (stored) {
        const parsed = JSON.parse(stored);
        if (parsed && typeof parsed === 'object' && Array.isArray(parsed.products)) {
          setDb({ ...parsed });
          return;
        }
      }
      setDb((prev) => ({ ...prev }));
    } catch (e) {
      console.error('Failed to reload from storage during refresh', e);
      setDb((prev) => ({ ...prev }));
    }
  };

  // Dynamic Pricing Engine
  const pricingSettings: PricingEngineSettings = db.pricingSettings || DEFAULT_PRICING_SETTINGS;
  const competitorQuotes: CompetitorQuote[] = db.competitorQuotes || INITIAL_COMPETITOR_QUOTES;

  const priceSuggestions = useMemo(() => {
    return generateDynamicPriceSuggestions(db, competitorQuotes, pricingSettings);
  }, [db, competitorQuotes, pricingSettings]);

  const applyPriceAdjustment = (
    productId: string,
    newSell: number,
    newWholesale?: number,
    reason?: string
  ): boolean => {
    const p = db.products.find((x) => x.id === productId);
    if (!p) {
      showToast('Product not found');
      return false;
    }

    const prevSell = p.sell;
    const prevWholesale = p.wholesale;
    const finalWholesale =
      newWholesale !== undefined
        ? newWholesale
        : roundPrice(newSell * (1 - pricingSettings.wholesaleDiscountPercent / 100), pricingSettings.roundingRule);

    const priceDelta = newSell - prevSell;
    const isIncrease = priceDelta > 0;

    setDb((prev) => {
      const updatedProducts = prev.products.map((prod) => {
        if (prod.id === productId) {
          return {
            ...prod,
            sell: newSell,
            wholesale: finalWholesale,
          };
        }
        return prod;
      });

      const logEntry = createLog(
        'DYNAMIC PRICE ADJUSTMENT',
        `${p.name} · Retail: ${money(prevSell)} → ${money(newSell)} (${isIncrease ? '+' : ''}${money(priceDelta)}) · Wholesale: ${money(prevWholesale)} → ${money(finalWholesale)} · Reason: ${reason || `Dynamic Pricing Rule: ${pricingSettings.activeStrategy}`}`,
        {
          userId: currentUser.id,
          userName: currentUser.name,
          userRole: currentUser.role,
          category: 'price_adjustment',
          amount: Math.abs(priceDelta),
          productName: p.name,
          productId: p.id,
          reason: reason || `Adjusted under strategy: ${pricingSettings.activeStrategy}`,
        }
      );

      return {
        ...prev,
        products: updatedProducts,
        activity: [logEntry, ...(prev.activity || [])],
      };
    });

    showToast(`Updated ${p.name} price to ${money(newSell)} (${isIncrease ? '+' : ''}${money(priceDelta)})`);
    return true;
  };

  const applyAllPriceAdjustments = (adjustments: PriceAdjustmentSuggestion[]): number => {
    const validAdjustments = adjustments.filter((s) => Math.abs(s.priceChangeDelta) >= 1);
    if (validAdjustments.length === 0) {
      showToast('All products are currently at optimal dynamic pricing.');
      return 0;
    }

    setDb((prev) => {
      const adjustmentMap = new Map(validAdjustments.map((a) => [a.productId, a]));
      const updatedProducts = prev.products.map((prod) => {
        const adj = adjustmentMap.get(prod.id);
        if (adj) {
          return {
            ...prod,
            sell: adj.suggestedPrice,
            wholesale: adj.suggestedWholesalePrice,
          };
        }
        return prod;
      });

      const batchLog = createLog(
        'BATCH DYNAMIC PRICING UPDATE',
        `Applied dynamic price adjustments across ${validAdjustments.length} products · Active Strategy: ${pricingSettings.activeStrategy}`,
        {
          userId: currentUser.id,
          userName: currentUser.name,
          userRole: currentUser.role,
          category: 'price_adjustment',
          reason: `Batch pricing engine execution under ${pricingSettings.activeStrategy}`,
        }
      );

      return {
        ...prev,
        products: updatedProducts,
        activity: [batchLog, ...(prev.activity || [])],
      };
    });

    showToast(`Applied dynamic pricing to ${validAdjustments.length} products.`);
    return validAdjustments.length;
  };

  const updatePricingSettings = (settings: Partial<PricingEngineSettings>) => {
    setDb((prev) => {
      const currentSettings = prev.pricingSettings || DEFAULT_PRICING_SETTINGS;
      const nextSettings = { ...currentSettings, ...settings };
      return {
        ...prev,
        pricingSettings: nextSettings,
      };
    });
    if (settings.activeStrategy) {
      showToast(`Active pricing strategy switched to ${settings.activeStrategy.replace(/_/g, ' ').toUpperCase()}`);
    } else {
      showToast('Pricing engine parameters updated');
    }
  };

  const addCompetitorQuote = (quote: Omit<CompetitorQuote, 'id' | 'lastChecked'>): boolean => {
    const newQuote: CompetitorQuote = {
      ...quote,
      id: uid('CQ'),
      lastChecked: 'Just now',
    };

    setDb((prev) => {
      const quotes = prev.competitorQuotes || INITIAL_COMPETITOR_QUOTES;
      return {
        ...prev,
        competitorQuotes: [newQuote, ...quotes],
        activity: [
          createLog(
            'COMPETITOR INTEL RECORDED',
            `${quote.competitorName} · ${quote.productName} at ${money(quote.price)} (${quote.inStock ? 'In-Stock' : 'Stockout'}) · Source: ${quote.source}`,
            {
              userId: currentUser.id,
              userName: currentUser.name,
              userRole: currentUser.role,
              category: 'competitor_intel',
              productName: quote.productName,
              productId: quote.productId,
              amount: quote.price,
            }
          ),
          ...(prev.activity || []),
        ],
      };
    });

    showToast(`Competitor quote added for ${quote.competitorName}`);
    return true;
  };

  const updateCompetitorQuote = (quoteId: string, updates: Partial<CompetitorQuote>): boolean => {
    setDb((prev) => {
      const quotes = (prev.competitorQuotes || INITIAL_COMPETITOR_QUOTES).map((q) => {
        if (q.id === quoteId) {
          return {
            ...q,
            ...updates,
            lastChecked: 'Just now',
          };
        }
        return q;
      });
      return {
        ...prev,
        competitorQuotes: quotes,
      };
    });
    showToast('Competitor quote updated');
    return true;
  };

  const deleteCompetitorQuote = (quoteId: string) => {
    setDb((prev) => {
      const quotes = (prev.competitorQuotes || INITIAL_COMPETITOR_QUOTES).filter((q) => q.id !== quoteId);
      return {
        ...prev,
        competitorQuotes: quotes,
      };
    });
    showToast('Competitor quote deleted');
  };

  const simulateMarketPriceShift = (
    type?:
      | 'inflation_spike'
      | 'competitor_discount_war'
      | 'competitor_stockouts'
      | 'supplier_cogs_drop'
      | 'random'
  ) => {
    const shiftType = type || 'inflation_spike';

    setDb((prev) => {
      let updatedProducts = [...prev.products];
      let updatedQuotes = [...(prev.competitorQuotes || INITIAL_COMPETITOR_QUOTES)];
      let activityAction = 'MARKET INTELLIGENCE SYNC';
      let activityDetail = '';

      if (shiftType === 'inflation_spike') {
        // Supplier COGS rises on staples
        updatedProducts = updatedProducts.map((p) => {
          if (['P-sug-01', 'P-ric-02', 'P-oil-03', 'P-flr-04'].includes(p.id)) {
            const costIncrease = Math.round(p.buy * 0.14); // 14% COGS spike
            return {
              ...p,
              buy: p.buy + costIncrease,
            };
          }
          return p;
        });

        // Competitors also adjust prices upwards
        updatedQuotes = updatedQuotes.map((q) => {
          if (['P-sug-01', 'P-ric-02', 'P-oil-03', 'P-flr-04'].includes(q.productId)) {
            return {
              ...q,
              price: Math.round(q.price * 1.12),
              lastChecked: 'Just now (Live Scrape)',
            };
          }
          return q;
        });

        activityAction = 'COGS INFLATION WAVE SIMULATED';
        activityDetail = 'Supplier raw goods index surged +14% across staples (Sugar, Rice, Oil, Flour). Margin compression alerts active.';
      } else if (shiftType === 'competitor_discount_war') {
        // Rivals cut prices by 6-9%
        updatedQuotes = updatedQuotes.map((q) => {
          if (q.inStock) {
            return {
              ...q,
              price: Math.round(q.price * 0.92),
              promoActive: true,
              lastChecked: 'Just now (Live Scrape)',
            };
          }
          return q;
        });
        activityAction = 'COMPETITOR PRICE WAR SIMULATED';
        activityDetail = 'Rival chains initiated aggressive -8% promotional discount wave across in-stock staples.';
      } else if (shiftType === 'competitor_stockouts') {
        // Rivals run out of stock
        updatedQuotes = updatedQuotes.map((q, idx) => {
          if (idx % 2 === 0) {
            return {
              ...q,
              inStock: false,
              lastChecked: 'Just now (Market Survey)',
            };
          }
          return q;
        });
        activityAction = 'COMPETITOR STOCKOUT WAVE';
        activityDetail = 'Major supply chain bottleneck triggered stockouts across 50% of competitor locations. Scarcity pricing opportunities unlocked.';
      } else if (shiftType === 'supplier_cogs_drop') {
        // Supplier discount
        updatedProducts = updatedProducts.map((p) => {
          return {
            ...p,
            buy: Math.round(p.buy * 0.91), // 9% supplier discount
          };
        });
        activityAction = 'SUPPLIER COGS RELIEF';
        activityDetail = 'Negotiated 9% bulk discount relief from wholesale suppliers across inventory catalog.';
      } else {
        // Random live variation
        updatedQuotes = updatedQuotes.map((q) => {
          const delta = Math.random() * 0.08 - 0.04;
          return {
            ...q,
            price: Math.round(q.price * (1 + delta)),
            lastChecked: 'Just now',
          };
        });
        activityAction = 'LIVE MARKET SCRAPE REFRESH';
        activityDetail = 'Live price telemetry refreshed from 5 competitor POS and ecommerce endpoints.';
      }

      const simLog = createLog(
        activityAction,
        activityDetail,
        {
          userId: currentUser.id,
          userName: currentUser.name,
          userRole: currentUser.role,
          category: 'market_intel',
        }
      );

      return {
        ...prev,
        products: updatedProducts,
        competitorQuotes: updatedQuotes,
        activity: [simLog, ...(prev.activity || [])],
      };
    });

    showToast(`Market scenario triggered: ${shiftType.replace(/_/g, ' ').toUpperCase()}`);
  };

  // Tax Settings & Tier Management
  const taxSettings = db.taxSettings || DEFAULT_TAX_SETTINGS;

  const updateTaxSettings = (settings: TaxSettings) => {
    setDb((prev) => {
      const log = createLog(
        'TAX SETTINGS UPDATED',
        `Tax regime updated: ${settings.taxLabel} (${settings.calculationMethod}) · TIN: ${settings.taxIdentificationNumber} · ${settings.tiers.length} active tiers`,
        {
          userId: currentUser.id,
          userName: currentUser.name,
          userRole: currentUser.role,
          category: 'tax_settings',
        }
      );
      return {
        ...prev,
        taxSettings: settings,
        activity: [log, ...(prev.activity || [])],
      };
    });
    showToast('Tax configuration & statutory rates saved');
  };

  const addTaxTier = (tierData: Omit<TaxTier, 'id'>) => {
    const newTier: TaxTier = {
      ...tierData,
      id: `TIER-${Date.now().toString(36).toUpperCase()}`,
    };

    setDb((prev) => {
      const current = prev.taxSettings || DEFAULT_TAX_SETTINGS;
      const updatedTiers = [...current.tiers, newTier];
      const log = createLog(
        'TAX TIER ADDED',
        `Added bracket ${newTier.name} (${newTier.code} @ ${newTier.rate}%)`,
        {
          userId: currentUser.id,
          userName: currentUser.name,
          userRole: currentUser.role,
          category: 'tax_settings',
        }
      );
      return {
        ...prev,
        taxSettings: {
          ...current,
          tiers: updatedTiers,
        },
        activity: [log, ...(prev.activity || [])],
      };
    });
    showToast(`Added tax tier: ${tierData.name}`);
  };

  const updateTaxTier = (id: string, updates: Partial<TaxTier>) => {
    setDb((prev) => {
      const current = prev.taxSettings || DEFAULT_TAX_SETTINGS;
      const updatedTiers = current.tiers.map((t) => (t.id === id ? { ...t, ...updates } : t));
      return {
        ...prev,
        taxSettings: {
          ...current,
          tiers: updatedTiers,
        },
      };
    });
    showToast('Tax tier updated');
  };

  const deleteTaxTier = (id: string): boolean => {
    const current = db.taxSettings || DEFAULT_TAX_SETTINGS;
    if (current.tiers.length <= 1) {
      showToast('Cannot delete the last remaining tax tier');
      return false;
    }
    if (current.defaultTierId === id) {
      showToast('Cannot delete the designated default tax tier. Change default first.');
      return false;
    }

    setDb((prev) => {
      const active = prev.taxSettings || DEFAULT_TAX_SETTINGS;
      const updatedTiers = active.tiers.filter((t) => t.id !== id);
      return {
        ...prev,
        taxSettings: {
          ...active,
          tiers: updatedTiers,
        },
      };
    });
    showToast('Tax tier removed');
    return true;
  };

  const setDefaultTaxTier = (id: string) => {
    setDb((prev) => {
      const active = prev.taxSettings || DEFAULT_TAX_SETTINGS;
      return {
        ...prev,
        taxSettings: {
          ...active,
          defaultTierId: id,
        },
      };
    });
    showToast('Default statutory tax tier updated');
  };

  const applyTaxPreset = (presetId: string) => {
    const preset = REGIONAL_TAX_PRESETS.find((p) => p.id === presetId);
    if (!preset) return;

    setDb((prev) => {
      const current = prev.taxSettings || DEFAULT_TAX_SETTINGS;
      const updated: TaxSettings = {
        ...current,
        taxLabel: preset.taxLabel,
        calculationMethod: preset.calculationMethod,
        defaultTierId:
          preset.defaultTierId ||
          preset.tiers.find((t) => t.isDefault)?.id ||
          preset.tiers[0]?.id ||
          'TIER-STD',
        tiers: preset.tiers.map((t) => ({ ...t })),
      };

      const log = createLog(
        'TAX REGIME PRESET APPLIED',
        `Applied statutory template: ${preset.name} (${preset.taxLabel})`,
        {
          userId: currentUser.id,
          userName: currentUser.name,
          userRole: currentUser.role,
          category: 'tax_settings',
        }
      );

      return {
        ...prev,
        taxSettings: updated,
        activity: [log, ...(prev.activity || [])],
      };
    });
    showToast(`Applied regional tax regime: ${preset.name}`);
  };

  return (
    <StoreContext.Provider
      value={{
        db,
        totals,
        activeTab,
        setActiveTab,
        isSearchOpen,
        setIsSearchOpen,
        isCapitalModalOpen,
        setIsCapitalModalOpen,
        stockAdjustProductId,
        setStockAdjustProductId,
        productQrModalId,
        setProductQrModalId,
        isBusinessInfoOpen,
        setIsBusinessInfoOpen,
        isCeoProfileModalOpen,
        setIsCeoProfileModalOpen,
        isGettingStartedOpen,
        setIsGettingStartedOpen,
        businessProfile,
        updateBusinessProfile,
        enterpriseSubTab,
        setEnterpriseSubTab,
        openTeamManagement,
        toastMessage,
        showToast,
        cart,
        addToCart,
        updateCartQty,
        removeFromCart,
        clearCart,
        updateCartItemTaxTier,
        completeSale,
        saveProduct,
        adjustStock,
        deleteProduct,
        recordPurchase,
        paySupplier,
        addSupplier,
        updateSupplier,
        deleteSupplier,
        addCustomer,
        updateCustomer,
        payCustomer,
        payCustomerCredit,
        deleteCustomer,
        createOrder,
        createDistributionOrder,
        assignDeliveryRoute,
        advanceOrder,
        updateOrderStatus,
        payOrder,
        payOrderBalance,
        deleteOrder,
        recordExpense,
        addExpense,
        deleteExpense,
        saveCapitalEntry,
        deleteCapitalEntry,
        transferBetweenAccounts,
        updateAccountBalance,
        setDailySalesTarget,
        setDailySalesTargetForDate,
        toggleDailyActionItem,
        addDailyActionItem,
        deleteDailyActionItem,
        addGoal,
        updateGoal,
        toggleGoal,
        deleteGoal,
        toggleCheck,
        clearActivity,
        clearActivityLog,
        currentUser,
        setCurrentUser: handleSetCurrentUser,
        availableUsers,
        highValueThreshold,
        setHighValueThreshold,
        logActivity,
        logSecurityAlert,
        verifyPin,
        updateUserPin,
        updateUserWebAuthn,
        recordFinancialLedgerAdjustment,
        updateActivityLogNote,
        assignShift,
        deleteShift,
        addSystemUser,
        updateSystemUser,
        deleteSystemUser,
        addWarehouse,
        updateWarehouse,
        deleteWarehouse,
        transferStock,
        pricingSettings,
        competitorQuotes,
        priceSuggestions,
        applyPriceAdjustment,
        applyAllPriceAdjustments,
        updatePricingSettings,
        addCompetitorQuote,
        updateCompetitorQuote,
        deleteCompetitorQuote,
        simulateMarketPriceShift,
        taxSettings,
        isTaxModalOpen,
        setIsTaxModalOpen,
        isMonthlyTaxReportModalOpen,
        setIsMonthlyTaxReportModalOpen,
        selectedTaxReportMonth,
        setSelectedTaxReportMonth,
        lastCompletedSale,
        setLastCompletedSale,
        updateTaxSettings,
        addTaxTier,
        updateTaxTier,
        deleteTaxTier,
        setDefaultTaxTier,
        applyTaxPreset,
        exportBackup,
        importBackup,
        resetAll,
        resetToDefault,
        refreshData,
      }}
    >
      {children}
    </StoreContext.Provider>
  );
}

export function useStore(): StoreContextType {
  const context = useContext(StoreContext);
  if (!context) {
    throw new Error('useStore must be used within a StoreProvider');
  }
  return context;
}
