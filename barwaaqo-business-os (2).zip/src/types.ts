export type PaymentMethod = 'Cash' | 'Bank' | 'Mobile Money' | 'Credit';
export type SaleMode = 'retail' | 'wholesale';
export type UnitType = 'pcs' | 'kg' | 'bag' | 'carton' | 'box';
export type OrderStatus =
  | 'NEW'
  | 'CONFIRMED'
  | 'PACKING'
  | 'OUT FOR DELIVERY'
  | 'DELIVERED'
  | 'PAID'
  | 'BOOKED'
  | 'PACKED'
  | 'OUT_FOR_DELIVERY';

export type DistributionOrderStatus = OrderStatus;

export interface Product {
  id: string;
  name: string;
  sku: string;
  stock: number;
  openingStock: number;
  buy: number;
  sell: number;
  wholesale: number;
  min: number;
  unit: UnitType | string;
  category?: string;
  taxTierId?: string;
}

export type CompetitorSource =
  | 'Live Web Scrape'
  | 'Market Survey'
  | 'Supplier Sheet'
  | 'Manual Feed'
  | 'POS Network';

export interface CompetitorQuote {
  id: string;
  competitorName: string;
  productId: string;
  productName: string;
  price: number;
  inStock: boolean;
  promoActive?: boolean;
  lastChecked: string;
  source: CompetitorSource;
  confidenceScore: number; // 0-100
}

export type PricingStrategy =
  | 'margin_guardrail'
  | 'competitor_undercut'
  | 'market_match'
  | 'premium_brand'
  | 'velocity_demand';

export type PricingUrgency = 'critical' | 'warning' | 'opportunity' | 'optimal';

export type PricingDriver =
  | 'cogs_increase'
  | 'cogs_decrease'
  | 'competitor_undercut'
  | 'competitor_stockout'
  | 'market_premium'
  | 'velocity_surge';

export interface PriceAdjustmentSuggestion {
  id: string;
  productId: string;
  productName: string;
  unit: string;
  currentCost: number;
  previousCost: number;
  costChangePercent: number;
  currentPrice: number;
  currentWholesalePrice: number;
  currentMarginPercent: number;
  suggestedPrice: number;
  suggestedWholesalePrice: number;
  suggestedMarginPercent: number;
  priceChangeDelta: number;
  priceChangePercent: number;
  urgency: PricingUrgency;
  primaryDriver: PricingDriver;
  reasoning: string;
  ruleApplied: string;
  competitorMetrics: {
    minPrice: number;
    avgPrice: number;
    maxPrice: number;
    cheapestCompetitor: string;
    inStockCompetitorsCount: number;
    totalCompetitorsCount: number;
  };
  confidence: number;
}

export interface PricingEngineSettings {
  targetRetailMargin: number; // e.g. 25 (%)
  minAllowedMargin: number; // e.g. 15 (%)
  wholesaleDiscountPercent: number; // e.g. 10 (%)
  maxPriceChangeStepPercent: number; // e.g. 20 (%)
  activeStrategy: PricingStrategy;
  roundingRule: 'none' | 'nearest_0.50' | 'nearest_1.00' | 'nearest_5.00' | 'charm_99';
  undercutMarginPercent: number; // e.g. 2 (%) below cheapest in-stock competitor
}

export interface TaxTier {
  id: string;
  name: string; // e.g., "Standard VAT", "Reduced / Food Staples", "Zero-Rated / Exempt"
  code: string; // e.g., "VAT-15", "RED-5", "EXEMPT-0", "TOT-10", "LUX-20"
  rate: number; // percentage, e.g. 15, 5, 0, 10, 20
  description?: string;
  isDefault?: boolean;
  isExempt?: boolean;
}

export type TaxCalculationMethod = 'exclusive' | 'inclusive';

export interface TaxSettings {
  enabled: boolean;
  calculationMethod: TaxCalculationMethod;
  defaultTierId: string;
  taxLabel: string; // e.g. "VAT", "Sales Tax", "TOT"
  taxIdentificationNumber: string; // e.g. "TIN-00941829-ET"
  registeredBusinessName?: string;
  roundPerItem: boolean;
  tiers: TaxTier[];
}

export interface CartItem {
  pid: string;
  name: string;
  qty: number;
  price: number;
  mode: SaleMode;
  buy: number;
  taxTierId?: string;
  taxRate?: number;
  taxAmount?: number;
  taxCode?: string;
}

export interface SaleItem {
  pid: string;
  name: string;
  qty: number;
  price: number;
  buy: number;
  mode: SaleMode;
  taxTierId?: string;
  taxRate?: number;
  taxAmount?: number;
  taxCode?: string;
}

export interface SaleTaxTierSummary {
  tierId: string;
  tierName: string;
  code: string;
  rate: number;
  taxableAmount: number;
  taxAmount: number;
  itemCount: number;
}

export interface Sale {
  id: string;
  invoice: string;
  date: string;
  time: string;
  items: SaleItem[];
  subtotal: number;
  discount: number;
  taxableAmount?: number;
  taxAmount?: number;
  taxCalculationMethod?: TaxCalculationMethod;
  taxSummary?: SaleTaxTierSummary[];
  total: number;
  profit: number;
  payment: PaymentMethod;
  customerId: string;
  customer: string;
  mode: SaleMode;
}

export type SupplierStatus = 'Active' | 'Under Review' | 'At Risk';

export interface Supplier {
  id: string;
  name: string;
  phone?: string;
  contactPerson?: string;
  category?: string;
  leadTimeDays?: number;
  reliabilityScore?: number; // 0-100
  notes?: string;
  status?: SupplierStatus;
}

export interface Purchase {
  id: string;
  number: string;
  date: string;
  supplier: string;
  phone?: string;
  productId: string;
  product: string;
  qty: number;
  unitCost: number;
  total: number;
  payment: PaymentMethod;
  note?: string;
}

export interface SupplierPayment {
  id: string;
  date: string;
  supplier: string;
  amount: number;
  account: 'Cash' | 'Bank' | 'Mobile Money';
}

export type CustomerType =
  | 'b2b_kiosk'
  | 'b2b_supermarket'
  | 'b2b_hotel_restaurant'
  | 'b2b_wholesaler'
  | 'individual';

export interface Customer {
  id: string;
  name: string;
  phone?: string;
  location?: string;
  credit: number;
  date?: string;
  limit?: number;
  customerType?: CustomerType;
  tinNumber?: string;
  paymentTerms?: string; // e.g. 'Cash on Delivery', 'Net 15', 'Net 30'
  contactPerson?: string;
}

export interface DistributionOrder {
  id: string;
  number: string;
  date: string;
  customerId: string;
  customer: string;
  driver?: string;
  route?: string;
  vehiclePlate?: string;
  productId: string;
  product: string;
  qty: number;
  unitPrice: number;
  fee: number;
  total: number;
  paid: number;
  balance: number;
  payment: PaymentMethod;
  status: OrderStatus;
  mode?: SaleMode;
  deposit?: number;
  deliveryDate?: string;
  note?: string;
}

export interface CapitalSpending {
  id: string;
  date: string;
  category: 'Stock' | 'Equipment' | 'Shop setup' | 'Rent' | 'Transport' | string;
  amount: number;
  note?: string;
}

export interface Expense {
  id: string;
  name: string;
  title?: string;
  category?: string;
  amount: number;
  account: 'Cash' | 'Bank' | 'Mobile Money' | string;
  date: string;
}

export interface Goal {
  id: string;
  title: string;
  text?: string;
  category?: string;
  completed?: boolean;
  target: number;
  done: number;
}

export interface SystemUser {
  id: string;
  name: string;
  role: string;
  badgeColor?: string;
  pin?: string;
  email?: string;
  phone?: string;
  permissions?: string[];
  status?: 'active' | 'suspended' | 'inactive' | 'on_leave';
  webAuthnCredentialId?: string;
}

export interface BusinessProfile {
  storeName: string;
  registeredBusinessName: string;
  ceoName: string;
  ceoTitle: string;
  ceoEmail: string;
  ceoPhone: string;
  tinNumber: string;
  address: string;
  currency: string;
  initialCapital: number;
  missionTarget: number;
}

export type WarehouseType =
  | 'store'
  | 'warehouse'
  | 'outlet'
  | 'storefront'
  | 'cold_storage'
  | 'distribution_hub';

export interface WarehouseLocation {
  id: string;
  name: string;
  code: string;
  type: WarehouseType;
  address: string;
  manager: string;
  capacityUnits: number;
  phone: string;
  status: 'active' | 'maintenance' | 'inactive';
  currentUtilizationPct?: number;
  isActive?: boolean;
}

export interface StockTransfer {
  id: string;
  date: string;
  time: string;
  fromLocationId: string;
  fromLocationName: string;
  toLocationId: string;
  toLocationName: string;
  productId: string;
  productName: string;
  qty: number;
  transferredBy: string;
  notes?: string;
  status: 'completed' | 'in_transit' | 'pending';
}

export type ActivityCategory =
  | 'high_value_transaction'
  | 'inventory_adjustment'
  | 'financial_ledger'
  | 'price_adjustment'
  | 'competitor_intel'
  | 'market_intel'
  | 'tax_settings'
  | 'sale'
  | 'purchase'
  | 'distribution'
  | 'payment'
  | 'expense'
  | 'ceo_note'
  | 'system'
  | 'general';

export interface ActivityLog {
  id: string;
  date: string;
  time: string;
  timestamp?: string; // ISO-8601 string or full timestamp
  action: string;
  detail: string;
  userId?: string;
  userName?: string;
  userRole?: string;
  category?: ActivityCategory;
  amount?: number;
  isHighValue?: boolean;
  productName?: string;
  productId?: string;
  adjustmentQty?: number;
  adjustmentType?: 'increase' | 'decrease';
  previousStock?: number;
  newStock?: number;
  reason?: string;
  referenceId?: string;
  unit?: string;
  verifiedByPin?: boolean;
  authorizedByUserId?: string;
  authorizedByUserName?: string;
  authorizedByUserRole?: string;
  auditNote?: string;
}

export interface Accounts {
  Cash: number;
  Bank: number;
  'Mobile Money': number;
}

export interface Shift {
  id: string;
  userId: string;
  userName: string;
  date: string; // YYYY-MM-DD
  startTime: string; // HH:mm
  endTime: string; // HH:mm
  role: string;
  notes?: string;
}

export interface DailyActionItem {
  id: string;
  text: string;
  done: boolean;
  impact: 'high' | 'medium' | 'growth';
  assignedTo?: string;
  category?: string;
}

export interface DbState {
  capital: number;
  target: number;
  dailySalesTarget?: number;
  dailyTargets?: Record<string, number>;
  dailyActionFocus?: Record<string, DailyActionItem[]>;
  products: Product[];
  sales: Sale[];
  purchases: Purchase[];
  supplierPayments: SupplierPayment[];
  expenses: Expense[];
  customers: Customer[];
  orders: DistributionOrder[];
  capitalSpending: CapitalSpending[];
  accounts: Accounts;
  goals: Goal[];
  checks: Record<string, boolean[]>;
  activity: ActivityLog[];
  competitorQuotes?: CompetitorQuote[];
  pricingSettings?: PricingEngineSettings;
  taxSettings?: TaxSettings;
  shifts?: Shift[];
  suppliers?: Supplier[];
  warehouses?: WarehouseLocation[];
  transfers?: StockTransfer[];
}

export interface Totals {
  rev: number;
  gross: number;
  exp: number;
  net: number;
  debt: number;
  supplierDebt: number;
  stock: number;
  value: number;
  cash: number;
  workingCapital: number;
  capitalSpent: number;
  capitalRemaining: number;
}

export interface StockMetrics {
  sold: number;
  purchased: number;
  stockValue: number;
  margin: number;
  health: 'out' | 'low' | 'good';
  reorder: number;
  recentSalesVelocity: number; // units sold per day over recent window (e.g. 7 days)
  dynamicSafetyThreshold: number; // dynamic safety stock based on sales velocity and lead buffer
  isBelowSafetyStock: boolean; // stock <= dynamicSafetyThreshold
  isVelocityTriggered: boolean; // stock <= dynamicSafetyThreshold && stock > p.min
  daysOfCover: number; // stock / dailyVelocity (days before stockout)
}

export type DashboardWidgetId =
  | 'revenue_velocity'
  | 'financial_kpis'
  | 'daily_performance'
  | 'liquidity_accounts'
  | 'inventory_health'
  | 'capital_tracking'
  | 'ceo_alerts'
  | 'ai_insights'
  | 'daily_checklist'
  | 'quick_actions'
  | 'financial_pulse';

export interface DashboardWidgetConfig {
  id: DashboardWidgetId;
  title: string;
  subtitle: string;
  category: 'financial' | 'inventory' | 'operations' | 'strategy';
  isPinned: boolean;
  isVisible: boolean;
  order: number;
}

