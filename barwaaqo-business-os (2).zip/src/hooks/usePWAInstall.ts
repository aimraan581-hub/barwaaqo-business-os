import { useEffect, useState, useCallback } from 'react';
import { checkStoragePersistence, requestStoragePersistence, StorageStatus } from '../utils/storagePersistence';

interface BeforeInstallPromptEvent extends Event {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: 'accepted' | 'dismissed'; platform: string }>;
}

export function usePWAInstall() {
  const [deferredPrompt, setDeferredPrompt] = useState<BeforeInstallPromptEvent | null>(null);
  const [isInstalled, setIsInstalled] = useState(false);
  const [isAndroid, setIsAndroid] = useState(false);
  const [isIOS, setIsIOS] = useState(false);
  const [isDesktop, setIsDesktop] = useState(false);
  const [storageStatus, setStorageStatus] = useState<StorageStatus>({
    isSupported: false,
    isPersisted: false,
  });

  const refreshStorage = useCallback(async () => {
    const status = await checkStoragePersistence();
    setStorageStatus(status);
  }, []);

  useEffect(() => {
    // Detect standalone display mode (already installed as APK or PWA)
    const isStandalone =
      window.matchMedia('(display-mode: standalone)').matches ||
      (window.navigator as unknown as { standalone?: boolean }).standalone === true;
    setIsInstalled(isStandalone);

    // Platform detection
    const userAgent = window.navigator.userAgent.toLowerCase();
    const isAndroidDevice = /android/.test(userAgent);
    const isIOSDevice = /iphone|ipad|ipod/.test(userAgent);
    setIsAndroid(isAndroidDevice);
    setIsIOS(isIOSDevice);
    setIsDesktop(!isAndroidDevice && !isIOSDevice);

    const handleBeforeInstallPrompt = (e: Event) => {
      e.preventDefault();
      setDeferredPrompt(e as BeforeInstallPromptEvent);
    };

    const handleAppInstalled = () => {
      setIsInstalled(true);
      setDeferredPrompt(null);
    };

    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    window.addEventListener('appinstalled', handleAppInstalled);

    // Check storage persistence and auto-request if possible
    refreshStorage();
    if (typeof navigator !== 'undefined' && navigator?.storage?.persist) {
      navigator.storage.persist().then(() => {
        refreshStorage();
      }).catch(() => {});
    }

    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
      window.removeEventListener('appinstalled', handleAppInstalled);
    };
  }, [refreshStorage]);

  const install = async (): Promise<boolean> => {
    if (!deferredPrompt) return false;
    await deferredPrompt.prompt();
    const { outcome } = await deferredPrompt.userChoice;
    if (outcome === 'accepted') {
      setIsInstalled(true);
      setDeferredPrompt(null);
      return true;
    }
    return false;
  };

  const enablePermanentStorage = async (): Promise<boolean> => {
    const granted = await requestStoragePersistence();
    await refreshStorage();
    return granted;
  };

  return {
    isInstallable: !!deferredPrompt,
    isInstalled,
    isAndroid,
    isIOS,
    isDesktop,
    storageStatus,
    install,
    enablePermanentStorage,
    refreshStorage,
  };
}
