package com.barwaaqo.businessos;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
