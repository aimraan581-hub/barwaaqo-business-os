# BARWAAQO Business OS — Standalone Android & Google Play AAB (.aab) Build Guide

This project is now fully configured as a **Standalone Native Android Application** with standard Gradle and Android Studio support, ready to produce **Android App Bundles (`.aab`)** for the Google Play Store or APKs for direct sideloading.

---

## 📱 Project Specifications
- **Package ID / Application ID**: `com.barwaaqo.businessos`
- **App Name**: `BARWAAQO Business OS`
- **Native Android Directory**: `/android`
- **Engine**: Capacitor Native Android Bridge + Offline-first PWA Engine
- **Target SDK**: Latest Android (API 34+)
- **Hardware & Permissions Configured**:
  - `INTERNET` & `ACCESS_NETWORK_STATE` (Cloud sync & AI endpoints)
  - `CAMERA` (Instant POS & Inventory barcode / QR scanner)
  - `VIBRATE` (Haptic feedback for POS transactions & scans)

---

## 🚀 How to Generate the `.aab` (Android App Bundle)

### Method 1: Command Line with Gradle (Fastest)
If you have Java (JDK 17+) and Android SDK installed on your machine:
```bash
# 1. Ensure latest web assets are synced
npm run android:sync

# 2. Enter the android folder
cd android

# 3. Build the signed or unsigned Release App Bundle (.aab)
./gradlew bundleRelease
```
The resulting Google Play bundle will be located at:
`android/app/build/outputs/bundle/release/app-release.aab`

For a standalone debug APK for testing on physical Android devices:
```bash
./gradlew assembleDebug
```
Output: `android/app/build/outputs/apk/debug/app-debug.apk`

---

### Method 2: Android Studio (GUI)
1. In AI Studio, click **Settings > Export to GitHub** or **Download as ZIP**.
2. Open **Android Studio**.
3. Select **Open an Existing Project** and choose the `android` folder in this repository.
4. Wait for Gradle sync to complete.
5. In the top menu, select:
   **Build > Generate Signed Bundle / APK...**
6. Select **Android App Bundle (.aab)** and click **Next**.
7. Provide your Google Play keystore (or click *Create new...* if generating your first key).
8. Select `release` build variant and click **Finish**.
9. Android Studio will produce your verified `.aab` ready for the Google Play Console!

---

### Method 3: Cloud 1-Click via PWABuilder (No Android Studio required)
Because BARWAAQO has a PWA manifest with maskable icons, you can generate an `.aab` in 60 seconds online:
1. Open [PWABuilder.com](https://www.pwabuilder.com)
2. Enter your live app URL:
   `https://ais-pre-7zxghfj4nvlqrbhtgd2fzo-336179362284.europe-west2.run.app`
3. Click **Package For Stores** -> **Android**.
4. Click **Download Package** or **Generate Digital Asset Links**.
5. PWABuilder will automatically compile an `.aab` package with your signing keys ready to upload directly to Google Play.

---

### Method 4: Google's Official Bubblewrap CLI
We have also generated `twa-manifest.json` in the root folder:
```bash
npm install -g @bubblewrap/cli
bubblewrap build
```

---

## 🔄 Keeping Android Assets in Sync
Whenever you modify the web interface or add features:
```bash
npm run android:sync
```
This builds the Vite distribution and copies all static assets into `android/app/src/main/assets/public/`.
