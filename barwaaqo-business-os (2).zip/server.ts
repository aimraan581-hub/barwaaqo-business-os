import "dotenv/config";
import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";

interface PulseCacheEntry {
  analysis: string;
  source: 'gemini' | 'engine';
  model?: string;
  timestamp: number;
  hash: string;
}

let pulseCache: PulseCacheEntry | null = null;
const CACHE_TTL_MS = 15 * 60 * 1000; // 15 minutes cache to preserve system bandwidth
let quotaCooldownUntil = 0; // Cooldown timer when 429 / quota limit is encountered

function withTimeout<T>(promise: Promise<T>, timeoutMs: number): Promise<T> {
  return Promise.race([
    promise,
    new Promise<T>((_, reject) =>
      setTimeout(() => reject(new Error(`Operation timed out after ${timeoutMs}ms`)), timeoutMs)
    ),
  ]);
}

function generateDeterministicPulse(data: any): string {
  const rev = Number(data.totalRevenue) || 0;
  const net = Number(data.totalNetProfit) || 0;
  const capital = Number(data.capital) || 0;
  const inventory = Number(data.inventoryValue) || 0;
  const salesCount = Number(data.salesCount) || 0;
  const debt = Number(data.customerDebt) || 0;
  const marginPct = rev > 0 ? ((net / rev) * 100).toFixed(1) : '0.0';
  const invRatio = capital > 0 ? ((inventory / capital) * 100).toFixed(0) : '0';

  let marginHealth = 'stable operational margins';
  if (Number(marginPct) >= 20) {
    marginHealth = `commanding net profitability at ${marginPct}%, well above standard retail benchmarks`;
  } else if (Number(marginPct) > 10) {
    marginHealth = `healthy net profitability of ${marginPct}% with balanced operating overhead`;
  } else {
    marginHealth = `compressed net margins at ${marginPct}%, indicating an immediate need for selective price adjustments or supplier rebates`;
  }

  let inventoryHealth = `inventory capitalization sits at ${invRatio}% of working assets`;
  if (Number(invRatio) > 50) {
    inventoryHealth = `high inventory concentration (${invRatio}% of working capital) warrants targeted clearance of slower-moving stock to free cash reserves`;
  } else {
    inventoryHealth = `inventory levels remain lean and responsive at ${invRatio}% of capital reserves`;
  }

  let debtComment = '';
  if (debt > 5000) {
    debtComment = ` Outstanding customer credit stands at ETB ${debt.toLocaleString()}; expedite account reconciliation to prevent cash lockup.`;
  }

  return `Executive Financial Summary: Pacing at ETB ${rev.toLocaleString()} in gross revenue across ${salesCount} recorded transactions, the enterprise exhibits ${marginHealth}. Currently, ${inventoryHealth}. Liquidity remains sufficient to service ongoing vendor liabilities; prioritize prompt collection of commercial receivables to preserve operating cashflow momentum.${debtComment}`;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // API Route: Financial Pulse with Gemini AI & Quota Guard
  app.post("/api/financial-pulse", async (req, res) => {
    const { summaryData, forceRefresh } = req.body || {};
    const dataHash = JSON.stringify(summaryData || {});
    const now = Date.now();

    // Check in-memory cache if not explicitly forced
    if (!forceRefresh && pulseCache && now - pulseCache.timestamp < CACHE_TTL_MS && pulseCache.hash === dataHash) {
      return res.json({
        analysis: pulseCache.analysis,
        source: pulseCache.source,
        model: pulseCache.model,
        cached: true,
        cachedAt: pulseCache.timestamp,
      });
    }

    const apiKey = process.env.GEMINI_API_KEY;
    const isCoolingDown = now < quotaCooldownUntil;

    if (!apiKey || isCoolingDown) {
      const fallbackAnalysis = generateDeterministicPulse(summaryData || {});
      pulseCache = {
        analysis: fallbackAnalysis,
        source: 'engine',
        timestamp: now,
        hash: dataHash,
      };
      return res.json({
        analysis: fallbackAnalysis,
        source: "engine",
        note: isCoolingDown ? "AI Quota Guard Active." : "API Key not configured.",
        cached: false,
      });
    }

    // Candidate model per user instructions
    const candidateModels = ["gemini-3.6-flash"];

    for (const model of candidateModels) {
      try {
        const ai = new GoogleGenAI({ apiKey });
        const prompt = `You are a Chief Financial Officer (CFO) advising the CEO of IMRUU Enterprise Grocery OS. 
Analyze the following financial snapshot and provide a concise, high-impact 3-sentence 'Financial Pulse' briefing. 
Evaluate:
1. Topline revenue and transaction velocity.
2. Net profit margin health.
3. Working capital and inventory allocation.

Use ETB currency. Be direct, authoritative, and concise.

Financial Snapshot:
${JSON.stringify(summaryData, null, 2)}
`;

        const response = await withTimeout(
          ai.models.generateContent({
            model,
            contents: prompt,
          }),
          8000
        );

        if (response?.text) {
          const analysisText = response.text.trim();
          pulseCache = {
            analysis: analysisText,
            source: 'gemini',
            model,
            timestamp: now,
            hash: dataHash,
          };

          return res.json({
            analysis: analysisText,
            source: "gemini",
            model,
            cached: false,
          });
        }
      } catch (err: any) {
        // Quota exhaustion detection: activate silent cooldown to prevent server logs and error cascades
        const isQuota =
          err?.status === 429 ||
          err?.message?.includes("429") ||
          err?.message?.includes("quota") ||
          err?.message?.includes("RESOURCE_EXHAUSTED");

        if (isQuota) {
          quotaCooldownUntil = Date.now() + 10 * 60 * 1000; // 10 minutes quiet cooldown
        }
      }
    }

    // Gracefully deliver Enterprise Financial Engine pulse
    const fallbackAnalysis = generateDeterministicPulse(summaryData || {});
    pulseCache = {
      analysis: fallbackAnalysis,
      source: 'engine',
      timestamp: now,
      hash: dataHash,
    };

    return res.json({
      analysis: fallbackAnalysis,
      source: "engine",
      note: "Financial Engine active.",
      cached: false,
    });
  });

  // Health endpoint
  app.get("/api/health", (_req, res) => {
    res.json({ status: "ok", timestamp: Date.now() });
  });

  // Direct Project ZIP Download endpoint
  app.get("/api/download-zip", (_req, res) => {
    const zipPath = path.join(process.cwd(), "public", "barwaaqo-business-os.zip");
    res.download(zipPath, "barwaaqo-business-os.zip", (err) => {
      if (err) {
        res.status(500).json({ error: "Failed to download zip", message: (err as Error).message });
      }
    });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: {
        middlewareMode: true,
        hmr: false,
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
