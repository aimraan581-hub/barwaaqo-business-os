# AGENTS.md — Developer & AI Agent Guidelines

## Project Overview
**BARWAAQO Business OS** is an Enterprise Grocery & Distribution Management OS providing a CEO Command Center, real-time Point of Sale (POS), stock inventory control, distribution order routing, multi-tier tax reporting, vendor reliability tracking, and financial intelligence.

---

## Tech Stack & Architecture
- **Client**: React 19, TypeScript, Vite, Tailwind CSS v4, `motion` (animations), Lucide React (icons).
- **PWA & Offline**: `vite-plugin-pwa` service worker with full offline capabilities and local storage persistence.
- **Server**: Express.js server (`server.ts`) running on port 3000 handling server-side API endpoints.
- **AI Integration**: Google GenAI SDK (`@google/genai`) on the server proxying requests to `gemini-3.6-flash`.

---

## Core Operational Rules & Guidelines

### 1. AI & Server-Side Integration
- All Gemini API interactions must run on the server (`server.ts`) via `/api/*` endpoints. Never expose API keys to the browser.
- Use model `gemini-3.6-flash`.
- Always guard against rate limits (`429 RESOURCE_EXHAUSTED`). Avoid polling AI endpoints automatically on every minor state change (e.g. per item added to cart or per sale); prefer user-initiated actions or throttled initial load.
- Suppress raw 429 quota exceptions from triggering server crashes and return clear, actionable user messages.

### 2. State & Data Persistence
- Core business data (inventory, sales, ledger transactions, suppliers, users, tax settings) is managed via `StoreContext.tsx` with offline local storage persistence.
- When working offline, notify the user with non-intrusive indicators/toasts that real-time AI calculations are utilizing cached metrics.

### 3. UI & Design System
- **Theme**: Executive dark emerald palette (`#03170f`, `#064229`, `#085a37`) paired with crisp slate backgrounds (`bg-slate-100/90`) and amber accents for executive badges and highlights.
- **Icons**: Use `lucide-react` exclusively. Do not create inline raw SVG icons.
- **Responsiveness**: Ensure touch-friendly controls (minimum 44px touch targets) on mobile devices alongside dense, productive desktop layouts.

### 4. Code Quality & Verification
- Strict TypeScript checks (`tsc --noEmit`) must pass on every change.
- Keep helper utilities and business logic modular in `src/utils/` and components organized inside `src/components/` and `src/views/`.
